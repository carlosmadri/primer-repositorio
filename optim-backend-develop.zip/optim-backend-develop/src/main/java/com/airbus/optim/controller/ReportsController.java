package com.airbus.optim.controller;

import com.airbus.optim.service.ReportsEmployeeService;
import com.airbus.optim.service.ReportsJobRequestService;
import com.airbus.optim.service.ReportsSubcontractingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("reports")
public class ReportsController {

    @Autowired
    private ReportsEmployeeService reportsEmployeeService;
    @Autowired
    private ReportsJobRequestService reportsJobRequestService;
    @Autowired
    private ReportsSubcontractingService reportsSubcontractingService;

    @GetMapping("/employee-workforce")
    public ResponseEntity<byte[]> getReportFromEmployee(
            @RequestParam MultiValueMap<String, String> params,
            @RequestParam Integer yearFilter) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDisposition(ContentDisposition.builder("attachment")
                .filename("EmployeeWorkforceReport.xlsx")
                .build());

        return new ResponseEntity<>(
                reportsEmployeeService.getReportFromEmployeeeWorkforce(params, yearFilter),
                headers,
                HttpStatus.OK);
    }

    @GetMapping("/siglum3-end-of-year")
    public ResponseEntity<byte[]> getReportSiglum3EndOfYear(
            @RequestParam MultiValueMap<String, String> params,
            @RequestParam Integer yearFilter) {

        byte[] reportContent = reportsEmployeeService.getReportSiglum3EndOfYear(params, yearFilter);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDisposition(ContentDisposition.builder("attachment")
                .filename("EmployeeSiglum3Report.xlsx")
                .build());

        return ResponseEntity.ok()
                .headers(headers)
                .body(reportContent);
    }

    @GetMapping("/siglum4-end-of-year")
    public ResponseEntity<byte[]> getReportSiglum4EndOfYear(
            @RequestParam MultiValueMap<String, String> params,
            @RequestParam Integer yearFilter) {

        byte[] reportContent = reportsEmployeeService.getReportSiglum4EndOfYear(params, yearFilter);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDisposition(ContentDisposition.builder("attachment")
                .filename("EmployeeSiglum4Report.xlsx")
                .build());

        return ResponseEntity.ok()
                .headers(headers)
                .body(reportContent);
    }

    @GetMapping("/siglum5-end-of-year")
    public ResponseEntity<byte[]> getReportSiglum5EndOfYear(
            @RequestParam MultiValueMap<String, String> params,
            @RequestParam Integer yearFilter) {

        byte[] reportContent = reportsEmployeeService.getReportSiglum5EndOfYear(params, yearFilter);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDisposition(ContentDisposition.builder("attachment")
                .filename("EmployeeSiglum5Report.xlsx")
                .build());

        return ResponseEntity.ok()
                .headers(headers)
                .body(reportContent);
    }

    @GetMapping("/site-end-of-year")
    public ResponseEntity<byte[]> getReportSiteEndOfYear(
            @RequestParam MultiValueMap<String, String> params,
            @RequestParam Integer yearFilter) {

        byte[] reportBytes = reportsEmployeeService.getReportSiteEndOfYear(params, yearFilter);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "EmployeeSiteReport.xls");

        return new ResponseEntity<>(reportBytes, headers, HttpStatus.OK);
    }

    @GetMapping("/employees-end-of-year")
    public ResponseEntity<byte[]> getReportEmployeesEndOfYear(
            @RequestParam MultiValueMap<String, String> params,
            @RequestParam Integer yearFilter) {

        byte[] reportContent;
        try {
            reportContent = reportsEmployeeService.getReportEmployeesEndOfYear(params, yearFilter);
            if (reportContent == null) {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDisposition(ContentDisposition.builder("attachment")
                .filename("EmployeeReport.xlsx")
                .build());

        return ResponseEntity.ok()
                .headers(headers)
                .body(reportContent);
    }

    @GetMapping("/jobRequest-closed")
    public ResponseEntity<byte[]> getReportJobRequestClosed(
            @RequestParam MultiValueMap<String, String> params,
            @RequestParam Integer yearFilter) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "JobRequestClosedReport.xlsx");

        return new ResponseEntity<>(
                reportsJobRequestService.getReportJobRequestClosed(params, yearFilter),
                headers,
                HttpStatus.OK);
    }

    @GetMapping("/jobRequest-by-status")
    public ResponseEntity<byte[]> getReportJobRerquestByStatus(
            @RequestParam MultiValueMap<String, String> params,
            @RequestParam Integer yearFilter) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "JobRequestStatusReport.xlsx");

        return new ResponseEntity<>(
                reportsJobRequestService.getReportJobRerquestByStatus(params, yearFilter),
                headers,
                HttpStatus.OK);
    }

    @GetMapping("/subcontracting-table")
    public ResponseEntity<byte[]> getReportSubcontractingTable(
            @RequestParam MultiValueMap<String, String> params) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "SubcontractingReport.xlsx");

        return new ResponseEntity<>(
                reportsSubcontractingService.getReportSubcontractingTable(params),
                headers,
                HttpStatus.OK);
    }
}
