package com.airbus.optim.service;

import com.airbus.optim.dto.subcontractingDto.SubcontractingDataDTO;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class ReportsSubcontractingService {

    @Autowired
    private PurchaseOrdersService purchaseOrdersService;

    public byte[] getReportSubcontractingTable(MultiValueMap<String, String> params) {

        Workbook workbook = new XSSFWorkbook();

        try {
            PageRequest pageRequest = PageRequest.of(0, 1000, Sort.by(Sort.Direction.DESC, "id"));
            List<SubcontractingDataDTO> subcontractingDataList = purchaseOrdersService.getSubcontractingTable(params, pageRequest).getContent();

            Sheet sheet = workbook.createSheet("Subcontracting Table");

            CellStyle headerStyleBase = workbook.createCellStyle();
            headerStyleBase.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
            headerStyleBase.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyleBase.setBorderBottom(BorderStyle.THIN);
            headerStyleBase.setBorderTop(BorderStyle.THIN);
            headerStyleBase.setBorderLeft(BorderStyle.THIN);
            headerStyleBase.setBorderRight(BorderStyle.THIN);
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyleBase.setFont(headerFont);

            CellStyle headerStyleLeft = workbook.createCellStyle();
            headerStyleLeft.cloneStyleFrom(headerStyleBase);
            headerStyleLeft.setBorderRight(BorderStyle.NONE);

            CellStyle headerStyleMiddle = workbook.createCellStyle();
            headerStyleMiddle.cloneStyleFrom(headerStyleBase);
            headerStyleMiddle.setBorderLeft(BorderStyle.NONE);
            headerStyleMiddle.setBorderRight(BorderStyle.NONE);

            CellStyle headerStyleRight = workbook.createCellStyle();
            headerStyleRight.cloneStyleFrom(headerStyleBase);
            headerStyleRight.setBorderLeft(BorderStyle.NONE);

            Row headerRow = sheet.createRow(0);
            String[] headers = {
                    "Siglum", "Site", "Description", "Provider", "Approved", "Quarter", "Year",
                    "keur", "OrderRequest", "OrderId", "hmg", "pep"
            };

            for (int i = 0; i < headers.length; i++) {
                String headerText = headers[i] + "    ";
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headerText);
                if (i == 0) {
                    cell.setCellStyle(headerStyleLeft);
                } else if (i == headers.length - 1) {
                    cell.setCellStyle(headerStyleRight);
                } else {
                    cell.setCellStyle(headerStyleMiddle);
                }
            }

            int rowIndex = 1;
            for (SubcontractingDataDTO s : subcontractingDataList) {
                Row row = sheet.createRow(rowIndex);
                row.createCell(0).setCellValue(s.getSiglum());
                row.createCell(1).setCellValue(s.getSite());
                row.createCell(2).setCellValue(s.getDescription());
                row.createCell(3).setCellValue(s.getProvider());
                row.createCell(4).setCellValue("false".equals(s.getApproved()) ? "No" : "Yes");
                row.createCell(5).setCellValue(s.getQuarter());
                row.createCell(6).setCellValue(s.getYear());
                row.createCell(7).setCellValue(s.getKeur());
                row.createCell(8).setCellValue(s.getOrderRequest());
                row.createCell(9).setCellValue(s.getOrderId());
                row.createCell(10).setCellValue(s.getHmg());
                row.createCell(11).setCellValue(s.getPep());
                rowIndex++;
            }

            int lastDataRowIndex = rowIndex - 1;
            int numCols = headers.length;
            for (int r = 1; r <= lastDataRowIndex; r++) {
                Row dataRow = sheet.getRow(r);
                if (dataRow == null) continue;
                for (int c = 0; c < numCols; c++) {
                    Cell cell = dataRow.getCell(c);
                    if (cell == null) continue;
                    CellStyle currentStyle = cell.getCellStyle();
                    CellStyle newStyle = workbook.createCellStyle();
                    if (currentStyle != null) {
                        newStyle.cloneStyleFrom(currentStyle);
                    }
                    if (c == 0) {
                        newStyle.setBorderLeft(BorderStyle.THIN);
                    }
                    if (c == numCols - 1) {
                        newStyle.setBorderRight(BorderStyle.THIN);
                    }
                    if (r == lastDataRowIndex) {
                        newStyle.setBorderBottom(BorderStyle.THIN);
                    }
                    cell.setCellStyle(newStyle);
                }
            }

            for (int cont = 0; cont < headers.length; cont++) {
                sheet.autoSizeColumn(cont);
            }

            try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                workbook.write(bos);
                return bos.toByteArray();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            try {
                workbook.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
