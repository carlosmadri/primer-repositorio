package com.airbus.optim.service;

import com.airbus.optim.entity.JobRequest;
import com.airbus.optim.repository.JobRequestRepository;
import com.airbus.optim.utils.Utils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

@Service
public class ReportsJobRequestService {

    @Autowired
    private JobRequestRepository jobRequestRepository;
    @Autowired
    private Utils utils;

    public byte[] getReportJobRerquestByStatus(
            MultiValueMap<String, String> params,
            Integer yearFilter) {

        // Filtro para solicitudes con estados específicos
        Predicate<JobRequest> statusFilter = jr -> {
            String status = jr.getStatus();
            return "Validation Required".equalsIgnoreCase(status) ||
                    "QMC Approved".equalsIgnoreCase(status) ||
                    "SHRBP/HO T1Q Approved".equalsIgnoreCase(status) ||
                    "COO Approved".equalsIgnoreCase(status);
        };

        return generateExcelReport(params, yearFilter, statusFilter);
    }

    public byte[] getReportJobRequestClosed(
            MultiValueMap<String, String> params,
            Integer yearFilter) {

        // Filtro para solicitudes que no estén cerradas
        Predicate<JobRequest> statusFilter = jr -> !"closed".equalsIgnoreCase(jr.getStatus());

        return generateExcelReport(params, yearFilter, statusFilter);
    }

    private byte[] generateExcelReport(
            MultiValueMap<String, String> params,
            Integer yearFilter,
            Predicate<JobRequest> statusFilter) {

        try (Workbook workbook = new XSSFWorkbook()) {
            // Especificaciones y recuperación de registros
            Specification<JobRequest> spec = utils.buildJobRequestSpecification(params, yearFilter);
            List<JobRequest> jobRequestList = jobRequestRepository.findAll(spec);

            // Aplicar filtro específico
            List<JobRequest> filteredRequests = jobRequestList.stream()
                    .filter(statusFilter)
                    .toList();

            // Crear hoja de Excel
            Sheet sheet = workbook.createSheet("Job Request Snapshot");

            // Configurar estilos
            Map<String, CellStyle> styles = createHeaderStyles(workbook);

            // Definir encabezados
            String[] headers = getReportHeaders();

            // Crear fila de encabezados
            createHeaderRow(sheet, headers, styles);

            // Agregar datos al Excel
            populateDataRows(sheet, filteredRequests, headers.length);

            // Ajustar tamaño de columnas
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // Escribir al archivo y devolver
            try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                workbook.write(bos);
                return bos.toByteArray();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private String[] getReportHeaders() {
        return new String[]{
                "Id", "WorkdayNumber", "Type", "Status", "Description", "Candidate",
                "StartDate", "ReleaseDate", "PostingDate", "External", "EarlyCareer",
                "OnTopHct", "IsCritical", "ActiveWorkforce", "ApprovedQMC",
                "ApprovedSHRBPH1Q", "ApprovedHOCOOHOHRCOO", "ApprovedEmploymentCommitee",
                "SiglumId", "SiglumName", "Direct", "Collar", "CostCenterId", "CostCenterCode"
        };
    }

    private Map<String, CellStyle> createHeaderStyles(Workbook workbook) {
        Map<String, CellStyle> styles = new HashMap<>();

        // Configuración de encabezados base
        CellStyle headerStyleBase = workbook.createCellStyle();
        headerStyleBase.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
        headerStyleBase.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyleBase.setBorderBottom(BorderStyle.THIN);
        headerStyleBase.setBorderTop(BorderStyle.THIN);
        headerStyleBase.setBorderLeft(BorderStyle.THIN);
        headerStyleBase.setBorderRight(BorderStyle.THIN);

        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerStyleBase.setFont(headerFont);

        // Primer columna: conservar borde izquierdo pero quitar el derecho
        CellStyle headerStyleLeft = workbook.createCellStyle();
        headerStyleLeft.cloneStyleFrom(headerStyleBase);
        headerStyleLeft.setBorderRight(BorderStyle.NONE);
        styles.put("left", headerStyleLeft);

        // Columnas intermedias: quitar ambos bordes laterales
        CellStyle headerStyleMiddle = workbook.createCellStyle();
        headerStyleMiddle.cloneStyleFrom(headerStyleBase);
        headerStyleMiddle.setBorderLeft(BorderStyle.NONE);
        headerStyleMiddle.setBorderRight(BorderStyle.NONE);
        styles.put("middle", headerStyleMiddle);

        // Última columna: conservar borde derecho pero quitar el izquierdo
        CellStyle headerStyleRight = workbook.createCellStyle();
        headerStyleRight.cloneStyleFrom(headerStyleBase);
        headerStyleRight.setBorderLeft(BorderStyle.NONE);
        styles.put("right", headerStyleRight);

        return styles;
    }

    private void createHeaderRow(Sheet sheet, String[] headers, Map<String, CellStyle> styles) {
        Row headerRow = sheet.createRow(0);

        for (int i = 0; i < headers.length; i++) {
            // Agregamos cuatro espacios al final de cada título
            String headerText = headers[i] + "    ";
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headerText);

            // Asignar estilos según la posición
            if (i == 0) {
                cell.setCellStyle(styles.get("left"));
            } else if (i == headers.length - 1) {
                cell.setCellStyle(styles.get("right"));
            } else {
                cell.setCellStyle(styles.get("middle"));
            }
        }
    }

    private void populateDataRows(Sheet sheet, List<JobRequest> jobRequests, int numColumns) {
        // Formato de fecha
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy").withZone(ZoneId.systemDefault());

        int rowIndex = 1;
        for (JobRequest jr : jobRequests) {
            Row row = sheet.createRow(rowIndex++);
            populateRowData(row, jr, formatter);
        }

        // Aplicar bordes a todas las filas de datos
        applyDataBorders(sheet, rowIndex - 1, numColumns);
    }

    private void populateRowData(Row row, JobRequest jr, DateTimeFormatter formatter) {
        // Columna 0
        setCellValue(row.createCell(0), jr.getId() != null ? jr.getId() : 0);
        // Columna 1
        setCellValue(row.createCell(1), jr.getWorkdayNumber());
        // Columna 2
        setCellValue(row.createCell(2), jr.getType());
        // Columna 3
        setCellValue(row.createCell(3), jr.getStatus());
        // Columna 4
        setCellValue(row.createCell(4), jr.getDescription());
        // Columna 5
        setCellValue(row.createCell(5), jr.getCandidate());
        // Columna 6
        setCellValue(row.createCell(6), jr.getStartDate() != null ? formatter.format(jr.getStartDate()) : "");
        // Columna 7
        setCellValue(row.createCell(7), jr.getReleaseDate() != null ? formatter.format(jr.getReleaseDate()) : "");
        // Columna 8
        setCellValue(row.createCell(8), jr.getPostingDate() != null ? formatter.format(jr.getPostingDate()) : "");
        // Columna 9 (booleano)
        setCellValue(row.createCell(9), jr.getExternal() != null && jr.getExternal() ? "Yes" : "No");
        // Columna 10 (booleano)
        setCellValue(row.createCell(10), jr.getEarlyCareer() != null && jr.getEarlyCareer() ? "Yes" : "No");
        // Columna 11 (booleano)
        setCellValue(row.createCell(11), jr.getOnTopHct() != null && jr.getOnTopHct() ? "Yes" : "No");
        // Columna 12 (booleano)
        setCellValue(row.createCell(12), jr.getIsCritical() != null && jr.getIsCritical() ? "Yes" : "No");
        // Columna 13
        setCellValue(row.createCell(13), jr.getActiveWorkforce());
        // Columna 14 (booleano)
        setCellValue(row.createCell(14), jr.getApprovedQMC() != null && jr.getApprovedQMC() ? "Yes" : "No");
        // Columna 15 (booleano)
        setCellValue(row.createCell(15), jr.getApprovedSHRBPHOT1Q() != null && jr.getApprovedSHRBPHOT1Q() ? "Yes" : "No");
        // Columna 16 (booleano)
        setCellValue(row.createCell(16), jr.getApprovedHOCOOHOHRCOO() != null && jr.getApprovedHOCOOHOHRCOO() ? "Yes" : "No");
        // Columna 17 (booleano)
        setCellValue(row.createCell(17), jr.getApprovedEmploymentCommitee() != null && jr.getApprovedEmploymentCommitee() ? "Yes" : "No");
        // Columna 18
        setCellValue(row.createCell(18), jr.getSiglum() != null ? jr.getSiglum().getId() : 0);
        // Columna 19
        setCellValue(row.createCell(19), jr.getSiglum() != null ? jr.getSiglum().getSiglum5() : "");
        // Columna 20
        setCellValue(row.createCell(20), jr.getDirect());
        // Columna 21
        setCellValue(row.createCell(21), jr.getCollar());
        // Columna 22
        setCellValue(row.createCell(22), jr.getCostCenter() != null ? jr.getCostCenter().getId() : 0);
        // Columna 23
        setCellValue(row.createCell(23), jr.getCostCenter() != null ? jr.getCostCenter().getCostCenterCode() : "");
    }

    private void setCellValue(Cell cell, Object value) {
        if (value == null) {
            cell.setCellValue("");
        } else if (value instanceof Number) {
            cell.setCellValue(((Number) value).doubleValue());
        } else {
            cell.setCellValue(value.toString());
        }
    }

    private void applyDataBorders(Sheet sheet, int lastDataRowIndex, int numCols) {
        for (int r = 1; r <= lastDataRowIndex; r++) {
            Row dataRow = sheet.getRow(r);
            if (dataRow == null) continue;

            for (int c = 0; c < numCols; c++) {
                Cell cell = dataRow.getCell(c);
                if (cell == null) continue;

                Workbook workbook = sheet.getWorkbook();
                CellStyle newStyle = workbook.createCellStyle();
                CellStyle currentStyle = cell.getCellStyle();

                if (currentStyle != null) {
                    newStyle.cloneStyleFrom(currentStyle);
                }

                if (c == 0) { // Primera columna: borde izquierdo
                    newStyle.setBorderLeft(BorderStyle.THIN);
                }
                if (c == numCols - 1) { // Última columna: borde derecho
                    newStyle.setBorderRight(BorderStyle.THIN);
                }
                if (r == lastDataRowIndex) { // Última fila de datos: borde inferior
                    newStyle.setBorderBottom(BorderStyle.THIN);
                }

                cell.setCellStyle(newStyle);
            }
        }
    }
}