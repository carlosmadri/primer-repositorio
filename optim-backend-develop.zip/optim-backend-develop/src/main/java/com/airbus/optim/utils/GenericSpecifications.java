package com.airbus.optim.utils;

import com.airbus.optim.entity.Siglum;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class GenericSpecifications {

    public static <T> Specification<T> withSiglumIn(List<Siglum> siglums, String siglumFieldName) {
        return (root, query, criteriaBuilder) -> {
            if (siglums == null || siglums.isEmpty()) {
                return criteriaBuilder.conjunction();
            }
            return root.get(siglumFieldName).in(siglums);
        };
    }
}
