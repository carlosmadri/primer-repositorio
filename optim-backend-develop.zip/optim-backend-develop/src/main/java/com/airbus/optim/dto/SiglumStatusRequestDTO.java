package com.airbus.optim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class SiglumStatusRequestDTO {
    List<String> approvedList;
    List<String> rejectedList;
}
