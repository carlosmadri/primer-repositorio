package com.airbus.optim.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

@Service
public class DynamicDataService {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final List<String> PREDEFINED_ACTIVE_WORKFORCE = List.of("AWF", "TEMP");
	private static final List<String> PREDEFINED_COLLAR = List.of("Direct", "BC");
	private static final List<String> PREDEFINED_STATUS = List.of("Validation Required", "On Hold", "QMC Approved",
			"Opened", "Filled");

	private static final List<String> PREDEFINED_TYPE = List.of("Replacement", "Creation", "Conversion");

	private static final List<String> PREDEFINED_DIRECT = List.of("Direct", "Indirect");

	private static final List<String> PREDEFINED_LEVER_TYPE = List.of("Perimeter Change", "Partial Retirement",
			"Parental leave absence", "Temp release", "Other absence leave", "Longterm sickness absence", "Mobilty Out",
			"Shift Change");

	private static final List<String> PREDEFINED_AVAILABILITY_REASON = List.of("Unlimited contract",
			"Parental leave absence", "Regular", "Dormant Contract Home", "Other absence leave");

	private static final List<String> PREDEFINED_CONTRACT_TYPE = List.of("Unlimited", "Temp", "Early Career");

	private static final List<String> PREDEFINED_JOB = List.of("AD Programme/Project Quality Management",
			"Manager & Leader", "Assistant", "Executive Assistance /Support to Mgmt", "Project Management Responsible",
			"Aircraft Quality Line Side", "AD Quality Manager", "AD Engineering Quality Management",
			"Programme Quality Assurance", "End 2 End Operations Quality Assurance",
			"Quality Manufacturing Engineering (QME)");

	public List<String> getDynamicOptions(String fieldName, String tableName, List<String> predefinedValues) {
		String query = "SELECT DISTINCT " + fieldName + " FROM " + tableName + " WHERE " + fieldName + " IS NOT NULL";

		List<String> databaseValues = jdbcTemplate.query(query, (rs, rowNum) -> rs.getString(fieldName));

		return databaseValues.stream().filter(value -> !predefinedValues.contains(value)) // Evitar duplicados
				.collect(Collectors.toCollection(() -> new ArrayList<>(predefinedValues))); // Fusionar listas
	}

	public List<String> getActiveWorkforceOptions() {
		return getDynamicOptions("active_workforce", "job_request", PREDEFINED_ACTIVE_WORKFORCE);
	}

	public List<String> getCollarOptions() {
		return getDynamicOptions("collar", "job_request", PREDEFINED_COLLAR);
	}

	public List<String> getStatusOptions() {
		return getDynamicOptions("status", "job_request", PREDEFINED_STATUS);
	}

	public List<String> getTypeOptions() {
		return getDynamicOptions("type", "job_request", PREDEFINED_TYPE);
	}

	public List<String> getActiveWorkforceOptionsForLevers() {
		return getDynamicOptions("active_workforce", "lever", PREDEFINED_ACTIVE_WORKFORCE);
	}

	public List<String> getDirectOptionsForLevers() {
		return getDynamicOptions("direct", "lever", PREDEFINED_DIRECT);
	}

	public List<String> getLeverTypeOptionsForLevers() {
		return getDynamicOptions("lever_type", "lever", PREDEFINED_LEVER_TYPE);
	}

	public List<String> getAvailabilityReasonOptions() {
		return getDynamicOptions("availability_reason", "employee", PREDEFINED_AVAILABILITY_REASON);
	}

	public List<String> getActiveWorkforceOptionsForEmployees() {
		return getDynamicOptions("active_workforce", "employee", PREDEFINED_ACTIVE_WORKFORCE);
	}

	public List<String> getCollarOptionsForEmployees() {
		return getDynamicOptions("collar", "employee", PREDEFINED_COLLAR);
	}

	public List<String> getDirectOptionsForEmployees() {
		return getDynamicOptions("direct", "employee", PREDEFINED_DIRECT);
	}

	public List<String> getContractTypeOptionsForEmployees() {
		return getDynamicOptions("contract_type", "employee", PREDEFINED_CONTRACT_TYPE);
	}

	public List<String> getJobOptionsForEmployees() {
		return getDynamicOptions("job", "employee", PREDEFINED_JOB);
	}
}
