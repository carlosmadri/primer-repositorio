package com.airbus.optim.repository;

import com.airbus.optim.entity.WorkloadSnapshot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WorkloadSnapshotRepository extends JpaRepository<WorkloadSnapshot, Long> {
}
