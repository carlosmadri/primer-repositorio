package com.airbus.optim.service;

import com.airbus.optim.dto.LocationFteSumDTO;
import com.airbus.optim.entity.Location;
import com.airbus.optim.entity.CostCenter;
import com.airbus.optim.entity.Employee;
import com.airbus.optim.repository.LocationRepository;
import com.airbus.optim.repository.CostCenterRepository;
import com.airbus.optim.repository.PurchaseOrdersRepository;
import com.airbus.optim.utils.Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class LocationService {

    @Autowired
    private LocationRepository locationRepository;

    @Autowired
    private CostCenterRepository costCenterRepository;

    @Autowired
    private PurchaseOrdersRepository purchaseOrdersRepository;

    @Autowired
    private Utils utils;

    public Location saveOrUpdateLocation(Location location) {
        return locationRepository.save(location);
    }

    public ResponseEntity<Location> updateLocation(Long id, Location locationDetails) {
        Optional<Location> optionalLocation = locationRepository.findById(id);

        if (optionalLocation.isPresent()) {
            Location existingLocation = optionalLocation.get();
            updateLocationFields(existingLocation, locationDetails);

            Location updatedLocation = locationRepository.save(existingLocation);
            return ResponseEntity.ok(updatedLocation);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    private void updateLocationFields(Location existingLocation, Location locationDetails) {
        existingLocation.setCountry(locationDetails.getCountry());
        existingLocation.setSite(locationDetails.getSite());
        existingLocation.setKapisCode(locationDetails.getKapisCode());
    }

    public List<LocationFteSumDTO> getAllLocationsWithFteSum(MultiValueMap<String, String> params) {
        List<Employee> employees = utils.getFilteredEmployees(params);

        Map<String, LocationFteSumDTO> locationMap = new HashMap<>();

        for (Employee employee : employees) {
            CostCenter costCenter = employee.getCostCenter();

            if (costCenter != null && costCenter.getLocation() != null) {
                Location location = costCenter.getLocation();
                Double longitude = location.getLongitude() != null ? location.getLongitude() : 0.0;
                Double latitude = location.getLatitude() != null ? location.getLatitude() : 0.0;

                String key = location.getSite() + location.getCountry() + longitude + latitude;

                if (locationMap.containsKey(key)) {
                    LocationFteSumDTO existingDto = locationMap.get(key);
                    existingDto.setFteSum(existingDto.getFteSum() + (employee.getFTE() != null ? employee.getFTE() : 0.0));
                } else {
                    LocationFteSumDTO newDto = new LocationFteSumDTO(
                            location.getCountry(),
                            location.getSite(),
                            employee.getFTE() != null ? employee.getFTE() : 0.0,
                            longitude,
                            latitude
                    );
                    locationMap.put(key, newDto);
                }
            }
        }

        return new ArrayList<>(locationMap.values());
    }
}