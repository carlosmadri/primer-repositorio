package com.airbus.optim.repository;

import com.airbus.optim.entity.JobRequestSnapshot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the JobRequest entity, exposed as a REST resource.
 */
@Repository
public interface JobRequestSnapshotRepository extends JpaRepository<JobRequestSnapshot, Long>, JpaSpecificationExecutor<JobRequestSnapshot> {
    @Query(value = "SELECT COALESCE(MAX(e.id), 0) + 1 FROM job_request_snapshot e", nativeQuery = true)
    Long findNextAvailableId();
}


