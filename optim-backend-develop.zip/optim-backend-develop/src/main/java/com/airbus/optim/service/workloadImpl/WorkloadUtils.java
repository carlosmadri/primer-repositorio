package com.airbus.optim.service.workloadImpl;

import com.airbus.optim.dto.EvolutionDTO;
import com.airbus.optim.dto.WorkloadFteDTO;
import com.airbus.optim.dto.WorkloadFteKhrsDTO;
import com.airbus.optim.dto.WorkloadMonthlyDistributionDTO;
import com.airbus.optim.entity.Siglum;
import com.airbus.optim.entity.Workload;
import com.airbus.optim.repository.WorkloadEvolutionRepository;
import com.airbus.optim.repository.WorkloadRepository;
import com.airbus.optim.utils.Constants;
import com.airbus.optim.utils.Utils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WorkloadUtils {
    @Autowired
    WorkloadRepository workloadRepository;

    @Autowired
    WorkloadEvolutionRepository workloadEvolutionRepository;

    @Autowired
    private Utils utils;

    public double getBottomup(List<Workload> workloads) {
        return workloads.stream()
                .filter(workload -> (Constants.WORKLOAD_STATUS_BOTTOM_UP.equalsIgnoreCase(workload.getExercise())))
                .mapToDouble(Workload::getKHrs)
                .sum();
    }

    public EvolutionDTO dbBuildWorkloadEvolutionDTO(List<Siglum> siglumList, String exercise, int year) {
        double ownDirectKHrs = 0.0;
        double ownIndirectKHrs = 0.0;
        double subDirectKHrs = 0.0;
        double subIndirectKHrs = 0.0;

        List<Workload> workloadsFiltered = workloadRepository
                .findWorkloads(Constants.WORKLOAD_STATUS_BOTTOM_UP, siglumList).stream()
                .filter(workload -> Constants.WORKLOAD_STATUS_BOTTOM_UP.equalsIgnoreCase(workload.getExercise()))
                .filter(Workload::getGo)
                .collect(Collectors.toList());

        for (Workload employee : workloadsFiltered) {
            LocalDate startDate = convertInstantToLocalDate(employee.getStartDate());
            LocalDate endDate = convertInstantToLocalDate(employee.getEndDate());
            long totalMonths = ChronoUnit.MONTHS.between(startDate.withDayOfMonth(1), endDate.withDayOfMonth(1)) + 1;
            long monthsInYear = 0;
            for (LocalDate date = startDate.withDayOfMonth(1); !date.isAfter(endDate); date = date.plusMonths(1)) {
                if (date.getYear() == year) {
                    monthsInYear++;
                }
            }
            if (monthsInYear == 0 || totalMonths == 0) {
                continue;
            }

            double kHrsPerMonth = employee.getKHrs() / totalMonths;
            double proportionalKHrs = kHrsPerMonth * monthsInYear;

            if (employee.getOwn().equalsIgnoreCase(Constants.WORKLOAD_STATUS_OWN)) {
                if (employee.getDirect().equalsIgnoreCase(Constants.WORKLOAD_STATUS_DIRECT)) {
                    ownDirectKHrs += proportionalKHrs;
                } else if (employee.getDirect().equalsIgnoreCase(Constants.WORKLOAD_STATUS_INDIRECT)) {
                    ownIndirectKHrs += proportionalKHrs;
                }
            } else if (employee.getOwn().equalsIgnoreCase(Constants.WORKLOAD_STATUS_SUB)) {
                if (employee.getDirect().equalsIgnoreCase(Constants.WORKLOAD_STATUS_DIRECT)) {
                    subDirectKHrs += proportionalKHrs;
                } else if (employee.getDirect().equalsIgnoreCase(Constants.WORKLOAD_STATUS_INDIRECT)) {
                    subIndirectKHrs += proportionalKHrs;
                }
            }
        }
        return new EvolutionDTO(
                null,
                exercise, "", "",
                ownDirectKHrs,
                ownIndirectKHrs,
                subDirectKHrs,
                subIndirectKHrs
        );
    }

    public List<Double> fillMontlyDistribution(List<WorkloadMonthlyDistributionDTO> workloadMonthlyDistributionDTOList) {
        Double [] fteList = {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
        for (WorkloadMonthlyDistributionDTO w :workloadMonthlyDistributionDTOList) {
            fteList[w.getMes()-1] = w.getFte();
        }

        return Arrays.asList(fteList);
    }

    public WorkloadFteKhrsDTO fteFromWorkload(List<Workload> workloadList, List<WorkloadFteDTO> workloadFteDTOList, Integer yearFilter) {
        double kHrs = 0.0;
        double fTEs = 0.0;

        for (Workload employee : workloadList) {
            LocalDate startDate = convertInstantToLocalDate(employee.getStartDate());
            LocalDate endDate = convertInstantToLocalDate(employee.getEndDate());

            if (endDate.getDayOfMonth() == 1) {
                endDate = endDate.plusMonths(1).minusDays(1);
            }

            long totalMonths = ChronoUnit.MONTHS.between(startDate.withDayOfMonth(1), endDate.withDayOfMonth(1)) + 1;
            double kHrsPerMonth = employee.getKHrs() / totalMonths;

            double proportionalKHrs = 0.0;

            for (LocalDate date = startDate.withDayOfMonth(1); !date.isAfter(endDate); date = date.plusMonths(1)) {
                if (date.getYear() == yearFilter) {
                    proportionalKHrs += kHrsPerMonth;
                }
            }
            if ("own".equalsIgnoreCase(employee.getOwn()) && !workloadFteDTOList.isEmpty()) {
                WorkloadFteDTO w = workloadFteDTOList.get(0);
                if (w.getEfficiency() != 0) {
                    double fte = proportionalKHrs * 1000 / w.getEfficiency();
                    fTEs += fte;
                }
            }
            kHrs += proportionalKHrs;
        }
        return new WorkloadFteKhrsDTO(kHrs, fTEs);
    }

    private LocalDate convertInstantToLocalDate(Instant instant) {
        LocalDate localDate = instant.atZone(ZoneId.systemDefault()).toLocalDate();
        return localDate;
    }

    public List<Workload> getLastExercise(String statusExercise, List<Workload> workloadList) {
        List<String> latestExercises = Collections.singletonList(statusExercise);
        List<Siglum> siglumFiltered = utils.getVisibleSiglums(null);

        if (Constants.WORKLOAD_EVOLUTION_STATUS_CLOSED.equals(statusExercise)) {
            latestExercises = getLastClosedExercise(siglumFiltered);
        } else if (!Constants.WORKLOAD_STATUS_BOTTOM_UP.equals(statusExercise)) {
            latestExercises = getLastWorkInProgresExercise(siglumFiltered);
        }

        List<Workload> workloadsLast = workloadRepository.findWorkloadsByExerciseAndSiglums(latestExercises, siglumFiltered, workloadList);

        return workloadsLast;
    }

    public List<String> getLastClosedExercise(List<Siglum> siglumFiltered) {
        return new LinkedList<>(workloadEvolutionRepository.findLastClosedExercise());
    }

    public List<Workload> getLastExerciseByYear(String statusExercise, List<Workload> workloadList, Integer yearFilter) {
        List<String> latestExercises = List.of(Constants.WORKLOAD_STATUS_BOTTOM_UP);
        List<Siglum> siglumFiltered = utils.getVisibleSiglums(null);
        latestExercises = (Constants.WORKLOAD_EVOLUTION_STATUS_OPENED.equals(statusExercise) ?
                getLastClosedExerciseByYear(siglumFiltered, yearFilter) : getLastWorkInProgresExercise(siglumFiltered));
        List<Workload> workloadsLast =
                workloadRepository.findWorkloadsByExerciseAndSiglums(latestExercises, siglumFiltered, workloadList);
        return workloadsLast;
    }

    public List<String> getLastClosedExerciseByYear(List<Siglum> siglumFiltered, Integer yearFilter) {
        return new LinkedList<>(workloadEvolutionRepository.findLastClosedExerciseByYear(siglumFiltered, yearFilter));
    }

    public List<String> getLastWorkInProgresExercise(List<Siglum> siglumFiltered) {
        // <> 'closed' and MAX(submit_date)
        return new LinkedList<>(workloadEvolutionRepository.findLastNoClosedExercise(siglumFiltered));
    }

    public List<Long> getIdsFromWorkloadList(List<Workload> workloadList) {
        List<Long> wIds = new ArrayList<>();
        for (Workload w : workloadList) {
            wIds.add(w.getId());
        }
        return wIds;
    }

    public double filterWorkloadByRatio(List<Workload> wL, String ratio) {
        Instant now = Instant.now();
        return wL.stream()
                .filter(workload -> {
                    boolean isBeforeOrEqual = workload.getEndDate().isBefore(now) || workload.getEndDate().equals(now);
                    return isBeforeOrEqual;
                })
                .mapToDouble(Workload::getKHrs)
                .sum();
    }

}
