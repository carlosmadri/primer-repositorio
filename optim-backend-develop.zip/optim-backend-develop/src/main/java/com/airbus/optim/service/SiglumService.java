package com.airbus.optim.service;

import com.airbus.optim.entity.Siglum;
import com.airbus.optim.exception.SiglumHasAssociatedUsersException;
import com.airbus.optim.repository.SiglumRepository;
import com.airbus.optim.utils.Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SiglumService {

    @Autowired
    private SiglumRepository siglumRepository;

    @Autowired
    private Utils utils;

    public Page<Siglum> getAllSiglums(Pageable pageable) {
        return siglumRepository.findAll(pageable);
    }

    public Optional<Siglum> getSiglumById(Long id) {
        return siglumRepository.findById(id);
    }

    public List<Siglum> getVisibleSiglums(String siglumHR) {
        return utils.getVisibleSiglums(siglumHR);
    }

    public boolean deleteSiglum(Long id) {
        Optional<Siglum> siglumOptional = siglumRepository.findById(id);

        if (siglumOptional.isPresent()) {
            Siglum siglum = siglumOptional.get();

            if (!siglum.getUsers().isEmpty()) {
                throw new SiglumHasAssociatedUsersException(id);
            }

            siglumRepository.deleteById(id);
            return true;
        }

        return false;
    }

    public Siglum saveOrUpdateSiglum(Siglum siglum) {
        normalizeToUppercase(siglum);
        validateSiglumHierarchy(siglum);
        return siglumRepository.save(siglum);
    }

    public Optional<Siglum> updateSiglum(Long id, Siglum siglumDetails) {
        Optional<Siglum> optionalSiglum = siglumRepository.findById(id);

        if (optionalSiglum.isPresent()) {
            Siglum existingSiglum = optionalSiglum.get();

            normalizeToUppercase(siglumDetails);
            updateSiglumFields(existingSiglum, siglumDetails);
            validateSiglumHierarchy(existingSiglum);

            return Optional.of(siglumRepository.save(existingSiglum));
        } else {
            return Optional.empty();
        }
    }

    private void updateSiglumFields(Siglum existingSiglum, Siglum siglumDetails) {
        existingSiglum.setSiglumHR(siglumDetails.getSiglumHR());
        existingSiglum.setSiglum6(siglumDetails.getSiglum6());
        existingSiglum.setSiglum5(siglumDetails.getSiglum5());
        existingSiglum.setSiglum4(siglumDetails.getSiglum4());
        existingSiglum.setSiglum3(siglumDetails.getSiglum3());
    }

    private void normalizeToUppercase(Siglum siglum) {
        if (siglum.getSiglum3() != null) {
            siglum.setSiglum3(siglum.getSiglum3().toUpperCase());
        }

        if (siglum.getSiglum4() != null) {
            siglum.setSiglum4(siglum.getSiglum4().toUpperCase());
        }

        if (siglum.getSiglum5() != null) {
            siglum.setSiglum5(siglum.getSiglum5().toUpperCase());
        }

        if (siglum.getSiglum6() != null) {
            siglum.setSiglum6(siglum.getSiglum6().toUpperCase());
        }

        if (siglum.getSiglumHR() != null) {
            siglum.setSiglumHR(siglum.getSiglumHR().toUpperCase());
        }
    }

    private void validateSiglumHierarchy(Siglum siglum) throws IllegalArgumentException {
        if (!isValidHierarchy(siglum.getSiglum3(), siglum.getSiglum4())) {
            throw new IllegalArgumentException("Siglum4 must start with or be equal to Siglum3");
        }

        if (!isValidHierarchy(siglum.getSiglum4(), siglum.getSiglum5())) {
            throw new IllegalArgumentException("Siglum5 must start with or be equal to Siglum4");
        }

        if (!isValidHierarchy(siglum.getSiglum5(), siglum.getSiglum6())) {
            throw new IllegalArgumentException("Siglum6 must start with or be equal to Siglum5");
        }

        if (!isValidHierarchy(siglum.getSiglum6(), siglum.getSiglumHR())) {
            throw new IllegalArgumentException("SiglumHR must start with or be equal to Siglum6");
        }
    }

    private boolean isValidHierarchy(String parent, String child) {
        if (parent == null) {
            return true;
        }

        if (child == null) {
            return false;
        }

        return child.equals(parent) || child.startsWith(parent);
    }
}