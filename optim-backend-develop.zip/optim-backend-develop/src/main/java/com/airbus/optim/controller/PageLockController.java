package com.airbus.optim.controller;

import com.airbus.optim.dto.PageLockResponse;
import com.airbus.optim.service.PageLockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("page-lock")
public class PageLockController {

    @Autowired
    private PageLockService pageLockService;

    @PostMapping("/activate")
    public ResponseEntity<PageLockResponse> activateApplicationLock() {
        try {
            PageLockResponse response = pageLockService.activateApplicationLock();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (SecurityException e) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/deactivate")
    public ResponseEntity<PageLockResponse> deactivateApplicationLock() {
        try {
            PageLockResponse response = pageLockService.deactivateApplicationLock();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (SecurityException e) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/status")
    public ResponseEntity<PageLockResponse> getApplicationLockStatus() {
        PageLockResponse response = pageLockService.getApplicationLockStatus();
        if (response == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}