package com.airbus.optim.repository.projections;

public interface LeverTypeFteSum {
    String getLeverType();
    Double getFteSum();
}

