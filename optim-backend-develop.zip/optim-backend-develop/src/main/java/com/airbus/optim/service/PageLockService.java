package com.airbus.optim.service;

import com.airbus.optim.dto.PageLockResponse;
import com.airbus.optim.entity.PageLock;
import com.airbus.optim.exception.ApplicationLockException;
import com.airbus.optim.repository.PageLockRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

@Service
public class PageLockService {

	private final PageLockRepository pageLockRepository;

	@Autowired
	public PageLockService(PageLockRepository pageLockRepository) {
		this.pageLockRepository = pageLockRepository;
	}

	@Transactional
	public PageLockResponse activateApplicationLock() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String username = authentication.getName();

		validateAdminAccess(authentication);

		Optional<PageLock> latestLock = pageLockRepository.findTopByOrderByLockedAtDesc();
		if (latestLock.isPresent() && latestLock.get().isLocked()) {
			throw new ApplicationLockException(
					"Ya existe un bloqueo activo. Debe desactivarlo antes de crear uno nuevo.");
		}

		return createAndSaveLock(username);
	}

	@Transactional
	public PageLockResponse createAndSaveLock(String username) {
		PageLock pageLock = new PageLock();
		pageLock.setLockId(generateUniqueLockId());
		pageLock.setLockedBy(username);
		pageLock.setLockedAt(LocalDateTime.now());
		pageLock.setUnlockedAt(null);

		pageLock = pageLockRepository.save(pageLock);
		return convertToResponse(pageLock);
	}

	@Transactional
	public PageLockResponse deactivateApplicationLock() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		validateAdminAccess(authentication);

		Optional<PageLock> latestLock = pageLockRepository.findTopByOrderByLockedAtDesc();

		if (!latestLock.isPresent()) {
			throw new ApplicationLockException("No hay ningún bloqueo para desactivar");
		}

		if (!latestLock.get().isLocked()) {
			throw new ApplicationLockException("No hay un bloqueo activo para desactivar");
		}

		PageLock pageLock = latestLock.get();
		pageLock.setUnlockedAt(LocalDateTime.now());
		pageLock = pageLockRepository.save(pageLock);
		return convertToResponse(pageLock);
	}

	private void validateAdminAccess(Authentication authentication) {
		boolean isAdmin = authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority)
				.anyMatch(authority -> authority.equalsIgnoreCase("ADMIN"));

		if (!isAdmin) {
			throw new SecurityException("Solo los administradores pueden bloquear/desbloquear la aplicación");
		}
	}

	public PageLockResponse getApplicationLockStatus() {
		Optional<PageLock> latestLock = pageLockRepository.findTopByOrderByLockedAtDesc();
		return latestLock.map(this::convertToResponse).orElse(new PageLockResponse());
	}

	private PageLockResponse convertToResponse(PageLock pageLock) {
		PageLockResponse response = new PageLockResponse();
		response.setId(pageLock.getId());
		response.setLockId(pageLock.getLockId());
		response.setLockedBy(pageLock.getLockedBy());
		response.setLockedAt(pageLock.getLockedAt());
		response.setUnlockedAt(pageLock.getUnlockedAt());
		response.setLocked(pageLock.isLocked());
		return response;
	}

	private String generateUniqueLockId() {
		long timestamp = System.currentTimeMillis();
		int randomComponent = new Random().nextInt(1000);
		return timestamp + "-" + randomComponent;
	}
}
