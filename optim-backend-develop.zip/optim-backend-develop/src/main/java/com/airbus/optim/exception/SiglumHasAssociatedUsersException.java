package com.airbus.optim.exception;

public class SiglumHasAssociatedUsersException extends RuntimeException {
    public SiglumHasAssociatedUsersException(Long siglumId) {
        super("Cannot delete siglum with ID " + siglumId + " because it has associated users");
    }
}