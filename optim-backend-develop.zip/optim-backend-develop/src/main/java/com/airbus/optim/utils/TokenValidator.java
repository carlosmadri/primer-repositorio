package com.airbus.optim.utils;

import com.airbus.optim.service.UserService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.JwtException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.RSAPublicKeySpec;
import java.time.Instant;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@Component
public class TokenValidator {

    private static final boolean VALIDATE_TOKEN_SOURCE = false;
    private static final String EXPECTED_ISSUER = "https://ssobroker-val.airbus.com:10443";
    private static final String ROLE_USER = "ROLE_USER";
    private static final String CLAIM_SUB = "sub";
    private static final String CLAIM_ISS = "iss";
    private static final String TOKEN_PARTS_SEPARATOR = "\\.";
    private final Environment env;
    private final UserService userService;
    private final JwtDecoder jwtDecoder;
    private final RSAPublicKey publicKey;
    private final Utils utils;


    @Autowired
    public TokenValidator(Environment env, UserService userService, Utils utils) {
        this.env = env;
        this.userService = userService;
        this.utils = utils;

        try {
            if (utils.isValidateWithCertificateEnabled()) {
                this.publicKey = Optional.ofNullable(fetchJWKS())
                        .orElseThrow(() -> new IllegalStateException("Failed to load the public key."));
                this.jwtDecoder = NimbusJwtDecoder.withPublicKey(publicKey).build();
            } else {
                this.publicKey = null;
                this.jwtDecoder = createSimpleJwtDecoder();
            }
        } catch (Exception e) {
            throw new IllegalStateException("Could not initialize TokenValidator", e);
        }
    }

    private JwtDecoder createSimpleJwtDecoder() {
        return token -> {
            try {
                String[] parts = token.split("\\.");
                if (parts.length != 3) {
                    throw new JwtException("Invalid JWT token format");
                }

                String payload = new String(Base64.getUrlDecoder().decode(parts[1]), StandardCharsets.UTF_8);
                Map<String, Object> claims = new ObjectMapper().readValue(payload,
                        new TypeReference<Map<String, Object>>() {
                        });

                return new Jwt(
                        token,
                        Instant.now(),
                        Instant.now().plusSeconds(3600),
                        Map.of("alg", "none", "typ", "JWT"),
                        claims
                );
            } catch (Exception e) {
                throw new JwtException("Error decoding JWT token", e);
            }
        };
    }

    public String getJwksUrl() {
        return Optional.ofNullable(env.getProperty("app.jwksUrl"))
                .filter(url -> !url.trim().isEmpty())
                .orElse("URL no definida");
    }

    private RSAPublicKey fetchJWKS() {
        if (!utils.isValidateWithCertificateEnabled()) {
            return null;
        }

        try {
            var url = new URL(getJwksUrl());
            var conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            var reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            var response = reader.lines().reduce("", String::concat);
            reader.close();

            var jwksJson = new JSONObject(response);
            var keys = jwksJson.getJSONArray("keys");

            var key = Optional.ofNullable(keys.isEmpty() ? null : keys.getJSONObject(0))
                    .orElseThrow(() -> new IllegalStateException("No keys found in JWKS."));

            var modulus = new BigInteger(1, Base64.getUrlDecoder().decode(key.getString("n")));
            var exponent = new BigInteger(1, Base64.getUrlDecoder().decode(key.getString("e")));

            return (RSAPublicKey) KeyFactory.getInstance("RSA").generatePublic(new RSAPublicKeySpec(modulus, exponent));

        } catch (Exception e) {
            throw new IllegalStateException("Failed to process the public key.", e);
        }
    }

    public boolean validateTokenSource(String token) {
        if (!VALIDATE_TOKEN_SOURCE) {
            return true;
        }

        try {
            var jwt = jwtDecoder.decode(token);
            var issuer = Optional.ofNullable(jwt.getClaim(CLAIM_ISS))
                    .map(Object::toString)
                    .orElse("");

            return EXPECTED_ISSUER.equals(issuer);
        } catch (Exception e) {
            throw new AuthenticationException("Token source validation failed.", e) {
            };
        }
    }

    public UserDetails getUserDetails(String token) {
        try {
            var jwt = jwtDecoder.decode(token);

            var email = Optional.ofNullable(jwt.getClaim(CLAIM_SUB))
                    .map(Object::toString)
                    .filter(name -> !name.isEmpty())
                    .orElse("anonymous");

            return userService.getUserByEmail(email)
                    .map(user -> createUserDetails(email, user.getRoles()))
                    .orElseGet(() -> createUserDetails(email, ROLE_USER));

        } catch (Exception e) {
            throw new AuthenticationException("Failed to retrieve user details.", e) {};
        }
    }

    private User createUserDetails(String username, String roles) {
        List<GrantedAuthority> authorities = utils.getAuthoritiesFromRoles(roles);
        if (authorities.isEmpty()) {
            authorities = Collections.singletonList(new SimpleGrantedAuthority(ROLE_USER));
        }
        return new User(username, "", authorities);
    }

    public boolean validateTokenStructure(String token) {
        return Optional.ofNullable(token)
                .map(String::trim)
                .filter(t -> !t.isEmpty())
                .map(t -> t.split(TOKEN_PARTS_SEPARATOR))
                .filter(parts -> parts.length == 3)
                .map(parts -> {
                    try {
                        Base64.getUrlDecoder().decode(parts[0]);
                        Base64.getUrlDecoder().decode(parts[1]);
                        return true;
                    } catch (IllegalArgumentException e) {
                        throw new AuthenticationException("Invalid token structure.", e) {
                        };
                    }
                })
                .orElseThrow(() -> new AuthenticationException("Token structure validation failed.") {
                });
    }
}
