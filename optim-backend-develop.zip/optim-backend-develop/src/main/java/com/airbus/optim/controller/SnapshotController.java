package com.airbus.optim.controller;

import com.airbus.optim.service.SnapshotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("snapshot")
public class SnapshotController {

    @Autowired
    private SnapshotService snapshotService;

    @GetMapping("/periods")
    public ResponseEntity<List<String>> getAllSnapshotPeriods() {
        List<String> periods = snapshotService.findAllSnapshotPeriods();
        return ResponseEntity.ok().body(periods);
    }

    @PostMapping("/save-all")
    public void saveAllToSnapshot() {
        snapshotService.saveAllToSnapshot();
    }
}
