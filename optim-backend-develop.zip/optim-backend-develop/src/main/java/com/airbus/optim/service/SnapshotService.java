package com.airbus.optim.service;

import com.airbus.optim.entity.Employee;
import com.airbus.optim.entity.EmployeeSnapshot;
import com.airbus.optim.entity.JobRequest;
import com.airbus.optim.entity.JobRequestSnapshot;
import com.airbus.optim.entity.Lever;
import com.airbus.optim.entity.LeverSnapshot;
import com.airbus.optim.exception.SnapshotAlreadyExistsException;
import com.airbus.optim.repository.EmployeeSnapshotRepository;
import com.airbus.optim.repository.EmployeeRepository;
import com.airbus.optim.repository.JobRequestSnapshotRepository;
import com.airbus.optim.repository.JobRequestRepository;
import com.airbus.optim.repository.LeverSnapshotRepository;
import com.airbus.optim.repository.LeverRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.ZonedDateTime;
import java.util.*;

@Service
public class SnapshotService {

    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    private EmployeeSnapshotRepository employeeSnapshotRepository;
    @Autowired
    private JobRequestRepository jobRequestRepository;
    @Autowired
    private JobRequestSnapshotRepository jobRequestSnapshotRepository;

    @Autowired
    private LeverSnapshotRepository leverSnapshotRepository;

    @Transactional(readOnly = true)
    public List<String> findAllSnapshotPeriods() {
        return employeeSnapshotRepository.findDistinctSnapshotPeriods();
    }

    @Transactional
    public void saveAllToSnapshot() {
        YearMonth currentMonth = YearMonth.now();
        YearMonth previousMonth = currentMonth.minusMonths(1);
        String previousMonthFormatted = previousMonth.format(DateTimeFormatter.ofPattern("MM-yyyy"));

        if (employeeSnapshotRepository.existsBySnapshotPeriod(previousMonthFormatted)) {
            throw new SnapshotAlreadyExistsException(
                "A snapshot for the period " + previousMonthFormatted + " already exists. Cannot create duplicate snapshots."
            );
        }

        Map<Employee, EmployeeSnapshot> employeeCache = new HashMap<>();
        Map<JobRequest, JobRequestSnapshot> jobRequestCache = new HashMap<>();
        float totalLeaverFTE = 0f;

        for (Employee e : employeeRepository.findAll()) {
            EmployeeSnapshot es = new EmployeeSnapshot(e);
            es.setId(employeeSnapshotRepository.findNextAvailableId());
            es.setSnapshotPeriod(previousMonthFormatted);
            es.setEmployee(e);
            employeeSnapshotRepository.save(es);
            employeeCache.put(e, es);
        }

        for (JobRequest jr : jobRequestRepository.findAll()) {
            JobRequestSnapshot jrs = new JobRequestSnapshot(jr);
            jrs.setId(jobRequestSnapshotRepository.findNextAvailableId());
            jrs.setSnapshotPeriod(previousMonthFormatted);
            jobRequestSnapshotRepository.save(jrs);
            jobRequestCache.put(jr, jrs);
        }

        for (Map.Entry<Employee, EmployeeSnapshot> entry : employeeCache.entrySet()) {
            Employee e = entry.getKey();
            EmployeeSnapshot es = entry.getValue();

            if (e.getJobRequest() != null) {
                JobRequestSnapshot jrs = jobRequestCache.get(e.getJobRequest());
                es.setJobRequestSnapshot(jrs);
            }

            List<LeverSnapshot> leversHist = new ArrayList<>();
            if (e.getLevers() != null) {
                for (Lever l : e.getLevers()) {
                    if (l == null || l.getStartDate() == null) continue;

                    YearMonth leverMonth = YearMonth.from(l.getStartDate().atZone(java.time.ZoneId.systemDefault()));
                    if (!leverMonth.equals(previousMonth)) continue;

                    LeverSnapshot ls = new LeverSnapshot(l, es);
                    ls.setId(leverSnapshotRepository.findNextAvailableId());
                    ls.setEmployeeSnapshot(es);
                    ls.setSnapshotPeriod(previousMonthFormatted);
                    ls.setCreatedAt(ZonedDateTime.now());
                    leverSnapshotRepository.save(ls);
                    leversHist.add(ls);

                    if ("Leaver".equalsIgnoreCase(ls.getLeverType()) && ls.getFTE() != null) {
                        totalLeaverFTE += ls.getFTE();
                    }
                }
            }

            es.setLeversSnapshot(leversHist);
            employeeSnapshotRepository.save(es);
        }

        LeverSnapshot totalSnapshot = new LeverSnapshot();
        totalSnapshot.setId(leverSnapshotRepository.findNextAvailableId());
        totalSnapshot.setLeverType("AGGREGATE_LEAVERS");
        totalSnapshot.setFTE(totalLeaverFTE);
        totalSnapshot.setSnapshotPeriod(previousMonthFormatted);
        totalSnapshot.setCreatedAt(ZonedDateTime.now());
        totalSnapshot.setSiglumId(null);
        totalSnapshot.setEmployeeType(null);
        totalSnapshot.setCollar(null);
        totalSnapshot.setCountry(null);

        leverSnapshotRepository.save(totalSnapshot);
    }
}
