package com.airbus.optim.service;

import com.airbus.optim.dto.PageLockResponse;
import com.airbus.optim.dto.UserPropertiesDTO;
import com.airbus.optim.entity.User;
import com.airbus.optim.repository.UserRepository;
import com.airbus.optim.utils.Utils;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Lazy
    @Autowired
    Utils utils;

    @Autowired
    UserRepository userRepository;

    @Autowired
    PageLockService pageLockService;

    public UserPropertiesDTO getUserProperties() {
        try {
            User user;
            user = utils.getUserFromToken();
            if (user == null) {
                throw new IllegalArgumentException("User not found from token");
            }

            var userProperties = getUserPropertiesFromUser(user);

            if (userProperties == null) {
                throw new EntityNotFoundException("User properties not found");
            }

            return userProperties;
        } catch (Exception e) {
            throw e;
        }
    }

    private UserPropertiesDTO getUserPropertiesFromUser(User user) {
        UserPropertiesDTO userProperties = new UserPropertiesDTO(
                user.getRoles(),
                user.getSiglum(),
                utils.getSiglumVisibilityList(user)
        );

        PageLockResponse lockStatus = pageLockService.getApplicationLockStatus();
        userProperties.setLocked(lockStatus.isLocked());
        userProperties.setLockId(lockStatus.isLocked() ? lockStatus.getLockId() : null);

        return userProperties;
    }

    public Optional<User> getUserByEmail(String email) {
        return userRepository.findOneByEmailIgnoreCase(email);
    }
}