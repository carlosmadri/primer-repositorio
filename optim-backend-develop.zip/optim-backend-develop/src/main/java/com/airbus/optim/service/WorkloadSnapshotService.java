package com.airbus.optim.service;

public class WorkloadSnapshotService {
}
