package com.airbus.optim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class MonthlyDistributionDTO {
    List<Double> realisticView;
    List<Double> validationView;
    List<Double> optimisticView;
    List<Double> op;
    List<Double> fcii;
    List<Double> wip;
    String wipValue;
    float hcCeiling;
}