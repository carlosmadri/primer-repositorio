package com.airbus.optim.service;

import com.airbus.optim.dto.ReportEndOfYear.ActiveWorkforceReportCapacityDTO;
import com.airbus.optim.dto.ReportEndOfYear.ActiveWorkforceReportDTO;
import com.airbus.optim.dto.ReportEndOfYear.ReportEndOfYearDTO;
import com.airbus.optim.dto.TeamOutlookDTO;
import com.airbus.optim.entity.CostCenter;
import com.airbus.optim.entity.Employee;
import com.airbus.optim.entity.Siglum;
import com.airbus.optim.repository.EmployeeRepository;
import com.airbus.optim.service.EmployeeImpl.EmployeeActiveWorkforceCapacityReport;
import com.airbus.optim.utils.Utils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReportsEmployeeService {

    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    private EmployeeActiveWorkforceCapacityReport employeeReportImpl;
    @Autowired
    private Utils utils;

    public byte[] getReportFromEmployeeeWorkforce(
            MultiValueMap<String, String> params,
            Integer yearFilter) {

        Workbook workbook = new XSSFWorkbook();

        try {
            List<Employee> employees = utils.getFilteredEmployees(params);

            LocalDate currentDate = LocalDate.now();
            StringBuilder monthlyHeader = new StringBuilder();
            for (int i = 1; i <= 12; i++) {
                if (currentDate.getMonthValue() == i) {
                    monthlyHeader.append("Actual,");
                } else {
                    monthlyHeader.append("01/").append(i).append("/").append(yearFilter).append(",");
                }
            }

            List<String> filterParams = List.of(
                    "SiglumHR", "Siglum6", "Siglum5", "Siglum4", "Siglum3", "WorkerId",
                    "ActiveWorkforce", "WC/BC", "LastName", "FirstName", "Job", "AvailabilityReason",
                    "Direct", "ContractType", "CostCenter", "Country", "Site", "KAPIS Code");

            StringBuilder endOfYearHeader = new StringBuilder();
            List<String> fields = params.get("fields");

            for (String key : fields) {
                if (existsIn(key, filterParams))
                    endOfYearHeader.append(key).append(",");
            }

            // Asegurarse de que los campos "Actual" y "EndOfYear" estén siempre presentes en el encabezado
            endOfYearHeader.append("Actual,EndOfYear,");

            Sheet sheet = workbook.createSheet("Employee Workforce Report");

            // Crear estilos para el encabezado
            Map<String, CellStyle> headerStyles = createHeaderStyles(workbook);

            Row headerRow = sheet.createRow(0);
            String[] headers = endOfYearHeader.toString().split(",");

            for (int i = 0; i < headers.length; i++) {
                String headerText = headers[i] + "    ";
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headerText);

                if (i == 0) {
                    cell.setCellStyle(headerStyles.get("left"));
                } else if (i == headers.length - 1) {
                    cell.setCellStyle(headerStyles.get("right"));
                } else {
                    cell.setCellStyle(headerStyles.get("middle"));
                }
            }

            int rowIndex = 1;
            for (Employee e : employees) {
                Row row = sheet.createRow(rowIndex);
                int cellIndex = 0;

                for (String key : fields) {
                    if (existsIn(key, filterParams)) {
                        setCellValueByKey(row, cellIndex, key, e);
                        cellIndex++;
                    }
                }

                // Calcular y añadir campos "Actual" y "EndOfYear"
                double actual = 0.0;
                double endOfYear = 0.0;

                if ("Parental leave absence".equals(e.getAvailabilityReason())) {
                    actual = 1.0;
                    endOfYear = 1.0;
                }

                row.createCell(cellIndex++).setCellValue(actual);
                row.createCell(cellIndex).setCellValue(endOfYear);
                rowIndex++;
            }

            // Aplicar bordes a todas las celdas de datos
            applyBordersToDataCells(sheet, rowIndex - 1, headers.length);

            // Ajustar ancho de columnas
            for (int cont = 0; cont < headers.length; cont++) {
                sheet.autoSizeColumn(cont);
            }

            try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                workbook.write(bos);
                return bos.toByteArray();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            try {
                workbook.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean existsIn(String filterParam, List<String> paramsFiltered) {
        for (String str : paramsFiltered) {
            if(filterParam.equals(str))
                return true;
        }
        return false;
    }

    private Map<String, CellStyle> createHeaderStyles(Workbook workbook) {
        Map<String, CellStyle> styles = new HashMap<>();

        CellStyle headerStyleBase = workbook.createCellStyle();
        headerStyleBase.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
        headerStyleBase.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyleBase.setBorderBottom(BorderStyle.THIN);
        headerStyleBase.setBorderTop(BorderStyle.THIN);
        headerStyleBase.setBorderLeft(BorderStyle.THIN);
        headerStyleBase.setBorderRight(BorderStyle.THIN);
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerStyleBase.setFont(headerFont);

        CellStyle headerStyleLeft = workbook.createCellStyle();
        headerStyleLeft.cloneStyleFrom(headerStyleBase);
        headerStyleLeft.setBorderRight(BorderStyle.NONE);
        styles.put("left", headerStyleLeft);

        CellStyle headerStyleMiddle = workbook.createCellStyle();
        headerStyleMiddle.cloneStyleFrom(headerStyleBase);
        headerStyleMiddle.setBorderLeft(BorderStyle.NONE);
        headerStyleMiddle.setBorderRight(BorderStyle.NONE);
        styles.put("middle", headerStyleMiddle);

        CellStyle headerStyleRight = workbook.createCellStyle();
        headerStyleRight.cloneStyleFrom(headerStyleBase);
        headerStyleRight.setBorderLeft(BorderStyle.NONE);
        styles.put("right", headerStyleRight);

        return styles;
    }

    private void setCellValueByKey(Row row, int cellIndex, String key, Employee e) {
        Cell cell = row.createCell(cellIndex);
        switch (key) {
            case "SiglumHR":
                cell.setCellValue(e.getSiglum().getSiglumHR());
                break;
            case "Siglum6":
                cell.setCellValue(e.getSiglum().getSiglum6());
                break;
            case "Siglum5":
                cell.setCellValue(e.getSiglum().getSiglum5());
                break;
            case "Siglum4":
                cell.setCellValue(e.getSiglum().getSiglum4());
                break;
            case "Siglum3":
                cell.setCellValue(e.getSiglum().getSiglum3());
                break;
            case "WorkerId":
                cell.setCellValue(e.getEmployeeId() != null ? e.getEmployeeId().toString() : "");
                break;
            case "ActiveWorkforce":
                cell.setCellValue(e.getActiveWorkforce());
                break;
            case "WC/BC":
                cell.setCellValue(e.getCollar());
                break;
            case "LastName":
                cell.setCellValue(e.getLastName());
                break;
            case "FirstName":
                cell.setCellValue(e.getFirstName());
                break;
            case "Job":
                cell.setCellValue(e.getJob());
                break;
            case "AvailabilityReason":
                cell.setCellValue(e.getAvailabilityReason() != null ? e.getAvailabilityReason() : "");
                break;
            case "Direct":
                cell.setCellValue(e.getDirect());
                break;
            case "ContractType":
                cell.setCellValue(e.getContractType());
                break;
            case "CostCenter":
                CostCenter costCenter = e.getCostCenter();
                cell.setCellValue(costCenter != null ? costCenter.getCostCenterCode() : "");
                break;
            case "Country":
                if (e.getCostCenter() != null && e.getCostCenter().getLocation() != null) {
                    cell.setCellValue(e.getCostCenter().getLocation().getCountry());
                } else {
                    cell.setCellValue("");
                }
                break;
            case "Site":
                if (e.getCostCenter() != null && e.getCostCenter().getLocation() != null) {
                    cell.setCellValue(e.getCostCenter().getLocation().getSite());
                } else {
                    cell.setCellValue("");
                }
                break;
            case "KAPIS Code":
                if (e.getCostCenter() != null && e.getCostCenter().getLocation() != null) {
                    cell.setCellValue(e.getCostCenter().getLocation().getKapisCode());
                } else {
                    cell.setCellValue("");
                }
                break;
        }
    }

    private void applyBordersToDataCells(Sheet sheet, int lastDataRowIndex, int numCols) {
        for (int r = 1; r <= lastDataRowIndex; r++) {
            Row dataRow = sheet.getRow(r);
            if (dataRow == null) continue;
            for (int c = 0; c < numCols; c++) {
                Cell cell = dataRow.getCell(c);
                if (cell == null) continue;
                CellStyle currentStyle = cell.getCellStyle();
                CellStyle newStyle = sheet.getWorkbook().createCellStyle();
                if (currentStyle != null) {
                    newStyle.cloneStyleFrom(currentStyle);
                }
                if (c == 0) {
                    newStyle.setBorderLeft(BorderStyle.THIN);
                }
                if (c == numCols - 1) {
                    newStyle.setBorderRight(BorderStyle.THIN);
                }
                if (r == lastDataRowIndex) {
                    newStyle.setBorderBottom(BorderStyle.THIN);
                }
                cell.setCellStyle(newStyle);
            }
        }
    }

    public ReportEndOfYearDTO getReportSiglumEndOfYear(
            List<ActiveWorkforceReportDTO> activeWorkforceReportList,
            List<ActiveWorkforceReportDTO> tempWorkforceReportList,
            TeamOutlookDTO teamOutlookDTO) {

        List<ActiveWorkforceReportCapacityDTO> actualsList =
                employeeReportImpl.getActualsActiveWorkforceCapacity(
                        activeWorkforceReportList, tempWorkforceReportList);

        List<ActiveWorkforceReportCapacityDTO> realisticList =
                employeeReportImpl.getRealisticActiveWorkforceCapacity(actualsList, teamOutlookDTO);

        List<ActiveWorkforceReportCapacityDTO> validationList =
                employeeReportImpl.getValidationActiveWorkforceCapacity(realisticList, teamOutlookDTO);

        List<ActiveWorkforceReportCapacityDTO> optimisticList =
                employeeReportImpl.getOptimisticActiveWorkforceCapacity(validationList, teamOutlookDTO);

        return new ReportEndOfYearDTO(actualsList, realisticList, validationList, optimisticList);
    }


    public byte[] getReportSiglum4EndOfYear(
            MultiValueMap<String, String> params,
            Integer yearFilter) {

        try (Workbook workbook = new XSSFWorkbook()) {
            // Obtener datos necesarios
            List<Employee> employees = utils.getFilteredEmployees(params);
            List<Siglum> siglumVisibilityList = utils.getSiglumVisibilityList();
            TeamOutlookDTO teamOutlookDTO = employeeService.getTeamOutlook(params, yearFilter).getBody();

            List<ActiveWorkforceReportDTO> activeWorkforceAndSiglumList =
                    employeeRepository.sumFTEsByActiveWorkforceAndSiglum4("AWF", employees, siglumVisibilityList);
            List<ActiveWorkforceReportDTO> tempWorkforceAndSiglumList =
                    employeeRepository.sumFTEsByActiveWorkforceAndSiglum4("TEMP", employees, siglumVisibilityList);

            ReportEndOfYearDTO reportSiglumEndOfYearDTO = getReportSiglumEndOfYear(
                    activeWorkforceAndSiglumList, tempWorkforceAndSiglumList, teamOutlookDTO);

            // Crear la hoja de Excel
            Sheet sheet = workbook.createSheet("Siglum 4 Report");

            // Definir estructura del reporte
            createEndOfYearReportStructure(workbook, sheet, "Managers included on their own siglum",
                    new String[]{"Siglum 4", "AWF", "TEMP", "Capacity", "AWF", "TEMP", "Capacity",
                            "AWF", "TEMP", "Capacity", "AWF", "TEMP", "Capacity"},
                    reportSiglumEndOfYearDTO, false);

            // Escribir la salida en un array de bytes
            try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                workbook.write(bos);
                return bos.toByteArray();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void createEndOfYearReportStructure(Workbook workbook, Sheet sheet, String title,
                                                String[] subHeaders, ReportEndOfYearDTO reportData, boolean includeExtraSiglumColumns) {

        // Crear estilos
        Map<String, CellStyle> styles = createEndOfYearReportStyles(workbook);

        // Fila 0: Título
        createTitleRow(sheet, title, styles.get("header"), subHeaders.length - 1);

        // Fila 1: Encabezados de grupo
        createGroupHeadersRow(sheet, styles.get("groupHeader"), subHeaders.length, includeExtraSiglumColumns);

        // Fila 2: Subencabezados
        createSubHeadersRow(sheet, subHeaders, styles.get("subHeader"));

        // Filas de datos
        int dataRowCount = reportData.getActuals().size();
        fillDataRows(sheet, reportData, dataRowCount, styles.get("dataCell"),
                styles.get("dataCapacityCell"), includeExtraSiglumColumns);

        // Fila de totales
        createTotalsRow(sheet, dataRowCount, styles.get("totalBase"),
                styles.get("totalNoBorder"), styles.get("totalCapacity"),
                subHeaders.length, includeExtraSiglumColumns);

        // Ajustar ancho de columnas
        for (int i = 0; i < subHeaders.length; i++) {
            sheet.autoSizeColumn(i);
        }
    }

    private Map<String, CellStyle> createEndOfYearReportStyles(Workbook workbook) {
        Map<String, CellStyle> styles = new HashMap<>();

        // Estilo para encabezados (negrita y con bordes)
        CellStyle headerStyle = workbook.createCellStyle();
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerStyle.setFont(headerFont);
        headerStyle.setBorderBottom(BorderStyle.THIN);
        headerStyle.setBorderTop(BorderStyle.THIN);
        headerStyle.setBorderLeft(BorderStyle.THIN);
        headerStyle.setBorderRight(BorderStyle.THIN);
        styles.put("header", headerStyle);

        // Estilo para encabezados de grupo (centrado, negrita, fondo azul)
        CellStyle groupHeaderStyle = workbook.createCellStyle();
        groupHeaderStyle.setAlignment(HorizontalAlignment.CENTER);
        Font groupHeaderFont = workbook.createFont();
        groupHeaderFont.setBold(true);
        groupHeaderStyle.setFont(groupHeaderFont);
        groupHeaderStyle.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
        groupHeaderStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        styles.put("groupHeader", groupHeaderStyle);

        // Estilo para subencabezados (fondo azul)
        CellStyle subHeaderStyle = workbook.createCellStyle();
        subHeaderStyle.cloneStyleFrom(headerStyle);
        subHeaderStyle.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
        subHeaderStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        styles.put("subHeader", subHeaderStyle);

        // Estilo para celdas de datos sin bordes
        CellStyle dataCellStyle = workbook.createCellStyle();
        dataCellStyle.setBorderTop(BorderStyle.NONE);
        dataCellStyle.setBorderBottom(BorderStyle.NONE);
        dataCellStyle.setBorderLeft(BorderStyle.NONE);
        dataCellStyle.setBorderRight(BorderStyle.NONE);
        styles.put("dataCell", dataCellStyle);

        // Estilo para celdas de capacidad (con bordes laterales)
        CellStyle dataCapacityCellStyle = workbook.createCellStyle();
        dataCapacityCellStyle.setBorderTop(BorderStyle.NONE);
        dataCapacityCellStyle.setBorderBottom(BorderStyle.NONE);
        dataCapacityCellStyle.setBorderLeft(BorderStyle.THIN);
        dataCapacityCellStyle.setBorderRight(BorderStyle.THIN);
        styles.put("dataCapacityCell", dataCapacityCellStyle);

        // Estilo base para totales (fondo azul, bordes superior e inferior)
        CellStyle totalBaseStyle = workbook.createCellStyle();
        totalBaseStyle.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
        totalBaseStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        totalBaseStyle.setBorderTop(BorderStyle.THIN);
        totalBaseStyle.setBorderBottom(BorderStyle.THIN);
        styles.put("totalBase", totalBaseStyle);

        // Estilo para totales sin bordes laterales
        CellStyle totalNoBorderStyle = workbook.createCellStyle();
        totalNoBorderStyle.cloneStyleFrom(totalBaseStyle);
        totalNoBorderStyle.setBorderLeft(BorderStyle.NONE);
        totalNoBorderStyle.setBorderRight(BorderStyle.NONE);
        styles.put("totalNoBorder", totalNoBorderStyle);

        // Estilo para totales de capacidad (con bordes laterales)
        CellStyle totalCapacityStyle = workbook.createCellStyle();
        totalCapacityStyle.cloneStyleFrom(totalBaseStyle);
        totalCapacityStyle.setBorderLeft(BorderStyle.THIN);
        totalCapacityStyle.setBorderRight(BorderStyle.THIN);
        styles.put("totalCapacity", totalCapacityStyle);

        return styles;
    }

    private void createTitleRow(Sheet sheet, String title, CellStyle style, int lastColumn) {
        Row titleRow = sheet.createRow(0);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue(title);
        titleCell.setCellStyle(style);
        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, lastColumn));

        for (int i = 0; i <= lastColumn; i++) {
            Cell cell = titleRow.createCell(i);
            cell.setCellStyle(style);
        }
        titleRow.getCell(0).setCellValue(title);
    }

    private void createGroupHeadersRow(Sheet sheet, CellStyle style, int totalColumns, boolean includeExtraSiglumColumns) {
        Row headerRow = sheet.createRow(1);
        String[] groupHeaders = {"Actuals", "Realistic View", "Validation Required View", "Optimistic View"};
        int headerIndex = 0;

        for (int i = 0; i < groupHeaders.length; i++) {
            Cell cell = headerRow.createCell(headerIndex);
            cell.setCellValue(groupHeaders[i]);
            cell.setCellStyle(style);

            int mergeSize;
            if (includeExtraSiglumColumns) {
                mergeSize = 3; // Cada grupo ocupa 4 columnas
            } else {
                mergeSize = (i == 0) ? 3 : 2; // Primer grupo 4 columnas, resto 3 columnas
            }

            sheet.addMergedRegion(new CellRangeAddress(1, 1, headerIndex, headerIndex + mergeSize));

            // Para el último grupo, aseguramos el borde derecho
            if (i == groupHeaders.length - 1) {
                for (int col = headerIndex; col <= headerIndex + mergeSize; col++) {
                    Cell mergedCell = headerRow.getCell(col);
                    if (mergedCell == null) {
                        mergedCell = headerRow.createCell(col);
                        mergedCell.setCellValue(groupHeaders[i]);
                    }
                    CellStyle tempStyle = sheet.getWorkbook().createCellStyle();
                    tempStyle.cloneStyleFrom(style);
                    tempStyle.setBorderRight(BorderStyle.THIN);
                    mergedCell.setCellStyle(tempStyle);
                }
            }

            headerIndex += mergeSize + 1;
        }
    }

    private void createSubHeadersRow(Sheet sheet, String[] subHeaders, CellStyle style) {
        Row subHeaderRow = sheet.createRow(2);
        for (int i = 0; i < subHeaders.length; i++) {
            Cell cell = subHeaderRow.createCell(i);
            cell.setCellValue(subHeaders[i]);
            cell.setCellStyle(style);
        }
    }

    private void fillDataRows(Sheet sheet, ReportEndOfYearDTO reportData, int dataRowCount,
                              CellStyle dataCellStyle, CellStyle capacityCellStyle, boolean includeExtraSiglumColumns) {

        for (int i = 0; i < dataRowCount; i++) {
            Row row = sheet.createRow(i + 3);
            int colIndex = 0;

            // Grupo 0: Actuals
            if (includeExtraSiglumColumns) {
                // Si incluimos columna extra de Siglum para cada grupo
                Cell cell0 = row.createCell(colIndex++);
                cell0.setCellValue(reportData.getActuals().get(i).getReport());
                cell0.setCellStyle(dataCellStyle);
            } else {
                // Solo incluimos Siglum en el primer grupo
                Cell cell0 = row.createCell(colIndex++);
                cell0.setCellValue(reportData.getActuals().get(i).getReport());
                cell0.setCellStyle(dataCellStyle);
            }

            Cell cell1 = row.createCell(colIndex++);
            cell1.setCellValue(reportData.getActuals().get(i).getAwfFTE());
            cell1.setCellStyle(dataCellStyle);

            Cell cell2 = row.createCell(colIndex++);
            cell2.setCellValue(reportData.getActuals().get(i).getTempFTE());
            cell2.setCellStyle(dataCellStyle);

            Cell cell3 = row.createCell(colIndex++);
            cell3.setCellValue(reportData.getActuals().get(i).getCapacity());
            cell3.setCellStyle(capacityCellStyle);

            // Grupo 1: Realistic
            if (includeExtraSiglumColumns) {
                Cell cellSiglum = row.createCell(colIndex++);
                cellSiglum.setCellValue(reportData.getRealistic().get(i).getReport());
                cellSiglum.setCellStyle(dataCellStyle);
            }

            Cell cell4 = row.createCell(colIndex++);
            cell4.setCellValue(reportData.getRealistic().get(i).getAwfFTE());
            cell4.setCellStyle(dataCellStyle);

            Cell cell5 = row.createCell(colIndex++);
            cell5.setCellValue(reportData.getRealistic().get(i).getTempFTE());
            cell5.setCellStyle(dataCellStyle);

            Cell cell6 = row.createCell(colIndex++);
            cell6.setCellValue(reportData.getRealistic().get(i).getCapacity());
            cell6.setCellStyle(capacityCellStyle);

            // Grupo 2: Validation
            if (includeExtraSiglumColumns) {
                Cell cellSiglum = row.createCell(colIndex++);
                cellSiglum.setCellValue(reportData.getValidation().get(i).getReport());
                cellSiglum.setCellStyle(dataCellStyle);
            }

            Cell cell7 = row.createCell(colIndex++);
            cell7.setCellValue(reportData.getValidation().get(i).getAwfFTE());
            cell7.setCellStyle(dataCellStyle);

            Cell cell8 = row.createCell(colIndex++);
            cell8.setCellValue(reportData.getValidation().get(i).getTempFTE());
            cell8.setCellStyle(dataCellStyle);

            Cell cell9 = row.createCell(colIndex++);
            cell9.setCellValue(reportData.getValidation().get(i).getCapacity());
            cell9.setCellStyle(capacityCellStyle);

            // Grupo 3: Optimistic
            if (includeExtraSiglumColumns) {
                Cell cellSiglum = row.createCell(colIndex++);
                cellSiglum.setCellValue(reportData.getOptimistic().get(i).getReport());
                cellSiglum.setCellStyle(dataCellStyle);
            }

            Cell cell10 = row.createCell(colIndex++);
            cell10.setCellValue(reportData.getOptimistic().get(i).getAwfFTE());
            cell10.setCellStyle(dataCellStyle);

            Cell cell11 = row.createCell(colIndex++);
            cell11.setCellValue(reportData.getOptimistic().get(i).getTempFTE());
            cell11.setCellStyle(dataCellStyle);

            Cell cell12 = row.createCell(colIndex++);
            cell12.setCellValue(reportData.getOptimistic().get(i).getCapacity());
            cell12.setCellStyle(capacityCellStyle);
        }
    }

    private void createTotalsRow(Sheet sheet, int dataRowCount, CellStyle baseStyle,
                                 CellStyle noBorderStyle, CellStyle capacityStyle,
                                 int totalColumns, boolean includeExtraSiglumColumns) {

        int totalRowIndex = dataRowCount + 3;
        Row totalRow = sheet.createRow(totalRowIndex);

        // Primera celda con "Total" y borde izquierdo
        Cell firstCell = totalRow.createCell(0);
        firstCell.setCellValue("Total");
        CellStyle firstCellStyle = sheet.getWorkbook().createCellStyle();
        firstCellStyle.cloneStyleFrom(baseStyle);
        firstCellStyle.setBorderLeft(BorderStyle.THIN);
        firstCell.setCellStyle(firstCellStyle);

        int colIndex = 1;

        // Grupo 0: Actuals
        if (includeExtraSiglumColumns) {
            // Si incluimos columna extra de Siglum para cada grupo
            // AWF
            Cell awfCell = totalRow.createCell(colIndex);
            awfCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                    + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
            awfCell.setCellStyle(noBorderStyle);
            colIndex++;

            // TEMP
            Cell tempCell = totalRow.createCell(colIndex);
            tempCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                    + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
            tempCell.setCellStyle(noBorderStyle);
            colIndex++;

            // Capacity
            Cell capacityCell = totalRow.createCell(colIndex);
            capacityCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                    + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
            capacityCell.setCellStyle(capacityStyle);
            colIndex++;
        } else {
            // AWF
            Cell awfCell = totalRow.createCell(colIndex);
            awfCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                    + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
            awfCell.setCellStyle(noBorderStyle);
            colIndex++;

            // TEMP
            Cell tempCell = totalRow.createCell(colIndex);
            tempCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                    + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
            tempCell.setCellStyle(noBorderStyle);
            colIndex++;

            // Capacity
            Cell capacityCell = totalRow.createCell(colIndex);
            capacityCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                    + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
            capacityCell.setCellStyle(capacityStyle);
            colIndex++;
        }

        // Grupo 1: Realistic
        if (includeExtraSiglumColumns) {
            // Siglum (si aplica)
            Cell siglumCell = totalRow.createCell(colIndex);
            siglumCell.setCellValue("");
            siglumCell.setCellStyle(noBorderStyle);
            colIndex++;
        }

        // AWF
        Cell awfCell = totalRow.createCell(colIndex);
        awfCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
        awfCell.setCellStyle(noBorderStyle);
        colIndex++;

        // TEMP
        Cell tempCell = totalRow.createCell(colIndex);
        tempCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
        tempCell.setCellStyle(noBorderStyle);
        colIndex++;

        // Capacity
        Cell capacityCell = totalRow.createCell(colIndex);
        capacityCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
        capacityCell.setCellStyle(capacityStyle);
        colIndex++;

        // Grupo 2: Validation
        if (includeExtraSiglumColumns) {
            // Siglum (si aplica)
            Cell siglumCell = totalRow.createCell(colIndex);
            siglumCell.setCellValue("");
            siglumCell.setCellStyle(noBorderStyle);
            colIndex++;
        }

        // AWF
        awfCell = totalRow.createCell(colIndex);
        awfCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
        awfCell.setCellStyle(noBorderStyle);
        colIndex++;

        // TEMP
        tempCell = totalRow.createCell(colIndex);
        tempCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
        tempCell.setCellStyle(noBorderStyle);
        colIndex++;

        // Capacity
        capacityCell = totalRow.createCell(colIndex);
        capacityCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
        capacityCell.setCellStyle(capacityStyle);
        colIndex++;

        // Grupo 3: Optimistic
        if (includeExtraSiglumColumns) {
            // Siglum (si aplica)
            Cell siglumCell = totalRow.createCell(colIndex);
            siglumCell.setCellValue("");
            siglumCell.setCellStyle(noBorderStyle);
            colIndex++;
        }

        // AWF
        awfCell = totalRow.createCell(colIndex);
        awfCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
        awfCell.setCellStyle(noBorderStyle);
        colIndex++;

        // TEMP
        tempCell = totalRow.createCell(colIndex);
        tempCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");
        tempCell.setCellStyle(noBorderStyle);
        colIndex++;

        // Capacity (última columna)
        capacityCell = totalRow.createCell(colIndex);
        capacityCell.setCellFormula("SUM(" + CellReference.convertNumToColString(colIndex) + "4:"
                + CellReference.convertNumToColString(colIndex) + totalRowIndex + ")");

        // Asegurarse de que la última celda tenga borde derecho
        CellStyle lastCellStyle = sheet.getWorkbook().createCellStyle();
        lastCellStyle.cloneStyleFrom(capacityStyle);
        lastCellStyle.setBorderRight(BorderStyle.THIN);
        capacityCell.setCellStyle(lastCellStyle);
    }

    public byte[] getReportSiglum5EndOfYear(
            MultiValueMap<String, String> params,
            Integer yearFilter) {

        try (Workbook workbook = new XSSFWorkbook()) {
            // Obtener datos necesarios
            List<Employee> employees = utils.getFilteredEmployees(params);
            List<Siglum> siglumVisibilityList = utils.getSiglumVisibilityList();
            TeamOutlookDTO teamOutlookDTO = employeeService.getTeamOutlook(params, yearFilter).getBody();

            List<ActiveWorkforceReportDTO> activeWorkforceAndSiglumList =
                    employeeRepository.sumFTEsByActiveWorkforceAndSiglum5("AWF", employees, siglumVisibilityList);
            List<ActiveWorkforceReportDTO> tempWorkforceAndSiglumList =
                    employeeRepository.sumFTEsByActiveWorkforceAndSiglum5("TEMP", employees, siglumVisibilityList);

            ReportEndOfYearDTO reportSiglumEndOfYearDTO = getReportSiglumEndOfYear(
                    activeWorkforceAndSiglumList, tempWorkforceAndSiglumList, teamOutlookDTO);

            // Crear la hoja de Excel
            Sheet sheet = workbook.createSheet("Siglum 5 Report");

            // Definir estructura del reporte - la diferencia principal es que incluimos columnas de Siglum5 en cada grupo
            createEndOfYearReportStructure(workbook, sheet, "Managers included on their own siglum",
                    new String[]{"Siglum5", "AWF", "Temp", "Capacity",
                            "Siglum5", "AWF", "Temp", "Capacity",
                            "Siglum5", "AWF", "Temp", "Capacity",
                            "Siglum5", "AWF", "Temp", "Capacity"},
                    reportSiglumEndOfYearDTO, true);

            // Escribir la salida en un array de bytes
            try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                workbook.write(bos);
                return bos.toByteArray();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public byte[] getReportSiteEndOfYear(
            MultiValueMap<String, String> params,
            Integer yearFilter) {

        try (Workbook workbook = new XSSFWorkbook()) {
            // Obtener datos necesarios
            List<Employee> employees = utils.getFilteredEmployees(params);
            List<Siglum> siglumVisibilityList = utils.getSiglumVisibilityList();
            TeamOutlookDTO teamOutlookDTO = employeeService.getTeamOutlook(params, yearFilter).getBody();

            // Se obtienen los datos para AWF y TEMP. La query en el repositorio ya agrupa correctamente por site.
            List<ActiveWorkforceReportDTO> activeWorkforceAndSiteList =
                    employeeRepository.sumFTEsByActiveWorkforceAndSite("AWF", employees, siglumVisibilityList);
            List<ActiveWorkforceReportDTO> tempWorkforceAndSiteList =
                    employeeRepository.sumFTEsByActiveWorkforceAndSite("TEMP", employees, siglumVisibilityList);

            ReportEndOfYearDTO reportEndOfYearDTO = getReportSiglumEndOfYear(
                    activeWorkforceAndSiteList, tempWorkforceAndSiteList, teamOutlookDTO);

            // Crear la hoja de Excel
            Sheet sheet = workbook.createSheet("Site Report");

            // Definir estructura del reporte - similar a Siglum4 pero con título diferente
            createEndOfYearReportStructure(workbook, sheet, "Managers included on their own site",
                    new String[]{"Site", "AWF", "Temp", "Capacity",
                            "AWF", "Temp", "Capacity",
                            "AWF", "Temp", "Capacity",
                            "AWF", "Temp", "Capacity"},
                    reportEndOfYearDTO, false);

            // Escribir la salida en un array de bytes
            try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                workbook.write(bos);
                return bos.toByteArray();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public byte[] getReportEmployeesEndOfYear(
            MultiValueMap<String, String> params,
            Integer yearFilter) throws IOException {

        try (Workbook workbook = new XSSFWorkbook()) {
            // Obtener datos necesarios
            List<Employee> employees = utils.getFilteredEmployees(params);

            Sheet sheet = workbook.createSheet("Employees Report");

            // Definir encabezados
            String[] headers = {"Siglum6", "Siglum5", "Siglum4", "Country", "Site", "id", "FirstName",
                    "LastName", "Job", "AvailabilityReason", "ActiveWorkforce", "Direct/Indirect", "ContractType",
                    "KAPIS code", "CostCenter", "Collar", "FTE"};

            // Crear estilos
            CellStyle headerStyle = createHeaderStyleWithColor(workbook);
            CellStyle cellStyle = createBasicCellStyle(workbook);

            // Crear fila de encabezados
            Row headerRow = sheet.createRow(0);
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // Llenar filas de datos
            int rowIndex = 1;
            for (Employee employee : employees) {
                Row row = sheet.createRow(rowIndex++);
                fillEmployeeDataRow(row, employee, headers, cellStyle);
            }

            // Ajustar ancho de columnas
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // Escribir la salida en un array de bytes
            try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                workbook.write(bos);
                return bos.toByteArray();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private CellStyle createHeaderStyleWithColor(Workbook workbook) {
        CellStyle headerStyle = workbook.createCellStyle();
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerStyle.setFont(headerFont);
        headerStyle.setBorderBottom(BorderStyle.THIN);
        headerStyle.setBorderTop(BorderStyle.THIN);
        headerStyle.setBorderLeft(BorderStyle.THIN);
        headerStyle.setBorderRight(BorderStyle.THIN);
        headerStyle.setAlignment(HorizontalAlignment.CENTER);
        headerStyle.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        return headerStyle;
    }

    private CellStyle createBasicCellStyle(Workbook workbook) {
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
        return cellStyle;
    }

    private void fillEmployeeDataRow(Row row, Employee employee, String[] headers, CellStyle cellStyle) {
        try {
            for (int j = 0; j < headers.length; j++) {
                Cell cell = row.createCell(j);

                Object cellValue = switch (headers[j]) {
                    case "Siglum6" -> employee.getSiglum() != null ? employee.getSiglum().getSiglum6() : "0";
                    case "Siglum5" -> employee.getSiglum() != null ? employee.getSiglum().getSiglum5() : "0";
                    case "Siglum4" -> employee.getSiglum() != null ? employee.getSiglum().getSiglum4() : "0";
                    case "Country" -> {
                        CostCenter costCenter = employee.getCostCenter();
                        yield (costCenter != null && costCenter.getLocation() != null) ? costCenter.getLocation().getCountry() : "";
                    }
                    case "Site" -> {
                        CostCenter costCenter = employee.getCostCenter();
                        yield (costCenter != null && costCenter.getLocation() != null) ? costCenter.getLocation().getSite() : "";
                    }
                    case "id" -> employee.getId();
                    case "FirstName" -> employee.getFirstName();
                    case "LastName" -> employee.getLastName();
                    case "Job" -> employee.getJob();
                    case "AvailabilityReason" -> employee.getAvailabilityReason();
                    case "ActiveWorkforce" -> employee.getActiveWorkforce();
                    case "Direct/Indirect" -> employee.getDirect();
                    case "ContractType" -> employee.getContractType();
                    case "KAPIS code" -> {
                        CostCenter costCenter = employee.getCostCenter();
                        yield (costCenter != null && costCenter.getLocation() != null) ? costCenter.getLocation().getKapisCode() : "0";
                    }
                    case "CostCenter" -> employee.getCostCenter() != null ? employee.getCostCenter().getId() : "0";
                    case "Collar" -> employee.getCollar();
                    case "FTE" -> employee.getFTE();
                    default -> "";
                };

                if (cellValue != null) {
                    if (cellValue instanceof Number) {
                        cell.setCellValue(((Number) cellValue).doubleValue());
                    } else {
                        cell.setCellValue(cellValue.toString());
                    }
                } else {
                    cell.setCellValue("");
                }

                cell.setCellStyle(cellStyle);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error procesando empleado: " + employee.getId() + " - " + e.getMessage());
        }
    }

    public byte[] getReportSiglum3EndOfYear(
            MultiValueMap<String, String> params,
            Integer yearFilter) {

        try (Workbook workbook = new XSSFWorkbook()) {
            // Obtain necessary data
            List<Employee> employees = utils.getFilteredEmployees(params);
            List<Siglum> siglumVisibilityList = utils.getSiglumVisibilityList();
            TeamOutlookDTO teamOutlookDTO = employeeService.getTeamOutlook(params, yearFilter).getBody();

            List<ActiveWorkforceReportDTO> activeWorkforceAndSiglumList =
                    employeeRepository.sumFTEsByActiveWorkforceAndSiglum3("AWF", employees, siglumVisibilityList);
            List<ActiveWorkforceReportDTO> tempWorkforceAndSiglumList =
                    employeeRepository.sumFTEsByActiveWorkforceAndSiglum3("TEMP", employees, siglumVisibilityList);

            ReportEndOfYearDTO reportSiglumEndOfYearDTO = getReportSiglumEndOfYear(
                    activeWorkforceAndSiglumList, tempWorkforceAndSiglumList, teamOutlookDTO);

            // Create Excel sheet
            Sheet sheet = workbook.createSheet("Siglum 3 Report");

            // Define report structure
            createEndOfYearReportStructure(workbook, sheet, "Managers included on their own siglum",
                    new String[]{"Siglum 3", "AWF", "TEMP", "Capacity", "AWF", "TEMP", "Capacity",
                            "AWF", "TEMP", "Capacity", "AWF", "TEMP", "Capacity"},
                    reportSiglumEndOfYearDTO, false);

            // Write output to byte array
            try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                workbook.write(bos);
                return bos.toByteArray();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
