package com.airbus.optim.controller;

import com.airbus.optim.service.DataSyncService;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/data-sync")
public class DataSyncController {

	@Autowired
	private DataSyncService dataSyncService;

	@GetMapping(value = "/export", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<byte[]> exportDataSync(@RequestParam MultiValueMap<String, String> params) {

		var reportContent = dataSyncService.generateDataSinc(params);

		if (reportContent == null || reportContent.length == 0) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		}

		var headers = new HttpHeaders();
		headers.setContentDisposition(
				ContentDisposition.builder("attachment").filename("EmployeeSiglum4Report.xlsm").build());
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

		return ResponseEntity.ok().headers(headers).body(reportContent);
	}

	@Operation(summary = "Import Excel file", description = "Imports data from an Excel file and updates the database", requestBody = @RequestBody(content = @Content(mediaType = "multipart/form-data")))
	@PostMapping(value = "/import", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<?> importFromExcel(@RequestParam("file") MultipartFile file) {
		if (file.isEmpty()) {
			return ResponseEntity.badRequest().body(Map.of("error", "The file is empty."));
		}

		try (Workbook workbook = WorkbookFactory.create(file.getInputStream())) {
			dataSyncService.importDataFromExcel(workbook);
			return ResponseEntity.ok(Map.of("message", "File imported successfully."));
		} catch (IOException e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body(Map.of("error", "Error reading the Excel file.", "message", e.getMessage()));
		} catch (IllegalArgumentException e) {
			return ResponseEntity.badRequest().body(Map.of("error", "Invalid file data.", "message", e.getMessage()));
		}
	}

}
