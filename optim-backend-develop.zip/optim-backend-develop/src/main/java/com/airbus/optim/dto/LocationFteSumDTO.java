package com.airbus.optim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LocationFteSumDTO {
    String country;
    String site;
    double fteSum;
    double longitude;
    double latitude;
}
