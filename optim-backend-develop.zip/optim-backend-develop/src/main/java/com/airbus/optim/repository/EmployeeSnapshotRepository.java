package com.airbus.optim.repository;

import com.airbus.optim.entity.EmployeeSnapshot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeSnapshotRepository extends JpaRepository<EmployeeSnapshot, Long>, JpaSpecificationExecutor<EmployeeSnapshot>, IdentifiableRepository<EmployeeSnapshot> {
    @Query(value = "SELECT COALESCE(MAX(e.id), 0) + 1 FROM employee_snapshot e", nativeQuery = true)
    Long findNextAvailableId();

    boolean existsBySnapshotPeriod(String snapshotPeriod);

    @Query("SELECT DISTINCT e.snapshotPeriod FROM EmployeeSnapshot e WHERE e.snapshotPeriod IS NOT NULL ORDER BY e.snapshotPeriod DESC")
    List<String> findDistinctSnapshotPeriods();
}



