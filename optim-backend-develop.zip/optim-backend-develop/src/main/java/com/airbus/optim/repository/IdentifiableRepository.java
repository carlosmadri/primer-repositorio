package com.airbus.optim.repository;

public interface IdentifiableRepository<T> {
    Long findNextAvailableId();
}
