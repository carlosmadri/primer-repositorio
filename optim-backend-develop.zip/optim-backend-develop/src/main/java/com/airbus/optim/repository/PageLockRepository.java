package com.airbus.optim.repository;

import com.airbus.optim.entity.PageLock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PageLockRepository extends JpaRepository<PageLock, Long> {
	Optional<PageLock> findTopByOrderByLockedAtDesc();

	Optional<PageLock> findTopByOrderByCreatedAtDesc();
}
