package com.airbus.optim.service;

import com.airbus.optim.entity.PurchaseOrders;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

@Service
public class PurchaseOrdersSpecitication {

    public static Specification<PurchaseOrders> getSpecifications(MultiValueMap<String, String> params) {
        return (root, query, criteriaBuilder) -> {
            Predicate predicate = criteriaBuilder.conjunction();

            for (Map.Entry<String, List<String>> entry : params.entrySet()) {
                String key = entry.getKey();
                List<String> values = entry.getValue();

                List<String> parsedValues = new ArrayList<>();
                for (String value : values) {
                    if (value.contains(",")) {
                        parsedValues.addAll(List.of(value.split(",")));
                    } else {
                        parsedValues.add(value);
                    }
                }

                if (key.startsWith("siglum.")) {
                    predicate = addPredicateWithMultipleValues(predicate, root.join("siglum").get(key.substring("siglum.".length())), parsedValues, criteriaBuilder, true);

                } else if (key.startsWith("subcontracting.siglum")) {
                    predicate = addPredicateWithMultipleValues(predicate, root.join("siglum").get("siglumHR"), parsedValues, criteriaBuilder, true);

                } else if (key.startsWith("subcontracting.site")) {
                    predicate = addPredicateWithMultipleValues(predicate, root.join("locations").get("site"), parsedValues, criteriaBuilder, true);

                } else if (key.startsWith("subcontracting.description")) {
                    predicate = addPredicateWithMultipleValues(predicate, root.get("description"), parsedValues, criteriaBuilder, true);

                } else if (key.startsWith("subcontracting.provider")) {
                    predicate = addPredicateWithMultipleValues(predicate, root.get("provider"), parsedValues, criteriaBuilder, true);

                } else if (key.startsWith("subcontracting.approved")) {
                    predicate = addPredicateWithMultipleValues(predicate, root.get("approved"), parsedValues, criteriaBuilder, true);

                } else if (key.startsWith("subcontracting.quarter")) {
                    predicate = addPredicateWithMultipleValues(predicate, root.get("quarter"), parsedValues, criteriaBuilder, true);

                } else if (key.startsWith("subcontracting.year")) {
                    predicate = addPredicateWithMultipleValues(predicate, root.get("year"), parsedValues, criteriaBuilder, true);

                } else if (key.startsWith("subcontracting.orderRequest")) {
                    predicate = addPredicateWithMultipleValues(predicate, root.get("orderRequest"), parsedValues, criteriaBuilder, true);

                } else if (key.startsWith("subcontracting.hmg")) {
                    predicate = addPredicateWithMultipleValues(predicate, root.get("hmg"), parsedValues, criteriaBuilder, true);

                } else if (key.startsWith("subcontracting.pep")) {
                    predicate = addPredicateWithMultipleValues(predicate, root.get("pep"), parsedValues, criteriaBuilder, true);

                } else if (key.startsWith("subcontracting.keur")) {
                    predicate = addPredicateWithMultipleValues(predicate, root.get("keur"), parsedValues, criteriaBuilder, true);

                } else if (key.startsWith("subcontracting.orderId")) {
                    predicate = addNumericPredicate(predicate, root.get("id"), parsedValues, criteriaBuilder);

                } else if (key.startsWith("subcontracting.location.")) {
                    predicate = addPredicateWithMultipleValues(predicate, root.join("location").get(key.substring("location.".length())), parsedValues, criteriaBuilder, true);

                }
            }

            return predicate;
        };
    }

    private static Predicate addPredicateWithMultipleValues(Predicate predicate, Path<?> path, List<String> values, CriteriaBuilder cb, boolean exactMatch) {
        if (path.getJavaType() == String.class) {
            Predicate newPredicate = cb.disjunction();
            for (String value : values) {
                if (exactMatch) {
                    newPredicate = cb.or(newPredicate, cb.equal(cb.lower(path.as(String.class)), value.toLowerCase()));
                } else {
                    newPredicate = cb.or(newPredicate, cb.like(cb.lower(path.as(String.class)), "%" + value.toLowerCase() + "%"));
                }
            }
            return cb.and(predicate, newPredicate);
        } else {
            return addGenericPredicate(predicate, path, values, cb);
        }
    }

    private static Predicate addNumericPredicate(Predicate predicate, Path<Long> path, List<String> values, CriteriaBuilder cb) {
        Predicate newPredicate = cb.disjunction();
        for (String value : values) {
            try {
                Long numericValue = Long.parseLong(value);
                newPredicate = cb.or(newPredicate, cb.equal(path, numericValue));
            } catch (NumberFormatException e) {
                continue;
            }
        }
        return cb.and(predicate, newPredicate);
    }

    private static Predicate addGenericPredicate(Predicate predicate, Path<?> path, List<String> values, CriteriaBuilder cb) {
        Predicate newPredicate = cb.disjunction();
        for (String value : values) {
            try {
                Object typedValue = convertStringToType(value, path.getJavaType());
                if (typedValue != null) {
                    newPredicate = cb.or(newPredicate, cb.equal(path, typedValue));
                }
            } catch (Exception e) {
                continue;
            }
        }
        return cb.and(predicate, newPredicate);
    }

    @SuppressWarnings("unchecked")
    private static <T> T convertStringToType(String value, Class<T> type) {
        if (type == String.class) {
            return (T) value;
        } else if (type == Long.class || type == long.class) {
            return (T) Long.valueOf(value);
        } else if (type == Integer.class || type == int.class) {
            return (T) Integer.valueOf(value);
        } else if (type == Double.class || type == double.class) {
            return (T) Double.valueOf(value);
        } else if (type == Boolean.class || type == boolean.class) {
            return (T) Boolean.valueOf(value);
        } else if (type.isEnum()) {
            return (T) Enum.valueOf((Class<Enum>) type, value);
        }
        return null;
    }
}
