package com.airbus.optim.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.CreationTimestamp;

import java.io.Serializable;
import java.time.Instant;
import java.time.ZonedDateTime;

/**
 * A Lever.
 */
@Entity
@Table(name = "lever_snapshot")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class LeverSnapshot implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id")
    @EqualsAndHashCode.Include
    private Long id;

    @NotNull
    @Column(name = "lever_type", nullable = false)
    private String leverType;

    @Column(name = "highlights")
    private String highlights;

    @Column(name = "start_date")
    private Instant startDate;

    @Column(name = "end_date")
    private Instant endDate;

    @Column(name = "f_te")
    private Float fTE;

    @Column(name = "direct")
    private String direct;

    @Column(name = "active_workforce")
    private String activeWorkforce;

    @Column(name = "snapshot_period", length = 7)
    private String snapshotPeriod;

    @Column(name = "created_at", nullable = false, updatable = false)
    @CreationTimestamp
    private ZonedDateTime createdAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "siglum_destination_id", nullable = true)
    @JsonIgnoreProperties(value = { "employee", "employees" }, allowSetters = true)
    private Siglum siglumDestination;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "siglum_origin_id", nullable = true)
    @JsonIgnoreProperties(value = { "employee", "employees" }, allowSetters = true)
    private Siglum siglumOrigin;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id")
    @JsonIgnoreProperties(value = {
        "levers", "siglum", "locations", "jobRequest", "costCenter"
    }, allowSetters = true)
    @ToString.Exclude
    private EmployeeSnapshot employeeSnapshot;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cost_center_id", unique = true)
    @JsonIgnoreProperties(value = {
        "employees", "jobRequests", "workloads", "levers"
    }, allowSetters = true)
    private CostCenter costCenter;

    @Column(name = "siglum_id")
    private Integer siglumId;

    @Column(name = "employee_type")
    private String employeeType;

    @Column(name = "collar")
    private String collar;

    @Column(name = "country")
    private String country;

    public LeverSnapshot(Lever l, EmployeeSnapshot es) {
        this.leverType = l.getLeverType();
        this.highlights = l.getHighlights();
        this.startDate = l.getStartDate();
        this.endDate = l.getEndDate();
        this.siglumDestination = l.getSiglumDestination();
        this.siglumOrigin = l.getSiglumOrigin();
        this.fTE = l.getFTE();
        this.direct = l.getDirect();
        this.activeWorkforce = l.getActiveWorkforce();
        this.costCenter = l.getCostCenter();
        this.employeeSnapshot = es;

        if (es != null) {
            if (es.getSiglum() != null && es.getSiglum().getId() != null) {
                this.siglumId = es.getSiglum().getId().intValue();
            }

            this.employeeType = es.getContractType();
            this.collar = es.getCollar();

            CostCenter cc = es.getCostCenter();
            if (cc != null && cc.getLocation() != null) {
                this.country = cc.getLocation().getCountry();
            }
        }
    }
}
