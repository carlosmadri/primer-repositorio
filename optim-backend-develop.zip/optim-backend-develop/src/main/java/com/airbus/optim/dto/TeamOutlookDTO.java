package com.airbus.optim.dto;

import lombok.Data;

@Data
public class TeamOutlookDTO {
    Float fteActives;
    Float fteNonActives;
    Float leavers;
    Float recoveries;
    Float redeployment;
    Float perimeterChanges;
    Float filled;
    Float opened;
    Float validationProcess;
    Float onHold;
    Float hcCeiling;
    Float internalMobility;
    Float realisticView;
    Float validationView;
    Float optimisticView;
    Float realisticViewAverage;
    Float validationViewAverage;
    Float optimisticViewAverage;
}
