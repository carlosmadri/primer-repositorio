package com.airbus.optim.exception;

public class ApplicationLockException extends RuntimeException {
    public ApplicationLockException(String message) {
        super(message);
    }
}