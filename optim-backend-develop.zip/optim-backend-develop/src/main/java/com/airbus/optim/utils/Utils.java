package com.airbus.optim.utils;

import com.airbus.optim.dto.ExistsOpenedExerciseDTO;
import com.airbus.optim.entity.Employee;
import com.airbus.optim.entity.JobRequest;
import com.airbus.optim.entity.Lever;
import com.airbus.optim.entity.Siglum;
import com.airbus.optim.entity.User;
import com.airbus.optim.entity.Workload;
import com.airbus.optim.entity.WorkloadEvolution;
import com.airbus.optim.repository.EmployeeRepository;
import com.airbus.optim.repository.JobRequestRepository;
import com.airbus.optim.repository.SiglumRepository;
import com.airbus.optim.repository.UserRepository;
import com.airbus.optim.repository.WorkloadEvolutionRepository;
import java.time.LocalDate;
import java.time.ZoneId;

import com.airbus.optim.repository.WorkloadRepository;
import com.airbus.optim.service.EmployeeSpecification;
import com.airbus.optim.service.JobRequestSpecification;
import com.airbus.optim.service.UserService;
import com.airbus.optim.service.WorkloadSpecification;
import jakarta.persistence.criteria.Expression;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class Utils {

    @Autowired
    private SiglumRepository siglumRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private JobRequestRepository jobRequestRepository;

    @Autowired
    private JobRequestSpecification jobRequestSpecification;

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private WorkloadRepository workloadRepository;

    @Autowired
    private WorkloadEvolutionRepository workloadEvolutionRepository;

    @Autowired
    private  Environment env;

    public static String capitalize(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }
        return Arrays.stream(str.toLowerCase().split(" "))
                .map(word -> word.substring(0, 1).toUpperCase() + word.substring(1))
                .collect(Collectors.joining(" "));
    }

    public boolean checkOverlapOfLevers(Lever newLever, Long employeeId) {
        Optional<Employee> employeeOptional = employeeRepository.findById(employeeId);
        if(!employeeOptional.isPresent()){
            return false;
        }

        for (Lever existingLever : employeeOptional.get().getLevers()) {
            if (doLeversOverlap(existingLever, newLever)) {
                return true;
            }
        }
        return false;
    }

    public boolean checkDuplicateLeverType(Lever newLever, Long employeeId) {
        if (newLever.getLeverType() == null || !isRestrictedLeverType(newLever.getLeverType())) {
            return false;
        }

        Optional<Employee> employeeOptional = employeeRepository.findById(employeeId);
        if (!employeeOptional.isPresent()) {
            return false;
        }

        for (Lever existingLever : employeeOptional.get().getLevers()) {
            if (existingLever.getLeverType() != null &&
                    existingLever.getLeverType().equals(newLever.getLeverType()) &&
                    !existingLever.getId().equals(newLever.getId())) {
                return true;
            }
        }

        return false;
    }

    private boolean isRestrictedLeverType(String leverType) {
        return Constants.RESTRICTED_LEVER_TYPES.contains(leverType.toUpperCase());
    }

    private boolean doLeversOverlap(Lever lever1, Lever lever2) {
        Instant start1 = lever1.getStartDate();
        Instant end1 = lever1.getEndDate();
        Instant start2 = lever2.getStartDate();
        Instant end2 = lever2.getEndDate();

        if (start1 == null || end1 == null || start2 == null || end2 == null) {
            return false;
        }

        return start1.isBefore(end2) && end1.isAfter(start2);
    }

    public String getExerciseOP(Integer yearFilter) {
        return Constants.EXERCISE_OPERATION_PLANNING+ Math.floorMod(yearFilter, 100);
    }

    public boolean filterYearComprobation(Integer yearFilter) {
        LocalDate currentDate = LocalDate.now(ZoneId.systemDefault());
        return ((yearFilter < currentDate.getYear()-1) || (yearFilter > currentDate.getYear()+5));
    }

    public List<Siglum> getSiglumVisibilityList() {
        String siglumVisible = getUserFromToken().getSiglumVisible();

        if (siglumVisible == null || siglumVisible.isEmpty()) {
            return Collections.emptyList();
        }

        String[] siglumsArray = siglumVisible.split(",");
        List<Siglum> userSiglumList = new ArrayList<>();

        for (String siglum : siglumsArray) {
            userSiglumList.addAll(getVisibleSiglums(siglum));
        }

        return userSiglumList;
    }

    public List<Siglum> getVisibleSiglums(String siglum) {
        User currentUser = getUserFromToken();

        List<Siglum> visibleSiglums = new ArrayList<>();

        if (currentUser != null) {
            if (isSuperUser()) {
                return siglumRepository.findAll();
            }

            Optional.ofNullable(currentUser.getSiglum())
                    .ifPresent(userSiglum -> visibleSiglums.addAll(
                            siglumRepository.findBySiglumHRStartingWith(userSiglum.getSiglumHR())
                    ));

            Optional.ofNullable(currentUser.getSiglumVisible())
                    .filter(siglums -> !siglums.isEmpty())
                    .ifPresent(visibleSiglumsString -> {
                        List<String> visibleSiglumList = Arrays.stream(visibleSiglumsString.split("[,;]"))
                                .map(String::trim)
                                .toList();
                        visibleSiglums.addAll(siglumRepository.findBySiglumHRIn(visibleSiglumList));
                    });
        }

        if (siglum != null && !siglum.isEmpty()) {
            visibleSiglums.addAll(siglumRepository.findBySiglumHRStartingWith(siglum));
        }

        return visibleSiglums;
    }

    public List<Siglum> getVisibleSiglumsWithFilters(MultiValueMap<String, String> params) {
        List<String> siglumFilters = new ArrayList<>();

        for (Map.Entry<String, List<String>> entry : params.entrySet()) {
            String key = entry.getKey();
            if (key.contains("siglum")) {
                siglumFilters.addAll(entry.getValue());
            }
        }

        if (!siglumFilters.isEmpty()) {
            List<Siglum> filteredSiglums = new ArrayList<>();

            for (String siglumFilter : siglumFilters) {
                filteredSiglums.addAll(siglumRepository.findBySiglumHRStartingWith(siglumFilter));
            }

            return filteredSiglums;
        }

        return getVisibleSiglums(null);
    }

    public User getUserFromToken() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Optional<User> userOpt = getUserByUsername(authentication.getName());
        return userOpt.orElse(null);
    }

    public boolean isValidateWithCertificateEnabled() {
        return Optional.ofNullable(env.getProperty("app.validateWithCertificate"))
                .map(Boolean::parseBoolean)
                .orElse(false);
    }

    public List<Siglum> getSiglumVisibilityList(User user) {
        if (user == null) {
            return Collections.emptyList();
        }

        if (isSuperUser()) {
            return siglumRepository.findAll();
        }

        List<Siglum> visibleSiglums = new ArrayList<>();

        if (user.getSiglum() != null) {
            visibleSiglums.addAll(
                    siglumRepository.findBySiglumHRStartingWith(user.getSiglum().getSiglumHR())
            );
        }

        String siglumVisible = user.getSiglumVisible();
        if (siglumVisible != null && !siglumVisible.isEmpty()) {
            List<String> visibleSiglumList = Arrays.stream(siglumVisible.split("[,;]"))
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .toList();

            if (!visibleSiglumList.isEmpty()) {
                visibleSiglums.addAll(siglumRepository.findBySiglumHRIn(visibleSiglumList));
            }
        }

        return visibleSiglums;
    }

    public List<GrantedAuthority> getAuthoritiesFromRoles(String rolesString) {
        if (rolesString == null || rolesString.trim().isEmpty()) {
            return Collections.emptyList();
        }

        return Arrays.stream(rolesString.split(","))
                .map(String::trim)
                .filter(role -> !role.isEmpty())
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());
    }

    public Optional<User> getUserByUsername(String username) {
        if (username.contains("@")) {
            return userRepository.findOneByEmailIgnoreCase(username);
        }
        return userRepository.findOneByLoginIgnoreCase(username);
    }

    public boolean isSuperUser() {
        User currentUser = getUserFromToken();

        if (currentUser != null && currentUser.getRoles() != null) {
            String roles = currentUser.getRoles();
            for (String superUserRole : Constants.SUPER_USER_ROLE) {
                if (roles.toLowerCase().contains(superUserRole.toLowerCase())) {
                    return true;
                }
            }
        }

        return false;
    }

    public List<Siglum> getEditableSiglums() {
        List<Siglum> siglumVisible = null;

        if (isSuperUser()) {
            return getVisibleSiglums(null);
        } else {
            Siglum mySiglum = getUserFromToken().getSiglum();
            siglumVisible = List.of(mySiglum);
        }

        String lastExercise = "";
        try {
            lastExercise = getLastOpenedExerciseOrThrow().getExercise();
        } catch (Exception e) {
            return Collections.emptyList();
        }

        return workloadEvolutionRepository.findSiglumBySiglumAndStatusAndExerciseIn(siglumVisible, Constants.TARGET_STATUS, lastExercise);
    }

    public String getNumberSiglums() {
        User currentUser = getUserFromToken();
        Siglum siglum = currentUser.getSiglum();

        if (siglum == null) {
            throw new IllegalArgumentException("Siglum not found for the current user");
        }

        if (!Objects.equals(siglum.getSiglumHR(), siglum.getSiglum6())) {
            return Constants.USER_SIGLUM_HR;
        }
        if (!Objects.equals(siglum.getSiglum6(), siglum.getSiglum5())) {
            return Constants.USER_SIGLUM_6;
        }
        if (!Objects.equals(siglum.getSiglum5(), siglum.getSiglum4())) {
            return Constants.USER_SIGLUM_5;
        }
        if (!Objects.equals(siglum.getSiglum4(), siglum.getSiglum3())) {
            return Constants.USER_SIGLUM_4;
        }
        return Constants.USER_SIGLUM_3;
    }

    public ExistsOpenedExerciseDTO existsOpenedExercise() {
        try {
            getLastOpenedExerciseOrThrow();
            return new ExistsOpenedExerciseDTO(true);
        } catch(Exception e){
            return new ExistsOpenedExerciseDTO(false);
        }
    }

    public WorkloadEvolution getLastOpenedExerciseOrThrow() {
        List<WorkloadEvolution> openedExercises = workloadEvolutionRepository.findByStatusAndExerciseNotInClosed(
                Constants.WORKLOAD_EVOLUTION_STATUS_OPENED,
                Constants.WORKLOAD_EVOLUTION_STATUS_CLOSED
        );

        if (openedExercises == null || openedExercises.isEmpty()) {
            throw new IllegalArgumentException("No opened exercise found.");
        }

        return workloadEvolutionRepository.findTopByStatusOrderBySubmitDateDesc(Constants.WORKLOAD_EVOLUTION_STATUS_OPENED)
                .orElseThrow(() -> new IllegalArgumentException("No opened exercise found."));
    }

    public List<Employee> getFilteredEmployees(MultiValueMap<String, String> params) {
        List<Siglum> visibleSiglum = getVisibleSiglums(null);

        Specification<Employee> siglumEmployeeSpec = GenericSpecifications.withSiglumIn(visibleSiglum, Constants.SIGLUM_STATIC_NAME);
        Specification<Employee> spec = EmployeeSpecification.getSpecifications(params).and(siglumEmployeeSpec);
        List<Employee> employees = employeeRepository.findAll(spec);

        return employees;
    }

    public List<JobRequest> getFilteredJobRequest(MultiValueMap<String, String> params, Integer yearFilter) {
        Specification<JobRequest> jobRequestSpec = buildJobRequestSpecification(params, yearFilter);
        return jobRequestRepository.findAll(jobRequestSpec);
    }

    public List<Workload> getFilteredWorkload(MultiValueMap<String, String> params, Integer yearFilter) {
        Specification<Workload> workloadSpec = buildWorkloadSpecification(params, yearFilter);
        return workloadRepository.findAll(workloadSpec);
    }

    public Specification<JobRequest> buildJobRequestSpecification(MultiValueMap<String, String> params,
                                                                  Integer yearFilter) {
        Specification<JobRequest> spec = jobRequestSpecification.getSpecifications(params);

        List<Siglum> visibleSiglum = getVisibleSiglums(null);
        Specification<JobRequest> siglumJobRequestSpec = GenericSpecifications.withSiglumIn(visibleSiglum, Constants.SIGLUM_STATIC_NAME);
        spec = spec.and(siglumJobRequestSpec);

        if (yearFilter != null) {
            spec = spec.and((root, query, criteriaBuilder) -> {
                Expression<Integer> startYear = criteriaBuilder.function("date_part", Integer.class,
                        criteriaBuilder.literal("year"),
                        root.get("startDate"));

                Expression<Integer> postingYear = criteriaBuilder.function("date_part", Integer.class,
                        criteriaBuilder.literal("year"),
                        root.get("postingDate"));

                Expression<Integer> yearFilterExpression = criteriaBuilder.literal(yearFilter);
                return criteriaBuilder.or(
                        criteriaBuilder.and(
                                criteriaBuilder.lessThanOrEqualTo(startYear, yearFilterExpression),
                                criteriaBuilder.greaterThanOrEqualTo(postingYear, yearFilterExpression)
                        ),
                        criteriaBuilder.equal(startYear, yearFilterExpression),
                        criteriaBuilder.equal(postingYear, yearFilterExpression)
                );
            });
        }

        return spec;
    }

    public Specification<Workload> buildWorkloadSpecification(MultiValueMap<String, String> params,
                                                              Integer yearFilter) {
        Specification<Workload> spec = WorkloadSpecification.getSpecifications(params);

        List<Siglum> visibleSiglum = getVisibleSiglums(null);
        Specification<Workload> siglumWorkloadSpec = GenericSpecifications.withSiglumIn(visibleSiglum, Constants.SIGLUM_STATIC_NAME);
        spec = spec.and(siglumWorkloadSpec);

        if (yearFilter != null) {
            spec = spec.and((root, query, criteriaBuilder) -> {
                Expression<Integer> startYear = criteriaBuilder.function("date_part", Integer.class,
                        criteriaBuilder.literal("year"),
                        root.get("startDate"));

                Expression<Integer> endYear = criteriaBuilder.function("date_part", Integer.class,
                        criteriaBuilder.literal("year"),
                        root.get("endDate"));

                Expression<Integer> yearFilterExpression = criteriaBuilder.literal(yearFilter);
                return criteriaBuilder.or(
                        criteriaBuilder.and(
                                criteriaBuilder.lessThanOrEqualTo(startYear, yearFilterExpression),
                                criteriaBuilder.greaterThanOrEqualTo(endYear, yearFilterExpression)
                        ),
                        criteriaBuilder.equal(startYear, yearFilterExpression),
                        criteriaBuilder.equal(endYear, yearFilterExpression)
                );
            });
        }

        return spec;
    }
}
