package com.airbus.optim.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.CreationTimestamp;

import java.io.Serializable;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * A JobRequestSnapshot.
 */
@Entity
@Table(name = "job_request_snapshot")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class JobRequestSnapshot implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    @EqualsAndHashCode.Include
    private Long id;

    @Column(name = "workday_number")
    private String workdayNumber;

    @Column(name = "type")
    private String type;

    @Column(name = "status")
    private String status;

    @Column(name = "description")
    private String description;

    @Column(name = "candidate")
    private String candidate;

    @Column(name = "start_date")
    private Instant startDate;

    @Column(name = "release_date")
    private Instant releaseDate;

    @Column(name = "posting_date")
    private Instant postingDate;

    @Column(name = "external")
    private Boolean external;

    @Column(name = "early_career")
    private Boolean earlyCareer;

    @Column(name = "on_top_hct")
    private Boolean onTopHct;

    @Column(name = "is_critical")
    private Boolean isCritical;

    @Column(name = "active_workforce")
    private String activeWorkforce;

    @Column(name = "approved_qmc")
    private Boolean approvedQMC;

    @Column(name = "approved_shrbph1q")
    private Boolean approvedSHRBPHOT1Q;

    @Column(name = "approved_hocoohohrcoo")
    private Boolean approvedHOCOOHOHRCOO;

    @Column(name = "approved_employment_commitee")
    private Boolean approvedEmploymentCommitee;

    @Column(name = "direct")
    private String direct;

    @Column(name = "collar", length = 10)
    private String collar;

    @Column(name = "snapshot_period", length = 7)
    private String snapshotPeriod;

    @Column(name = "created_at", nullable = false, updatable = false)
    @CreationTimestamp
    private ZonedDateTime createdAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "siglum_id")
    @JsonIgnoreProperties(value = { "jobRequests", "headCounts", "purchaseOrders" }, allowSetters = true)
    @ToString.Exclude
    private Siglum siglum;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "jobRequestSnapshot", orphanRemoval = true)
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    @JsonIgnore
    @ToString.Exclude
    private List<EmployeeSnapshot> employeesSnapshot = new ArrayList<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cost_center_id")
    @JsonIgnoreProperties(value = { "jobRequests", "levers" }, allowSetters = true)
    @ToString.Exclude
    private CostCenter costCenter;

    public JobRequestSnapshot(JobRequest jr) {
        this.workdayNumber = jr.getWorkdayNumber();
        this.type = jr.getType();
        this.status = jr.getStatus();
        this.description = jr.getDescription();
        this.candidate = jr.getCandidate();
        this.startDate = jr.getStartDate();
        this.postingDate = jr.getPostingDate();
        this.external = jr.getExternal();
        this.earlyCareer = jr.getEarlyCareer();
        this.onTopHct = jr.getOnTopHct();
        this.isCritical = jr.getIsCritical();
        this.activeWorkforce = jr.getActiveWorkforce();
        this.approvedQMC = jr.getApprovedQMC();
        this.approvedSHRBPHOT1Q = jr.getApprovedSHRBPHOT1Q();
        this.approvedHOCOOHOHRCOO = jr.getApprovedHOCOOHOHRCOO();
        this.approvedEmploymentCommitee = jr.getApprovedEmploymentCommitee();
        this.siglum = jr.getSiglum();
        this.direct = jr.getDirect();
        this.releaseDate = jr.getReleaseDate();
        this.collar = jr.getCollar();
        this.costCenter = jr.getCostCenter();
    }
}
