package com.airbus.optim.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class WorkloadMonthlyDistributionExerciseDTO {
    List<Double> op;
    List<Double> fcii;
    List<Double> wip;
    String wipValue;
}
