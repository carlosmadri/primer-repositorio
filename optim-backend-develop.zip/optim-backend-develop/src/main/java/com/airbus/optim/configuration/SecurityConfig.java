package com.airbus.optim.configuration;

import com.airbus.optim.auth.filter.ApplicationLockFilter;
import com.airbus.optim.filter.TokenValidationFilter;
import com.airbus.optim.service.PageLockService;
import com.airbus.optim.utils.TokenValidator;
import com.airbus.optim.utils.Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Configuration
public class SecurityConfig {

    @Value("${app.cors.allowed-origin}")
    private String allowedOrigin;
    private static final String AUTH_PATH = "/auth/**";
    private static final String ERROR_GENERIC_PATH = "/error/**";
    private static final String HEALTH_CHECK_WHITELIST = "/api/optim/actuator/**";
    private static final String ERROR_PATH = "/error/403";
    private static final String LOCK_API_PATH = "/api/optim/page-lock/**";
    private static final String SNAPSHOT_API_PATH = "/api/optim/snapshot/**";
    private static final String SNAPSHOT_PERIODS_API_PATH = "/api/optim/snapshot/periods";
    private static final String USER_PROPERTIES_API_PATH = "/api/optim/user/**";
    private static final String DATA_SYNC_IMPORT_API_PATH = "/api/optim/data-sync/import";
    private static final String DATA_SYNC_EXPORT_API_PATH = "/api/optim/data-sync/export";

    private static final String V3_API_DOCS_PATH = "/v3/api-docs/**";
    private static final String SWAGGER_UI_PATH = "/swagger-ui/**";
    private static final String SWAGGER_UI_HTML_PATH = "/swagger-ui.html";
    private static final String AUTH_LOGIN_PATH = "/auth/login";
    private static final String API_OPTIM_V3_API_DOCS_PATH = "/api/optim/v3/api-docs/**";
    private static final String API_OPTIM_SWAGGER_UI_PATH = "/api/optim/swagger-ui/**";
    private static final String API_OPTIM_SWAGGER_UI_HTML_PATH = "/api/optim/swagger-ui.html";
    private static final String API_OPTIM_AUTH_LOGIN_PATH = "/api/optim/auth/login";

    private static final List<String> ALLOWED_METHODS = List.of("GET", "POST", "PUT", "DELETE");
    private static final List<String> ALLOWED_HEADERS = List.of("Authorization", "Content-Type");

    private static final String[] SWAGGER_WHITELIST = {
            V3_API_DOCS_PATH,
            SWAGGER_UI_PATH,
            SWAGGER_UI_HTML_PATH,
            AUTH_LOGIN_PATH,
            API_OPTIM_V3_API_DOCS_PATH,
            API_OPTIM_SWAGGER_UI_PATH,
            API_OPTIM_SWAGGER_UI_HTML_PATH,
            API_OPTIM_AUTH_LOGIN_PATH
    };

    private static final String[] LOCK_EXCLUDED_PATHS = {
            AUTH_PATH,
            LOCK_API_PATH + "/status",
            LOCK_API_PATH + "/deactivate",
            ERROR_GENERIC_PATH,
            HEALTH_CHECK_WHITELIST,
            SNAPSHOT_API_PATH,
            SNAPSHOT_PERIODS_API_PATH,
            USER_PROPERTIES_API_PATH,
            DATA_SYNC_IMPORT_API_PATH,
            DATA_SYNC_EXPORT_API_PATH
    };

    @Autowired
    private TokenValidator tokenValidator;
    @Autowired
    private PageLockService pageLockService;
    @Autowired
    private Utils utils;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(AUTH_PATH).permitAll()
                .requestMatchers(SWAGGER_WHITELIST).permitAll()
                .requestMatchers(new AntPathRequestMatcher(HEALTH_CHECK_WHITELIST)).permitAll()
                .requestMatchers(new AntPathRequestMatcher(ERROR_GENERIC_PATH)).permitAll()
                .requestMatchers(new AntPathRequestMatcher(LOCK_API_PATH + "/status")).permitAll()
                .anyRequest().authenticated()
            )
            .exceptionHandling(ex -> ex
                .authenticationEntryPoint((request, response, authException) -> {
                    if (SecurityContextHolder.getContext().getAuthentication() == null) {
                        response.sendRedirect(ERROR_PATH);
                    }
                })
            );

        http.addFilterBefore(applicationLockFilter(), UsernamePasswordAuthenticationFilter.class);
        http.addFilterBefore(new TokenValidationFilter(tokenValidator, utils), UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of(allowedOrigin));
        config.setAllowedMethods(ALLOWED_METHODS);
        config.setAllowedHeaders(ALLOWED_HEADERS);
        config.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }

    @Bean
    public FilterRegistrationBean<ApplicationLockFilter> applicationLockFilterRegistration() {
        FilterRegistrationBean<ApplicationLockFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(applicationLockFilter());
        registrationBean.setOrder(1);
        registrationBean.addUrlPatterns("/*");
        registrationBean.setEnabled(true);
        return registrationBean;
    }

    @Bean
    public FilterRegistrationBean<TokenValidationFilter> tokenValidationFilterRegistration() {
        FilterRegistrationBean<TokenValidationFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(tokenValidationFilter());
        registrationBean.setOrder(2);
        registrationBean.addUrlPatterns("/*");
        registrationBean.setEnabled(true);
        return registrationBean;
    }

    @Bean
    public TokenValidationFilter tokenValidationFilter() {
        return new TokenValidationFilter(tokenValidator, utils);
    }
  
    @Bean
    public ApplicationLockFilter applicationLockFilter() {
        List<String> excludedPaths = new ArrayList<>();
        excludedPaths.addAll(Arrays.asList(LOCK_EXCLUDED_PATHS));
        excludedPaths.addAll(Arrays.asList(SWAGGER_WHITELIST));
        return new ApplicationLockFilter(pageLockService, excludedPaths);
    }   
}