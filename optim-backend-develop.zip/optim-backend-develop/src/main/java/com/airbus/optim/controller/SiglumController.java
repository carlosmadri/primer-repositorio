package com.airbus.optim.controller;

import com.airbus.optim.entity.Siglum;
import com.airbus.optim.service.SiglumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("siglums")
public class SiglumController {

    @Autowired
    private SiglumService siglumService;

    @GetMapping
    public ResponseEntity<Page<Siglum>> getAllSiglums(Pageable pageable) {
        Page<Siglum> siglumPage = siglumService.getAllSiglums(pageable);
        return ResponseEntity.ok(siglumPage);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Siglum> getSiglumById(@PathVariable Long id) {
        return siglumService.getSiglumById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/visible-siglum")
    public ResponseEntity<List<Siglum>> getVisibleSiglums(
            @RequestParam(required = false) String siglumHR) {
        return ResponseEntity.ok(siglumService.getVisibleSiglums(siglumHR));
    }

    @PostMapping
    public ResponseEntity<Siglum> createSiglum(@RequestBody Siglum siglum) {
        Siglum savedSiglum = siglumService.saveOrUpdateSiglum(siglum);
        return new ResponseEntity<>(savedSiglum, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Siglum> updateSiglum(@PathVariable Long id, @RequestBody Siglum siglumDetails) {
        return siglumService.updateSiglum(id, siglumDetails)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSiglum(@PathVariable Long id) {
        boolean deleted = siglumService.deleteSiglum(id);
        return deleted ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}

