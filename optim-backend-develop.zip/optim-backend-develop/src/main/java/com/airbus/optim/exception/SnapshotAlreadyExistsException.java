package com.airbus.optim.exception;

public class SnapshotAlreadyExistsException extends RuntimeException {
    public SnapshotAlreadyExistsException(String message) {
        super(message);
    }
}