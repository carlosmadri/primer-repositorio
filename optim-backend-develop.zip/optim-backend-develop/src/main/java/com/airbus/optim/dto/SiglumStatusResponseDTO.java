package com.airbus.optim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SiglumStatusResponseDTO {
    List<String> pendingList;
    List<String> approvedList;
    List<String> rejectedList;
}
