package com.airbus.optim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class WorkloadPerProgramDTO {
    String programName;
    double programKHrsSum;
    double programsCount;
}
