package com.airbus.optim.repository;

import com.airbus.optim.entity.LeverSnapshot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Spring Data JPA repository for the LeverSnapshot entity, exposed as a REST resource.
 */
@Repository
public interface LeverSnapshotRepository extends JpaRepository<LeverSnapshot, Long>,
        JpaSpecificationExecutor<LeverSnapshot>,
        IdentifiableRepository<LeverSnapshot> {

    @Query(value = "SELECT COALESCE(MAX(e.id), 0) + 1 FROM lever_snapshot e", nativeQuery = true)
    Long findNextAvailableId();

    List<LeverSnapshot> findBySnapshotPeriod(String snapshotPeriod);
}

