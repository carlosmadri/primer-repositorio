package com.airbus.optim.auth.filter;

import com.airbus.optim.dto.PageLockResponse;
import com.airbus.optim.service.PageLockService;
import org.springframework.core.Ordered;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

public class ApplicationLockFilter extends OncePerRequestFilter implements Ordered {

    private final PageLockService pageLockService;
    private final RequestMatcher excludedPaths;

    public ApplicationLockFilter(PageLockService pageLockService, List<String> excludedPathPatterns) {
        this.pageLockService = pageLockService;

        List<RequestMatcher> matchers = excludedPathPatterns.stream()
                .map(AntPathRequestMatcher::new)
                .collect(Collectors.toList());

        this.excludedPaths = new OrRequestMatcher(matchers.toArray(new RequestMatcher[0]));
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws IOException, jakarta.servlet.ServletException {

        if (excludedPaths.matches(request)) {
            filterChain.doFilter(request, response);
            return;
        }

        PageLockResponse lockStatus = pageLockService.getApplicationLockStatus();

        if (lockStatus != null && lockStatus.isLocked()) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.setContentType("application/json");
            response.getWriter().write("{\"error\":\"Maintenance Lock\", " +
                    "\"message\":\"The application is temporarily locked for maintenance.\"}");
            return;
        }

        filterChain.doFilter(request, response);
    }

    @Override
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE - 20;
    }
}
