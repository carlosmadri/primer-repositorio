package com.airbus.optim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PageLockResponse {
    Long id;
    boolean locked;
    String lockId;
    String lockedBy;
    LocalDateTime lockedAt;
    LocalDateTime unlockedAt;

    public boolean isLocked() {
        if(lockedAt == null) return false;
        return lockedAt != null && unlockedAt == null;
    }
}
