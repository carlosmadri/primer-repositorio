package com.airbus.optim.service;

import com.airbus.optim.entity.CostCenter;
import com.airbus.optim.entity.Employee;
import com.airbus.optim.entity.JobRequest;
import com.airbus.optim.entity.Lever;
import com.airbus.optim.entity.Location;
import com.airbus.optim.entity.PageLock;
import com.airbus.optim.entity.Siglum;
import com.airbus.optim.exception.ApplicationLockException;
import com.airbus.optim.repository.CostCenterRepository;
import com.airbus.optim.repository.EmployeeRepository;
import com.airbus.optim.repository.JobRequestRepository;
import com.airbus.optim.repository.LeverRepository;
import com.airbus.optim.repository.PageLockRepository;
import com.airbus.optim.repository.SiglumRepository;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import java.io.ByteArrayOutputStream;
import java.time.Instant;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.StreamSupport;

@Service
@Slf4j
public class DataSyncService {

    private Map<Long, Employee> employeeReferences = new HashMap<>();
    private Map<Long, Lever> leverReferences = new HashMap<>();
    private Map<Long, JobRequest> jobRequestReferences = new HashMap<>();

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private LeverRepository leverRepository;

    @Autowired
    private JobRequestRepository jobRequestRepository;

    @Autowired
    private EmployeeSpecification employeeSpecification;

    @Autowired
    private DynamicDataService dynamicDataService;

    @Autowired
    private SiglumRepository siglumRepository;

    @Autowired
    private CostCenterRepository costCenterRepository;

    @Autowired
    private PageLockRepository pageLockRepository;

    public byte[] generateDataSinc(MultiValueMap<String, String> params) {
        var template = Optional
                .ofNullable(getClass().getClassLoader().getResourceAsStream("templates/DataUpdateTemplate.xlsm"))
                .orElseThrow(() -> new IllegalArgumentException("Template file not found"));

        try (var workbook = WorkbookFactory.create(template)) {
            var employees = employeeRepository.findAll(employeeSpecification.getSpecifications(params));
            var levers = leverRepository.findAll();
            var jobRequests = jobRequestRepository.findAll();

            var sheets = Map.of("Employees", workbook.getSheet("Employees"), "Levers", workbook.getSheet("Levers"),
                    "Job Requests", workbook.getSheet("Job Requests"));

            if (sheets.values().stream().anyMatch(Objects::isNull)) {
                throw new IllegalStateException("One or more required sheets are missing in the Excel template");
            }

            var cellStyle = workbook.createCellStyle();
            cellStyle.setBorderBottom(BorderStyle.THIN);
            cellStyle.setBorderTop(BorderStyle.THIN);
            cellStyle.setBorderLeft(BorderStyle.THIN);
            cellStyle.setBorderRight(BorderStyle.THIN);

            var validMonths = generateMonthYearList();

            fillSheetWithData(sheets.get("Employees"), employees, cellStyle, validMonths);
            fillSheetWithData(sheets.get("Levers"), levers, cellStyle, validMonths);
            fillSheetWithData(sheets.get("Job Requests"), jobRequests, cellStyle, validMonths);

            var hiddenSheet = Optional.ofNullable(workbook.getSheet("HiddenData"))
                    .orElseGet(() -> workbook.createSheet("HiddenData"));

            workbook.setSheetHidden(workbook.getSheetIndex(hiddenSheet), true);

            PageLock pageLock = pageLockRepository.findTopByOrderByCreatedAtDesc()
                    .orElseThrow(() -> new IllegalStateException("No registered PageLock was found"));
            String lockCode = pageLock.getLockId();

            // Sign Excel in cell Z1000 (row 999, column 25)
            Row lockRow = Optional.ofNullable(hiddenSheet.getRow(999)).orElseGet(() -> hiddenSheet.createRow(999));
            Cell lockCell = lockRow.createCell(25);
            lockCell.setCellValue("PAGE_LOCK:" + lockCode);

            try (var output = new ByteArrayOutputStream()) {
                workbook.write(output);
                return output.toByteArray();
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate Excel export", e);
        }
    }

    private List<String> generateMonthYearList() {
        var formatter = DateTimeFormatter.ofPattern("yyyy-MM");
        var start = YearMonth.now();
        return IntStream.range(0, 60).mapToObj(i -> start.plusMonths(i).format(formatter)).toList();
    }

    private <T> void fillSheetWithData(Sheet sheet, List<T> data, CellStyle cellStyle, List<String> validMonths) {
        if (sheet == null) return;

        if (data == null || data.isEmpty()) {
            var headers = getHeadersForType(sheet.getSheetName());
            if (!headers.isEmpty()) {
                var headerRow = sheet.createRow(0);
                IntStream.range(0, headers.size()).forEach(i -> {
                    var cell = headerRow.createCell(i);
                    cell.setCellValue(headers.get(i));
                    cell.setCellStyle(cellStyle);
                });

                switch (sheet.getSheetName()) {
                    case "Employees" -> fillSheetWithData(sheet, List.of(new Employee()), cellStyle, validMonths);
                    case "Levers" -> fillSheetWithData(sheet, List.of(new Lever()), cellStyle, validMonths);
                    case "Job Requests" -> fillSheetWithData(sheet, List.of(new JobRequest()), cellStyle, validMonths);
                    default -> {
                    }
                }
            }
            return;
        }

        var headerRow = sheet.createRow(0);
        var headers = getHeadersForType(data.get(0));

        IntStream.range(0, headers.size()).forEach(i -> {
            var cell = headerRow.createCell(i);
            cell.setCellValue(headers.get(i));
            cell.setCellStyle(cellStyle);
        });

        var updatedColumnIndex = headers.size();
        var updatedHeader = headerRow.createCell(updatedColumnIndex);
        updatedHeader.setCellValue("Updated");
        updatedHeader.setCellStyle(cellStyle);

        IntStream.range(0, data.size()).forEach(i -> {
            var row = sheet.createRow(i + 1);
            fillRowData(row, data.get(i), cellStyle);
            var updatedCell = row.createCell(updatedColumnIndex);
            updatedCell.setCellValue("");
            updatedCell.setCellStyle(cellStyle);
        });

        var fieldToOptionsMap = new HashMap<String, String>();
        fieldToOptionsMap.put("Cost Center ID", "cost_centers");
        fieldToOptionsMap.put("Siglum Origin ID", "siglums");
        fieldToOptionsMap.put("Siglum Destination ID", "siglums");
        fieldToOptionsMap.put("Siglum ID", "siglums");
        if ("Levers".equals(sheet.getSheetName())) {
            fieldToOptionsMap.put("Employee ID", "employees");
        }

        fieldToOptionsMap.forEach((header, source) -> {
            var index = headers.indexOf(header);
            if (index >= 0) {
                var options = getForeignKeyOptions(source);
                addDropdownToSheet(sheet, options, index, header);
                addFormulaColumn(sheet, index);
            }
        });

        if ("Job Requests".equals(sheet.getSheetName())) {
            var dynamicFields = Map.of(
                    "Active Workforce", dynamicDataService.getActiveWorkforceOptions(),
                    "Collar", dynamicDataService.getCollarOptions(),
                    "Status", dynamicDataService.getStatusOptions(),
                    "Type", dynamicDataService.getTypeOptions()
            );
            dynamicFields.forEach((header, options) -> {
                var index = headers.indexOf(header);
                if (index >= 0) {
                    addDropdownToSheet(sheet, options, index, header);
                }
            });

            var booleanFields = List.of(
                    "External", "Early Career", "On Top HCT", "Approved SHRBP H1Q",
                    "Critical", "Approved QMC", "Approved HOCOOHOHRCOO", "Approved Employment Committee"
            );
            booleanFields.forEach(header -> {
                var index = headers.indexOf(header);
                if (index >= 0) {
                    addDropdownToSheet(sheet, List.of("true", "false"), index, header);
                }
            });

            var startCol = headers.indexOf("Start Date");
            var releaseCol = headers.indexOf("Release Date");
            if (startCol >= 0) {
                addDropdownToSheet(sheet, validMonths, startCol, "Start Date");
            }
            if (releaseCol >= 0) {
                addDropdownToSheet(sheet, validMonths, releaseCol, "Release Date");
            }
        }

        if ("Levers".equals(sheet.getSheetName())) {
            var dynamicFields = Map.of(
                    "Active Workforce", dynamicDataService.getActiveWorkforceOptionsForLevers(),
                    "Direct", dynamicDataService.getDirectOptionsForLevers(),
                    "Lever Type", dynamicDataService.getLeverTypeOptionsForLevers()
            );
            dynamicFields.forEach((header, options) -> {
                var index = headers.indexOf(header);
                if (index >= 0) {
                    addDropdownToSheet(sheet, options, index, header);
                }
            });

            var startCol = headers.indexOf("Start Date");
            var endCol = headers.indexOf("End Date");
            if (startCol >= 0) {
                addDropdownToSheet(sheet, validMonths, startCol, "Start Date");
            }
            if (endCol >= 0) {
                addDropdownToSheet(sheet, validMonths, endCol, "End Date");
            }
        }

        if ("Employees".equals(sheet.getSheetName())) {
            var dynamicFields = Map.of(
                    "Availability Reason", dynamicDataService.getAvailabilityReasonOptions(),
                    "Active Workforce", dynamicDataService.getActiveWorkforceOptionsForEmployees(),
                    "Collar", dynamicDataService.getCollarOptionsForEmployees(),
                    "Direct", dynamicDataService.getDirectOptionsForEmployees(),
                    "Contract Type", dynamicDataService.getContractTypeOptionsForEmployees(),
                    "Job", dynamicDataService.getJobOptionsForEmployees()
            );
            dynamicFields.forEach((header, options) -> {
                var index = headers.indexOf(header);
                if (index >= 0) {
                    addDropdownToSheet(sheet, options, index, header);
                }
            });
        }
    }

    private void addFormulaColumn(Sheet sheet, int columnIndex) {
        IntStream.rangeClosed(1, sheet.getLastRowNum()).forEach(rowIndex -> Optional.ofNullable(sheet.getRow(rowIndex))
                .flatMap(row -> Optional.ofNullable(row.getCell(columnIndex))).ifPresent(cell -> {
                    // (no-op)
                }));
    }

    private List<String> getForeignKeyOptions(String tableName) {
        var options = new ArrayList<String>();

        switch (tableName) {
            case "cost_centers" -> costCenterRepository.findAll()
                    .forEach(c -> options.add(c.getId() + " - " + c.getCostCenterFinancialCode()));
            case "siglums" -> siglumRepository.findAll().forEach(s -> options.add(s.getId() + " - " + s.getSiglumHR()));
            case "employees" -> employeeRepository.findAll().forEach(e -> {
                var fullName = e.getFirstName() + " " + e.getLastName();
                options.add(e.getId() + " - " + fullName);
            });
            default -> {
            }
        }

        return options;
    }

    private void addDropdownToSheet(Sheet sheet, List<String> options, int columnIndex, String columnHeader) {
        if (options == null || options.isEmpty()) {
            return;
        }

        var workbook = sheet.getWorkbook();
        var validationHelper = sheet.getDataValidationHelper();
        var hiddenSheet = Optional.ofNullable(workbook.getSheet("HiddenData"))
                .orElseGet(() -> workbook.createSheet("HiddenData"));

        var listStartRow = hiddenSheet.getLastRowNum() + 1;

        for (var i = 0; i < options.size(); i++) {
            var row = hiddenSheet.createRow(listStartRow + i);
            var cell = row.createCell(0);
            cell.setCellValue(options.get(i));
        }

        var rangeName = "Dropdown_" + columnHeader.replace(" ", "_");
        var existingName = workbook.getName(rangeName);

        if (existingName == null) {
            var namedRange = workbook.createName();
            namedRange.setNameName(rangeName);
            namedRange.setRefersToFormula(
                    "HiddenData!$A$" + (listStartRow + 1) + ":$A$" + (listStartRow + options.size()));
        }

        int maxRows = sheet.getLastRowNum() + 200;
        var addressList = new CellRangeAddressList(1, maxRows, columnIndex, columnIndex);
        var constraint = validationHelper.createFormulaListConstraint(rangeName);
        var validation = validationHelper.createValidation(constraint, addressList);

        validation.setShowErrorBox(true);
        validation.createErrorBox("Error", "Select a value from the list.");

        sheet.addValidationData(validation);
    }

    private <T> List<String> getHeadersForType(T item) {
        List<String> headers;

        if (item instanceof Employee) {
            headers = List.of("ID", "Employee ID", "First Name", "Last Name", "Job", "Contract Type", "FTE", "Direct",
                    "Collar", "Active Workforce", "Availability Reason", "Siglum ID", "Cost Center ID");
        } else if (item instanceof Lever) {
            headers = List.of("ID", "Lever Type", "Highlights", "Start Date", "End Date", "Employee ID",
                    "Siglum Destination ID", "Siglum Origin ID", "FTE", "Direct", "Active Workforce", "Cost Center ID");
        } else if (item instanceof JobRequest) {
            headers = List.of("ID", "Workday Number", "Type", "Status", "Description", "Candidate", "Start Date",
                    "Release Date", "Posting Date", "External", "Early Career", "On Top HCT", "Critical",
                    "Active Workforce", "Approved QMC", "Approved SHRBP H1Q", "Approved HOCOOHOHRCOO",
                    "Approved Employment Committee", "Direct", "Collar", "Siglum ID", "Cost Center ID");
        } else if (item instanceof CostCenter) {
            headers = List.of("ID", "Cost Center Code", "Financial Code", "Efficiency", "Rate Own", "Rate Sub",
                    "Location ID");
        } else if (item instanceof Siglum) {
            headers = List.of("ID", "Siglum HR", "Siglum 6", "Siglum 5", "Siglum 4", "Siglum 3", "Head Count ID",
                    "Purchase Orders ID", "Job Request ID");
        } else if (item instanceof Location) {
            headers = List.of("ID", "Country", "Site", "KAPIS Code", "Purchase Orders ID", "Longitude", "Latitude",
                    "Job Request ID");
        } else {
            headers = List.of();
        }

        return headers;
    }

    private void fillRowData(Row row, Object item, CellStyle cellStyle) {
        if (item instanceof Employee employee) {
            createCell(row, 0, employee.getId(), cellStyle);
            createCell(row, 1, employee.getEmployeeId(), cellStyle);
            createCell(row, 2, employee.getFirstName(), cellStyle);
            createCell(row, 3, employee.getLastName(), cellStyle);
            createCell(row, 4, employee.getJob(), cellStyle);
            createCell(row, 5, employee.getContractType(), cellStyle);
            createCell(row, 6, employee.getFTE(), cellStyle);
            createCell(row, 7, employee.getDirect(), cellStyle);
            createCell(row, 8, employee.getCollar(), cellStyle);
            createCell(row, 9, employee.getActiveWorkforce(), cellStyle);
            createCell(row, 10, employee.getAvailabilityReason(), cellStyle);
            createCell(row, 11, employee.getSiglum() != null ? employee.getSiglum().getId() : null, cellStyle);
            createCell(row, 12, employee.getCostCenter() != null ? employee.getCostCenter().getId() : null, cellStyle);
        } else if (item instanceof Lever lever) {
            createCell(row, 0, lever.getId(), cellStyle);
            createCell(row, 1, lever.getLeverType(), cellStyle);
            createCell(row, 2, lever.getHighlights(), cellStyle);
            createCell(row, 3, lever.getStartDate() != null ? lever.getStartDate().toString() : "", cellStyle);
            createCell(row, 4, lever.getEndDate() != null ? lever.getEndDate().toString() : "", cellStyle);
            createCell(row, 5, lever.getEmployee() != null ? lever.getEmployee().getId() : null, cellStyle);
            createCell(row, 6, lever.getSiglumDestination() != null ? lever.getSiglumDestination().getId() : null,
                    cellStyle);
            createCell(row, 7, lever.getSiglumOrigin() != null ? lever.getSiglumOrigin().getId() : null, cellStyle);
            createCell(row, 8, lever.getFTE(), cellStyle);
            createCell(row, 9, lever.getDirect(), cellStyle);
            createCell(row, 10, lever.getActiveWorkforce(), cellStyle);
            createCell(row, 11, lever.getCostCenter() != null ? lever.getCostCenter().getId() : null, cellStyle);
        } else if (item instanceof JobRequest job) {
            createCell(row, 0, job.getId(), cellStyle);
            createCell(row, 1, job.getWorkdayNumber(), cellStyle);
            createCell(row, 2, job.getType(), cellStyle);
            createCell(row, 3, job.getStatus(), cellStyle);
            createCell(row, 4, job.getDescription(), cellStyle);
            createCell(row, 5, job.getCandidate() != null ? job.getCandidate() : "", cellStyle);
            createCell(row, 6, job.getStartDate() != null ? job.getStartDate().toString() : "", cellStyle);
            createCell(row, 7, job.getReleaseDate() != null ? job.getReleaseDate().toString() : "", cellStyle);
            createCell(row, 8, job.getPostingDate() != null ? job.getPostingDate().toString() : "", cellStyle);
            createCell(row, 9, job.getExternal(), cellStyle);
            createCell(row, 10, job.getEarlyCareer(), cellStyle);
            createCell(row, 11, job.getOnTopHct(), cellStyle);
            createCell(row, 12, job.getIsCritical(), cellStyle);
            createCell(row, 13, job.getActiveWorkforce(), cellStyle);
            createCell(row, 14, job.getApprovedQMC(), cellStyle);
            createCell(row, 15, job.getApprovedSHRBPHOT1Q(), cellStyle);
            createCell(row, 16, job.getApprovedHOCOOHOHRCOO(), cellStyle);
            createCell(row, 17, job.getApprovedEmploymentCommitee(), cellStyle);
            createCell(row, 18, job.getDirect(), cellStyle);
            createCell(row, 19, job.getCollar(), cellStyle);
            createCell(row, 20, job.getSiglum() != null ? job.getSiglum().getId() : null, cellStyle);
            createCell(row, 21, job.getCostCenter() != null ? job.getCostCenter().getId() : null, cellStyle);
        }
    }

    private void createCell(Row row, int columnIndex, Object value, CellStyle cellStyle) {
        var cell = row.createCell(columnIndex);
        if (value instanceof Number number) {
            cell.setCellValue(number.doubleValue());
        } else {
            cell.setCellValue(value != null ? value.toString() : "");
        }
        cell.setCellStyle(cellStyle);
    }

    @Transactional
    public boolean importDataFromExcel(Workbook workbook) {
        PageLock expectedLock = pageLockRepository.findTopByOrderByCreatedAtDesc()
                .orElseThrow(() -> new ApplicationLockException("No registered PageLock was found in the database."));

        String expectedLockCode = "PAGE_LOCK:" + expectedLock.getLockId();

        Sheet hiddenSheet = workbook.getSheet("HiddenData");
        if (hiddenSheet == null) {
            throw new ApplicationLockException("Sheet 'HiddenData' not found in the Excel file.");
        }

        Row lockRow = hiddenSheet.getRow(999);
        if (lockRow == null || lockRow.getCell(25) == null) {
            throw new ApplicationLockException("The file does not contain the lock code (cell Z1000 is empty).");
        }

        String foundCode = lockRow.getCell(25).getStringCellValue().trim();
        if (!expectedLockCode.equals(foundCode)) {
            throw new ApplicationLockException(
                    "Invalid lock code. The file was not generated by the system or has already expired.");
        }

        saveReferencesBeforeDelete();

        deleteExistingData();

        Sheet employeesSheet = workbook.getSheet("Employees");
        Sheet leversSheet = workbook.getSheet("Levers");
        Sheet jobRequestsSheet = workbook.getSheet("Job Requests");

        List<JobRequest> newJobRequests = processJobRequestSheet(jobRequestsSheet);

        insertJobRequests(newJobRequests);

        List<Employee> newEmployees = processEmployeeSheet(employeesSheet);

        insertEmployees(newEmployees);

        List<Employee> savedEmployees = employeeRepository.findAll();
        if (savedEmployees.isEmpty()) {
            throw new IllegalStateException("No employees were inserted. Cannot proceed.\"");
        }

        List<Lever> newLevers = processLeverSheet(leversSheet);

        insertLevers(newLevers);

        return true;

    }

    public void insertJobRequests(List<JobRequest> jobRequests) {
        if (jobRequests == null || jobRequests.isEmpty()) {
            return;
        }

        jobRequestRepository.saveAll(jobRequests);
    }

    public void saveReferencesBeforeDelete() {
        employeeRepository.findAll().forEach(e -> employeeReferences.put(e.getId(), e));
        leverRepository.findAll().forEach(l -> leverReferences.put(l.getId(), l));
        jobRequestRepository.findAll().forEach(j -> jobRequestReferences.put(j.getId(), j));
    }

    public void deleteExistingData() {
        leverRepository.deleteAll();
        jobRequestRepository.deleteAll();
        employeeRepository.deleteAll();
    }

    @Transactional
    public void insertLevers(List<Lever> levers) {
        if (levers == null || levers.isEmpty()) {
            return;
        }

        try {
            leverRepository.saveAll(levers);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private List<Employee> processEmployeeSheet(Sheet sheet) {
        var employees = new ArrayList<Employee>();

        if (sheet == null) {
            return employees;
        }

        for (Row row : sheet) {
            if (row.getRowNum() == 0) {
                continue;
            }

            Long id = getLongCell(row, 0);
            Integer employeeId = getIntegerCell(row, 1);

            if (employeeId == null) {
                continue;
            }

            var employee = new Employee();

            if (id != null) {
                employee.setId(id);

            }

            employee.setEmployeeId(employeeId);
            employee.setFirstName(getStringCell(row, 2));
            employee.setLastName(getStringCell(row, 3));
            employee.setJob(getStringCell(row, 4));
            employee.setContractType(getStringCell(row, 5));
            employee.setFTE(getFloatCell(row, 6));
            employee.setDirect(getStringCell(row, 7));
            employee.setCollar(getStringCell(row, 8));
            employee.setActiveWorkforce(getStringCell(row, 9));
            employee.setAvailabilityReason(getStringCell(row, 10));

            Optional.ofNullable(getLongCell(row, 11)).filter(idSiglum -> idSiglum > 0)
                    .flatMap(siglumRepository::findById).ifPresent(employee::setSiglum);

            Optional.ofNullable(getLongCell(row, 12)).filter(idCc -> idCc > 0).flatMap(costCenterRepository::findById)
                    .ifPresent(employee::setCostCenter);

            Optional.ofNullable(getLongCell(row, 13)).filter(idJr -> idJr > 0).flatMap(jobRequestRepository::findById)
                    .ifPresent(employee::setJobRequest);

            employees.add(employee);
        }

        return employees;
    }

    private Integer getIntegerCell(Row row, int index) {
        return Optional.ofNullable(row).map(r -> r.getCell(index))
                .filter(cell -> cell.getCellType() == CellType.NUMERIC).map(cell -> (int) cell.getNumericCellValue())
                .orElse(null);
    }

    private Float getFloatCell(Row row, int index) {
        return Optional.ofNullable(row).map(r -> r.getCell(index))
                .filter(cell -> cell.getCellType() == CellType.NUMERIC).map(cell -> (float) cell.getNumericCellValue())
                .orElse(null);
    }

    private List<Lever> processLeverSheet(Sheet sheet) {
        if (sheet == null) {
            return List.of();
        }

        var levers = new ArrayList<Lever>();

        for (Row row : sheet) {
            if (row.getRowNum() == 0) {
                continue;
            }

            var id = getLongCell(row, 0);
            var startDate = parseDateCell(row.getCell(3));
            var endDate = parseDateCell(row.getCell(4));
            var employeeId = getLongCell(row, 5);

            if (startDate == null || employeeId == null) {
                continue;
            }

            var lever = new Lever();

            if (id != null) {
                lever.setId(id);

            }

            lever.setLeverType(Optional.ofNullable(getStringCell(row, 1)).orElse("No definido"));
            lever.setHighlights(getStringCell(row, 2));
            lever.setStartDate(startDate.atStartOfDay().toInstant(ZoneOffset.UTC));

            if (endDate != null) {
                lever.setEndDate(endDate.atStartOfDay().toInstant(ZoneOffset.UTC));
            }

            lever.setFTE(getFloatCell(row, 8));
            lever.setDirect(getStringCell(row, 9));
            lever.setActiveWorkforce(getStringCell(row, 10));

            Optional.of(employeeId).flatMap(employeeRepository::findById).ifPresent(lever::setEmployee);

            Optional.ofNullable(getLongCell(row, 6)).flatMap(siglumRepository::findById)
                    .ifPresent(lever::setSiglumDestination);

            Optional.ofNullable(getLongCell(row, 7)).flatMap(siglumRepository::findById)
                    .ifPresent(lever::setSiglumOrigin);

            Optional.ofNullable(getLongCell(row, 11)).flatMap(costCenterRepository::findById)
                    .ifPresent(lever::setCostCenter);

            levers.add(lever);
        }

        return levers;
    }

    private LocalDate parseDateCell(Cell cell) {
        if (cell == null)
            return null;

        if (cell.getCellType() == CellType.NUMERIC && DateUtil.isCellDateFormatted(cell)) {
            return cell.getLocalDateTimeCellValue().toLocalDate();
        } else if (cell.getCellType() == CellType.STRING) {
            String text = cell.getStringCellValue().trim();
            if (text.isEmpty() || text.equalsIgnoreCase("no date")) {
                return null;
            }

            try {

                Instant instant = Instant.parse(text);
                return instant.atZone(ZoneId.systemDefault()).toLocalDate();
            } catch (DateTimeParseException e1) {
                try {

                    if (text.matches("\\d{4}-\\d{1,2}")) {
                        text += "-01";
                    }
                    return LocalDate.parse(text);
                } catch (DateTimeParseException e2) {
                    System.out.println("Unable to parse date: '" + text + "'");
                }
            }
        }

        return null;
    }

    public List<JobRequest> processJobRequestSheet(Sheet sheet) {
        return StreamSupport.stream(sheet.spliterator(), false).skip(1).map(row -> {
            var jr = new JobRequest();

            var id = getLongCell(row, 0);
            if (id != null) {
                jr.setId(id);

            } else {

            }

            jr.setWorkdayNumber(getStringCell(row, 1));
            jr.setType(getStringCell(row, 2));
            jr.setStatus(getStringCell(row, 3));
            jr.setDescription(getStringCell(row, 4));
            jr.setCandidate(getStringCell(row, 5));
            jr.setStartDate(getFlexibleInstantCell(row, 6));
            jr.setReleaseDate(getFlexibleInstantCell(row, 7));
            jr.setPostingDate(getFlexibleInstantCell(row, 8));
            jr.setExternal(getBooleanCell(row, 9));
            jr.setEarlyCareer(getBooleanCell(row, 10));
            jr.setOnTopHct(getBooleanCell(row, 11));
            jr.setIsCritical(getBooleanCell(row, 12));
            jr.setActiveWorkforce(getStringCell(row, 13));
            jr.setApprovedQMC(getBooleanCell(row, 14));
            jr.setApprovedSHRBPHOT1Q(getBooleanCell(row, 15));
            jr.setApprovedHOCOOHOHRCOO(getBooleanCell(row, 16));
            jr.setApprovedEmploymentCommitee(getBooleanCell(row, 17));
            jr.setDirect(getStringCell(row, 18));
            jr.setCollar(getStringCell(row, 19));

            Optional.ofNullable(getLongCell(row, 20)).filter(siglumId -> siglumId > 0)
                    .flatMap(siglumRepository::findById).ifPresent(jr::setSiglum);

            Optional.ofNullable(getLongCell(row, 21)).filter(ccId -> ccId > 0).flatMap(costCenterRepository::findById)
                    .ifPresent(jr::setCostCenter);

            return jr;
        }).collect(Collectors.toList());
    }

    private String getStringCell(Row row, int index) {
        return Optional.ofNullable(row.getCell(index)).filter(c -> c.getCellType() == CellType.STRING)
                .map(c -> c.getStringCellValue().trim()).orElse("");
    }

    private Boolean getBooleanCell(Row row, int index) {
        return Optional.ofNullable(row.getCell(index)).map(cell -> switch (cell.getCellType()) {
            case BOOLEAN -> cell.getBooleanCellValue();
            case STRING -> cell.getStringCellValue().trim().equalsIgnoreCase("true");
            case NUMERIC -> cell.getNumericCellValue() == 1.0;
            default -> null;
        }).orElse(null);
    }

    private Instant getFlexibleInstantCell(Row row, int index) {
        return Optional.ofNullable(row.getCell(index)).map(cell -> {
            if (cell.getCellType() == CellType.NUMERIC) {
                return cell.getLocalDateTimeCellValue().toInstant(ZoneOffset.UTC);
            } else if (cell.getCellType() == CellType.STRING) {
                var text = cell.getStringCellValue().trim();
                if (text.isEmpty() || text.equalsIgnoreCase("no date")) {
                    return null;
                }
                try {
                    return Instant.parse(text);
                } catch (DateTimeParseException e1) {
                    try {
                        var date = LocalDate.parse(text);
                        return date.atStartOfDay().toInstant(ZoneOffset.UTC);
                    } catch (DateTimeParseException ignored) {
                    }
                }
            }
            return null;
        }).orElse(null);
    }

    private Long getLongCell(Row row, int index) {
        var cell = Optional.ofNullable(row.getCell(index)).orElse(null);
        if (cell == null)
            return null;

        return switch (cell.getCellType()) {
            case NUMERIC -> (long) cell.getNumericCellValue();
            case STRING -> {
                try {
                    yield Long.parseLong(cell.getStringCellValue().trim());
                } catch (NumberFormatException e) {
                    yield null;
                }
            }
            default -> null;
        };
    }

    public void insertEmployees(List<Employee> newEmployees) {
        employeeRepository.saveAll(newEmployees);

        var savedEmployees = employeeRepository.findAll();
        if (savedEmployees.isEmpty()) {
            throw new IllegalStateException("ERROR: No employees were inserted into the database.");
        }
    }
}