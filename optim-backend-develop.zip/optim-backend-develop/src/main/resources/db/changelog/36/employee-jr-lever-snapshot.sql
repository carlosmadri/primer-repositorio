DROP TABLE IF EXISTS public.employee_snapshot CASCADE;
DROP TABLE IF EXISTS public.lever_snapshot CASCADE;
DROP TABLE IF EXISTS public.job_request_snapshot CASCADE;
DROP SEQUENCE IF EXISTS public.employee_snapshot_id_seq;
DROP SEQUENCE IF EXISTS public.lever_snapshot_id_seq;
DROP SEQUENCE IF EXISTS public.job_request_snapshot_id_seq;

CREATE SEQUENCE employee_snapshot_id_seq;

CREATE TABLE employee_snapshot (
    id bigint NOT NULL DEFAULT nextval('employee_snapshot_id_seq'::regclass),
    employee_id integer,
    direct character varying(255),
    job character varying(255),
    collar character varying(255),
    last_name character varying(255),
    first_name character varying(255),
    active_workforce character varying(255),
    availability_reason character varying(255),
    contract_type character varying(255),
    f_te double precision,
    job_request_snapshot_id bigint,
    siglum_id bigint,
    impersonal boolean DEFAULT false,
    cost_center_id bigint,
    snapshot_period varchar(7),
    created_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE SEQUENCE lever_snapshot_id_seq;

CREATE TABLE lever_snapshot (
    id bigint NOT NULL DEFAULT nextval('lever_snapshot_id_seq'::regclass),
    lever_type character varying(255) NOT NULL,
    highlights character varying(255),
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    employee_id bigint,
    siglum_destination_id bigint,
    siglum_origin_id bigint,
    f_te double precision,
    direct character varying(255),
    active_workforce character varying(255),
    cost_center_id bigint,
    snapshot_period varchar(7),
    created_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE SEQUENCE job_request_snapshot_id_seq;

CREATE TABLE job_request_snapshot (
    id bigint NOT NULL DEFAULT nextval('job_request_snapshot_id_seq'::regclass),
    workday_number character varying(255),
    type character varying(255),
    status character varying(255),
    description character varying(255),
    candidate character varying(255),
    start_date timestamp without time zone,
    posting_date timestamp without time zone,
    external boolean,
    early_career boolean,
    on_top_hct boolean,
    is_critical boolean,
    active_workforce character varying(255),
    approved_qmc boolean,
    approved_shrbph1q boolean,
    approved_hocoohohrcoo boolean,
    approved_employment_commitee boolean,
    siglum_id bigint,
    direct character varying(255),
    release_date timestamp without time zone,
    collar character varying(10),
    cost_center_id bigint,
    snapshot_period varchar(7),
    created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE ONLY public.employee_snapshot
    ADD CONSTRAINT employee_snapshot_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.lever_snapshot
    ADD CONSTRAINT lever_snapshot_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.job_request_snapshot
    ADD CONSTRAINT job_request_snapshot_pkey PRIMARY KEY (id);