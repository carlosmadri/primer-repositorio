DROP TABLE IF EXISTS public.workload_snapshot CASCADE;
DROP SEQUENCE IF EXISTS public.workload_snapshot_id_seq;

CREATE SEQUENCE public.workload_snapshot_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE TABLE workload_snapshot (
    id bigint DEFAULT nextval('workload_snapshot_id_seq'::regclass) NOT NULL,
    direct VARCHAR(255),
    collar VARCHAR(255),
    own VARCHAR(255),
    core VARCHAR(255),
    go BOOLEAN,
    description VARCHAR(255),
    exercise VARCHAR(255),
    start_date TIMESTAMP,
    end_date TIMESTAMP,
    k_hrs DOUBLE PRECISION,
    f_te DOUBLE PRECISION,
    k_eur DOUBLE PRECISION,
    eac BOOLEAN,
    submit_date TIMESTAMP,
    cost_center_id BIGINT UNIQUE,
    siglum_id BIGINT,
    ppsid_id BIGINT,
    workload_id BIGINT,
    CONSTRAINT fk_cost_center FOREIGN KEY (cost_center_id) REFERENCES cost_center(id),
    CONSTRAINT fk_siglum FOREIGN KEY (siglum_id) REFERENCES siglum(id),
    CONSTRAINT fk_ppsid FOREIGN KEY (ppsid_id) REFERENCES ppsid(id),
    CONSTRAINT fk_workload FOREIGN KEY (workload_id) REFERENCES workload(id)
);
