ALTER TABLE public.optim_user
ADD COLUMN IF NOT EXISTS roles character varying(255);