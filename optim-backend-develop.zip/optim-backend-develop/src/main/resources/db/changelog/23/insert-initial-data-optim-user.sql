INSERT INTO public.optim_user (id, login, password_hash, first_name, last_name, email, activated, lang_key, image_url, activation_key, reset_key, reset_date, created_date, siglum_visible)
VALUES(1, 'admin', '12345','','','admin.airbus.org',false,'','','','','2030-01-01 00:00:00','2024-11-25 00:00:00','T1QTST,T1QA,T1QC,T1QE,T1QM,T1QS');

INSERT INTO public.optim_user (id, login, password_hash, first_name, last_name, email, activated, lang_key, image_url, activation_key, reset_key, reset_date, created_date, siglum_visible)
VALUES(2, 'user', '12345','','','user.airbus.org',false,'','','','','2030-01-01 00:00:00','2024-11-25 00:00:00','T1QTST');