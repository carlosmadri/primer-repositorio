ALTER TABLE workload_snapshot
ADD CONSTRAINT workload_snapshot_pkey PRIMARY KEY (id);
