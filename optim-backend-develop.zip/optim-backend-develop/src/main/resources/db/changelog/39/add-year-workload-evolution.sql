ALTER TABLE workload_evolution ADD COLUMN year INT;
