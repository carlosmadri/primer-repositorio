DROP TABLE IF EXISTS public.page_lock CASCADE;
DROP SEQUENCE IF EXISTS public.page_lock_id_seq;

CREATE SEQUENCE page_lock_id_seq;

CREATE TABLE page_lock (
    id bigint NOT NULL DEFAULT nextval('page_lock_id_seq'::regclass),
    lock_id varchar NOT NULL,
    locked_by character varying(255),
    locked_at timestamp without time zone,
    unlocked_at timestamp without time zone,
    created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE ONLY public.page_lock
    ADD CONSTRAINT page_lock_pkey PRIMARY KEY (id);