INSERT INTO head_count (description, year, f_te, exercise) VALUES ('nan', '2023', 23, 'OP23');
INSERT INTO head_count (description, year, f_te, exercise) VALUES ('explicación, texto libre, para determinar el cambio si se quiere explicar', '2024', 24, 'FCII');
INSERT INTO head_count (description, year, f_te, exercise) VALUES ('nan', '2025', 20, 'OP24');
