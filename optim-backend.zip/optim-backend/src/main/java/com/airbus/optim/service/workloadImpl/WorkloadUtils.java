package com.airbus.optim.service.workloadImpl;

import com.airbus.optim.dto.EvolutionDTO;
import com.airbus.optim.dto.WorkloadFteDTO;
import com.airbus.optim.dto.WorkloadFteKhrsDTO;
import com.airbus.optim.dto.WorkloadMonthlyDistributionDTO;
import com.airbus.optim.entity.Siglum;
import com.airbus.optim.entity.Workload;
import com.airbus.optim.repository.WorkloadEvolutionRepository;
import com.airbus.optim.repository.WorkloadRepository;
import com.airbus.optim.utils.Constants;
import com.airbus.optim.utils.Utils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WorkloadUtils {
    @Autowired
    WorkloadRepository workloadRepository;

    @Autowired
    WorkloadEvolutionRepository workloadEvolutionRepository;

    @Autowired
    private Utils utils;

    public double getBottomup(List<Workload> workloads) {
        return workloads.stream()
                .filter(workload -> (Constants.WORKLOAD_STATUS_BOTTOM_UP.equalsIgnoreCase(workload.getExercise())))
                .mapToDouble(Workload::getKHrs)
                .sum();
    }

    public EvolutionDTO dbBuildWorkloadEvolutionDTO(List<Siglum> siglumList, String exercise) {
        return new EvolutionDTO(
                null,
                exercise, "", "",
                workloadRepository.getWorkloadEvolutionLastExerciseApproved(siglumList, exercise, Constants.WORKLOAD_STATUS_OWN, Constants.WORKLOAD_STATUS_DIRECT),
                workloadRepository.getWorkloadEvolutionLastExerciseApproved(siglumList, exercise, Constants.WORKLOAD_STATUS_OWN, Constants.WORKLOAD_STATUS_INDIRECT),
                workloadRepository.getWorkloadEvolutionLastExerciseApproved(siglumList, exercise, Constants.WORKLOAD_STATUS_SUB, Constants.WORKLOAD_STATUS_DIRECT),
                workloadRepository.getWorkloadEvolutionLastExerciseApproved(siglumList, exercise, Constants.WORKLOAD_STATUS_SUB, Constants.WORKLOAD_STATUS_INDIRECT)
        );
    }

    public List<EvolutionDTO> formatExerciseValidator(List<EvolutionDTO> workloadEvolutionList) {
        for(EvolutionDTO w : workloadEvolutionList) w.mapper();
        return workloadEvolutionList;
    }

    public List<Double> fillMontlyDistribution(List<WorkloadMonthlyDistributionDTO> workloadMonthlyDistributionDTOList) {
        Double [] fteList = {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
        for (WorkloadMonthlyDistributionDTO w :workloadMonthlyDistributionDTOList) {
            fteList[w.getMes()-1] = w.getFte();
        }

        return Arrays.asList(fteList);
    }

    public WorkloadFteKhrsDTO fteFromWorkload(List<WorkloadFteDTO> workloadFteDTOList) {
        // FTEs = Hrs / ( Efficiency x (duración de la actividad/ 12)
        WorkloadFteKhrsDTO workloadFteKhrsDTO = new WorkloadFteKhrsDTO(0.0,0.0);

        double kHrs = 0.0;
        double fTEs = 0.0;

        for (WorkloadFteDTO w : workloadFteDTOList) {
            fTEs += w.getKHrs() / (w.getEfficiency() * ((double) w.getMonthsCount() / 12));
            kHrs += w.getKHrs();
        }

        return new WorkloadFteKhrsDTO(kHrs,fTEs);
    }

    public List<Workload> getLastExercise(String statusExercise, String userSelected, List<Workload> workloadList) {
        List<String> latestExercises = List.of(Constants.WORKLOAD_STATUS_BOTTOM_UP);
        List<Siglum> siglumFiltered = utils.getVisibleSiglums(null, userSelected);
        latestExercises = (Constants.WORKLOAD_EVOLUTION_STATUS_CLOSED.equals(statusExercise) ?
                getLastClosedExercise(siglumFiltered) : getLastWorkInProgresExercise(siglumFiltered));
        List<Workload> workloadsLast =
                workloadRepository.findWorkloadsByExerciseAndSiglums(latestExercises, siglumFiltered, workloadList);
        return workloadsLast;
    }

    public List<String> getLastClosedExercise(List<Siglum> siglumFiltered) {
        return new LinkedList<>(workloadEvolutionRepository.findLastClosedExercise(siglumFiltered));
    }
    public List<String> getLastWorkInProgresExercise(List<Siglum> siglumFiltered) {
        // <> 'closed' and MAX(submit_date)
        return new LinkedList<>(workloadEvolutionRepository.findLastNoClosedExercise(siglumFiltered));
    }

    public List<Long> getIdsFromWorkloadList(List<Workload> workloadList) {
        List<Long> wIds = new ArrayList<>();
        for (Workload w : workloadList) {
            wIds.add(w.getId());
        }
        return wIds;
    }

    public double filterWorkloadByRatio(List<Workload> wL, String ratio) {
        return wL.stream()
                .filter(workload -> (Constants.WORKLOAD_STATUS_DIRECT.equalsIgnoreCase(workload.getDirect())))
                .mapToDouble(Workload::getKHrs)
                .sum();
    }

}
