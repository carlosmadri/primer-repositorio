package com.airbus.optim.exception;

public class LeverConflictException extends RuntimeException {
    public LeverConflictException(String message) {
        super(message);
    }
}