package com.airbus.optim.service;

import com.airbus.optim.dto.HomeTeamOutlookWorkloadDTO;
import com.airbus.optim.dto.IndirectRadioDTO;
import com.airbus.optim.dto.OwnRatioDTO;
import com.airbus.optim.dto.TeamOutlookDTO;
import com.airbus.optim.dto.EvolutionDTO;
import com.airbus.optim.dto.WorkloadFteDTO;
import com.airbus.optim.dto.WorkloadFteKhrsDTO;
import com.airbus.optim.dto.WorkloadMonthlyDistributionExerciseDTO;
import com.airbus.optim.dto.WorkloadPerProgramDTO;
import com.airbus.optim.dto.WorkloadPreviewDTO;
import com.airbus.optim.dto.WorkloadWorkforceDTO;
import com.airbus.optim.entity.CostCenter;
import com.airbus.optim.entity.PPSID;
import com.airbus.optim.entity.Siglum;
import com.airbus.optim.entity.Workload;
import com.airbus.optim.entity.WorkloadEvolution;
import com.airbus.optim.repository.CostCenterRepository;
import com.airbus.optim.repository.HeadCountRepository;
import com.airbus.optim.repository.PPSIDRepository;
import com.airbus.optim.repository.SiglumRepository;
import com.airbus.optim.repository.WorkloadEvolutionRepository;
import com.airbus.optim.repository.WorkloadRepository;
import com.airbus.optim.service.workloadImpl.WorkloadMontlyDistributionImpl;
import com.airbus.optim.utils.Constants;
import com.airbus.optim.utils.Utils;
import com.airbus.optim.service.workloadImpl.WorkloadUtils;
import jakarta.persistence.EntityNotFoundException;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Objects;

import jakarta.persistence.criteria.Path;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;

@Service
public class WorkloadService {

    @Autowired
    private WorkloadRepository workloadRepository;

    @Autowired
    private WorkloadEvolutionRepository workloadEvolutionRepository;

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private SiglumRepository siglumRepository;

    @Autowired
    private CostCenterRepository costCenterRepository;

    @Autowired
    private PPSIDRepository ppsidRepository;

    @Autowired
    private WorkloadSpecification workloadSpecification;

    @Autowired
    private WorkloadEvolutionSpecification workloadEvolutionSpecification;

    @Autowired
    WorkloadMontlyDistributionImpl workloadMontlyDistributionImpl;

    @Autowired
    private HeadCountRepository headCountRepository;

    @Autowired
    WorkloadUtils workloadUtils;

    @Autowired
    private Utils utils;

    public Workload createWorkload(Workload newWorkload) {
        handleSiglum(newWorkload);
        handleCostCenter(newWorkload);
        handlePpsidCreationOrUpdate(newWorkload);
        //default value
        if (newWorkload.getExercise() == null || newWorkload.getExercise().isEmpty()) {
            newWorkload.setExercise(Constants.WORKLOAD_STATUS_BOTTOM_UP);
        }
        return workloadRepository.save(newWorkload);
    }

    @Transactional
    public Workload updateWorkload(Long id, Workload workloadDetails) {
        if (id == null) {
            throw new EntityNotFoundException("Workload ID cannot be null.");
        }

        Workload existingWorkload = workloadRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Workload not found with ID: " + id));

        validateLastWorkloadEvolution(existingWorkload.getSiglum());

        updateWorkloadFields(existingWorkload, workloadDetails);
        handleSiglum(existingWorkload, workloadDetails);
        handleCostCenter(existingWorkload, workloadDetails);
        handlePpsidCreationOrUpdate(existingWorkload, workloadDetails);

        return workloadRepository.save(existingWorkload);
    }

    @Transactional
    public List<Workload> updateWorkloads(List<Workload> workloads) {
        if (workloads == null || workloads.isEmpty()) {
            throw new IllegalArgumentException("La lista no puede estar vacía.");
        }

        return workloads.stream()
                .map(workload -> {
                    if (workload.getId() == null) {
                        throw new EntityNotFoundException("Workload ID no puede ser nulo.");
                    }

                    Workload existingWorkload = workloadRepository.findById(workload.getId())
                            .orElseThrow(() -> new EntityNotFoundException("No se ha encontrando un workload con el id: " + workload.getId()));

                    validateLastWorkloadEvolution(existingWorkload.getSiglum());

                    updateWorkloadFields(existingWorkload, workload);
                    handleSiglum(existingWorkload, workload);
                    handleCostCenter(existingWorkload, workload);
                    handlePpsidCreationOrUpdate(existingWorkload, workload);

                    return workloadRepository.save(existingWorkload);
                })
                .collect(Collectors.toList());
    }

    private void validateLastWorkloadEvolution(Siglum siglum) {
        if (siglum == null) {
            throw new IllegalArgumentException("El Siglum del workload no puede ser nulo.");
        }

        WorkloadEvolution lastOpenedExercise = utils.getLastOpenedExerciseOrThrow();
        Optional<WorkloadEvolution> latestWorkloadEvolution = workloadEvolutionRepository.findBySiglumAndExerciseWithLatestSubmitDate(
                siglum,
                lastOpenedExercise.getExercise()
        );

        if (latestWorkloadEvolution.isEmpty()) {
            throw new IllegalArgumentException("No se encontró ningún registro en WorkloadEvolution para el siglum: " + siglum.getSiglumHR());
        }

        String status = latestWorkloadEvolution.get().getStatus();
        if (!status.toLowerCase().contains(Constants.STATUS_REJECTED.toLowerCase()) &&
                !status.toLowerCase().contains((Constants.WORKLOAD_EVOLUTION_STATUS_OPENED.toLowerCase()))) {
            throw new IllegalArgumentException("El último registro en WorkloadEvolution para el siglum "
                    + siglum.getSiglumHR() + " no tiene un estado válido ('rejected' o 'opened').");
        }
    }

    private void handleSiglum(Workload workload) {
        Siglum siglum = workload.getSiglum();
        if (siglum != null && siglum.getId() != null) {
            workload.setSiglum(
                    siglumRepository.findById(siglum.getId())
                            .orElseThrow(() -> new EntityNotFoundException("No se ha encontrado el siglum con el id: " + siglum.getId()))
            );
        } else {
            workload.setSiglum(null);
        }
    }

    private void handleCostCenter(Workload workload) {
        CostCenter costCenter = workload.getCostCenter();
        if (costCenter != null && costCenter.getId() != null) {
            workload.setCostCenter(
                    costCenterRepository.findById(costCenter.getId())
                            .orElseThrow(() -> new EntityNotFoundException("No se ha encontrado el cost center con el id: " + costCenter.getId()))
            );
        } else {
            workload.setCostCenter(null);
        }
    }

    private void handleCostCenter(Workload existingWorkload, Workload updatedWorkload) {
        CostCenter costCenter = updatedWorkload.getCostCenter();
        if (costCenter != null) {
            existingWorkload.setCostCenter(
                    costCenter.getId() != null
                            ? costCenterRepository.findById(costCenter.getId())
                            .orElseThrow(() -> new EntityNotFoundException("No se ha encontrado el cost center con el id: " + costCenter.getId()))
                            : null
            );
        }
    }

    private void handlePpsidCreationOrUpdate(Workload workload) {
        PPSID ppsid = workload.getPpsid();
        if (ppsid != null) {
            PPSID savedPpsid = ppsid.getId() != null
                    ? ppsidRepository.findById(ppsid.getId())
                    .orElseGet(() -> ppsidRepository.save(ppsid))
                    : ppsidRepository.save(ppsid);
            workload.setPpsid(savedPpsid);
        }
    }

    private void handleSiglum(Workload existingWorkload, Workload updatedWorkload) {
        Siglum siglum = updatedWorkload.getSiglum();
        if (siglum != null) {
            existingWorkload.setSiglum(
                    siglum.getId() != null
                            ? siglumRepository.findById(siglum.getId())
                            .orElseThrow(() -> new EntityNotFoundException("No se ha encontrado el siglum con el id: " + siglum.getId()))
                            : null
            );
        }
    }

    private void handlePpsidCreationOrUpdate(Workload existingWorkload, Workload updatedWorkload) {
        PPSID ppsid = updatedWorkload.getPpsid();
        if (ppsid != null) {
            PPSID savedPpsid = ppsid.getId() != null
                    ? ppsidRepository.findById(ppsid.getId())
                    .orElseGet(() -> ppsidRepository.save(ppsid))
                    : ppsidRepository.save(ppsid);
            existingWorkload.setPpsid(savedPpsid);
        }
    }


    private void updateWorkloadFields(Workload existingWorkload, Workload workloadDetails) {
        if (workloadDetails.getDirect() != null) {
            existingWorkload.setDirect(workloadDetails.getDirect());
        }
        if (workloadDetails.getCollar() != null) {
            existingWorkload.setCollar(workloadDetails.getCollar());
        }
        if (workloadDetails.getOwn() != null) {
            existingWorkload.setOwn(workloadDetails.getOwn());
        }
        if (workloadDetails.getCore() != null) {
            existingWorkload.setCore(workloadDetails.getCore());
        }
        if (workloadDetails.getGo() != null) {
            existingWorkload.setGo(workloadDetails.getGo());
        }
        if (workloadDetails.getDescription() != null) {
            existingWorkload.setDescription(workloadDetails.getDescription());
        }
        if (workloadDetails.getExercise() != null) {
            existingWorkload.setExercise(workloadDetails.getExercise());
        }
        if (workloadDetails.getStartDate() != null) {
            existingWorkload.setStartDate(workloadDetails.getStartDate());
        }
        if (workloadDetails.getEndDate() != null) {
            existingWorkload.setEndDate(workloadDetails.getEndDate());
        }
        if (workloadDetails.getKHrs() != null) {
            existingWorkload.setKHrs(workloadDetails.getKHrs());
        }
        if (workloadDetails.getFTE() != null) {
            existingWorkload.setFTE(workloadDetails.getFTE());
        }
        if (workloadDetails.getKEur() != null) {
            existingWorkload.setKEur(workloadDetails.getKEur());
        }
        if (workloadDetails.getEac() != null) {
            existingWorkload.setEac(workloadDetails.getEac());
        }
    }

    public HomeTeamOutlookWorkloadDTO getHomeTeamOutlookWorkloadData(
            MultiValueMap<String, String> params,
            String userSelected,
            int yearFilter) {

        Specification<Workload> spec = workloadSpecification.getSpecifications(params);
        List<Workload> workloadList = workloadRepository.findAll(spec);

        List<Workload> lastExerciseList = workloadUtils.getLastExercise(
                Constants.WORKLOAD_EVOLUTION_STATUS_CLOSED, userSelected, workloadList);
        String lastExerciseName = (!lastExerciseList.isEmpty()) ? lastExerciseList.get(0).getExercise() : "";
        double LastExerciseKhrs = workloadRepository.getKhrsByExercise(lastExerciseList, yearFilter);

        Instant currentDateInstant = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant();
        Float hcFormerRefference = headCountRepository.sumTotalFTEForCurrentYear(
                String.valueOf(currentDateInstant.atZone(ZoneId.systemDefault()).getYear()-1));

        return new HomeTeamOutlookWorkloadDTO(
                workloadRepository.getKhrsByExerciseEditionByYear(yearFilter),
                lastExerciseName,
                LastExerciseKhrs,
                (hcFormerRefference != null ? hcFormerRefference : 0.0f)
        );
    }

    public IndirectRadioDTO getIndirectRatio(
            MultiValueMap<String, String> params,
            List<Siglum> siglumList,
            String userSelected,
            int yearFilter) {

        Specification<Workload> spec = workloadSpecification.getSpecifications(params);
        List<Workload> workloadList = workloadRepository.findAll(spec);

        List<Workload> wL = workloadRepository.getIndirectRatioForBottomUp(
                workloadList, siglumList, Constants.WORKLOAD_STATUS_BOTTOM_UP, yearFilter);

        if(wL.isEmpty()) {
            wL = workloadRepository.getIndirectRatioForLastExercise(workloadUtils.getLastExercise(
                    Constants.WORKLOAD_EVOLUTION_STATUS_CLOSED, userSelected, workloadList), yearFilter);

            /*wL = workloadRepository.getIndirectRatio(
                    workloadList, siglumList, utils.getExercise(utils.getExerciseName(), yearFilter), yearFilter);*/
        }

        double directKhrs = wL.stream()
                .filter(employee ->
                        "Direct".equalsIgnoreCase(employee.getDirect()))
                .mapToDouble(Workload::getKHrs)
                .sum();
        double indirectKhrs = wL.stream()
                .filter(employee ->
                        "Inirect".equalsIgnoreCase(employee.getDirect()))
                .mapToDouble(Workload::getKHrs)
                .sum();

        return new IndirectRadioDTO(directKhrs, indirectKhrs);
    }

    public OwnRatioDTO getOwnRatio(
            MultiValueMap<String, String> params,
            List<Siglum> siglumList,
            String userSelected,
            int yearFilter) {
        Specification<Workload> spec = workloadSpecification.getSpecifications(params);
        List<Workload> workloadList = workloadRepository.findAll(spec);

        List<Workload> wL = workloadRepository.getOwnRatioForBottomUp(
                workloadList, siglumList, Constants.WORKLOAD_STATUS_BOTTOM_UP, yearFilter);

        if(wL.isEmpty()) {
            wL = workloadRepository.getOwnRatioForLastExercise(workloadUtils.getLastExercise(
                    Constants.WORKLOAD_EVOLUTION_STATUS_CLOSED, userSelected, workloadList), yearFilter);
        }

        double ownKhrs = wL.stream()
                .filter(employee ->
                        "OWN".equalsIgnoreCase(employee.getDirect()))
                .mapToDouble(Workload::getKHrs)
                .sum();
        double subKhrs = wL.stream()
                .filter(employee ->
                        "SUB".equalsIgnoreCase(employee.getDirect()))
                .mapToDouble(Workload::getKHrs)
                .sum();

        return new OwnRatioDTO(ownKhrs, subKhrs);
    }

    public List<WorkloadPerProgramDTO> getWorkloadPerProgram(
            MultiValueMap<String, String> params,
            List<Siglum> siglumList,
            String userSelected,
            int yearFilter) {

        Specification<Workload> spec = workloadSpecification.getSpecifications(params);
        List<Workload> workloadList = workloadRepository.findAll(spec);

        List<WorkloadPerProgramDTO> workloadPerProgramDTOs =
                workloadRepository.getWorkloadPerProgram(
                        workloadList, siglumList, Constants.WORKLOAD_STATUS_BOTTOM_UP, yearFilter);

        if(workloadPerProgramDTOs.isEmpty()) {
            List<Workload> wL = workloadUtils.getLastExercise(
                    Constants.WORKLOAD_EVOLUTION_STATUS_CLOSED, userSelected, workloadList);

            workloadPerProgramDTOs = workloadRepository.getPerProgramLastExercise(
                    workloadUtils.getIdsFromWorkloadList(wL), yearFilter);
        }

        return workloadPerProgramDTOs;
    }

    public WorkloadMonthlyDistributionExerciseDTO workloadMontlyDistribution(
            MultiValueMap<String, String> params,
            List<Siglum> siglumList,
            int yearFilter) {
        Specification<Workload> spec = workloadSpecification.getSpecifications(params);
        List<Workload> workloadList = workloadRepository.findAll(spec);

        String workloadWIP = workloadRepository.getWorkloadWIP(siglumList) != null ? workloadRepository.getWorkloadWIP(siglumList) : "";
        EvolutionDTO w = new EvolutionDTO(workloadWIP);
        w.mapper();

        return new WorkloadMonthlyDistributionExerciseDTO(
                workloadUtils.fillMontlyDistribution(
                        workloadMontlyDistributionImpl.getMontlyDistributionByExercise(
                                workloadList, siglumList, yearFilter, utils.getExerciseOP(yearFilter))),
                workloadUtils.fillMontlyDistribution(
                        workloadMontlyDistributionImpl.getMontlyDistributionByExercise(
                                workloadList, siglumList, yearFilter, Constants.EXERCISE_FORECAST)),
                workloadUtils.fillMontlyDistribution(
                        workloadMontlyDistributionImpl.getMontlyDistributionByExercise(
                                workloadList, siglumList, yearFilter, Constants.WORKLOAD_STATUS_BOTTOM_UP)),
                w.getExerciseName()
        );
    }

    public WorkloadWorkforceDTO getWorkloadWorkforce(MultiValueMap<String, String> params, List<Siglum> siglumList, int yearFilter) {
        Specification<Workload> spec = workloadSpecification.getSpecifications(params);
        List<Workload> workloadList = workloadRepository.findAll(spec);

        ResponseEntity<TeamOutlookDTO> teamOutlookDTO = employeeService.getTeamOutlook(params, siglumList, yearFilter);

        WorkloadWorkforceDTO workloadWorkforce = new WorkloadWorkforceDTO(
                workloadUtils.fteFromWorkload(workloadRepository.getWorkloadWorkforceExerciseFTE(
                        workloadList, siglumList, utils.getExerciseOP(yearFilter))).getFte(),
                workloadUtils.fteFromWorkload(workloadRepository.getWorkloadWorkforceExerciseFTE(
                        workloadList, siglumList, Constants.EXERCISE_FORECAST)).getFte(),
                workloadRepository.getWorkloadWorkforceExerciseEditionFTE(
                        siglumList, Constants.WORKLOAD_STATUS_BOTTOM_UP, Constants.WORKLOAD_EVOLUTION_STATUS_BU_SUBMIT),
                workloadUtils.fteFromWorkload(workloadRepository.getWorkloadWorkforceExerciseFTE(
                        workloadList, siglumList, Constants.WORKLOAD_STATUS_BOTTOM_UP)).getFte(),
                workloadRepository.getWorkloadWorkforceExerciseEditionFTE(
                        siglumList, Constants.WORKLOAD_STATUS_BOTTOM_UP, Constants.WORKLOAD_EVOLUTION_STATUS_QMC_APPROVED),
                workloadRepository.getWorkloadWorkforceExerciseEditionFTE(
                        siglumList, Constants.WORKLOAD_STATUS_BOTTOM_UP, Constants.WORKLOAD_EVOLUTION_STATUS_HOT1Q_APPROVED),
                Objects.requireNonNull(teamOutlookDTO.getBody()).getOptimisticView(),
                teamOutlookDTO.getBody().getValidationView(),
                teamOutlookDTO.getBody().getRealisticView(),
                teamOutlookDTO.getBody().getHcCeiling(),
                ""
        );
        workloadWorkforce.buildWIPwhenRejected();

        return workloadWorkforce;
    }

    public WorkloadPreviewDTO getWorkloadPreview(
            MultiValueMap<String, String> params,
            List<Siglum> siglumList,
            String userSelected,
            int yearFilter) {

        Specification<Workload> spec = workloadSpecification.getSpecifications(params);
        List<Workload> workloadList = workloadRepository.findAll(spec);

        // Se indicará el total de kHrs de la última planificación aprobada del último ejercicio financiero,
        // es decir, las kHrs del FC o de la OP más reciente.
        List<Workload> wLastExercise = workloadUtils.getLastExercise(
                Constants.WORKLOAD_EVOLUTION_STATUS_CLOSED, userSelected, workloadList);
        String lastExercise = (!wLastExercise.isEmpty()) ? wLastExercise.get(0).getExercise() : "";
        WorkloadFteKhrsDTO workloadFteKhrsExercise = workloadUtils.fteFromWorkload(
                workloadRepository.workloadFTEbyLastExercise(wLastExercise, yearFilter));

        // Se indicará el total de kHrs del “Work in progress” que se esté editando en ese instante.
        // Si se encuentra fuera de la ventana de cambios, aparecerá el valor del último Bottom Up enviado a validar.
        List<Workload> wLastBU = workloadUtils.getLastExercise(
                Constants.WORKLOAD_STATUS_WORK_IN_PROGRES, userSelected, workloadList);

        String lastWorkInProgres = (!wLastBU.isEmpty()) ? wLastBU.get(0).getExercise() : "";
        List<WorkloadFteDTO> wList = workloadRepository.workloadFTEbyLastExercise(wLastBU, yearFilter);
        WorkloadFteKhrsDTO workloadFteKhrsPlanification = workloadUtils.fteFromWorkload(wList);

        ResponseEntity<TeamOutlookDTO> teamOutlookDTO =
                employeeService.getTeamOutlook(params, siglumList, yearFilter);

        double endOfYear = 0.0;
        if(!wLastBU.isEmpty()) {
            endOfYear = workloadUtils.filterWorkloadByRatio(wLastBU, Constants.WORKLOAD_STATUS_DIRECT);
        } else {
            endOfYear = workloadUtils.filterWorkloadByRatio(wLastExercise, Constants.WORKLOAD_STATUS_DIRECT);
        }
        
        // TODO end of year value
        return new WorkloadPreviewDTO(
                lastExercise,
                workloadFteKhrsExercise.getKHrs(),
                workloadFteKhrsExercise.getFte(),
                workloadFteKhrsPlanification.getKHrs(),
                workloadFteKhrsPlanification.getFte(),
                endOfYear,
                Objects.requireNonNull(teamOutlookDTO.getBody()).getRealisticViewAverage(),
                teamOutlookDTO.getBody().getHcCeiling());
    }

    public Page<Workload> filterWorkloads(MultiValueMap<String, String> params, Pageable pageable, String userSelected) {
        List<Siglum> visibleSiglums = utils.getVisibleSiglums(null, userSelected);
        Siglum mySiglum = utils.getUserInSession(userSelected).getSiglum();

        if (visibleSiglums.isEmpty()) {
            return Page.empty(pageable);
        }

        boolean isSuperUser = utils.isSuperUser(userSelected);

        List<Siglum> filteredSiglums = isSuperUser ? visibleSiglums : List.of(mySiglum);

        Specification<Workload> spec;
        String exercise = null;

        try {
            utils.getLastOpenedExerciseOrThrow();
            exercise = Constants.WORKLOAD_STATUS_BOTTOM_UP;

            String finalExercise = exercise;
            spec = Specification.where((root, query, criteriaBuilder) -> {
                Path<Siglum> siglumPath = root.get("siglum");
                Path<String> exercisePath = root.get("exercise");

                return criteriaBuilder.and(
                        siglumPath.in(filteredSiglums),
                        criteriaBuilder.equal(exercisePath, finalExercise)
                );
            });

        } catch (Exception e) {
            exercise = workloadEvolutionRepository.findLatestClosedExercisesByType()
                    .stream()
                    .findFirst()
                    .orElse("");

            if (exercise == null) {
                return Page.empty(pageable);
            }

            String finalExercise1 = exercise;
            spec = Specification.where((root, query, criteriaBuilder) -> {
                Path<Siglum> siglumPath = root.get("siglum");
                Path<String> exercisePath = root.get("exercise");

                return criteriaBuilder.and(
                        siglumPath.in(filteredSiglums),
                        criteriaBuilder.equal(exercisePath, finalExercise1)
                );
            });
        }

        Specification<Workload> dynamicSpec = workloadSpecification.getSpecifications(params);
        spec = spec.and(dynamicSpec);

        Page<Workload> workloadsPage = workloadRepository.findAll(spec, pageable);

        Optional<WorkloadEvolution> lastStatusMySiglum = workloadEvolutionRepository.findBySiglumAndExerciseWithLatestSubmitDate(mySiglum, exercise);

        List<Workload> workloads = workloadsPage.getContent().stream()
                .peek(workload -> {
                    if (isSuperUser) {
                        workload.setReadOnly(false);
                    } else {
                        boolean isMySiglum = workload.getSiglum() != null && workload.getSiglum().equals(mySiglum);
                        boolean isStatusInvalid = lastStatusMySiglum.isPresent() &&
                                !lastStatusMySiglum.get().getStatus().toLowerCase().contains(Constants.STATUS_REJECTED.toLowerCase()) &&
                                !lastStatusMySiglum.get().getStatus().toLowerCase().contains(Constants.STATUS_OPENED.toLowerCase());
                        workload.setReadOnly(!isMySiglum || isStatusInvalid);
                    }
                })
                .sorted((w1, w2) -> {
                    if (!isSuperUser) {
                        return Boolean.compare(w1.getReadOnly(), w2.getReadOnly());
                    }
                    return 0;
                })
                .toList();

        return new PageImpl<>(workloads, pageable, workloadsPage.getTotalElements());
    }
}