package com.airbus.optim.service;

import com.airbus.optim.dto.subcontractingDto.SubcontractingDataDTO;
import com.airbus.optim.dto.subcontractingDto.SubcontractingQuarterDTO;
import com.airbus.optim.entity.Employee;
import com.airbus.optim.entity.PurchaseOrders;
import com.airbus.optim.entity.Siglum;
import com.airbus.optim.entity.Location;
import com.airbus.optim.entity.Workload;
import com.airbus.optim.repository.PurchaseOrdersRepository;
import com.airbus.optim.repository.SiglumRepository;
import com.airbus.optim.repository.LocationRepository;
import com.airbus.optim.repository.WorkloadRepository;
import com.airbus.optim.utils.Utils;
import jakarta.persistence.EntityNotFoundException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.airbus.optim.dto.subcontractingDto.SubcontractingDTO;

import java.util.ArrayList;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.util.MultiValueMap;

@Service
public class PurchaseOrdersService {

    @Autowired
    private PurchaseOrdersRepository purchaseOrdersRepository;

    @Autowired
    private PurchaseOrdersSpecitication purchaseOrdersSpecification;

    @Autowired
    private WorkloadSpecification workloadSpecification;

    @Autowired
    private WorkloadRepository workloadRepository;

    @Autowired
    private SiglumRepository siglumRepository;

    @Autowired
    private LocationRepository locationRepository;

    @Autowired
    private Utils utils;

    public PurchaseOrders savePurchaseOrder(PurchaseOrders purchaseOrder) {
        handleSiglum(purchaseOrder);
        handleLocations(purchaseOrder);
        return purchaseOrdersRepository.save(purchaseOrder);
    }

    public ResponseEntity<PurchaseOrders> updatePurchaseOrder(Long id, PurchaseOrders purchaseOrderDetails) {
        Optional<PurchaseOrders> optionalPurchaseOrder = purchaseOrdersRepository.findById(id);

        if (optionalPurchaseOrder.isPresent()) {
            PurchaseOrders existingPurchaseOrder = optionalPurchaseOrder.get();
            updatePurchaseOrderFields(existingPurchaseOrder, purchaseOrderDetails);

            handleSiglum(purchaseOrderDetails);
            handleLocations(purchaseOrderDetails);

            PurchaseOrders updatedPurchaseOrder = purchaseOrdersRepository.save(existingPurchaseOrder);
            return ResponseEntity.ok(updatedPurchaseOrder);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    private void updatePurchaseOrderFields(PurchaseOrders existingPurchaseOrder, PurchaseOrders purchaseOrderDetails) {
        existingPurchaseOrder.setDescription(purchaseOrderDetails.getDescription());
        existingPurchaseOrder.setProvider(purchaseOrderDetails.getProvider());
        existingPurchaseOrder.setOrderRequest(purchaseOrderDetails.getOrderRequest());
        existingPurchaseOrder.setPurchaseDocument(purchaseOrderDetails.getPurchaseDocument());
        existingPurchaseOrder.setHmg(purchaseOrderDetails.getHmg());
        existingPurchaseOrder.setPep(purchaseOrderDetails.getPep());
        existingPurchaseOrder.setQuarter(purchaseOrderDetails.getQuarter());
        existingPurchaseOrder.setYear(purchaseOrderDetails.getYear());
        existingPurchaseOrder.setKEur(purchaseOrderDetails.getKEur());
    }

    private void handleSiglum(PurchaseOrders purchaseOrder) {
        if (purchaseOrder.getSiglum() != null) {
            Siglum siglum = purchaseOrder.getSiglum();

            if (siglum.getId() == null) {
                throw new IllegalArgumentException("Cannot assign a new Siglum. Only existing Siglums are allowed.");
            }

            Siglum existingSiglum = siglumRepository.findById(siglum.getId())
                    .orElseThrow(() -> new EntityNotFoundException("Siglum not found with ID: " + siglum.getId()));

            purchaseOrder.setSiglum(existingSiglum);
        }
    }

    private void handleLocations(PurchaseOrders purchaseOrder) {
        if (purchaseOrder.getLocations() != null && !purchaseOrder.getLocations().isEmpty()) {
            Set<Location> savedLocations = purchaseOrder.getLocations().stream().map(location -> {
                return location.getId() != null
                        ? locationRepository.findById(location.getId())
                        .orElseThrow(() -> new EntityNotFoundException("Location not found"))
                        : locationRepository.save(location);
            }).collect(Collectors.toSet());
            purchaseOrder.setLocations(new ArrayList<>(savedLocations));
        }
    }

    public SubcontractingDTO getSubcontractingData(
            MultiValueMap<String, String> params, String userSelected, String yearFilter){
        LocalDate currentDate = LocalDate.now(ZoneId.systemDefault());

        Specification<PurchaseOrders> spec = purchaseOrdersSpecification.getSpecifications(params);
        List<PurchaseOrders> purchaseOrderFilteredList = purchaseOrdersRepository.findAll(spec);

        List<Siglum> siglumVisibleList = utils.getSiglumVisibilityList(userSelected);

        List<PurchaseOrders> purchaseOrderSubcontractingList =
                purchaseOrdersRepository.findAllPurchaseOrdersFiltered(purchaseOrderFilteredList, siglumVisibleList);

        return new SubcontractingDTO(
                getSubcontractingAproved(purchaseOrderSubcontractingList, currentDate.getYear()),
                getSubcontractingNotAproved(purchaseOrderSubcontractingList, currentDate.getYear()),
                getSubcontractingBaseline(params, siglumVisibleList, currentDate.getYear()),
                getSubcontractingPerQuarter(purchaseOrderSubcontractingList, currentDate.getYear())
        );
    }
    public Double getSubcontractingAproved(List<PurchaseOrders> purchaseOrderList, int currentYear) {
        return purchaseOrderList.stream()
                .filter(purchaseOrder -> "true".equals(purchaseOrder.getApproved()) &&
                        purchaseOrder.getYear().equals(Integer.toString(currentYear)))
                .mapToDouble(PurchaseOrders::getKEur)
                .sum();
    }
    public Double getSubcontractingNotAproved(List<PurchaseOrders> purchaseOrderList, int currentYear) {
        return purchaseOrderList.stream()
                .filter(purchaseOrder -> "false".equals(purchaseOrder.getApproved()) &&
                        purchaseOrder.getYear().equals(Integer.toString(currentYear)))
                .mapToDouble(PurchaseOrders::getKEur)
                .sum();
    }
    public Double getSubcontractingBaseline(
            MultiValueMap<String, String> params, List<Siglum> siglumVisibleList, int currentYear) {

        Specification<Workload> spec = workloadSpecification.getSpecifications(params);
        List<Workload> workloadFilteredList = workloadRepository.findAll(spec);

        return workloadRepository.getSubcontractingOwnRatio(workloadFilteredList, siglumVisibleList, currentYear);
    }
    public SubcontractingQuarterDTO getSubcontractingPerQuarter(
            List<PurchaseOrders> purchaseOrderList, int currentYear) {
        return new SubcontractingQuarterDTO(
                purchaseOrdersRepository.groupPerQuarter(purchaseOrderList,"true", currentYear),
                purchaseOrdersRepository.groupPerQuarter(purchaseOrderList,"false", currentYear)
        );
    }
    public Page<SubcontractingDataDTO> getSubcontractingTable(
            MultiValueMap<String, String> params, Pageable pageable, String userSelected) {

        Specification<PurchaseOrders> spec = purchaseOrdersSpecification.getSpecifications(params);
        List<PurchaseOrders> purchaseOrderFilteredList = purchaseOrdersRepository.findAll(spec);

        return purchaseOrdersRepository.findAllSelectiveTableElements(
                pageable, purchaseOrderFilteredList, utils.getSiglumVisibilityList(userSelected));
    }

    public String getReportSubcontractingTable(
            MultiValueMap<String, String> params, String userSelected) {

        PageRequest pageRequest = PageRequest.of(
                0, 1000, Sort.by(Sort.Direction.DESC, "id"));

        List<SubcontractingDataDTO> subcontractingDataList =
                getSubcontractingTable(params, pageRequest, userSelected).getContent();

        final String CSV_HEADER =
                "\"Siglum\",\"Site\",\"Description\",\"Provider\",\"Approved\",\"Quarter\",\"Year\"," +
                        "\"kEur\",\"OrderRequest\",\"OrderId\",\"hmg\",\"pep\"\n";

        StringBuilder csvContent = new StringBuilder();
        csvContent.append(CSV_HEADER);

        for (SubcontractingDataDTO s : subcontractingDataList) {
            csvContent.append("\"").append(s.getSiglum()).append("\"").append(",").append("\"")
                    .append(s.getSite()).append("\"").append(",").append("\"")
                    .append(s.getDescription()).append("\"").append(",").append("\"")
                    .append(s.getProvider()).append("\"").append(",").append("\"")
                    .append(s.getApproved()).append("\"").append(",").append("\"")
                    .append(s.getQuarter()).append("\"").append(",").append("\"")
                    .append(s.getYear()).append("\"").append(",").append("\"")
                    .append(s.getKEur()).append("\"").append(",").append("\"")
                    .append(s.getOrderRequest()).append("\"").append(",").append("\"")
                    .append(s.getOrderId()).append("\"").append(",").append("\"")
                    .append(s.getHmg()).append("\"").append(",").append("\"")
                    .append(s.getPep()).append("\"").append("\n");
        }

        return csvContent.toString();
    }

}