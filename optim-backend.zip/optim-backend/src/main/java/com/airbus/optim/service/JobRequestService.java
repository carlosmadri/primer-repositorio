package com.airbus.optim.service;

import com.airbus.optim.dto.JobRequestTypeCountDTO;
import com.airbus.optim.dto.ReportEndOfYear.EmployeeReportDTO;
import com.airbus.optim.entity.CostCenter;
import com.airbus.optim.entity.Employee;
import com.airbus.optim.entity.JobRequest;
import com.airbus.optim.entity.Siglum;
import com.airbus.optim.repository.CostCenterRepository;
import com.airbus.optim.repository.EmployeeRepository;
import com.airbus.optim.repository.JobRequestRepository;
import com.airbus.optim.repository.SiglumRepository;
import com.airbus.optim.utils.Constants;
import com.airbus.optim.utils.Utils;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class JobRequestService {

    @Autowired
    private JobRequestRepository jobRequestRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private CostCenterRepository costCenterRepository;

    @Autowired
    private SiglumRepository siglumRepository;

    @Autowired
    private EmployeeSpecification employeeSpecification;

    @Autowired
    private JobRequestSpecification jobRequestSpecification;

    @Autowired
    private Utils utils;

    public JobRequest updateJobRequest(Long id, JobRequest jobRequestDetails) {

        JobRequest existingJobRequest = jobRequestRepository.findById(jobRequestDetails.getId())
                .orElseThrow(() -> new EntityNotFoundException("JobRequest not found: " + jobRequestDetails.getId()));

        updateJobRequestFields(existingJobRequest, jobRequestDetails);

        handleEmployees(existingJobRequest, jobRequestDetails);
        handleCostCenter(existingJobRequest, jobRequestDetails);
        handleSiglum(existingJobRequest, jobRequestDetails);

        JobRequest updatedJobRequest = jobRequestRepository.save(existingJobRequest);
        return updatedJobRequest;
    }

    public JobRequest createJobRequest(JobRequest jobRequest) {
        handleEmployees(jobRequest);
        handleCostCenter(jobRequest);
        handleSiglum(jobRequest);

        return jobRequestRepository.save(jobRequest);
    }

    private void updateJobRequestFields(JobRequest existingJobRequest, JobRequest jobRequestDetails) {
        existingJobRequest.setWorkdayNumber(jobRequestDetails.getWorkdayNumber());
        existingJobRequest.setType(jobRequestDetails.getType());
        existingJobRequest.setStatus(jobRequestDetails.getStatus());
        existingJobRequest.setDescription(jobRequestDetails.getDescription());
        existingJobRequest.setCandidate(jobRequestDetails.getCandidate());
        existingJobRequest.setStartDate(jobRequestDetails.getStartDate());
        existingJobRequest.setReleaseDate(jobRequestDetails.getReleaseDate());
        existingJobRequest.setPostingDate(jobRequestDetails.getPostingDate());
        existingJobRequest.setExternal(jobRequestDetails.getExternal());
        existingJobRequest.setEarlyCareer(jobRequestDetails.getEarlyCareer());
        existingJobRequest.setOnTopHct(jobRequestDetails.getOnTopHct());
        existingJobRequest.setIsCritical(jobRequestDetails.getIsCritical());
        existingJobRequest.setActiveWorkforce(jobRequestDetails.getActiveWorkforce());
        existingJobRequest.setApprovedQMC(jobRequestDetails.getApprovedQMC());
        existingJobRequest.setApprovedSHRBPHOT1Q(jobRequestDetails.getApprovedSHRBPHOT1Q());
        existingJobRequest.setApprovedHOCOOHOHRCOO(jobRequestDetails.getApprovedHOCOOHOHRCOO());
        existingJobRequest.setApprovedEmploymentCommitee(jobRequestDetails.getApprovedEmploymentCommitee());
        existingJobRequest.setDirect(jobRequestDetails.getDirect());
        existingJobRequest.setCollar(jobRequestDetails.getCollar());
    }

    private void handleEmployees(JobRequest jobRequest) {
        if (jobRequest.getEmployees() != null && !jobRequest.getEmployees().isEmpty()) {
            Set<Employee> savedEmployees = jobRequest.getEmployees().stream().map(employee -> {
                return employee.getId() != null
                        ? employeeRepository.findById(employee.getId())
                        .orElseThrow(() -> new EntityNotFoundException("Employee not found"))
                        : employeeRepository.save(employee);
            }).collect(Collectors.toSet());
            jobRequest.setEmployees(new ArrayList<>(savedEmployees));
        }
    }

    private void handleEmployees(JobRequest existingJobRequest, JobRequest jobRequestDetails) {
        if (jobRequestDetails.getEmployees() != null && !jobRequestDetails.getEmployees().isEmpty()) {
            Set<Employee> savedEmployees = jobRequestDetails.getEmployees().stream().map(employee -> {
                return employee.getId() != null
                        ? employeeRepository.findById(employee.getId())
                        .orElseThrow(() -> new EntityNotFoundException("Employee not found"))
                        : employeeRepository.save(employee);
            }).collect(Collectors.toSet());
            existingJobRequest.setEmployees(new ArrayList<>(savedEmployees));
        }
    }

    private void handleCostCenter(JobRequest jobRequest) {
        saveCostCenter(jobRequest, jobRequest.getCostCenter());
    }

    private void handleCostCenter(JobRequest existingJobRequest, JobRequest jobRequestDetails) {
        saveCostCenter(existingJobRequest, jobRequestDetails.getCostCenter());
    }

    private void saveCostCenter(JobRequest jobRequest, CostCenter costCenter) {
        if (costCenter != null) {
            CostCenter savedCostCenter = costCenter.getId() != null
                    ? costCenterRepository.findById(costCenter.getId())
                    .orElseThrow(() -> new EntityNotFoundException("CostCenter not found with id: " + costCenter.getId()))
                    : costCenterRepository.save(costCenter);
            jobRequest.setCostCenter(savedCostCenter);
        }
    }

    private void handleSiglum(JobRequest jobRequest) {
        saveSiglum(jobRequest, jobRequest.getSiglum());
    }

    private void handleSiglum(JobRequest existingJobRequest, JobRequest jobRequestDetails) {
        saveSiglum(existingJobRequest, jobRequestDetails.getSiglum());
    }

    private void saveSiglum(JobRequest jobRequest, Siglum siglum) {
        if (siglum != null) {
            Siglum savedSiglum = siglum.getId() != null
                    ? siglumRepository.findById(siglum.getId())
                    .orElseThrow(() -> new EntityNotFoundException("Siglum not found with id: " + siglum.getId()))
                    : siglumRepository.save(siglum);
            jobRequest.setSiglum(savedSiglum);
        }
    }

    public List<JobRequestTypeCountDTO> countJobRequestsByTypeAndYear(MultiValueMap<String, String> params, int yearFilter) {
        Specification<JobRequest> spec = jobRequestSpecification.getSpecifications(params);
        List<JobRequest> jobRequestList = jobRequestRepository.findAll(spec);
        return jobRequestRepository.countJobRequestsByType(jobRequestList);
    }

    public Page<JobRequest> filterJobRequests(MultiValueMap<String, String> params, Pageable pageable) {
        Specification<JobRequest> spec = jobRequestSpecification.getSpecifications(params);
        return jobRequestRepository.findAll(spec, pageable);
    }

    public String getReportJobRerquestByStatus(
            MultiValueMap<String, String> params,
            String userSelected,
            int yearFilter) {

        Specification<JobRequest> spec = jobRequestSpecification.getSpecifications(params);
        List<JobRequest> jobRequestList = jobRequestRepository.findAll(spec);

        List<String> status = List.of(
                Constants.JOB_REQUEST_STATUS_CLOSED
        );

        List<JobRequest> jobRequestReportList =  jobRequestRepository.findJobsByStatus(
                status, jobRequestList, utils.getSiglumVisibilityList(userSelected));

        final String CSV_HEADER = """
                "Id","WorkdayNumber","Type","Status","Description","Candidate","StartDate","PostingDate","External","EarlyCareer","OnTopHct","IsCritical","ActiveWorkforce","ApprovedQMC","ApprovedSHRBPHOT1Q","ApprovedHOCOOHOHRCOO","ApprovedEmploymentCommitee","Siglum","Direct","ReleaseDate","Collar","CostCenter"
                """;

        StringBuilder csvContent = new StringBuilder();
        csvContent.append(CSV_HEADER);

        for (JobRequest jr : jobRequestReportList) {
            csvContent.append("\"").append(jr.getId()).append("\",\"")
                    .append(jr.getWorkdayNumber()).append("\",\"")
                    .append(jr.getType()).append("\",\"")
                    .append(jr.getStatus()).append("\",\"")
                    .append(jr.getDescription()).append("\",\"")
                    .append(jr.getCandidate()).append("\",\"")
                    .append(jr.getStartDate()).append("\",\"")
                    .append(jr.getPostingDate()).append("\",\"")
                    .append(jr.getExternal()).append("\",\"")
                    .append(jr.getEarlyCareer()).append("\",\"")
                    .append(jr.getOnTopHct()).append("\",\"")
                    .append(jr.getIsCritical()).append("\",\"")
                    .append(jr.getActiveWorkforce()).append("\",\"")
                    .append(jr.getApprovedQMC()).append("\",\"")
                    .append(jr.getApprovedSHRBPHOT1Q()).append("\",\"")
                    .append(jr.getApprovedHOCOOHOHRCOO()).append("\",\"")
                    .append(jr.getApprovedEmploymentCommitee()).append("\",\"")
                    .append(jr.getSiglum()).append("\",\"")
                    .append(jr.getDirect()).append("\",\"")
                    .append(jr.getReleaseDate()).append("\",\"")
                    .append(jr.getCollar()).append("\",\"")
                    .append(jr.getCostCenter()).append("\"\n");
        }
        return csvContent.toString();
    }

    public String getReportJobRerquestClosed(
            MultiValueMap<String, String> params,
            String userSelected,
            int yearFilter) {

        Specification<JobRequest> spec = jobRequestSpecification.getSpecifications(params);
        List<JobRequest> jobRequestList = jobRequestRepository.findAll(spec);

        List<String> status = List.of(
                Constants.JOB_REQUEST_STATUS_VALIDATION_REQUEST,
                Constants.JOB_REQUEST_STATUS_QMC_APPROVED,
                Constants.JOB_REQUEST_STATUS_SHRBP_T1Q_APPROVED,
                Constants.JOB_REQUEST_STATUS_HO_T1Q_APPROVED,
                Constants.JOB_REQUEST_STATUS_COO_APPROVED);

        List<JobRequest> jobRequestReportList = jobRequestRepository.findJobsByStatus(
                status, jobRequestList, utils.getSiglumVisibilityList(userSelected));

        final String CSV_HEADER = """
                "Id","WorkdayNumber","Type","Status","Description","Candidate","StartDate","PostingDate","External","EarlyCareer","OnTopHct","IsCritical","ActiveWorkforce","ApprovedQMC","ApprovedSHRBPHOT1Q","ApprovedHOCOOHOHRCOO","ApprovedEmploymentCommitee","Siglum","Direct","ReleaseDate","Collar","CostCenter"
                """;

        StringBuilder csvContent = new StringBuilder();
        csvContent.append(CSV_HEADER);

        for (JobRequest jr : jobRequestReportList) {
            csvContent.append("\"").append(jr.getId()).append("\",\"")
                    .append(jr.getWorkdayNumber()).append("\",\"")
                    .append(jr.getType()).append("\",\"")
                    .append(jr.getStatus()).append("\",\"")
                    .append(jr.getDescription()).append("\",\"")
                    .append(jr.getCandidate()).append("\",\"")
                    .append(jr.getStartDate()).append("\",\"")
                    .append(jr.getPostingDate()).append("\",\"")
                    .append(jr.getExternal()).append("\",\"")
                    .append(jr.getEarlyCareer()).append("\",\"")
                    .append(jr.getOnTopHct()).append("\",\"")
                    .append(jr.getIsCritical()).append("\",\"")
                    .append(jr.getActiveWorkforce()).append("\",\"")
                    .append(jr.getApprovedQMC()).append("\",\"")
                    .append(jr.getApprovedSHRBPHOT1Q()).append("\",\"")
                    .append(jr.getApprovedHOCOOHOHRCOO()).append("\",\"")
                    .append(jr.getApprovedEmploymentCommitee()).append("\",\"")
                    .append(jr.getSiglum()).append("\",\"")
                    .append(jr.getDirect()).append("\",\"")
                    .append(jr.getReleaseDate()).append("\",\"")
                    .append(jr.getCollar()).append("\",\"")
                    .append(jr.getCostCenter()).append("\"\n");
        }
        return csvContent.toString();
    }

}