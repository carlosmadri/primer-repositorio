ALTER TABLE public.job_request
    DROP COLUMN IF EXISTS kapis_code;