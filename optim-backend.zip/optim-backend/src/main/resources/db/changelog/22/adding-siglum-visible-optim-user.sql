ALTER TABLE public.optim_user
ADD COLUMN IF NOT EXISTS siglum_visible character varying(255);