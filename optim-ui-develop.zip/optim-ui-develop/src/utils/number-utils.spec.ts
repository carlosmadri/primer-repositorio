import { roundToDecimalPlaces, roundArrayToDecimalPlaces, getOverallMinMax, arrayAverage, fillArrayWithRoundToDecimalAvg } from './number-utils';

describe('NumberUtils', () => {
  describe('roundToDecimalPlaces', () => {
    it('should round to one decimal place', () => {
      expect(roundToDecimalPlaces(3.33333, 1)).toBe(3.3);
    });

    it('should round up with one decimal place', () => {
      expect(roundToDecimalPlaces(3.39, 1)).toBe(3.4);
    });

    it('should round to two decimal places', () => {
      expect(roundToDecimalPlaces(3.33333, 2)).toBe(3.33);
    });

    it('should handle negative numbers', () => {
      expect(roundToDecimalPlaces(-3.33333, 1)).toBe(-3.3);
    });

    it('should handle zero decimal places', () => {
      expect(roundToDecimalPlaces(3.33333, 0)).toBe(3);
    });
  });

  describe('roundArrayToDecimalPlaces', () => {
    it('should return correct array with values rounded to the number of decimals', () => {
      expect(roundArrayToDecimalPlaces([3.3333, 9.999, 1], 0)).toStrictEqual([3, 10, 1]);
    });
  });

  describe('getOverallMinMax', () => {
    it('should return correct min and max for a 2D array', () => {
      const data = [
        [1, 2, 3],
        [-1, 5, 0],
      ];
      expect(getOverallMinMax(data)).toEqual({ min: -1, max: 5 });
    });

    it('should return correct min and max for a single row array', () => {
      const data = [[1, 2, 3]];
      expect(getOverallMinMax(data)).toEqual({ min: 1, max: 3 });
    });

    it('should return correct min and max for an array with negative numbers', () => {
      const data = [
        [-10, -20, -30],
        [-1, -5, -15],
      ];
      expect(getOverallMinMax(data)).toEqual({ min: -30, max: -1 });
    });

    it('should return correct min and max for an array with mixed positive and negative numbers', () => {
      const data = [
        [10, -20, 30],
        [-1, 5, -15],
      ];
      expect(getOverallMinMax(data)).toEqual({ min: -20, max: 30 });
    });

    it('should handle an empty 2D array', () => {
      const data: number[][] = [];
      expect(getOverallMinMax(data)).toEqual({ min: Infinity, max: -Infinity });
    });

    it('should handle an array with empty sub-arrays', () => {
      const data = [[], []];
      expect(getOverallMinMax(data)).toEqual({ min: Infinity, max: -Infinity });
    });
  });

  describe('arrayAverage', () => {
    it('should return the average of the array', () => {
      expect(arrayAverage([1, 2, 3, 4, 5])).toBe(3);
    });

    it('should return 0 for an empty array', () => {
      expect(arrayAverage([])).toBe(0);
    });
  });

  describe('fillArrayWithRoundToDecimalAvg', () => {
    it('should return an array with the same length as the input array', () => {
      const arr = [1, 2, 3, 4, 5];
      expect(fillArrayWithRoundToDecimalAvg(arr).length).toBe(arr.length);
    });

    it('should return an array with the average value rounded to one decimal place', () => {
      const arr = [1, 2, 3, 4, 5];
      expect(fillArrayWithRoundToDecimalAvg(arr)).toStrictEqual([3, 3, 3, 3, 3]);
    });

    it('should return an array with the average value rounded to two decimal places', () => {
      const arr = [1.1, 2.2, 3.3, 4.4, 5.5];
      expect(fillArrayWithRoundToDecimalAvg(arr)).toStrictEqual([3.3, 3.3, 3.3, 3.3, 3.3]);
    });

    it('should return an empty array for an empty input array', () => {
      expect(fillArrayWithRoundToDecimalAvg([])).toStrictEqual([]);
    });
  });
});
