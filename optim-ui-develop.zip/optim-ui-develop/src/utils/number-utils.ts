export const roundToDecimalPlaces = (num: number, decimalPlaces: number): number => {
  const factor = Math.pow(10, decimalPlaces);
  return Math.round(num * factor) / factor;
};

export const roundArrayToDecimalPlaces = (arr: number[], decimalPlaces: number): number[] => {
  return arr?.map((num) => roundToDecimalPlaces(num, decimalPlaces)) || [];
};

export const getOverallMinMax = (values: number[][]): { min: number; max: number } => {
  const allValues = values.flat();
  return {
    min: Math.min(...allValues),
    max: Math.max(...allValues),
  };
};

export const arrayAverage = (arr: number[]): number => {
  if (!arr || !Array.isArray(arr) || arr.length === 0) {
    return 0;
  }
  return arr.reduce((acc, val) => acc + val, 0) / arr.length;
};

export const fillArrayWithRoundToDecimalAvg = (arr: number[]): number[] => {
  const avg = arrayAverage(arr);
  const avgRounded = roundToDecimalPlaces(avg, 1);
  return arr.map(() => avgRounded);
};
