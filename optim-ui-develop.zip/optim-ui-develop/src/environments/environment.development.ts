export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api/optim/',
  // apiUrl: 'http://10.49.2.215:8080/api/optim/',
  issuerUrl: 'http://localhost:8081/FedBroker',
  // issuerUrl: 'https://v3.airbus.com/FedBroker/',
  useProdAuth: true,
  testServer: 'http://localhost:4200',
  clientId: 'CLI_9DD8_OPTIM-SSO-DEV-D',
  redirectUri: 'callback',
  requireHttps: false,
};
