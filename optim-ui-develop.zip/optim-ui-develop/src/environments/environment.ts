export const environment = {
  production: true,
  // apiUrl: 'https://optim-dev.9dd8-optim.aws.cloud.airbus-v.corp:8080/api/optim/',
  apiUrl: 'http://10.49.2.215:8080/api/optim/',
  issuerUrl: 'https://v3.airbus.com/FedBroker/',
  useProdAuth: true,
  testServer: 'http://10.49.2.215:4200',
  clientId: 'CLI_9DD8_OPTIM-DEV-VAL-V',
  scope: 'SCO_9DD8_OPTIM_API_VAL-V',
  redirectUri: 'callback',
  requireHttps: true,
};
