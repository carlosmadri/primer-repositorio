export const environment = {
  production: true,
  apiUrl: 'http://10.49.2.215:8080/api/optim/',
  useProdAuth: false,
  testServer: 'http://10.49.2.215:4200',
  issuerUrl: 'http://localhost:8081/FedBroker',
  clientId: 'CLI_9DD8_OPTIM-SSO-DEV-D',
  scope: '',
  redirectUri: 'callback',
  requireHttps: false,
};
