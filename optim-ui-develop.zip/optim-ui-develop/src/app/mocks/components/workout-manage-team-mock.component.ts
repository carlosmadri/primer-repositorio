import { Component } from '@angular/core';

@Component({
  selector: 'optim-manage-teams',
  template: ``,
})
export class MockManageTeamsComponent {}
