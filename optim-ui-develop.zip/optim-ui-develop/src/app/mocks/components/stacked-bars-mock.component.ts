import { Component, input } from '@angular/core';
import { LeversTotal } from '@src/app/shared/models/levers-total.model';

@Component({
  selector: 'optim-stacked-bars',
  template: ``,
  standalone: true,
})
export class MockStackedBarsComponent {
  chartData = input<LeversTotal[]>();
  colors = input<string[]>(['#044B70', '#0AAEC7']);
  containerHeight = input<number>();
}
