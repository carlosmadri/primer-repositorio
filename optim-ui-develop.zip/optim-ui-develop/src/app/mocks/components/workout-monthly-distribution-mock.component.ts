import { Component } from '@angular/core';

@Component({
  selector: 'optim-workout-monthly-distribution',
  template: ``,
  standalone: true,
})
export class MockWorkoutMonthlyDistributionComponent {}
