import { Component } from '@angular/core';

@Component({
  selector: 'optim-workout-borrowed-leased',
  template: ``,
  standalone: true,
})
export class MockWorkoutBorrowedLeasedComponent {}
