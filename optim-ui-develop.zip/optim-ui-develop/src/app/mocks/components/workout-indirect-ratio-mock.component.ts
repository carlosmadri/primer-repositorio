import { Component } from '@angular/core';

@Component({
  selector: 'optim-workout-indirect-ratio',
  template: ``,
  standalone: true,
})
export class MockWorkoutIndirectRatioComponent {}
