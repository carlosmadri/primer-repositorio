import { Component } from '@angular/core';

@Component({
  selector: 'optim-workload-submission',
  template: ``,
  standalone: true,
})
export class MockWorkloadSubmissionComponent {}
