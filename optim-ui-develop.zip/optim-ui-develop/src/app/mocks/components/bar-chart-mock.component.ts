import { Component, input, signal } from '@angular/core';
import { WorkloadWorkforce } from '@src/app/shared/models/worksync.model';
import { ApexOptions } from 'apexcharts';

@Component({
  selector: 'optim-bar-chart',
  template: ``,
  standalone: true,
})
export class MockBarChartComponent {
  chartData = input<WorkloadWorkforce[]>();
  containerHeight = input<number>();
  public chartOptions = signal<Partial<ApexOptions> | null>(null);
}
