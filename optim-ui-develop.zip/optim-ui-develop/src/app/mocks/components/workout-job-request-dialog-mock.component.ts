import { Component } from '@angular/core';

@Component({
  selector: 'optim-job-request-dialog',
  template: ``,
  standalone: true,
})
export class MockJobRequestDialogComponent {}
