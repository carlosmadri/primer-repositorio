import { Component } from '@angular/core';

@Component({
  selector: 'optim-manage-workload-table',
  template: ``,
})
export class MockManageWorkloadTableComponent {}
