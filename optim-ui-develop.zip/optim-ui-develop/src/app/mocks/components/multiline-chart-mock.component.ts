import { Component, input } from '@angular/core';
import { MultiLineChartData } from '@src/app/shared/models/graphs/multiline-chart.model';

@Component({
  selector: 'optim-multiline-chart',
  template: ``,
  standalone: true,
})
export class MockMultilineChartComponent {
  chartData = input<MultiLineChartData>();
  containerHeight = input<number>();
  markers = input<boolean>(false);
}
