import { Component } from '@angular/core';

@Component({
  selector: 'optim-manage-table',
  template: ``,
})
export class MockManageTableComponent {}
