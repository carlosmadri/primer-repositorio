import { Component, input } from '@angular/core';
import { WorkloadWorkforce } from '@src/app/shared/models/worksync.model';

@Component({
  selector: 'optim-multi-column-chart',
  template: ``,
  standalone: true,
})
export class MockMultiColumnChartComponent {
  chartData = input<WorkloadWorkforce>();
}
