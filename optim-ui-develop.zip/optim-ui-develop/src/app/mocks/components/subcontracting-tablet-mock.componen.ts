import { Component } from '@angular/core';

@Component({
  selector: 'optim-subcontracting-table',
  template: ``,
})
export class MockSubcontractingTableComponent {}
