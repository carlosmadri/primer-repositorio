import { Component } from '@angular/core';

@Component({
  selector: 'optim-wayback-selector',
  template: ``,
  standalone: true,
})
export class MockWaybackSelectorComponent {}
