import { Component } from '@angular/core';

@Component({
  selector: 'optim-workload-per-program',
  template: ``,
  standalone: true,
})
export class MockWorkloadPerProgramComponent {}
