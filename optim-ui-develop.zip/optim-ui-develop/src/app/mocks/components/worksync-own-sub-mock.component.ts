import { Component } from '@angular/core';

@Component({
  selector: 'optim-worksync-own-sub',
  template: ``,
  standalone: true,
})
export class MockWorksyncOwnSubComponent {}
