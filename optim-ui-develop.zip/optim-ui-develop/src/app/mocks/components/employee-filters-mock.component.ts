import { Component } from '@angular/core';

@Component({
  selector: 'optim-chart-selector',
  template: ``,
  standalone: true,
})
export class MockEmployeeFiltersComponent {}
