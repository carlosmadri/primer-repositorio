import { Component } from '@angular/core';

@Component({
  selector: 'optim-manage-job-requests-table',
  template: ``,
})
export class MockManageJobRequestsTableComponent {}
