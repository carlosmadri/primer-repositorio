import { Component } from '@angular/core';

@Component({
  selector: 'optim-workload-preview',
  template: ``,
  standalone: true,
})
export class MockWorkloadPreviewComponent {}
