import { Component } from '@angular/core';

@Component({
  selector: 'optim-workout-jr-breakdown',
  template: ``,
  standalone: true,
})
export class MockWorkoutJrBreakdownComponent {}
