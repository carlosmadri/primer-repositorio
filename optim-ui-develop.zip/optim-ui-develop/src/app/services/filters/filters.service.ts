import { computed, inject, Injectable, signal } from '@angular/core';
import { SiglumService } from '@services/siglum/siglum.service';
import { apiParams, subcontractingParams, workloadParams } from '@models/filters.model';
import { LocationService } from '@services/location/location.service';
import { LOCATION_TYPES } from '@models/location.model';
import {
  ACTIVE_WORKFORCE_TYPES,
  activeWorkforceValues,
  availabilityReasonValues,
  contractTypeValues,
  DIRECT_INDIRECT_TYPES,
  directIndirectValues,
} from '@models/employee.model';
import { AuthService } from '../auth/auth.service';
import { USER_NAME_FILTER } from '@models/user.model';

export interface GeneralFilter {
  field: string;
  values: string[];
}

export interface EmployeeFilter {
  siglumHR: string[];
  firstName: string | null;
  lastName: string | null;
  countries: string[];
  site: string[];
  direct: string[];
  activeWorkforce: string[];
  availabilityReason: string[];
  contractType: string[];
  job: string | null;
  WCBC: string | null;
  FTE: number | null;
}

export interface JobRequestFilter {
  siglumHR: string[];
  workdayNumber: string | null;
  status: string[];
  activeWorkforce: string[];
  startDate: string | null;
}

export interface WorkloadFilter {
  siglums: string[];
  description: string | null;
  own: string[];
  countries: string[];
  site: string[];
  costCenter: string[];
  direct: string[];
  khrs: number | null;
  collar: string[];
  core: string[];
  scenario: string | null;
  efficiency: number | null;
  rateOwn: number | null;
  fte: number | null;
  keur: number | null;
  eac: string | null;
  ppsid: string[];
}

export interface SubcontractingFilter {
  siglum: string;
  site: string[];
  description: string | null;
  approved: string;
  quarter: string;
  year: string;
  keur: number;
  provider: string;
  orderRequest: string;
  orderId: number;
  hmg: string;
  pep: string;
}

@Injectable({
  providedIn: 'root',
})
export class FiltersService {
  private siglumService = inject(SiglumService);
  private locationService = inject(LocationService);
  private authService = inject(AuthService);

  #yearFilter = signal<number>(new Date().getFullYear());
  yearFilter = this.#yearFilter.asReadonly();

  #generalFilter = signal<GeneralFilter[]>([]);
  generalFilter = this.#generalFilter.asReadonly();

  #employeeFilter = signal<GeneralFilter[]>([]);
  employeeFilter = this.#employeeFilter.asReadonly();

  #jobRequestFilter = signal<GeneralFilter[]>([]);
  jobRequestFilter = this.#jobRequestFilter.asReadonly();

  #workloadFilter = signal<GeneralFilter[]>([]);
  workloadFilter = this.#workloadFilter.asReadonly();

  #subcontractingFilter = signal<GeneralFilter[]>([]);
  subcontractingFilter = this.#subcontractingFilter.asReadonly();

  #waybackFilter = signal<string | undefined>(undefined);
  waybackFilter = this.#waybackFilter.asReadonly();

  private readonly reloadTrigger = signal(0); // Signal to trigger reloads

  reloadData() {
    this.reloadTrigger.update((val) => val + 1);
  }

  private createDeepEqualityFn<T>() {
    return (a: T | undefined, b: T | undefined) => {
      if (!a && !b) return true;
      if (!a || !b) return false;
      return JSON.stringify(a) === JSON.stringify(b);
    };
  }

  filtersArray = computed<string[] | undefined>(
    () => {
      const yearFilters = this.generateYearParams(this.yearFilter());
      const generalFilters = this.generateGeneralParams(this.generalFilter());
      const waybackFilters: string[] = this.getWaybackFilter(this.waybackFilter());
      const userFilter = this.authService.getUserNameFilter();
      if (yearFilters && generalFilters && userFilter) {
        return [userFilter, yearFilters, ...generalFilters, ...waybackFilters];
      }
      return undefined;
    },
    {
      equal: this.createDeepEqualityFn<string[]>(),
    },
  );

  readonly paramsFilter = computed(
    () => {
      // Include reload trigger in the computation
      this.reloadTrigger();

      // Get the current filters
      const filters = this.filtersArray();
      return filters;
    },
    {
      equal: () => false,
    },
  );

  employeeParamsFilter = computed(() => {
    const employeeParams = this.generateGeneralParams(this.employeeFilter());
    if (employeeParams) {
      return employeeParams;
    }
    return;
  });

  jobRequestParamsFilter = computed(() => {
    const jobRequestParams = this.generateGeneralParams(this.jobRequestFilter());
    if (jobRequestParams) {
      return jobRequestParams;
    }
    return;
  });

  workloadParamsFilter = computed(() => {
    const workloadParams = this.generateGeneralParams(this.workloadFilter());
    if (workloadParams) {
      return workloadParams;
    }
    return;
  });

  subcontractingParamsFilter = computed(() => {
    const subcontractingParams = this.generateGeneralParams(this.subcontractingFilter());
    if (subcontractingParams) {
      return subcontractingParams;
    }
    return;
  });

  allFilterValues = computed(() => {
    const allValues: Record<string, string[]> = {
      ...this.siglumService.allFormattedVisibleSiglums(),
      ...this.locationService.getSitesFilterValues(),
      ...this.locationService.getCountriesFilterValues(),
      activeWorkforce: activeWorkforceValues,
      direct: directIndirectValues,
    };
    return allValues;
  });

  async initializeFilters(userName: string) {
    await this.siglumService.getVisibleSiglums([`${USER_NAME_FILTER}=${userName}`]);
    await this.siglumService.getAllSiglums();
    await this.locationService.getAllLocations();
  }

  setYearFilter(year: number) {
    this.#yearFilter.set(year);
  }

  setWaybackFilter(wayback: string | undefined) {
    this.#waybackFilter.set(wayback);
  }

  private generateYearParams(year: number): string {
    return `yearFilter=${year}`;
  }

  getYearParams() {
    if (this.yearFilter()) {
      return `yearFilter=${this.yearFilter()}`;
    }
    return;
  }

  private generateGeneralParams(filters: GeneralFilter[]) {
    return filters.map((filter) => {
      return filter.values.map((value) => `${filter.field}=${value}`).join('&');
    });
  }

  private getWaybackFilter(wayback: string | undefined): string[] {
    if (wayback) {
      return [`wayback=${wayback}`];
    }
    return [];
  }

  getFilterFields() {
    let allFields: string[] = [];
    allFields = allFields.concat(
      this.siglumService.getSiglumFilterFields(),
      this.locationService.getLocationsFilterFields(),
      Object.values(ACTIVE_WORKFORCE_TYPES),
      Object.values(DIRECT_INDIRECT_TYPES),
    );

    const sortedFields = allFields.sort();

    return sortedFields;
  }

  getFilterValues(field: string, selectedCountries?: string[]): string[] {
    if (field === LOCATION_TYPES.SITE && selectedCountries && selectedCountries.length > 0) {
      return this.locationService.getSitesFilterValues(selectedCountries).site?.sort();
    }
    return this.allFilterValues()[field]?.sort();
  }

  getLocationId(site: string): number {
    return this.locationService.allLocations().find((location) => location[LOCATION_TYPES.SITE] === site)!.id;
  }

  getSiglumId(siglumHR: string): number {
    return this.siglumService.allSiglums().find((siglum) => siglum.siglumHR === siglumHR)!.id;
  }

  getAlternativeFilterValues(field: string): string[] {
    switch (
      field //Temporalmente hasta que la implementacion del backend este completa.
    ) {
      case 'availabilityReason':
        return availabilityReasonValues.sort();
      case 'contractType':
        return contractTypeValues.sort();
      default:
        return [];
    }
  }

  getAllSiglumsHR() {
    return this.siglumService.allSiglumsHR().siglumHR;
  }

  getAllVisibleSiglumsHR() {
    return this.siglumService.allVisibleSiglumsHR().siglumHR;
  }

  updateGeneralFilter(field: string, values: string[]) {
    const fieldApiParam = apiParams[field];
    const generalFilter = this.generalFilter();
    const filterIndex = generalFilter.findIndex((filter) => filter.field === fieldApiParam);
    if (filterIndex > -1) {
      generalFilter[filterIndex] = { field: fieldApiParam, values };
      this.#generalFilter.set([...generalFilter]);
    } else {
      this.#generalFilter.set([...this.generalFilter(), { field: fieldApiParam, values }]);
    }
  }

  updateFilters(
    filters: JobRequestFilter | EmployeeFilter | WorkloadFilter | SubcontractingFilter,
    activeFilters: GeneralFilter[],
    objParams = apiParams,
  ): GeneralFilter[] {
    Object.entries(filters).forEach((entry) => {
      const [key, filterValue] = entry;
      let values: string[] = [];
      const fieldApiParam = objParams[key];
      const filterIndex = activeFilters.findIndex((filter) => filter.field === fieldApiParam);
      if (!filterValue || filterValue.length === 0) {
        if (activeFilters[filterIndex]) {
          activeFilters.splice(filterIndex, 1);
        }
        return;
      }
      if (typeof filterValue === 'string' || typeof filterValue === 'number') {
        values = [filterValue as string];
      } else {
        values = filterValue;
      }
      if (filterIndex > -1) {
        activeFilters[filterIndex] = { field: fieldApiParam, values };
      } else {
        activeFilters = [...activeFilters, { field: fieldApiParam, values }];
      }
    });
    return [...activeFilters];
  }

  updateEmployeeFilter(filters?: EmployeeFilter) {
    const employeeFilter = this.employeeFilter();
    if (!filters) {
      this.#employeeFilter.set([...employeeFilter]);
      return;
    }
    const updatedFilters = this.updateFilters(filters, employeeFilter);
    this.#employeeFilter.set([...updatedFilters]);
  }

  updateJobRequestFilter(filters: JobRequestFilter) {
    const jobRequestFilter = this.jobRequestFilter();
    const updatedFilters = this.updateFilters(filters, jobRequestFilter);
    this.#jobRequestFilter.set(updatedFilters);
  }

  updateWorkloadFilter(filters: WorkloadFilter) {
    const workloadFilter = this.workloadFilter();
    const updatedFilters = this.updateFilters(filters, workloadFilter, workloadParams);
    this.#workloadFilter.set(updatedFilters);
  }

  updateSubcontractingFilter(filters: SubcontractingFilter) {
    const subcontractingFilters = this.subcontractingFilter();
    const updatedFilters = this.updateFilters(filters, subcontractingFilters, subcontractingParams);
    this.#subcontractingFilter.set(updatedFilters);
  }

  removeGeneralFilter(field: string) {
    const fieldApiParam = apiParams[field];
    const generalFilter = this.generalFilter();
    const fieldIndex = generalFilter.findIndex((filter) => filter.field === fieldApiParam);
    if (fieldIndex > -1) {
      generalFilter.splice(fieldIndex, 1);
    }
    this.#generalFilter.set([...generalFilter]);
  }

  clearFilters() {
    this.#generalFilter.set([]);
  }

  clearEmployeeFilters() {
    this.#employeeFilter.set([]);
  }

  clearJobRequestFilters() {
    this.#jobRequestFilter.set([]);
  }

  clearWorkloadFilters() {
    this.#workloadFilter.set([]);
  }

  clearSubcontractingFilters() {
    this.#subcontractingFilter.set([]);
  }
}
