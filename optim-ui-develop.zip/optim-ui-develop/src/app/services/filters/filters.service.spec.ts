import { TestBed } from '@angular/core/testing';
import { FiltersService } from './filters.service';
import { LocationService } from '@services/location/location.service';
import { SiglumService } from '@services/siglum/siglum.service';
import { signal } from '@angular/core';
import { AllSiglums, Siglum } from '@models/siglum.model';
import { AuthService } from '../auth/auth.service';
import { USER_NAME_FILTER } from '@src/app/shared/models/user.model';

describe('FiltersService', () => {
  let service: FiltersService;
  let authService: Partial<AuthService>;

  const mockLocationService: Partial<LocationService> = {
    getSitesFilterValues: jest.fn(),
    getCountriesFilterValues: jest.fn(),
    getAllLocations: jest.fn(),
  };

  const allSiglums = signal<Siglum[]>([]);
  const allVisibleSiglums = signal<Siglum[]>([]);
  const allFormattedSiglums = signal<AllSiglums | null>(null);
  const allFormattedVisibleSiglums = signal<AllSiglums | null>(null);
  const mockSiglumService: Partial<SiglumService> = {
    allSiglums: allSiglums,
    allVisibleSiglums: allVisibleSiglums,
    allFormattedSiglums: allFormattedSiglums,
    allFormattedVisibleSiglums: allFormattedVisibleSiglums,
    getAllSiglums: jest.fn(),
    getSiglumFilterFields: jest.fn(),
  };

  const mockUser = `${USER_NAME_FILTER}=user`;

  beforeEach(() => {
    authService = {
      getUserNameFilter: jest.fn().mockReturnValue(mockUser),
    };

    TestBed.configureTestingModule({
      providers: [
        { provide: LocationService, useValue: mockLocationService },
        { provide: SiglumService, useValue: mockSiglumService },
        { provide: AuthService, useValue: authService },
      ],
    });
    service = TestBed.inject(FiltersService);
  });

  afterEach(() => {
    jest.clearAllMocks();
    service.setWaybackFilter(undefined);
    service.clearFilters();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('filtersArray', () => {
    it('should return default filters array', () => {
      const result = service.filtersArray();

      expect(result).toEqual(expect.arrayContaining([`yearFilter=${new Date().getFullYear()}`, mockUser]));
    });

    it('should return the filters array with all the filters', () => {
      service.setWaybackFilter('2021-01-01');
      service.updateGeneralFilter('site', ['site1']);
      service.setYearFilter(2021);

      const result = service.filtersArray();

      expect(result).toEqual(expect.arrayContaining(['wayback=2021-01-01', expect.stringContaining('site=site1'), 'yearFilter=2021', mockUser]));
    });
  });
});
