import { TestBed } from '@angular/core/testing';

import { ReportService } from './report.service';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { IAuthService } from '../auth/auth.service.interface';
import { signal } from '@angular/core';
import { AuthService } from '../auth/auth.service';

describe('ReportService', () => {
  let service: ReportService;
  let mockAuthService: Partial<IAuthService>;

  beforeEach(() => {
    mockAuthService = {
      user: signal(null),
    };
    TestBed.configureTestingModule({
      providers: [provideHttpClient(withInterceptorsFromDi()), provideHttpClientTesting(), { provide: AuthService, useValue: mockAuthService }],
    });
    service = TestBed.inject(ReportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
