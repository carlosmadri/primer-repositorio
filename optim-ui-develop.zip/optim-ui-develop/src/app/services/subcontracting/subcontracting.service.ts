import { inject, Injectable, signal } from '@angular/core';
import { Subcontracting, SubcontractingGraphs, SubcontractsApiResponse } from '@models/subcontracting.model';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { CRUD_SUBCONTRACTING, GET_SUBCONTRACTING_GRAPHS } from '@app/shared/api.urls';
import { catchError, firstValueFrom, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SubcontractingService {
  #subcontracts = signal<Subcontracting[]>([]);
  subcontracts = this.#subcontracts.asReadonly();

  #totalSubcontracts = signal<number>(0);
  totalSubcontracts = this.#totalSubcontracts.asReadonly();

  #graphs = signal<SubcontractingGraphs | null>(null);
  graphs = this.#graphs.asReadonly();

  private http: HttpClient = inject(HttpClient);

  async getSubcontracts(params?: string[]): Promise<void> {
    try {
      const subcontracts$ = this.http
        .get<SubcontractsApiResponse>(`${CRUD_SUBCONTRACTING}${params ? `?${params.join('&')}` : ''}`)
        .pipe(catchError(this.handleError));
      const response = await firstValueFrom(subcontracts$);
      this.#totalSubcontracts.set(response.page?.totalElements);
      this.#subcontracts.set(response.content);
    } catch (error) {
      this.resetSubcontracts();
      throw error;
    }
  }

  resetSubcontracts(): void {
    this.#subcontracts.set([]);
    this.#totalSubcontracts.set(0);
  }

  async getSubcontractingGraphs(params?: string[]): Promise<void> {
    try {
      const subcontracts$ = this.http
        .get<SubcontractingGraphs>(`${GET_SUBCONTRACTING_GRAPHS}${params ? `?${params.join('&')}` : ''}`)
        .pipe(catchError(this.handleError));
      const response = await firstValueFrom(subcontracts$);
      this.#graphs.set(response);
    } catch (error) {
      this.resetSubcontractingGraphs();
      throw error;
    }
  }

  resetSubcontractingGraphs(): void {
    this.#graphs.set(null);
  }

  private handleError(error: HttpErrorResponse) {
    console.error('An error occurred:', error.message);
    return throwError(() => new Error('Something bad happened; please try again later.' + error.message));
  }
}
