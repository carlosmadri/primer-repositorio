import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import * as yaml from 'js-yaml';
import { HelpContent } from '@models/help/help-content.model';
import { HgmList } from '@src/app/shared/models/help/hmg-list.model';
@Injectable({
  providedIn: 'root',
})
export class HelpContentService {
  constructor(private http: HttpClient) {}

  loadHelpContent(): Observable<HelpContent[]> {
    return this.http.get('/assets/help.yaml', { responseType: 'text' }).pipe(map((yamlText) => yaml.load(yamlText) as HelpContent[]));
  }

  loadHmgDefinitionsContent(): Observable<HgmList> {
    return this.http.get('/assets/hmg-list.yaml', { responseType: 'text' }).pipe(map((yamlText) => yaml.load(yamlText) as HgmList));
  }
}
