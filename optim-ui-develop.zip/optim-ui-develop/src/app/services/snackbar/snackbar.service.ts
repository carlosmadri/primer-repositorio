import { inject, Injectable } from '@angular/core';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root',
})
export class SnackbarService {
  private defaultDuration = 5000;

  snackBar: MatSnackBar = inject(MatSnackBar);

  showInfo(message: string, duration?: number): void {
    const config: MatSnackBarConfig = {
      duration: duration || this.defaultDuration,
      panelClass: ['info-snackbar'],
      horizontalPosition: 'center',
      verticalPosition: 'bottom',
    };

    this.snackBar.open(message, 'Close', config);
  }

  showSuccess(message: string, duration?: number): void {
    const config: MatSnackBarConfig = {
      duration: duration || this.defaultDuration,
      panelClass: ['success-snackbar'],
      horizontalPosition: 'center',
      verticalPosition: 'bottom',
    };

    this.snackBar.open(message, 'Close', config);
  }

  showError(message: string, duration?: number): void {
    const config: MatSnackBarConfig = {
      duration: duration || this.defaultDuration,
      panelClass: ['error-snackbar'],
      horizontalPosition: 'center',
      verticalPosition: 'bottom',
    };

    this.snackBar.open(message, 'Close', config);
  }

  showWarning(message: string, duration?: number): void {
    const config: MatSnackBarConfig = {
      duration: duration || this.defaultDuration,
      panelClass: ['warning-snackbar'],
      horizontalPosition: 'center',
      verticalPosition: 'bottom',
    };

    this.snackBar.open(message, 'Close', config);
  }

  showCustom(message: string, action = 'Close', config?: MatSnackBarConfig): void {
    this.snackBar.open(message, action, config);
  }

  dismissAll(): void {
    this.snackBar.dismiss();
  }
}
