import { TestBed } from '@angular/core/testing';

import { ManageJobRequestService } from './manage-job-request.service';
import { AccessRuleService } from '../access-rule/access-rule.service';
import { User } from '@src/app/shared/models/user.model';
import { signal } from '@angular/core';

describe('ManageJobRequestService', () => {
  let service: ManageJobRequestService;
  let mockAccessRuleService: Partial<AccessRuleService>;

  beforeEach(() => {
    mockAccessRuleService = {
      canValidateJobRequisition: jest.fn().mockReturnValue(true),
      canQMCApproveJobRequisition: jest.fn().mockReturnValue(true),
      canHOT1QApproveJobRequisition: jest.fn().mockReturnValue(true),
      canCOOApproveJobRequisition: jest.fn().mockReturnValue(true),
      user: signal<User | null>(null),
    };

    TestBed.configureTestingModule({
      providers: [{ provide: AccessRuleService, useValue: mockAccessRuleService }],
    });
    service = TestBed.inject(ManageJobRequestService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
