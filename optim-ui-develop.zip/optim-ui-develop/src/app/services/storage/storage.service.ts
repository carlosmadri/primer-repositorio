import { Injectable } from '@angular/core';
import { User } from '@src/app/shared/models/user.model';

export const USER_SESSION_KEY = 'User';

@Injectable({
  providedIn: 'root',
})
export class StorageService {
  getToken(): string | null {
    const userJson = localStorage.getItem(USER_SESSION_KEY);
    if (userJson) {
      const user = JSON.parse(userJson);
      return user.JWT;
    }
    return null;
  }

  clearToken(): void {
    localStorage.removeItem(USER_SESSION_KEY);
  }

  getUser(): User | null {
    const userJson = localStorage.getItem(USER_SESSION_KEY);
    if (userJson) {
      return JSON.parse(userJson);
    }
    return null;
  }

  saveUser(user: User): void {
    localStorage.setItem(USER_SESSION_KEY, JSON.stringify(user));
  }
}
