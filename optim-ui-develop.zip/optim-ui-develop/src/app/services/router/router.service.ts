import { Injectable, inject } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { environment } from '@src/environments/environment';
import { filter, firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RouterService {
  router = inject(Router);

  async isCallbackPage(): Promise<boolean> {
    const currentRoute: NavigationStart = await firstValueFrom(this.router.events.pipe(filter((e) => e instanceof NavigationStart)));
    const isCallback = currentRoute.url.includes(environment.redirectUri);
    return isCallback;
  }

  static currentHost(): string {
    const currentLocation = window.location.href;
    const currentUrl = currentLocation.split('?')[0];
    const urlParts = currentUrl.split('/');
    const host = urlParts.slice(0, 3).join('/');
    return host;
  }

  static isTestServer(): boolean {
    return environment.testServer === this.currentHost();
  }
}
