import { inject, Injectable, signal } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { AllSiglums, Siglum, SIGLUM_TYPES, SiglumAPiResponse } from '@models/siglum.model';
import { GET_ALL_SIGLUMS, GET_VISIBLE_SIGLUMS } from '@app/shared/api.urls';
import { catchError, firstValueFrom, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SiglumService {
  #allFormattedSiglums = signal<AllSiglums | null>(null);
  allFormattedSiglums = this.#allFormattedSiglums.asReadonly();

  #allFormattedVisibleSiglums = signal<AllSiglums | null>(null);
  allFormattedVisibleSiglums = this.#allFormattedVisibleSiglums.asReadonly();

  #allSiglums = signal<Siglum[]>([]);
  allSiglums = this.#allSiglums.asReadonly();

  #allVisibleSiglums = signal<Siglum[]>([]);
  allVisibleSiglums = this.#allVisibleSiglums.asReadonly();

  #allSiglumsHR = signal<{ siglumHR: string[] }>({ siglumHR: [] });
  allSiglumsHR = this.#allSiglumsHR.asReadonly();

  #allVisibleSiglumsHR = signal<{ siglumHR: string[] }>({ siglumHR: [] });
  allVisibleSiglumsHR = this.#allVisibleSiglumsHR.asReadonly();

  private http = inject(HttpClient);

  async getAllSiglums(): Promise<void> {
    try {
      const siglums$ = this.http.get<SiglumAPiResponse>(`${GET_ALL_SIGLUMS}`).pipe(catchError(this.handleError));
      const response = await firstValueFrom(siglums$);
      this.#allSiglums.set(response.content);
      const formattedSiglums = this.formatAllSiglums(response.content);
      this.#allFormattedSiglums.set(formattedSiglums);
      this.#allSiglumsHR.set({ siglumHR: formattedSiglums.siglumHR });
    } catch (error) {
      this.#allSiglums.set([]);
      this.#allFormattedSiglums.set(null);
      throw error;
    }
  }

  async getVisibleSiglums(params?: string[]): Promise<void> {
    try {
      const siglums$ = this.http.get<Siglum[]>(`${GET_VISIBLE_SIGLUMS}${params ? `?${params.join('&')}` : ''}`).pipe(catchError(this.handleError));
      const response = await firstValueFrom(siglums$);
      this.#allVisibleSiglums.set(response);
      const formattedSiglums = this.formatAllSiglums(response);
      this.#allFormattedVisibleSiglums.set(formattedSiglums);
      this.#allVisibleSiglumsHR.set({ siglumHR: formattedSiglums.siglumHR });
    } catch (error) {
      this.#allVisibleSiglums.set([]);
      this.#allFormattedVisibleSiglums.set(null);
      throw error;
    }
  }

  private handleError(error: HttpErrorResponse) {
    console.error('An error occurred:', error.message);
    return throwError(() => new Error('Something bad happened; please try again later.'));
  }

  formatAllSiglums(siglums: Siglum[]): AllSiglums {
    const result: AllSiglums = {
      siglumHR: [...new Set(siglums.map((s) => s.siglumHR))],
      siglum6: [...new Set(siglums.map((s) => s.siglum6))],
      siglum5: [...new Set(siglums.map((s) => s.siglum5))],
      siglum4: [...new Set(siglums.map((s) => s.siglum4))],
    };

    return result;
  }

  getSiglumFilterFields() {
    return Object.values(SIGLUM_TYPES);
  }

  getSiglumFilterValues(field: SIGLUM_TYPES) {
    return this.allFormattedVisibleSiglums()![field];
  }
}
