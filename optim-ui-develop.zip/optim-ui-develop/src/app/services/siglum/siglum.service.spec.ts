import { TestBed } from '@angular/core/testing';

import { SiglumService } from './siglum.service';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Siglum } from '@src/app/shared/models/siglum.model';
import { GET_VISIBLE_SIGLUMS } from '@src/app/shared/api.urls';

describe('SiglumService', () => {
  let service: SiglumService;
  let httpMock: HttpTestingController;

  const mockSiglums: Siglum[] = [
    { id: 6, siglumHR: 'T1QAA', siglum6: 'T1QAA', siglum5: 'T1QAA', siglum4: 'T1QA' },
    { id: 7, siglumHR: 'T1QAA1', siglum6: 'T1QAA1', siglum5: 'T1QAA', siglum4: 'T1QA' },
    { id: 7, siglumHR: 'T1QAA1', siglum6: 'T1QAA1', siglum5: 'T1QAA', siglum4: 'T1QA' },
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(withInterceptorsFromDi()), provideHttpClientTesting()],
    });
    service = TestBed.inject(SiglumService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getVisibleSiglums', () => {
    it('should fetch visible siglums and update signals correctly', async () => {
      // Arrange
      const params = 'userName=admin1';

      // Act
      const promise = service.getVisibleSiglums([params]);

      // Assert - Check HTTP request
      const req = httpMock.expectOne(`${GET_VISIBLE_SIGLUMS}?${params}`);
      expect(req.request.method).toBe('GET');
      req.flush(mockSiglums);

      // Wait for the promise to resolve
      await promise;

      // Assert - Check signals
      expect(service.allVisibleSiglums()).toEqual(mockSiglums);

      // Check allFormattedSiglums signal
      const expectedFormattedSiglums = {
        siglumHR: ['T1QAA', 'T1QAA1'],
        siglum6: ['T1QAA', 'T1QAA1'],
        siglum5: ['T1QAA'],
        siglum4: ['T1QA'],
      };
      expect(service.allFormattedVisibleSiglums()).toEqual(expectedFormattedSiglums);

      // Check allSiglumsHR signal
      expect(service.allVisibleSiglumsHR()).toEqual({
        siglumHR: ['T1QAA', 'T1QAA1'],
      });
    });
  });
});
