import { TestBed } from '@angular/core/testing';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { CostCenterService } from './cost-center.service';
import { CRUD_COST_CENTER } from '@app/shared/api.urls';
import { CostCenter, CostCenterAPiResponse } from '@models/cost-center.model';
import { Location } from '@models/location.model';
import { HttpErrorResponse } from '@angular/common/http';

describe('CostCenterService', () => {
  let service: CostCenterService;
  let httpMock: HttpTestingController;

  // Mock location data
  const mockLocation: Location = {
    country: 'France',
    site: 'Paris',
    id: 1,
    kapisCode: 'PAR001',
    latitude: 48.8566,
    longitude: 2.3522,
    purchaseOrders: 'PO123',
    workload: 'Normal',
  };

  // Mock cost center data
  const mockCostCenters: CostCenter[] = [
    {
      id: 1,
      costCenterCode: 'CC001',
      costCenterFinancialCode: 'FC001',
      efficiency: 0.85,
      rateOwn: 100,
      rateSub: 80,
      location: mockLocation,
    },
    {
      id: 2,
      costCenterCode: 'CC002',
      costCenterFinancialCode: 'FC002',
      efficiency: 0.9,
      rateOwn: 110,
      rateSub: 85,
      location: mockLocation,
    },
  ];

  // Mock API response
  const mockApiResponse: CostCenterAPiResponse = {
    content: mockCostCenters,
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(withInterceptorsFromDi()), provideHttpClientTesting()],
    });

    service = TestBed.inject(CostCenterService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getAllCostCenters', () => {
    it('should fetch all cost centers successfully', async () => {
      // Arrange
      const getAllPromise = service.getAllCostCenters();

      // Act
      const req = httpMock.expectOne(CRUD_COST_CENTER);
      expect(req.request.method).toBe('GET');
      req.flush(mockApiResponse.content); // Send just the content array, not the wrapped response

      // Assert
      await getAllPromise;
      expect(service.allCostCenters()).toEqual(mockCostCenters);
    });

    it('should handle error and set empty array', async () => {
      // Arrange
      const errorPromise = service.getAllCostCenters();

      // Act & Assert
      const req = httpMock.expectOne(CRUD_COST_CENTER);
      req.flush('Error message', {
        status: 500,
        statusText: 'Internal Server Error',
      });

      await expect(errorPromise).rejects.toThrow('Something bad happened; please try again later.');
      expect(service.allCostCenters()).toEqual([]);
    });
  });

  describe('editCostCenter', () => {
    it('should edit cost center successfully', async () => {
      const id = 1;
      const updateData: Partial<CostCenter> = {
        costCenterCode: 'CC001-Updated',
        efficiency: 0.95,
        rateOwn: 120,
        rateSub: 90,
      };
      const updatedCostCenter: CostCenter = {
        ...mockCostCenters[0],
        ...updateData,
      };

      const editPromise = service.editCostCenter(id, updateData);

      const req = httpMock.expectOne(`${CRUD_COST_CENTER}/${id}`);
      expect(req.request.method).toBe('PUT');
      expect(req.request.body).toEqual(updateData);
      req.flush(updatedCostCenter);

      const result = await editPromise;
      expect(result).toEqual(updatedCostCenter);
    });

    it('should handle error during edit', (done) => {
      const id = 1;
      const updateData: Partial<CostCenter> = {
        costCenterCode: 'CC001-Updated',
        efficiency: 0.95,
      };

      service.editCostCenter(id, updateData).catch((error) => {
        expect(error instanceof HttpErrorResponse).toBeTruthy();
        expect(error.status).toBe(500);
        done();
      });

      const req = httpMock.expectOne(`${CRUD_COST_CENTER}/${id}`);
      req.flush('Error message', {
        status: 500,
        statusText: 'Internal Server Error',
      });
    });
  });
});
