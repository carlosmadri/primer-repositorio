import { computed, inject, Injectable } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { Role } from '@app/shared/models/user.model';

const HO = 'HO';
const HR = 'HR';
const QMC = 'QMC';
const HRBOSS = 'HRBoss';
const WL = 'WL';
const FINANCE = 'Finance';
const WL_DELEGATE = Role.WL_DELEGATE as string;
const HO_T1Q = 'HO.T1Q';
const ADMIN = Role.ADMIN as string;

const CAN_EDIT_LEVERS = [HO, HR, QMC, HRBOSS, ADMIN];
const CAN_ADD_INTERNAL_MOBILITY = [HO, QMC, ADMIN];
const CAN_ADD_PERIMETER_CHANGE = [HR, ADMIN];
const CAN_ADD_JOB_REQUISITION = [HO, HR, ADMIN];
const CAN_VALIDATE_JOB_REQUISITION = [QMC, ADMIN];
const CAN_QMC_APPROVE_JOB_REQUISITION = [HO_T1Q, ADMIN];
const CAN_HOT1Q_APPROVE_JOB_REQUISITION = [HO_T1Q, ADMIN];
const CAN_COO_APPROVE_JOB_REQUISITION = [ADMIN];
const CAN_ACCESS_MANAGE_WORKLOAD = [HO, FINANCE, WL, ADMIN];
const CAN_VALIDATE_WORKLOAD = [HO, QMC, HO_T1Q, ADMIN];

@Injectable({
  providedIn: 'root',
})
export class AccessRuleService {
  authService = inject(AuthService);

  user = this.authService.user;

  isAdmin = computed<boolean>(() => this.authService.isAuth() && this.user()?.role === ADMIN);

  canSeeWorkoutPages = computed<boolean>(() => this.authService.isAuth() && this.user()?.role !== WL_DELEGATE);

  canSeeManageWorkloadPage = computed<boolean>(() => {
    const rol = this.getRol();
    return this.authService.isAuth() && !!rol && CAN_ACCESS_MANAGE_WORKLOAD.includes(rol);
  });

  canAddInternalMobility(): boolean {
    const rol = this.getRol();
    return this.authService.isAuth() && !!rol && CAN_ADD_INTERNAL_MOBILITY.includes(rol);
  }

  canAddPerimeterChange(): boolean {
    const rol = this.getRol();
    return this.authService.isAuth() && !!rol && CAN_ADD_PERIMETER_CHANGE.includes(rol);
  }

  canAddJobRequisition(): boolean {
    const rol = this.getRol();
    return this.authService.isAuth() && !!rol && CAN_ADD_JOB_REQUISITION.includes(rol);
  }

  canValidateJobRequisition(): boolean {
    const rol = this.getRol();
    return this.authService.isAuth() && !!rol && CAN_VALIDATE_JOB_REQUISITION.includes(rol);
  }

  canQMCApproveJobRequisition(): boolean {
    const rol = this.user()?.role;
    return this.authService.isAuth() && !!rol && CAN_QMC_APPROVE_JOB_REQUISITION.includes(rol);
  }

  canHOT1QApproveJobRequisition(): boolean {
    const rol = this.user()?.role;
    return this.authService.isAuth() && !!rol && CAN_HOT1Q_APPROVE_JOB_REQUISITION.includes(rol);
  }

  canCOOApproveJobRequisition(): boolean {
    const rol = this.getRol();
    return this.authService.isAuth() && !!rol && CAN_COO_APPROVE_JOB_REQUISITION.includes(rol);
  }

  hasRol(roles: string[]): boolean {
    const rolesWithAdmin = [...roles, Role.ADMIN];
    const rol = this.getRol();

    return this.authService.isAuth() && !!rol && rolesWithAdmin.includes(rol);
  }

  canEditLevers(): boolean {
    const rol = this.getRol();
    return this.authService.isAuth() && !!rol && CAN_EDIT_LEVERS.includes(rol);
  }

  canAddComments(): boolean {
    const rol = this.getRol();
    return this.authService.isAuth() && !!rol && rol === HO;
  }

  canSubmitWorkload(): boolean {
    const rol = this.getRol();
    return this.authService.isAuth() && !!rol && rol === HO;
  }

  canValidateWorkload(): boolean {
    const rol = this.getRol();
    return this.authService.isAuth() && !!rol && CAN_VALIDATE_WORKLOAD.includes(rol);
  }

  private getRol(): string {
    const rol = this.user()?.role?.split('.')[0] || '';
    return rol;
  }
}
