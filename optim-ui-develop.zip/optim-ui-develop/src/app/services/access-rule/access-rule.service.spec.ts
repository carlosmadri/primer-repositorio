import { TestBed } from '@angular/core/testing';

import { AccessRuleService } from './access-rule.service';
import { AuthService } from '../auth/auth.service';
import { signal } from '@angular/core';
import { User } from '@src/app/shared/models/user.model';

describe('AccessRuleService', () => {
  let service: AccessRuleService;
  let mockAuthService: Partial<AuthService>;

  beforeEach(() => {
    mockAuthService = {
      isAuth: signal<boolean>(true),
      user: signal<User | null>(null),
    };
    TestBed.configureTestingModule({
      providers: [{ provide: AuthService, useValue: mockAuthService }],
    });
    service = TestBed.inject(AccessRuleService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
