import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class MockStateService {
  private readonly MOCK_STATE_KEY = 'useMockData';
  private mockStateSubject: BehaviorSubject<boolean>;

  constructor() {
    const savedState = localStorage.getItem(this.MOCK_STATE_KEY);
    this.mockStateSubject = new BehaviorSubject<boolean>(savedState ? JSON.parse(savedState) : false);
  }

  get useMocks$(): Observable<boolean> {
    return this.mockStateSubject.asObservable();
  }

  get currentState(): boolean {
    return this.mockStateSubject.value;
  }

  toggleMockState(enable?: boolean): void {
    const newState = enable ?? !this.currentState;
    localStorage.setItem(this.MOCK_STATE_KEY, JSON.stringify(newState));
    this.mockStateSubject.next(newState);
    window.location.reload();
  }
}
