export interface MockConfig {
  url: string;
  mockFile: string;
}

export const MOCK_ENDPOINTS: MockConfig[] = [
  {
    url: '/employee/team-outlook?',
    mockFile: 'team-outlook.json',
  },
  {
    url: '/workloads/home-team-outlook-workload?',
    mockFile: 'team-outlook-workload.json',
  },
  {
    url: '/employee/sum-levers-by-type?',
    mockFile: 'sum-levers-by-type.json',
  },
  {
    url: '/job-requests/count-by-type?',
    mockFile: 'count-by-type.json',
  },
  {
    url: '/workloads/evolution?',
    mockFile: 'evolution.json',
  },
  {
    url: '/workloads/own-sub-ratio?',
    mockFile: 'own-sub-ratio.json',
  },
  {
    url: '/workloads/indirect-ratio?',
    mockFile: 'workload-indirect-ratio.json',
  },
  {
    url: '/workloads/workforce?',
    mockFile: 'workload-workforce.json',
  },
  {
    url: '/workloads/per-program?',
    mockFile: 'per-program.json',
  },
  {
    url: '/workloads/preview?',
    mockFile: 'preview.json',
  },
  {
    url: '/purchase-orders/subcontracting-graphics?',
    mockFile: 'subcontracting-graphics.json',
  },
  {
    url: '/employee/monthly-distribution?',
    mockFile: 'monthly-distribution.json',
  },
  {
    url: '/employee/borrowed-vs-leased?',
    mockFile: 'borrowed-vs-leased.json',
  },
  {
    url: '/user/user-properties?',
    mockFile: 'user-properties.json',
  },
  {
    url: '/siglums/visible-siglum?',
    mockFile: 'visible-siglum.json',
  },
  {
    url: '/locations/coordinates-by-location?',
    mockFile: 'coordinates-by-location.json',
  },
  {
    url: '/locations',
    mockFile: 'locations.json',
  },
  {
    url: '/employee/naws-by-reason?',
    mockFile: 'naws-by-reason.json',
  },
  {
    url: '/employee/indirect-radio?',
    mockFile: 'employee-indirect-radio.json',
  },
  {
    url: '/optim/employee?',
    mockFile: 'employee-table.json',
  },
  {
    url: '/workload-evolution/can-update-workload?',
    mockFile: 'can-update-workload.json',
  },
  {
    url: '/workload-evolution/exists-opened-exercise',
    mockFile: 'exists-opened-exercise.json',
  },
  {
    url: '/ppsids/all',
    mockFile: 'ppsids-all.json',
  },
  {
    url: '/optim/workloads?',
    mockFile: 'workloads-table.json',
  },
  {
    url: '/purchase-orders/subcontracting-table?',
    mockFile: 'subcontracting-table.json',
  },
  {
    url: '/cost-centers',
    mockFile: 'cost-centers.json',
  },
  {
    url: '/optim/job-requests?',
    mockFile: 'job-requests.json',
  },
  {
    url: '/workload-evolution/siglums-first-submission?',
    mockFile: 'siglums-first-submission.json',
  },
  {
    url: '/workload-evolution/siglums-status?',
    mockFile: 'siglums-validation-status.json',
  },
];
