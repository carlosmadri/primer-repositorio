import { Injectable } from '@angular/core';
import { IAuthService } from './auth.service.interface';
import { AuthServiceBase } from './auth-base.service';
import { User } from '@src/app/shared/models/user.model';

@Injectable({
  providedIn: 'root',
})
export class AuthTestingService extends AuthServiceBase implements IAuthService {
  constructor() {
    super();
    this.initializeAuthState();
  }

  private initializeAuthState(): void {
    const storedUser = this.loadStoredUser();
    if (storedUser) {
      this.setLoginUserName(storedUser.userName);
    } else {
      this.setLoginUserName('admin');
    }
    this.initLogin();
  }

  async initLogin(): Promise<boolean> {
    try {
      const loadedUser = await this.loadUserInfo(this.userNameDev!);

      if (loadedUser) {
        this.storageService.saveUser(loadedUser as User);
        this._user.set(loadedUser as User);
        this._isAuth.set(true);
        this._isAuthorizing.set(false);
        return true;
      } else {
        this.snackarService.showError('User not found');
        this.clearToken();
        this._isAuthorizing.set(false);
        return false;
      }
    } catch (error) {
      console.error('Login error:', error);
      this._isAuthorizing.set(false);
      return false;
    }
  }

  logout(): void {
    this.clearToken();
  }

  isTokenExpired(): boolean {
    const tokenExpiration = localStorage.getItem('expires_at');
    if (!tokenExpiration) {
      return true;
    }
    const expirationTime = Number(tokenExpiration);
    const currentTime = Date.now();
    return currentTime > expirationTime;
  }

  getUserDataFromIdToken(): Partial<User> | null {
    return null;
  }

  async checkAuthState(): Promise<void> {
    return Promise.resolve();
  }
}
