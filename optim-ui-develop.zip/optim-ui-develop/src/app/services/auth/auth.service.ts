import { Injectable, inject } from '@angular/core';
import { Router } from '@angular/router';
import { OAuthService } from 'angular-oauth2-oidc';
import { authConfig } from '@src/app/shared/config/auth-config';
import { User } from '@src/app/shared/models/user.model';
import { TokenResponse } from 'angular-oauth2-oidc';
import { IAuthService } from './auth.service.interface';
import { AuthServiceBase } from './auth-base.service';
import { RouterService } from '../router/router.service';
import { environment } from '@src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AuthService extends AuthServiceBase implements IAuthService {
  private oauthService = inject(OAuthService);
  readonly routerService = inject(RouterService);
  router = inject(Router);

  constructor() {
    super();
    this.configureAuth();
  }

  private async configureAuth(): Promise<void> {
    try {
      this.oauthService.configure(authConfig);
      this.oauthService.setStorage(localStorage);

      // Set up event handling
      // this.oauthService.events.subscribe((event) => {
      //   if (event.type === 'token_received') {
      //     this.updateAuthState();
      //   }
      // });
      await this.checkAuthState();
    } catch (error) {
      console.error('Auth configuration error:', error);
    }
  }

  async checkAuthState(): Promise<void> {
    try {
      const isCallback = await this.checkCallbackStatus();
      if (isCallback) {
        return;
      }
      if (this.oauthService.hasValidIdToken()) {
        const user = this.getUserDataFromIdToken();
        if (user?.userName) {
          const loadedUser = await this.loadUserInfo(user.userName);
          if (loadedUser) {
            this._user.set(loadedUser as User);
            this.saveUser(user as User);
            this._isAuth.set(true);
          } else {
            this.snackarService.showError('User not found');
            this.clearToken();
          }
          this._isAuthorizing.set(false);
          return;
        }
      }
    } catch (error) {
      console.error('Auth configuration error:', error);
      this._isAuthorizing.set(false);
      this.snackarService.showError('Authentication error. Please try again.');
    }
    await this.initLogin();
  }

  private async checkCallbackStatus(): Promise<boolean> {
    const isCallback = await this.routerService.isCallbackPage();
    if (isCallback) {
      const success = await this.handleCallback();
      if (success) {
        this.router.navigate(['/']);
        return true;
      }
      console.error('Authentication failed during callback handling');
    }
    return false;
  }

  private async getDiscoveryDocument(): Promise<void> {
    try {
      await this.oauthService.loadDiscoveryDocument();
    } catch (error) {
      console.error('Discovery document error:', error);
    }
  }

  async initLogin(): Promise<boolean> {
    this.clearToken();
    this._redirectingToCallback.set(true);
    let result = false;
    try {
      await this.getDiscoveryDocument();
      this.oauthService.initCodeFlow();
      result = true;
    } catch (error) {
      console.error('Login error:', error);
    }
    this._redirectingToCallback.set(false);
    return result;
  }

  async handleCallback(): Promise<boolean> {
    try {
      await this.getDiscoveryDocument();
      const idToken: string | null = await this.getIdToken();
      if (!idToken) {
        return false;
      }

      const tokenResponse: TokenResponse | null = await this.getAccessToken(idToken);
      console.log('Token response:', tokenResponse);
      // if (!tokenResponse) {
      //   return false;
      // }

      const userFromToken = this.getUserDataFromIdToken();
      if (!userFromToken?.userName) {
        console.error('Failed to extract user data from token');
        return false;
      }
      const loadedUserInfo: Partial<User> | null = await this.loadUserInfo(userFromToken.userName);

      if (!loadedUserInfo) {
        console.error('Failed to load user info after token exchange');
        return false;
      }
      const user: User = {
        ...loadedUserInfo,
        JWT: userFromToken.JWT,
      } as User;

      this.saveUser(user);

      // Setup automatic refresh if needed
      // this.oauthService.setupAutomaticSilentRefresh();
      return true;
    } catch (error) {
      console.error('Token exchange error:', error);
      return false;
    } finally {
      this._isAuthorizing.set(false);
    }
  }

  private async getIdToken(): Promise<string | null> {
    try {
      // Process the code flow login
      await this.oauthService.tryLoginCodeFlow();

      // Check if we have a valid ID token after the code flow
      const idToken = this.oauthService.getIdToken();

      if (!idToken) {
        console.error('No ID token received');
        return null;
      }
      return idToken;
    } catch (error) {
      console.error('Error getting ID token:', error);
    }
    return null;
  }

  private async getAccessToken(idToken: string): Promise<TokenResponse | null> {
    const tokenResponse: TokenResponse = await this.oauthService.fetchTokenUsingGrant('urn:ietf:params:oauth:grant-type:jwt-bearer', {
      assertion: idToken,
      scope: environment.scope,
    });
    if (tokenResponse && tokenResponse.access_token) {
      return tokenResponse;
    } else {
      console.error('No access token received');
      return null;
    }
  }

  getUserDataFromIdToken(): Partial<User> | null {
    try {
      if (this.oauthService.hasValidAccessToken()) {
        const idToken = this.oauthService.getIdToken();
        if (idToken) {
          const parts = idToken.split('.');
          if (parts.length === 3) {
            const payload = JSON.parse(atob(parts[1]));
            console.log('Decoded ID token payload:', payload);
            const email = payload.email || '';
            if (email) {
              const user: Partial<User> = {
                userName: email,
                JWT: '',
              };
              return user;
            }
          }
        }
      }
    } catch (e) {
      console.warn('Error extracting email from token:', e);
    }
    return null;
  }

  logout(): void {
    this.oauthService.logOut();
    this.clearToken();
  }
}
