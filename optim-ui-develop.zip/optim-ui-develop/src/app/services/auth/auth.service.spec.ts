import { TestBed } from '@angular/core/testing';

import { AuthService } from './auth.service';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { OAuthService } from 'angular-oauth2-oidc';

describe('AuthService', () => {
  let service: AuthService;
  let mockOAuthService: Partial<OAuthService>;

  beforeEach(() => {
    mockOAuthService = {
      hasValidAccessToken: jest.fn().mockReturnValue(true),
      getAccessToken: jest.fn().mockReturnValue('mockAccessToken'),
      getIdentityClaims: jest.fn().mockReturnValue({}),
      loadDiscoveryDocumentAndTryLogin: jest.fn(),
      initImplicitFlow: jest.fn(),
      logOut: jest.fn(),
    };
    TestBed.configureTestingModule({
      providers: [provideHttpClient(withInterceptorsFromDi()), provideHttpClientTesting(), { provide: OAuthService, useValue: mockOAuthService }],
    });
    service = TestBed.inject(AuthService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
