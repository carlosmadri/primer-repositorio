import { Signal } from '@angular/core';
import { User } from '@src/app/shared/models/user.model';

export interface IAuthService {
  user: Signal<User | null>;
  isAuth: Signal<boolean>;
  redirectingToCallback: Signal<boolean>;
  getUser(): User | null;
  initLogin(): Promise<boolean>;
  loadStoredUser(): User | null;
  loadUserInfo(userName: string): Promise<Partial<User> | null>;
  logout(): void;
  getUserNameFilter(): string | undefined;
  getUserDataFromIdToken(): Partial<User> | null;
  checkAuthState(): Promise<void>;
  isAuthorizing: Signal<boolean>;
}
