import { inject, signal } from '@angular/core';
import { StorageService } from '../storage/storage.service';
import { HttpClient } from '@angular/common/http';
import { Role, User, USER_NAME_FILTER, UserAPI } from '@src/app/shared/models/user.model';
import { GET_USER } from '@src/app/shared/api.urls';
import { firstValueFrom } from 'rxjs';
import { SnackbarService } from '../snackbar/snackbar.service';

export class AuthServiceBase {
  storageService = inject(StorageService);
  snackarService = inject(SnackbarService);
  http = inject(HttpClient);

  // To be removed when the app is in production
  protected userNameDev: string | undefined;

  protected _user = signal<User | null>(null);
  user = this._user.asReadonly();

  protected _isAuth = signal<boolean>(false);
  isAuth = this._isAuth.asReadonly();

  protected _isAuthorizing = signal<boolean>(true);
  isAuthorizing = this._isAuthorizing.asReadonly();

  protected _redirectingToCallback = signal<boolean>(false);
  redirectingToCallback = this._redirectingToCallback.asReadonly();

  loadStoredUser(): User | null {
    const storedUser = this.storageService.getUser();
    if (storedUser) {
      return storedUser;
    }
    return null;
  }

  async loadUserInfo(userName: string): Promise<Partial<User> | null> {
    try {
      const user$ = this.http.get<UserAPI>(`${GET_USER}?userSelected=${userName}`);
      const userAPI = await firstValueFrom(user$);
      const user: Partial<User> = {
        siglum: userAPI.siglum,
        visibleSiglums: userAPI.visibleSiglums,
        userName,
        role: userAPI.userRol as Role,
      };
      return user;
    } catch (error) {
      console.error(error);
      this.clearToken();
      return null;
    }
  }

  getUser(): User | null {
    return this.user();
  }

  setLoginUserName(userName: string): void {
    this.userNameDev = userName;
  }

  protected saveUser(user: Partial<User>): void {
    this._user.update(
      (currentUser) =>
        ({
          ...currentUser,
          ...user,
        }) as User,
    );
    this.storageService.saveUser(this.getUser()!);
    this._isAuth.set(true);
  }

  protected clearToken(): void {
    this._user.set(null);
    this.storageService.clearToken();
    this._isAuth.set(false);
  }

  getUserNameFilter(): string | undefined {
    const user = this.user();
    if (user?.userName) {
      return `${USER_NAME_FILTER}=${user.userName}`;
    }
    return;
  }
}
