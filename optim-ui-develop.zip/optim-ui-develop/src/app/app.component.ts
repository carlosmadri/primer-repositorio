import { ChangeDetectionStrategy, Component, HostListener, inject, OnInit, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SidenavComponent } from './shared/components/sidenav/sidenav.component';
import { ToolbarComponent } from './shared/components/toolbar/toolbar.component';
import { NgOptimizedImage } from '@angular/common';
import { AuthService } from '@services/auth/auth.service';
import { MatSidenavModule } from '@angular/material/sidenav';
import { LoginComponent } from './pages/login/login.component';
import { MatIcon } from '@angular/material/icon';

@Component({
  selector: 'optim-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [SidenavComponent, ToolbarComponent, LoginComponent, NgOptimizedImage, MatIcon, MatSidenavModule, RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit {
  readonly authService = inject(AuthService);
  isAuth = this.authService.isAuth;
  title = 'optim-ui';

  showSideNav = signal(true);
  showNavBtn = signal(false);

  ngOnInit() {
    this.checkWindowSize(window.innerWidth);
  }

  onSidenavMouseLeave() {
    if (this.showNavBtn()) {
      this.toggleSideNav();
    }
  }

  toggleSideNav() {
    this.showSideNav.set(!this.showSideNav());
  }

  @HostListener('window:resize', ['$event.target.innerWidth'])
  onResize(width: number) {
    this.checkWindowSize(width);
  }

  checkWindowSize(width: number) {
    if (width < 1300) {
      this.showSideNav.set(false);
      this.showNavBtn.set(true);
    } else {
      this.showSideNav.set(true);
      this.showNavBtn.set(false);
    }
  }
}
