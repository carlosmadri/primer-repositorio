import { Routes } from '@angular/router';
import { AuthGuard } from '@src/app/shared/guards/auth.guard';
import { WorkoutGuard } from './shared/guards/workout.guard';
import { ManageWorkloadGuard } from './shared/guards/manage-workload.guard';

export const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    loadComponent: () => import('./pages/home/home.component').then((mod) => mod.HomeComponent),
    canActivate: [AuthGuard],
  },
  {
    path: 'workout',
    pathMatch: 'full',
    loadComponent: () => import('./pages/workout/workout.component').then((mod) => mod.WorkoutComponent),
    canActivate: [AuthGuard, WorkoutGuard],
  },
  {
    path: 'workout/manage-team',
    loadComponent: () => import('./pages/workout/manage-teams/manage-teams.component').then((mod) => mod.ManageTeamsComponent),
    canActivate: [AuthGuard, WorkoutGuard],
  },
  {
    path: 'workout/manage-job-requisitions',
    loadComponent: () => import('./pages/workout/manage-job-requests/manage-job-requests.component').then((mod) => mod.ManageJobRequestsComponent),
    canActivate: [AuthGuard, WorkoutGuard],
  },
  {
    path: 'worksync',
    pathMatch: 'full',
    loadComponent: () => import('./pages/worksync/worksync.component').then((mod) => mod.WorksyncComponent),
    canActivate: [AuthGuard],
  },
  {
    path: 'worksync/manage-workload',
    loadComponent: () => import('./pages/worksync/manage-workload/manage-workload.component').then((mod) => mod.ManageWorkloadComponent),
    canActivate: [AuthGuard, ManageWorkloadGuard],
  },
  {
    path: 'subcontracting',
    loadComponent: () => import('./pages/subcontracting/subcontracting.component').then((mod) => mod.SubcontractingComponent),
    canActivate: [AuthGuard],
  },
  {
    path: 'help',
    loadComponent: () => import('./pages/help/help.component').then((mod) => mod.HelpComponent),
    canActivate: [AuthGuard],
  },
  { path: 'callback', loadComponent: () => import('./pages/auth-callback/auth-callback.component').then((mod) => mod.AuthCallbackComponent) },
  {
    path: '**',
    pathMatch: 'full',
    loadComponent: () => import('./pages/page-not-found/page-not-found.component').then((mod) => mod.PageNotFoundComponent),
  },
];
