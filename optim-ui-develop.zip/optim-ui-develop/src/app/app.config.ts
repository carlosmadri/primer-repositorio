import { ApplicationConfig, provideZoneChangeDetection, importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { tokenValidationInterceptor } from './shared/interceptors/token-validation.interceptor';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideMomentDateAdapter } from '@angular/material-moment-adapter';
import { mockApiInterceptor } from './shared/interceptors/mock-api.interceptor';
import { OAuthModule, OAuthService } from 'angular-oauth2-oidc';
import { AuthService } from './services/auth/auth.service';
import { AuthTestingService } from './services/auth/auth-testing.service';
import { RouterService } from './services/router/router.service';
import { MAT_RIPPLE_GLOBAL_OPTIONS, RippleGlobalOptions } from '@angular/material/core';

const MY_DATE_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
const globalRippleConfig: RippleGlobalOptions = { disabled: true };
export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideHttpClient(withInterceptors([tokenValidationInterceptor, mockApiInterceptor])),
    provideRouter(routes),
    provideAnimations(),
    provideMomentDateAdapter(MY_DATE_FORMATS, { useUtc: true }),
    importProvidersFrom(OAuthModule.forRoot()),
    { provide: OAuthService, useClass: OAuthService },
    {
      provide: AuthService,
      useClass: RouterService.isTestServer() ? AuthTestingService : AuthService,
    },
    { provide: MAT_RIPPLE_GLOBAL_OPTIONS, useValue: globalRippleConfig },
  ],
};
