import { TestBed } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MockToolbarComponent } from './mocks/components';
import { IAuthService } from './services/auth/auth.service.interface';
import { signal } from '@angular/core';
import { AuthService } from './services/auth/auth.service';

describe('AppComponent', () => {
  let authServiceMock: Partial<IAuthService>;
  const mockIsAuth = signal(false);

  beforeEach(async () => {
    authServiceMock = {
      isAuth: mockIsAuth,
    };

    await TestBed.configureTestingModule({
      imports: [AppComponent, RouterModule.forRoot([]), NoopAnimationsModule, MockToolbarComponent],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: AuthService,
          useValue: authServiceMock,
        },
      ],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have the 'optim-ui' title`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toBe('optim-ui');
  });
});
