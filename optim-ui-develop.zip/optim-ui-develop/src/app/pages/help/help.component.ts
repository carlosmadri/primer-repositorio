import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { HelpContentService } from '@services/help/help-content.service';
import { CommonModule } from '@angular/common';
import { HelpContent } from '@models/help/help-content.model';

@Component({
  selector: 'optim-help',
  imports: [CommonModule],
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss'],
})
export class HelpComponent implements OnInit {
  renderedContent = '';

  private helpContentService = inject(HelpContentService);
  private cd = inject(ChangeDetectorRef);

  ngOnInit(): void {
    this.helpContentService.loadHelpContent().subscribe(
      (data) => {
        if (Array.isArray(data)) {
          this.renderContent(data as HelpContent[]);
          this.cd.detectChanges();
        } else {
          console.error('The content is not an array:', data);
        }
      },
      (error) => {
        console.error('Error loading the content:', error);
      },
    );
  }

  renderContent(content: HelpContent[]): void {
    const htmlOutput = content
      .map((concept) => {
        const reasons = concept.reasons?.length ? `<h4>Reasons for NAWF:</h4><ul>${concept.reasons.map((reason) => `<li>${reason}</li>`).join('')}</ul>` : '';
        const types = concept.types?.length ? `<h4>Types:</h4><ul>${concept.types.map((type) => `<li>${type}</li>`).join('')}</ul>` : '';
        const scenarios = concept.scenarios?.length
          ? `<h4>Scenarios:</h4><ul>${concept.scenarios.map((scenario) => `<li>${scenario}</li>`).join('')}</ul>`
          : '';

        return `
          <div>
            <h2>${concept.title}</h2>
            <p>${concept.description}</p>
            ${reasons}
            ${types}
            ${scenarios}
          </div>
        `;
      })
      .join('');

    this.renderedContent = htmlOutput;
  }
}
