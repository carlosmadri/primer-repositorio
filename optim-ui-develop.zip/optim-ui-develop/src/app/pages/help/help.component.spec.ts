import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HelpComponent } from './help.component';
import { HelpContentService } from '@src/app/services/help/help-content.service';
import { of } from 'rxjs';

describe('HelpComponent', () => {
  let component: HelpComponent;
  let fixture: ComponentFixture<HelpComponent>;
  let mockHelpContentService: Partial<HelpContentService>;

  beforeEach(async () => {
    mockHelpContentService = {
      loadHelpContent: () => of([]),
    };
    await TestBed.configureTestingModule({
      imports: [HelpComponent],
      providers: [{ provide: HelpContentService, useValue: mockHelpContentService }],
    }).compileComponents();

    fixture = TestBed.createComponent(HelpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
