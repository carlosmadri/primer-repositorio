import { ChangeDetectionStrategy, Component, computed, effect, inject, input, OnDestroy, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { ChartSelectorService } from '@src/app/services/chart-selector/chart-selector.service';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';
import { WorkloadEvolutionAdapter } from '@src/app/shared/adapters/workload-evolution/workload-evolution.adapter';
import { ElementHeightDirective } from '@src/app/shared/directives/element-height.directive';
import { MultibarChartComponent } from '@src/app/shared/graphs/multibar-chart/multibar-chart.component';
import {
  ChartIds,
  EvolutionValidationOptions,
  VALIDATION_STATUS_SELECTOR,
  WorkloadEvolution,
  WorkloadEvolutionBarData,
} from '@src/app/shared/models/worksync.model';

@Component({
  selector: 'optim-workload-evolution',
  imports: [MultibarChartComponent, FormsModule, MatSelectModule, MatOptionModule, ElementHeightDirective],
  templateUrl: './workload-evolution.component.html',
  styleUrl: './workload-evolution.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkloadEvolutionComponent implements OnDestroy {
  private filtersService: FiltersService = inject(FiltersService);
  private worksyncService: WorksyncService = inject(WorksyncService);
  private readonly chartSelectorService = inject(ChartSelectorService);
  private readonly workloadEvolutionAdapter = inject(WorkloadEvolutionAdapter);

  standAlone = input(false);

  protected readonly evolutionData = this.worksyncService.evolution;
  protected readonly selectedChecks = this.chartSelectorService.selectedChecks;

  private currentParams: string[] | undefined;

  graphTypes = EvolutionValidationOptions;

  selectedGraphType: EvolutionValidationOptions = EvolutionValidationOptions.ALL;

  chartElementHeight = signal(0);

  constructor() {
    effect(() => {
      this.currentParams = this.filtersService.paramsFilter();
      this.loadData(this.currentParams);
    });
    effect(() => {
      const evolutionData = this.evolutionData();
      this.setAvailableChecks(evolutionData);
    });
  }

  onResize(newHeight: number): void {
    this.chartElementHeight.set(newHeight);
  }

  async loadData(params?: string[]) {
    await this.worksyncService.getWorkLoadEvolution(params);
  }

  barChartFiltered = computed<WorkloadEvolutionBarData[]>(() => {
    const evolutionData = this.evolutionData();
    const checkedLines = this.selectedChecks();
    if (evolutionData?.data && evolutionData.data.length > 0 && checkedLines.length > 0) {
      return this.workloadEvolutionAdapter.filterWorkloadEvolutionLines(evolutionData?.data, checkedLines);
    }
    return [];
  });

  multipleSiglums = computed<boolean>(() => {
    const evolutionData = this.evolutionData();
    return evolutionData?.multipleSiglums || false;
  });

  onGraphChange() {
    let params = this.currentParams;
    if (this.selectedGraphType !== EvolutionValidationOptions.ALL) {
      const validationStatusParam = `${VALIDATION_STATUS_SELECTOR}=${this.selectedGraphType}`;
      params = [...(this.currentParams || []), validationStatusParam];
    }
    this.loadData(params);
  }

  private setAvailableChecks(evolutionData: WorkloadEvolution | null) {
    const allChecksIds: ChartIds[] = evolutionData ? evolutionData.data.map((data) => data.id) : [];
    this.chartSelectorService.setWorkloadChecks(allChecksIds);
    if (this.standAlone()) {
      this.chartSelectorService.setSelectedChecks(allChecksIds);
    }
  }

  ngOnDestroy(): void {
    this.worksyncService.resetEvolutionData();
  }
}
