import { ChangeDetectionStrategy, Component, inject, computed, effect, signal, OnDestroy } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';
import * as numberUtils from '@src/utils/number-utils';
import { TooltipComponent } from '@src/app/shared/components/tooltip/tooltip.component';
import { LoadingComponent } from '@src/app/shared/components/loading/loading.component';

@Component({
  selector: 'optim-workload-preview',
  imports: [MatIconModule, TooltipComponent, LoadingComponent],
  templateUrl: './workload-preview.component.html',
  styleUrl: './workload-preview.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkloadPreviewComponent implements OnDestroy {
  constructor() {
    effect(() => {
      const params = this.filtersService.paramsFilter();
      this.loadData(params);
    });
  }

  private filtersService: FiltersService = inject(FiltersService);
  private worksyncService: WorksyncService = inject(WorksyncService);

  protected readonly previewData = this.worksyncService.workloadPreview;

  isLoading = signal(false);
  errorMsg = signal<string | null>(null);

  async loadData(params?: string[]) {
    this.isLoading.set(true);
    try {
      await this.worksyncService.getWorkloadPreview(params);
    } catch (err) {
      this.errorMsg.set(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      this.isLoading.set(false);
    }
  }

  previewDataFormatted = computed(() => {
    const data = this.previewData();
    if (!data) {
      return null;
    }
    const formattedData = {
      ...data,
      khrs: numberUtils.roundToDecimalPlaces(data?.khrs || 0, 1),
      previsionkHrs: numberUtils.roundToDecimalPlaces(data?.previsionkHrs || 0, 1),
      fte: numberUtils.roundToDecimalPlaces(data?.fte || 0, 1),
      previsionFte: numberUtils.roundToDecimalPlaces(data?.previsionFte || 0, 1),
      realisticViewAVG: numberUtils.roundToDecimalPlaces(data?.realisticViewAVG || 0, 1),
      vlActualsEoY: numberUtils.roundToDecimalPlaces(data?.vlActualsEoY || 0, 1),
      hcmaxCelling: numberUtils.roundToDecimalPlaces(data?.hcmaxCelling || 0, 1),
    };
    return formattedData;
  });

  ngOnDestroy(): void {
    this.worksyncService.resetWorkloadPreview();
  }
}
