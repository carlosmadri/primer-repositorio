import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkloadCommentsComponent } from './workload-comments.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';
import { AuthService } from '@src/app/services/auth/auth.service';
import { signal } from '@angular/core';

describe('WorkloadCommentsComponent', () => {
  let component: WorkloadCommentsComponent;
  let fixture: ComponentFixture<WorkloadCommentsComponent>;
  let mockWorksyncService: Partial<WorksyncService>;
  let mockAuthService: Partial<AuthService>;

  beforeEach(async () => {
    mockWorksyncService = {
      workloadComment: signal<string | null>(null),
      getComment: jest.fn(),
      postComment: jest.fn(),
    };

    mockAuthService = {
      getUserNameFilter: jest.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [WorkloadCommentsComponent, NoopAnimationsModule],
      providers: [
        { provide: WorksyncService, useValue: mockWorksyncService },
        { provide: AuthService, useValue: mockAuthService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(WorkloadCommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
