import { ChangeDetectionStrategy, Component, inject, OnInit, output, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormField, MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { AuthService } from '@src/app/services/auth/auth.service';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';
import { WorkloadPostResponse } from '@src/app/shared/models/worksync.model';

@Component({
  selector: 'optim-workload-comments',
  imports: [MatDialogModule, MatButtonModule, MatFormField, ReactiveFormsModule, MatFormFieldModule, MatInputModule],
  templateUrl: './workload-comments.component.html',
  styleUrl: './workload-comments.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkloadCommentsComponent implements OnInit {
  private worksyncService: WorksyncService = inject(WorksyncService);
  private authService: AuthService = inject(AuthService);

  private workloadComment = this.worksyncService.workloadComment;

  requestCompleted = output<WorkloadPostResponse>();

  private userSelected: string | undefined;

  form = signal<FormGroup<{ comment: FormControl<string | null> }> | null>(null);

  async ngOnInit() {
    this.userSelected = this.authService.getUserNameFilter();
    await this.worksyncService.getComment([this.userSelected!]);
    this.initForm(this.workloadComment());
  }

  async submit() {
    const comment = this.form()!.value.comment;
    if (comment) {
      const response = await this.worksyncService.postComment(comment, [this.userSelected!]);
      this.requestCompleted.emit(response);
    }
  }

  private initForm(comment: string | null) {
    this.form.set(
      new FormGroup({
        comment: new FormControl<string | null>(comment, Validators.required),
      }),
    );
  }
}
