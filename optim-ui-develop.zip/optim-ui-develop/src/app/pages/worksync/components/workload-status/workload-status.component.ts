import { ChangeDetectionStrategy, Component, computed, effect, inject, input, signal, TemplateRef, viewChild } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatDialog, MatDialogConfig, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';
import { GenericDialogComponent } from '@src/app/shared/components/generic-dialog/generic-dialog.component';
import {
  WorkloadEvolutionBarType,
  WorkloadExerciseStatus,
  WorkloadPostResponse,
  WorkloadSubmissionStatus,
  WorkloadValidationStatus,
} from '@src/app/shared/models/worksync.model';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { take } from 'rxjs';
import { TooltipComponent } from '@app/shared/components/tooltip/tooltip.component';
import { AccessRuleService } from '@services/access-rule/access-rule.service';

const DIALOG_CONFIG: MatDialogConfig = {
  panelClass: 'no-border-radius-dialog',
  width: '25%',
  height: '250px',
  maxWidth: '100vw',
  maxHeight: '100vh',
};

const CONFIRM_CONFIG: MatDialogConfig = {
  panelClass: 'no-border-radius-dialog',
  width: '30%',
  height: '25%',
  maxWidth: '100vw',
  maxHeight: '100vh',
};

enum ExerciseTypes {
  OP = 'OP',
  FCII = 'FCII',
}

@Component({
  selector: 'optim-workload-status',
  imports: [
    CommonModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatButtonToggleModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    TooltipComponent,
  ],
  templateUrl: './workload-status.component.html',
  styleUrl: './workload-status.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkloadStatusComponent {
  private filtersService: FiltersService = inject(FiltersService);
  private worksyncService: WorksyncService = inject(WorksyncService);
  private accessRuleService = inject(AccessRuleService);

  protected readonly evolutionData = this.worksyncService.evolution;
  protected readonly hasOpenExercise = this.worksyncService.hasOpenExercise;
  protected readonly user = this.accessRuleService.user;

  readonly dialog = inject(MatDialog);
  confirmDialog: MatDialogRef<GenericDialogComponent, unknown> | undefined;
  reloadDialog: MatDialogRef<GenericDialogComponent, unknown> | undefined;

  readonly openTemplate = viewChild.required<TemplateRef<unknown>>('openTemplate');
  readonly closeTemplate = viewChild.required<TemplateRef<unknown>>('closeTemplate');
  readonly messageTemplate = viewChild.required<TemplateRef<unknown>>('messageTemplate');

  modalMessage = signal<string>('');

  exerciseTypes = ExerciseTypes;

  form = new FormGroup({
    exerciseType: new FormControl<ExerciseTypes | undefined>(undefined, Validators.required),
    exerciseYear: new FormControl<number | undefined>(undefined, [Validators.max(99), Validators.min(10), Validators.required]),
  });

  private currentParams: string[] | undefined;

  loadEvolutionStatusData = input<boolean>(false);

  workloadSubmissionStatus = WorkloadSubmissionStatus;
  workloadValidationStatus = WorkloadValidationStatus;
  workloadExerciseStatus = WorkloadExerciseStatus;

  constructor() {
    //  TODO: Convertir en una llamada normal a getCanUpdate cuando se deshabilite la posibilidad de cambiar de usuario de pruebas
    effect(() => {
      const user = this.user();
      if (user?.userName) {
        this.worksyncService.getCanUpdate(user.userName);
      }
    });
    effect(() => {
      this.currentParams = this.filtersService.paramsFilter();
      if (this.loadEvolutionStatusData()) {
        this.loadData(this.currentParams);
      }
      this.worksyncService.getOpenExercise();
    });
  }

  async loadData(params?: string[]) {
    await this.worksyncService.getWorkLoadEvolution(params);
  }

  submissionStatus = computed<WorkloadSubmissionStatus | undefined>(() => {
    const evolutionData = this.evolutionData();
    return evolutionData ? evolutionData.submissionStatus : undefined;
  });

  validationStatus = computed<WorkloadValidationStatus | undefined>(() => {
    const evolutionData = this.evolutionData();
    return evolutionData ? evolutionData.validationStatus : undefined;
  });

  isAdmin = this.accessRuleService.isAdmin;

  closeExerciseDialog() {
    this.confirmDialog = this.dialog.open(GenericDialogComponent, {
      ...DIALOG_CONFIG,
      data: {
        title: 'Close exercise',
        content: this.closeTemplate(),
      },
    });
  }

  async closeExercise() {
    const response: WorkloadPostResponse = await this.worksyncService.closeExercise();
    if (!response.error) {
      this.reloadDialog = this.openMessageDialog('Completed', 'Exercise closed successfully');
      this.confirmDialog?.close();
      this.reloadOnClose();
    } else {
      this.openMessageDialog('Error closing exercise', response.message);
    }
  }

  openExerciseDialog() {
    this.setNewExerciseData();
    this.confirmDialog = this.dialog.open(GenericDialogComponent, {
      ...DIALOG_CONFIG,
      data: {
        title: 'Select the exercise options',
        content: this.openTemplate(),
      },
    });
  }

  private setNewExerciseData() {
    if (this.evolutionData()?.nextExerciseType) {
      const nextExerciseType = this.evolutionData()?.nextExerciseType === WorkloadEvolutionBarType.OP ? ExerciseTypes.OP : ExerciseTypes.FCII;
      this.form.controls.exerciseType.setValue(nextExerciseType);
      this.form.controls.exerciseType.disable();
    }
    if (this.evolutionData()?.nextExerciseNumber) {
      this.form.controls.exerciseYear.setValue(this.evolutionData()?.nextExerciseNumber);
    }
  }

  async openExercise() {
    const exerciseType: ExerciseTypes = this.form.controls.exerciseType.getRawValue()!;
    const exerciseYear: number = this.form.controls.exerciseYear.getRawValue()!;
    const exercise = `${exerciseType}${exerciseYear}`;
    const response: WorkloadPostResponse = await this.worksyncService.openExercise(exercise);
    if (!response.error) {
      this.reloadDialog = this.openMessageDialog('Completed', `Exercise ${exercise} opened successfully`);
      this.confirmDialog?.close();
      this.reloadOnClose();
    } else {
      this.openMessageDialog('Error opening exercise', response.message);
    }
  }

  private openMessageDialog(title: string, message: string) {
    const dialog = this.dialog.open(GenericDialogComponent, {
      ...CONFIRM_CONFIG,
      data: {
        title: title,
        content: this.messageTemplate(),
      },
    });
    this.modalMessage.set(message);
    return dialog;
  }

  private reloadOnClose() {
    this.reloadDialog!.afterClosed()
      .pipe(take(1))
      .subscribe(() => {
        this.reloadPage();
      });
  }

  private reloadPage() {
    this.filtersService.reloadData();
  }
}
