import { ChangeDetectionStrategy, Component, inject, signal, TemplateRef, viewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';
import { GenericDialogComponent } from '@src/app/shared/components/generic-dialog/generic-dialog.component';
import { SiglumSelectionComponent } from '@src/app/shared/components/siglum-selection/siglum-selection.component';
import { WorkloadUploadComponent } from '@src/app/shared/components/workload-upload/workload-upload.component';
import { SubmitRequestResult, WorkloadPostResponse } from '@src/app/shared/models/worksync.model';
import { take } from 'rxjs';
import { WorkloadCommentsComponent } from '../workload-comments/workload-comments.component';
import { AccessRuleService } from '@src/app/services/access-rule/access-rule.service';

const DIALOG_CONFIG: MatDialogConfig = {
  panelClass: 'no-border-radius-dialog',
  minWidth: '70%',
  height: '80%',
  maxWidth: '100vw',
  maxHeight: '100vh',
};

const CONFIRM_CONFIG: MatDialogConfig = {
  panelClass: 'no-border-radius-dialog',
  height: '35%',
  maxWidth: '100vw',
  maxHeight: '100vh',
};

const COMMENT_CONFIG: MatDialogConfig = {
  panelClass: 'no-border-radius-dialog',
  minWidth: '500px',
  height: '285px',
  maxWidth: '100vw',
  maxHeight: '100vh',
};

@Component({
  selector: 'optim-workload-submission',
  imports: [MatButtonModule, MatIconModule, SiglumSelectionComponent, WorkloadUploadComponent, WorkloadCommentsComponent],
  templateUrl: './workload-submission.component.html',
  styleUrl: './workload-submission.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkloadSubmissionComponent {
  private filtersService: FiltersService = inject(FiltersService);
  private worksyncService: WorksyncService = inject(WorksyncService);
  private accessRuleService: AccessRuleService = inject(AccessRuleService);

  protected readonly evolutionData = this.worksyncService.evolution;
  protected readonly canUpdate = this.worksyncService.canUpdate;
  protected readonly hasOpenExercise = this.worksyncService.hasOpenExercise;

  readonly dialog = inject(MatDialog);
  selectSiglumDialog: MatDialogRef<GenericDialogComponent, unknown> | undefined;
  uploadDialog: MatDialogRef<GenericDialogComponent, unknown> | undefined;
  commentDialog: MatDialogRef<GenericDialogComponent, unknown> | undefined;
  reloadDialog: MatDialogRef<GenericDialogComponent, unknown> | undefined;

  readonly submitTemplate = viewChild.required<TemplateRef<unknown>>('submitTemplate');
  readonly validateTemplate = viewChild.required<TemplateRef<unknown>>('validateTemplate');
  readonly uploadTemplate = viewChild.required<TemplateRef<unknown>>('uploadTemplate');
  readonly commentTemplate = viewChild.required<TemplateRef<unknown>>('commentTemplate');
  readonly messageTemplate = viewChild.required<TemplateRef<unknown>>('messageTemplate');

  modalMessage = signal<string>('');
  isDownloading = signal<boolean>(false);

  canAddComments = this.accessRuleService.canAddComments();
  canSubmitWorkload = this.accessRuleService.canSubmitWorkload();
  canValidateWorkload = this.accessRuleService.canValidateWorkload();

  submissionCompleted(response: SubmitRequestResult[]) {
    if (response.length > 0) {
      const siglums = response.map((r) => `${r.siglum}: ${!r.error ? 'Ok' : `<span class="error-message">${r.message || 'Error'}</span>`}`).join('<br />');
      const withErrors = response.filter((r) => r.error).length;
      if (withErrors === 0) {
        this.reloadDialog = this.openMessageDialog('Confirmation', `Submission completed for ${siglums}`);
      } else {
        this.reloadDialog = this.openMessageDialog('Error submitting', siglums);
      }
      this.reloadOnClose();
    } else {
      this.openMessageDialog('Error submitting', 'No siglums selected');
    }

    this.selectSiglumDialog?.close();
  }

  validationCompleted(response: WorkloadPostResponse) {
    if (!response.error) {
      this.reloadDialog = this.openMessageDialog('Confirmation', 'Validation completed');
      this.reloadOnClose();
    } else {
      this.openMessageDialog('Error validating', response.message);
    }
    this.selectSiglumDialog?.close();
  }

  addCommentCompleted(response: WorkloadPostResponse) {
    if (!response.error) {
      this.reloadDialog = this.openMessageDialog('Confirmation', 'Comment sent sucessfully');
    } else {
      this.openMessageDialog('Error sending comment', response.message);
    }
    this.commentDialog?.close();
  }

  openSubmitDialog() {
    this.selectSiglumDialog = this.dialog.open(GenericDialogComponent, {
      ...DIALOG_CONFIG,
      data: {
        title: 'Submit teams',
        content: this.submitTemplate(),
      },
    });
  }

  openValidateDialog() {
    this.selectSiglumDialog = this.dialog.open(GenericDialogComponent, {
      ...DIALOG_CONFIG,
      data: {
        title: 'Validate teams',
        content: this.validateTemplate(),
      },
    });
  }

  openUploadDialog() {
    this.uploadDialog = this.dialog.open(GenericDialogComponent, {
      ...CONFIRM_CONFIG,
      data: {
        title: 'Confirm upload',
        content: this.uploadTemplate(),
      },
    });
  }

  openCommentDialog() {
    this.commentDialog = this.dialog.open(GenericDialogComponent, {
      ...COMMENT_CONFIG,
      data: {
        title: 'Send HO comment',
        content: this.commentTemplate(),
      },
    });
  }

  async uploadFile(file: File) {
    this.uploadDialog?.close();
    const userSelected = this.getUserSelected();
    if (userSelected) {
      const response: WorkloadPostResponse = await this.worksyncService.uploadWorkload(file, [userSelected]);
      if (!response.error) {
        this.reloadDialog = this.openMessageDialog('Confirmation', 'Import completed successfully');
        this.reloadOnClose();
      } else {
        this.openMessageDialog('Error importing', response.message);
      }
    }
  }

  async downloadFile() {
    this.isDownloading.set(true);
    const userSelected = this.getUserSelected();
    if (userSelected) {
      await this.worksyncService.getWorkloadExport([userSelected]);
      this.isDownloading.set(false);
    }
  }

  private openMessageDialog(title: string, message: string) {
    const dialog = this.dialog.open(GenericDialogComponent, {
      ...CONFIRM_CONFIG,
      data: {
        title: title,
        content: this.messageTemplate(),
      },
    });
    this.modalMessage.set(message);
    return dialog;
  }

  private getUserSelected(): string {
    const filters = this.filtersService.paramsFilter();
    if (filters && filters.length > 0) {
      const userName = filters.find((filter) => filter.includes('userSelected'));
      return userName!;
    }
    return '';
  }

  private reloadOnClose() {
    this.reloadDialog!.afterClosed()
      .pipe(take(1))
      .subscribe(() => {
        this.reloadPage();
      });
  }

  private reloadPage() {
    this.filtersService.reloadData();
  }
}
