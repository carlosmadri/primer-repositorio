import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkloadSubmissionComponent } from './workload-submission.component';
import { signal } from '@angular/core';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';
import { AccessRuleService } from '@src/app/services/access-rule/access-rule.service';

describe('WorkloadSubmissionComponent', () => {
  let component: WorkloadSubmissionComponent;
  let fixture: ComponentFixture<WorkloadSubmissionComponent>;
  let mockWorksyncService: Partial<WorksyncService>;
  let mockFiltersService: Partial<FiltersService>;
  let mockAccessRuleService: Partial<AccessRuleService>;

  beforeEach(async () => {
    mockWorksyncService = {
      getWorkloadExport: jest.fn(),
      uploadWorkload: jest.fn(),
      canUpdate: signal<boolean>(true),
      hasOpenExercise: signal<boolean>(true),
    };

    mockAccessRuleService = {
      canAddComments: jest.fn(),
      canSubmitWorkload: jest.fn(),
      canValidateWorkload: jest.fn(),
    };

    mockFiltersService = {
      paramsFilter: signal<string[]>([]),
      reloadData: jest.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [WorkloadSubmissionComponent],
      providers: [
        { provide: WorksyncService, useValue: mockWorksyncService },
        { provide: FiltersService, useValue: mockFiltersService },
        { provide: AccessRuleService, useValue: mockAccessRuleService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(WorkloadSubmissionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
