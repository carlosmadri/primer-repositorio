import { ChangeDetectionStrategy, Component, viewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { CommonModule, NgClass } from '@angular/common';
import { ManageWorkloadTableComponent } from '@tables/manage-workload-table/manage-workload-table.component';
import { WorkloadPreviewComponent } from '../components/workload-preview/workload-preview.component';
import { WorkloadStatusComponent } from '../components/workload-status/workload-status.component';
import { WorkloadSubmissionComponent } from '../components/workload-submission/workload-submission.component';
import { WorkloadFiltersComponent } from '@components/workload-filters/workload-filters.component';
import { MatDialogModule } from '@angular/material/dialog';

@Component({
  selector: 'optim-manage-workload',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    MatButtonModule,
    WorkloadStatusComponent,
    WorkloadSubmissionComponent,
    WorkloadPreviewComponent,
    MatExpansionModule,
    MatIconModule,
    MatDatepickerModule,
    NgClass,
    ManageWorkloadTableComponent,
    WorkloadFiltersComponent,
    MatIconModule,
    MatDialogModule,
  ],
  templateUrl: './manage-workload.component.html',
  styleUrl: './manage-workload.component.scss',
})
export class ManageWorkloadComponent {
  activeFilters = false;
  readonly tableComponent = viewChild.required(ManageWorkloadTableComponent);

  toggleActiveFilters(event: boolean) {
    this.activeFilters = event;
  }

  addWorkload() {
    this.tableComponent().addEmptyWorkload();
  }
}
