import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageTeamsComponent } from './manage-teams.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { EmployeeDialogComponent } from '../dialogs/employee-dialog/employee-dialog.component';
import { MockWorkoutEmployeeDialogComponent, MockWorkoutTeamOutlookComponent } from '@src/app/mocks/components';
import { MatDialogModule } from '@angular/material/dialog';
import { ManageTableComponent } from '@src/app/tables/manage-table/manage-table.component';
import { MockManageTableComponent } from '@src/app/mocks/components/workout-manage-job-requests-mock.component';
import { ManageLeversService } from '@src/app/services/levers/manage-levers.service';
import { WorkoutTeamOutlookComponent } from '../components/workout-team-outlook/workout-team-outlook.component';
import { EmployeeFiltersComponent } from '@src/app/shared/components/employee-filters/employee-filters.component';
import { MockEmployeeFiltersComponent } from '@src/app/mocks/components/employee-filters-mock.component';

describe('ManageTeamsComponent', () => {
  let component: ManageTeamsComponent;
  let fixture: ComponentFixture<ManageTeamsComponent>;
  let mockManageLeversService: Partial<ManageLeversService>;

  beforeEach(async () => {
    mockManageLeversService = {
      openLeverDialog: jest.fn(),
    };
    TestBed.overrideComponent(ManageTeamsComponent, {
      remove: {
        imports: [EmployeeDialogComponent, ManageTableComponent, WorkoutTeamOutlookComponent, EmployeeFiltersComponent],
      },
      add: {
        imports: [MockWorkoutEmployeeDialogComponent, MockManageTableComponent, MockWorkoutTeamOutlookComponent, MockEmployeeFiltersComponent],
      },
    });

    await TestBed.configureTestingModule({
      imports: [ManageTeamsComponent, MockManageTableComponent, MockWorkoutTeamOutlookComponent, NoopAnimationsModule, MatDialogModule],
      providers: [{ provide: ManageLeversService, useValue: mockManageLeversService }],
    }).compileComponents();

    fixture = TestBed.createComponent(ManageTeamsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
