import { ComponentHarness } from '@angular/cdk/testing';
import { MatSelectHarness } from '@angular/material/select/testing';
import { MatInputHarness } from '@angular/material/input/testing';
import { MatButtonHarness } from '@angular/material/button/testing';
import { MatCheckboxHarness } from '@angular/material/checkbox/testing';

export class LeverDialogHarness extends ComponentHarness {
  static hostSelector = 'optim-lever-dialog';

  getLeverTypeSelect = this.locatorFor(MatSelectHarness.with({ selector: '[formControlName="leverType"]' }));
  private getFTEInput = this.locatorFor(MatInputHarness.with({ selector: '[formControlName="fte"]' }));
  getCountrySelect = this.locatorFor(MatSelectHarness.with({ selector: '[formControlName="country"]' }));
  private getCostCenterSelect = this.locatorFor(MatSelectHarness.with({ selector: '[formControlName="costCenter"]' }));
  private getWorkforceSelect = this.locatorFor(MatSelectHarness.with({ selector: '[formControlName="activeWorkforce"]' }));
  private getDirectSelect = this.locatorFor(MatSelectHarness.with({ selector: '[formControlName="direct"]' }));
  private getStartDateInput = this.locatorFor(MatInputHarness.with({ selector: '[formControlName="startDateValue"]' }));
  private getEndDateInput = this.locatorFor(MatInputHarness.with({ selector: '[formControlName="endDateValue"]' }));
  private getSiglumOriginSelect = this.locatorFor(MatSelectHarness.with({ selector: '[formControlName="siglumOrigin"]' }));
  private getSiglumOriginOutOfT1QSelect = this.locatorFor(MatCheckboxHarness.with({ selector: '[data-test="siglum-origin-out-t1q"]' }));
  private getSiglumDestinationSelect = this.locatorFor(MatSelectHarness.with({ selector: '[formControlName="siglumDestination"]' }));
  private getSiglumDestinationOutOfT1QSelect = this.locatorFor(MatCheckboxHarness.with({ selector: '[data-test="siglum-destination-out-t1q"]' }));
  getSubmitButton = this.locatorFor(MatButtonHarness.with({ text: 'Submit' }));

  async selectLeverType(value: string): Promise<void> {
    const select = await this.getLeverTypeSelect();
    await select.open();
    await select.clickOptions({ text: value });
  }

  async setFTE(value: string): Promise<void> {
    const input = await this.getFTEInput();
    await input.setValue(value);
  }

  async selectCountry(country: string): Promise<void> {
    const select = await this.getCountrySelect();
    await select.open();
    await select.clickOptions({ text: country });
  }

  async selectCostCenter(costCenter: string): Promise<void> {
    const select = await this.getCostCenterSelect();
    await select.open();
    await select.clickOptions({ text: costCenter });
  }

  async selectWorkforceType(type: string): Promise<void> {
    const select = await this.getWorkforceSelect();
    await select.open();
    await select.clickOptions({ text: type });
  }

  async selectDirect(value: string): Promise<void> {
    const select = await this.getDirectSelect();
    await select.open();
    await select.clickOptions({ text: value });
  }

  async setStartDate(date: string): Promise<void> {
    const input = await this.getStartDateInput();
    await input.setValue(date);
  }

  async setEndDate(date: string): Promise<void> {
    const input = await this.getEndDateInput();
    await input.setValue(date);
  }

  async selectSiglumOrigin(siglum: string): Promise<void> {
    const select = await this.getSiglumOriginSelect();
    await select.open();
    await select.clickOptions({ text: siglum });
  }

  async checkSiglumOriginOutOfT1QSelect(): Promise<void> {
    const checkbox = await this.getSiglumOriginOutOfT1QSelect();
    await checkbox.check();
  }

  async uncheckSiglumOriginOutOfT1QSelect(): Promise<void> {
    const checkbox = await this.getSiglumOriginOutOfT1QSelect();
    await checkbox.uncheck();
  }

  async selectSiglumDestination(siglum: string): Promise<void> {
    const select = await this.getSiglumDestinationSelect();
    await select.open();
    await select.clickOptions({ text: siglum });
  }

  async checkSiglumDestinationOutOfT1QSelect(): Promise<void> {
    const checkbox = await this.getSiglumDestinationOutOfT1QSelect();
    await checkbox.check();
  }

  async uncheckSiglumDestinationOutOfT1QSelect(): Promise<void> {
    const checkbox = await this.getSiglumDestinationOutOfT1QSelect();
    await checkbox.uncheck();
  }

  async submitForm(): Promise<void> {
    const button = await this.getSubmitButton();
    await button.click();
  }

  async submitButtonDisabled(): Promise<boolean> {
    const button = await this.getSubmitButton();
    return await button.isDisabled();
  }
}
