import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TestbedHarnessEnvironment } from '@angular/cdk/testing/testbed';

import { LeverDialogComponent } from './lever-dialog.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TeamOutlookService } from '@services/team-outlook/team-outlook.service';
import { Signal, signal, WritableSignal } from '@angular/core';
import { TeamOutlook } from '@src/app/shared/models/team-outlook.model';
import { LeversService } from '@services/levers/levers.service';
import { CostCenterService } from '@services/cost-center/cost-center.service';
import { CostCenter } from '@src/app/shared/models/cost-center.model';
import { Location } from '@src/app/shared/models/location.model';
import { FiltersService } from '@services/filters/filters.service';
import { SiglumService } from '@services/siglum/siglum.service';
import { LeverDialogData, ManageLeversService } from '@services/levers/manage-levers.service';
import { impersonalLeverTypes, Lever, LEVER_TYPES, personalLeverTypes } from '@models/lever.model';
import { Siglum } from '@src/app/shared/models/siglum.model';
import { LeverDialogHarness } from './lever-dialog.harness';
import { DIRECT_INDIRECT_VALUES, Employee } from '@src/app/shared/models/employee.model';
import moment from 'moment';
import { AccessRuleService } from '@src/app/services/access-rule/access-rule.service';

const mockLocations: Location[] = [
  {
    id: 1,
    country: 'Belgium',
    site: 'Diegem',
    kapisCode: '1000',
  } as Location,
  {
    id: 2,
    country: 'France',
    site: 'City2',
    kapisCode: '1001',
  } as Location,
];

const mockCostCenters: Partial<CostCenter>[] = [
  {
    id: 1,
    costCenterCode: 'BE1000',
    location: mockLocations[0],
  },
  {
    id: 2,
    costCenterCode: 'BE1001',
    location: mockLocations[1],
  },
];

const mockSiglums: Siglum[] = [
  {
    id: 1,
    siglumHR: 'siglumHR1',
    siglum6: 'siglum6',
    siglum5: 'siglum5',
    siglum4: 'siglum4',
  },
  {
    id: 2,
    siglumHR: 'siglumHR2',
    siglum6: 'siglum6',
    siglum5: 'siglum5',
    siglum4: 'siglum4',
  },
];

const mockActiveWorkForce = 'AWF';

let mockDialogData: LeverDialogData;
let mockEmployee: Partial<Employee>;
let mockEditLever: Partial<Lever>;

describe('LeverDialogComponent', () => {
  let component: LeverDialogComponent;
  let fixture: ComponentFixture<LeverDialogComponent>;
  let harness: LeverDialogHarness;

  let mockTeamOutlookService: Partial<TeamOutlookService>;
  let mockLeversService: Partial<LeversService>;
  let mockSiglumService: Partial<SiglumService>;
  let mockCostCenterService: Partial<CostCenterService>;
  let mockManageLeversService: Partial<ManageLeversService>;
  let mockFiltersService: Partial<FiltersService>;
  let mockParamsFilter: WritableSignal<string[]>;
  let mockAccessRuleService: Partial<AccessRuleService>;

  const mockDialogRef = {
    close: jest.fn(),
  };

  async function createComponent(dialogData?: LeverDialogData) {
    TestBed.configureTestingModule({
      imports: [LeverDialogComponent, NoopAnimationsModule],
      providers: [
        { provide: TeamOutlookService, useValue: mockTeamOutlookService },
        { provide: LeversService, useValue: mockLeversService },
        { provide: CostCenterService, useValue: mockCostCenterService },
        { provide: ManageLeversService, useValue: mockManageLeversService },
        { provide: FiltersService, useValue: mockFiltersService },
        { provide: SiglumService, useValue: mockSiglumService },
        { provide: AccessRuleService, useValue: mockAccessRuleService },
        { provide: MatDialogRef, useValue: mockDialogRef },
        { provide: MAT_DIALOG_DATA, useValue: dialogData },
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(LeverDialogComponent);
    component = fixture.componentInstance;
    harness = await TestbedHarnessEnvironment.harnessForFixture(fixture, LeverDialogHarness);
    fixture.detectChanges();
  }

  beforeEach(() => {
    mockTeamOutlookService = {
      teamOutlook: signal<TeamOutlook | null>(null),
    };

    mockLeversService = {
      getLever: jest.fn(),
    };

    mockSiglumService = {
      allSiglums: signal([]),
      allVisibleSiglums: signal([]),
    };

    mockCostCenterService = {
      allCostCenters: signal<CostCenter[]>(mockCostCenters as CostCenter[]),
      getAllCostCenters: jest.fn(),
    };

    mockManageLeversService = {
      upsertLever: jest.fn(),
    };

    mockAccessRuleService = {
      canAddInternalMobility: jest.fn().mockReturnValue(true),
      canAddPerimeterChange: jest.fn().mockReturnValue(true),
    };

    mockParamsFilter = signal<string[]>([]);

    mockFiltersService = {
      paramsFilter: mockParamsFilter as Signal<string[]>,
      getFilterValues: jest.fn().mockImplementation((param: string) => {
        switch (param) {
          case 'country':
            return mockLocations.map((location) => location.country);
          case 'direct':
            return ['Direct', 'Indirect'];
          case 'activeWorkforce':
            return [mockActiveWorkForce, 'NAWF', 'TEMP'];
          case 'site':
            return mockLocations.map((location) => location.site);
          default:
            return [];
        }
      }),
    };

    mockDialogData = {
      employeeFTE: 0,
      editLever: undefined,
      leverTypes: [],
      employee: undefined,
    };
  });

  afterEach(() => {
    TestBed.resetTestingModule();
  });

  it('should create', async () => {
    await createComponent(mockDialogData);
    expect(component).toBeTruthy();
  });

  describe('Create Impersonal lever types', () => {
    beforeEach(async () => {
      (mockSiglumService.allSiglums as WritableSignal<Siglum[]>).set(mockSiglums);
      const impersonalMockData = { ...mockDialogData, leverTypes: impersonalLeverTypes };
      await createComponent(impersonalMockData);
      await fixture.whenStable();
    });

    it('should show only impersonal lever types options', async () => {
      const select = await harness.getLeverTypeSelect();
      await select.open();
      const options = await select.getOptions();

      expect(options.length).toBe(impersonalLeverTypes.length);
    });

    describe('Perimeter change levers', () => {
      it('should create new Perimeter Change lever with siglums origin and destination', async () => {
        await harness.selectLeverType(LEVER_TYPES.PERIMETER_CHANGE);
        fixture.whenStable();
        await harness.setFTE('1');
        await harness.selectCountry(mockLocations[1].country);
        fixture.whenStable();
        await harness.selectCostCenter(`${mockLocations[1].site} / ${mockCostCenters[1].costCenterCode}`);
        await harness.selectWorkforceType(mockActiveWorkForce);
        await harness.selectDirect(DIRECT_INDIRECT_VALUES.DIRECT);
        await harness.setStartDate('01/01/2024');
        await harness.selectSiglumOrigin(mockSiglums[0].siglumHR);
        await harness.selectSiglumDestination(mockSiglums[1].siglumHR);
        fixture.whenStable();
        await harness.submitForm();

        expect(mockManageLeversService.upsertLever).toHaveBeenCalledWith(
          expect.objectContaining({
            leverType: LEVER_TYPES.PERIMETER_CHANGE,
            fte: 1,
            startDate: expect.any(String),
            country: mockLocations[1].country,
            costCenter: { id: mockCostCenters[1].id },
            activeWorkforce: mockActiveWorkForce,
            direct: 'Direct',
            siglumOrigin: { id: mockSiglums[0].id },
            siglumDestination: { id: mockSiglums[1].id },
            employee: expect.objectContaining({ impersonal: true }),
          }),
          undefined,
          undefined,
        );
      });

      it('should create new Perimeter Change lever with siglum origin outside T1Q', async () => {
        await harness.selectLeverType(LEVER_TYPES.PERIMETER_CHANGE);
        fixture.whenStable();
        await harness.setFTE('1');
        await harness.selectCountry(mockLocations[1].country);
        fixture.whenStable();
        await harness.selectCostCenter(`${mockLocations[1].site} / ${mockCostCenters[1].costCenterCode}`);
        await harness.selectWorkforceType(mockActiveWorkForce);
        await harness.selectDirect(DIRECT_INDIRECT_VALUES.DIRECT);
        await harness.setStartDate('01/01/2024');
        await harness.checkSiglumOriginOutOfT1QSelect();
        await harness.selectSiglumDestination(mockSiglums[1].siglumHR);
        fixture.whenStable();
        await harness.submitForm();

        expect(mockManageLeversService.upsertLever).toHaveBeenCalledWith(
          expect.objectContaining({
            siglumOrigin: null,
            siglumDestination: { id: mockSiglums[1].id },
          }),
          undefined,
          undefined,
        );
      });

      it('should create new Perimeter Change lever with siglum destination outside T1Q', async () => {
        await harness.selectLeverType(LEVER_TYPES.PERIMETER_CHANGE);
        fixture.whenStable();
        await harness.setFTE('1');
        await harness.selectCountry(mockLocations[1].country);
        fixture.whenStable();
        await harness.selectCostCenter(`${mockLocations[1].site} / ${mockCostCenters[1].costCenterCode}`);
        await harness.selectWorkforceType(mockActiveWorkForce);
        await harness.selectDirect(DIRECT_INDIRECT_VALUES.DIRECT);
        await harness.setStartDate('01/01/2024');
        await harness.selectSiglumOrigin(mockSiglums[0].siglumHR);
        await harness.checkSiglumDestinationOutOfT1QSelect();
        fixture.whenStable();
        await harness.submitForm();

        expect(mockManageLeversService.upsertLever).toHaveBeenCalledWith(
          expect.objectContaining({
            siglumOrigin: { id: mockSiglums[0].id },
            siglumDestination: null,
          }),
          undefined,
          undefined,
        );
      });

      it('should not create new Perimeter Change lever with siglum origin and destination outside T1Q', async () => {
        await harness.selectLeverType(LEVER_TYPES.PERIMETER_CHANGE);
        fixture.whenStable();
        await harness.setFTE('1');
        await harness.selectCountry(mockLocations[1].country);
        fixture.whenStable();
        await harness.selectCostCenter(`${mockLocations[1].site} / ${mockCostCenters[1].costCenterCode}`);
        await harness.selectWorkforceType(mockActiveWorkForce);
        await harness.selectDirect(DIRECT_INDIRECT_VALUES.DIRECT);
        await harness.setStartDate('01/01/2024');
        await harness.checkSiglumOriginOutOfT1QSelect();
        await harness.checkSiglumDestinationOutOfT1QSelect();
        fixture.whenStable();

        const submitButtonDisabled = await harness.submitButtonDisabled();
        expect(submitButtonDisabled).toBeTruthy();
      });

      it('should reset the form after the Lever Type changes', async () => {
        await harness.selectLeverType(LEVER_TYPES.PERIMETER_CHANGE);
        fixture.whenStable();
        await harness.setFTE('1');
        await harness.selectCountry(mockLocations[1].country);
        fixture.whenStable();
        await harness.selectCostCenter(`${mockLocations[1].site} / ${mockCostCenters[1].costCenterCode}`);
        await harness.selectWorkforceType(mockActiveWorkForce);
        await harness.selectDirect(DIRECT_INDIRECT_VALUES.DIRECT);
        await harness.setStartDate('01/01/2024');
        await harness.selectSiglumOrigin(mockSiglums[0].siglumHR);
        await harness.selectSiglumDestination(mockSiglums[1].siglumHR);
        fixture.whenStable();

        const countryValue = await harness.getCountrySelect();

        let submitButtonDisabled = await harness.submitButtonDisabled();
        expect(submitButtonDisabled).toBeFalsy();
        expect(await countryValue.getValueText()).toBe(mockLocations[1].country);

        await harness.selectLeverType(LEVER_TYPES.REDEPLOYMENT);
        fixture.whenStable();

        expect(await countryValue.getValueText()).toBe('');

        submitButtonDisabled = await harness.submitButtonDisabled();
        expect(submitButtonDisabled).toBeTruthy();
      });
    });

    describe('Redeployment levers', () => {
      it('should create new Redeployment lever', async () => {
        await harness.selectLeverType(LEVER_TYPES.REDEPLOYMENT);
        fixture.whenStable();
        await harness.setFTE('1');
        await harness.selectCountry(mockLocations[1].country);
        fixture.whenStable();
        await harness.selectCostCenter(`${mockLocations[1].site} / ${mockCostCenters[1].costCenterCode}`);
        await harness.selectWorkforceType(mockActiveWorkForce);
        await harness.selectDirect(DIRECT_INDIRECT_VALUES.DIRECT);
        await harness.setStartDate('01/01/2024');
        await harness.selectSiglumOrigin(mockSiglums[0].siglumHR);
        fixture.whenStable();
        await harness.submitForm();

        expect(mockManageLeversService.upsertLever).toHaveBeenCalledWith(
          expect.objectContaining({
            leverType: LEVER_TYPES.REDEPLOYMENT,
            fte: 1,
            startDate: expect.any(String),
            country: mockLocations[1].country,
            costCenter: { id: mockCostCenters[1].id },
            activeWorkforce: mockActiveWorkForce,
            direct: 'Direct',
            siglumOrigin: { id: mockSiglums[0].id },
            siglumDestination: null,
            employee: expect.objectContaining({ impersonal: true }),
          }),
          undefined,
          undefined,
        );
      });
    });
  });

  describe('Edit Perimeter change levers', () => {
    beforeEach(async () => {
      mockEmployee = {
        id: 1,
        impersonal: true,
        employeeId: 1,
        direct: DIRECT_INDIRECT_VALUES.DIRECT,
        firstName: 'Impersonal',
      };
      mockEditLever = {
        id: 1,
        leverType: LEVER_TYPES.PERIMETER_CHANGE,
        fte: 1,
        startDate: '2024-01-01',
        costCenter: { id: mockCostCenters[1].id, location: mockLocations[1] } as CostCenter,
        activeWorkforce: mockActiveWorkForce,
        direct: DIRECT_INDIRECT_VALUES.DIRECT,
        siglumOrigin: { id: mockSiglums[0].id } as Siglum,
        siglumDestination: { id: mockSiglums[1].id } as Siglum,
        employee: mockEmployee as Employee,
        highlights: 'test',
      };
      jest.spyOn(mockLeversService, 'getLever').mockResolvedValue(mockEditLever as Lever);
      (mockSiglumService.allSiglums as WritableSignal<Siglum[]>).set(mockSiglums);
      const impersonalMockData = { ...mockDialogData, leverTypes: impersonalLeverTypes, editLever: mockEditLever as Lever, employee: mockEmployee as Employee };
      await createComponent(impersonalMockData);
      await fixture.whenStable();
    });

    describe('Edit Perimeter change levers', () => {
      it('should edit Perimeter change lever', async () => {
        const leverTypeSelect = await harness.getLeverTypeSelect();

        const leverTypeDisabled = await leverTypeSelect.isDisabled();
        expect(leverTypeDisabled).toBeTruthy();

        await harness.submitForm();

        expect(mockManageLeversService.upsertLever).toHaveBeenCalledWith(
          expect.objectContaining({
            leverType: mockEditLever.leverType,
            fte: mockEditLever.fte,
            startDate: moment(mockEditLever.startDate).toISOString(),
            endDate: undefined,
            country: mockLocations[1].country,
            costCenter: { id: mockEditLever.costCenter!.id },
            activeWorkforce: mockEditLever.activeWorkforce,
            direct: mockEditLever.direct,
            siglumOrigin: { id: mockEditLever.siglumOrigin!.id },
            siglumDestination: { id: mockEditLever.siglumDestination!.id },
            highlights: mockEditLever.highlights,
            employee: expect.objectContaining({ impersonal: mockEmployee.impersonal }),
          }),
          mockEmployee as Employee,
          mockEditLever as Lever,
        );
      });

      it('should disable Submit button if both siglums are equal', async () => {
        await harness.selectSiglumOrigin(mockSiglums[0].siglumHR);
        await harness.selectSiglumDestination(mockSiglums[0].siglumHR);
        fixture.whenStable();

        const submitButtonDisabled = await harness.submitButtonDisabled();
        expect(submitButtonDisabled).toBeTruthy();
      });
    });
  });

  describe('Create Personal lever types', () => {
    beforeEach(async () => {
      mockEmployee = {
        id: 1,
        impersonal: false,
        employeeId: 1,
        direct: DIRECT_INDIRECT_VALUES.DIRECT,
        firstName: 'Test',
      };
      (mockSiglumService.allSiglums as WritableSignal<Siglum[]>).set(mockSiglums);
      (mockSiglumService.allVisibleSiglums as WritableSignal<Siglum[]>).set(mockSiglums);
      const personalMockData = {
        ...mockDialogData,
        leverTypes: personalLeverTypes,
        employee: mockEmployee as Employee,
        employeeFTE: 1,
      };
      await createComponent(personalMockData);
      await fixture.whenStable();
    });

    it('should show only impersonal lever types options', async () => {
      const select = await harness.getLeverTypeSelect();
      await select.open();
      const options = await select.getOptions();

      expect(options.length).toBe(personalLeverTypes.length);
    });

    describe('Internal mobility levers', () => {
      it('should create new Internal mobility lever', async () => {
        await harness.selectLeverType(LEVER_TYPES.INTERNAL_MOBILITY);
        fixture.whenStable();
        await harness.setStartDate('01/01/2024');
        await harness.selectSiglumDestination(mockSiglums[1].siglumHR);
        fixture.whenStable();
        await harness.submitForm();

        expect(mockManageLeversService.upsertLever).toHaveBeenCalledWith(
          expect.objectContaining({
            leverType: LEVER_TYPES.INTERNAL_MOBILITY,
            fte: -1,
            startDate: expect.any(String),
            siglumOrigin: null,
            siglumDestination: { id: mockSiglums[1].id },
            employee: expect.objectContaining({ impersonal: false }),
          }),
          mockEmployee as Employee,
          undefined,
        );
      });
    });
  });

  describe('Role protected personal actions', () => {
    beforeEach(async () => {
      mockEmployee = {
        id: 1,
        impersonal: false,
        employeeId: 1,
        direct: DIRECT_INDIRECT_VALUES.DIRECT,
        firstName: 'Test',
      };
      (mockSiglumService.allSiglums as WritableSignal<Siglum[]>).set(mockSiglums);
      (mockSiglumService.allVisibleSiglums as WritableSignal<Siglum[]>).set(mockSiglums);
      const personalMockData = {
        ...mockDialogData,
        leverTypes: personalLeverTypes,
        employee: mockEmployee as Employee,
        employeeFTE: 1,
      };
      mockAccessRuleService = {
        canAddInternalMobility: jest.fn().mockReturnValue(false),
      };
      await createComponent(personalMockData);
      await fixture.whenStable();
    });

    it('should not display Internal mobility option if user has not permissions', async () => {
      const select = await harness.getLeverTypeSelect();
      await select.open();
      const options = await select.getOptions();
      const optionsValues = await Promise.all(options.map((option) => option.getText()));

      expect(optionsValues?.length).toBe(personalLeverTypes.length - 1);
      expect(optionsValues).not.toContain(LEVER_TYPES.INTERNAL_MOBILITY);
    });
  });

  describe('Role protected impersonal actions', () => {
    beforeEach(async () => {
      (mockSiglumService.allSiglums as WritableSignal<Siglum[]>).set(mockSiglums);
      const impersonalMockData = { ...mockDialogData, leverTypes: impersonalLeverTypes };
      mockAccessRuleService = {
        canAddPerimeterChange: jest.fn().mockReturnValue(false),
      };
      await createComponent(impersonalMockData);
      await fixture.whenStable();
    });

    it('should not display Perimeter change option if user has not permissions', async () => {
      const select = await harness.getLeverTypeSelect();
      await select.open();
      const options = await select.getOptions();
      const optionsValues = await Promise.all(options.map((option) => option.getText()));

      expect(optionsValues?.length).toBe(impersonalLeverTypes.length - 1);
      expect(optionsValues).not.toContain(LEVER_TYPES.PERIMETER_CHANGE);
    });
  });
});
