import { AfterViewInit, ChangeDetectionStrategy, Component, computed, inject, OnDestroy, OnInit, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialog, MatDialogConfig, MatDialogModule } from '@angular/material/dialog';
import { MatFormField, MatFormFieldModule, MatLabel } from '@angular/material/form-field';
import { MatSelect, MatSelectModule } from '@angular/material/select';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatOption } from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { FiltersService } from '@services/filters/filters.service';
import { Lever, LEVER_TYPES } from '@models/lever.model';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { Moment } from 'moment';
import moment from 'moment';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { LeversService } from '@services/levers/levers.service';
import { JobRequestDialogComponent } from '../job-request-dialog/job-request-dialog.component';
import { DIRECT_INDIRECT_VALUES, Employee } from '@src/app/shared/models/employee.model';
import { CostCenterService } from '@services/cost-center/cost-center.service';
import { CostCenter } from '@models/cost-center.model';
import { TeamOutlookService } from '@services/team-outlook/team-outlook.service';
import { MatCheckbox } from '@angular/material/checkbox';
import { Siglum } from '@src/app/shared/models/siglum.model';
import { toSignal } from '@angular/core/rxjs-interop';
import { SiglumService } from '@src/app/services/siglum/siglum.service';
import { Subscription } from 'rxjs';
import { LeverDialogData, ManageLeversService } from '@src/app/services/levers/manage-levers.service';
import { LoadingComponent } from '@src/app/shared/components/loading/loading.component';
import { AccessRuleService } from '@src/app/services/access-rule/access-rule.service';

interface LeverForm {
  leverType: FormControl<string>;
  fte: FormControl<number | undefined>;
  highlights: FormControl<string>;
  startDate: FormControl<string | null>;
  startDateValue: FormControl<Moment | null>;
  endDate: FormControl<string | null>;
  endDateValue: FormControl<Moment | null>;
  country: FormControl<string | null>;
  costCenter: FormControl<number | null>;
  siglumDestination: FormControl<number | null>;
  siglumOrigin: FormControl<number | null>;
  direct: FormControl<DIRECT_INDIRECT_VALUES | undefined>;
  activeWorkforce: FormControl<string | undefined>;
}

enum FIELDS {
  START_DATE = 'startDateValue',
  END_DATE = 'endDateValue',
  FTE = 'fte',
  COUNTRY = 'country',
  COST_CENTER = 'costCenter',
  ACTIVE_WORKFORCE = 'activeWorkforce',
  DIRECT = 'direct',
  SIGLUM_DESTINATION = 'siglumDestination',
  SIGLUM_ORIGIN = 'siglumOrigin',
}

const REPLACEMENT_LEVER_TYPES = [
  LEVER_TYPES.LONG_TERM_SICKNESS,
  LEVER_TYPES.PARENTAL_LEAVE,
  LEVER_TYPES.MOBILITY_OUT,
  LEVER_TYPES.TEMP_RELEASE,
  LEVER_TYPES.PRE_RETIREMENT,
  LEVER_TYPES.RETIREMENT,
  LEVER_TYPES.OTHER_ABSENCE,
];

const SIGLUM_OUTSIDE_T1Q = 'OUTSIDE-T1Q';

const DIALOG_CONFIG: MatDialogConfig = {
  panelClass: 'no-border-radius-dialog',
  width: '80%',
  height: '95%',
  maxWidth: '100vw',
  maxHeight: '100vh',
};

interface siglumSelect {
  siglumId: number;
  siglumHR: string;
}

@Component({
  selector: 'optim-lever-dialog',
  imports: [
    MatDialogModule,
    MatButtonModule,
    MatFormField,
    MatLabel,
    MatSelect,
    MatCheckbox,
    ReactiveFormsModule,
    MatOption,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatDatepickerModule,
    MatMomentDateModule,
    MatIconModule,
    MatTooltipModule,
    LoadingComponent,
  ],
  templateUrl: './lever-dialog.component.html',
  styleUrl: './lever-dialog.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LeverDialogComponent implements OnInit, AfterViewInit, OnDestroy {
  private teamOutlookService: TeamOutlookService = inject(TeamOutlookService);
  readonly dialog = inject(MatDialog);
  leversService = inject(LeversService);
  private siglumService = inject(SiglumService);
  private costCenterService = inject(CostCenterService);
  private filterService = inject(FiltersService);
  private manageLeversService = inject(ManageLeversService);
  private accessRuleService = inject(AccessRuleService);
  protected readonly teamOutlookData = this.teamOutlookService.teamOutlook;

  data = inject<LeverDialogData>(MAT_DIALOG_DATA);
  employeeFTE: number = this.data.employeeFTE ?? 0;
  editLever: Lever | undefined = this.data.editLever ?? undefined;
  lever: Lever | undefined;
  isImpersonalLevers = this.data.leverTypes?.includes(LEVER_TYPES.PERIMETER_CHANGE) || this.data.leverTypes?.includes(LEVER_TYPES.REDEPLOYMENT);
  leverTypes = this.getLeverTypes();
  employee: Employee | undefined = this.data.employee;
  form: FormGroup<LeverForm> = this.getFormGroup();
  countryChangesSubscription: Subscription | undefined;
  readonly today = new Date();
  fields = FIELDS;
  leverTypesEnum = LEVER_TYPES;
  fteWarningMsg = "FTE value plus employee's FTE value result cannot be less than 0 and more than 1";
  private formFields: Record<FIELDS, boolean> = {
    startDateValue: true,
    endDateValue: true,
    fte: true,
    country: false,
    costCenter: false,
    activeWorkforce: false,
    direct: false,
    siglumDestination: false,
    siglumOrigin: false,
  };
  existRedeployments: boolean | undefined = false;
  impersonalSelected = false;

  isLoading = signal(false);

  siglumOriginOutside = signal(false);
  siglumDestinationOutside = signal(false);

  allCostCenter = signal<CostCenter[]>([]);
  allCountries = computed<string[]>(() => this.filterService.getFilterValues('country'));
  initialSiteInputValue = signal<string>('Site*');
  allCostCenters = computed<{ costCenterId: number; siteName: string }[]>(() => {
    const allCostCenter = this.allCostCenter().map((cc) => {
      return {
        costCenterId: cc.id,
        siteName: `${cc.location.site} / ${cc.costCenterCode}`,
      };
    });
    const sortedCostCenters = allCostCenter.sort((a, b) => a.siteName.localeCompare(b.siteName));
    return sortedCostCenters;
  });
  allActiveWorkforce = computed<string[]>(() => this.filterService.getFilterValues('activeWorkforce'));
  allDirects = computed<string[]>(() => this.filterService.getFilterValues('direct'));
  allSiglums = computed<siglumSelect[]>(() => {
    if (this.impersonalSelected) {
      return this.siglumsToSiglumsSelect(this.siglumService.allSiglums());
    } else {
      return this.siglumsToSiglumsSelect(this.siglumService.allVisibleSiglums());
    }
  });

  allSiglumsOrigin = computed<siglumSelect[]>(() => {
    if (this.siglumOriginOutside()) {
      return [{ siglumId: 0, siglumHR: SIGLUM_OUTSIDE_T1Q }];
    } else {
      return this.allSiglums();
    }
  });

  allSiglumsDestination = computed<siglumSelect[]>(() => {
    if (this.siglumDestinationOutside()) {
      return [{ siglumId: 0, siglumHR: SIGLUM_OUTSIDE_T1Q }];
    } else {
      return this.allSiglums();
    }
  });

  showFormField = computed<Record<string, boolean>>(() => {
    return this.formFields;
  });

  formChanges = toSignal(this.form.valueChanges);
  formInvalid = computed<boolean>(() => {
    const bothSiglumsOutside = this.siglumOriginOutside() && this.siglumDestinationOutside();
    const formValues = this.formChanges();
    let bothSiglumsEqual = false;
    if (!!formValues?.siglumOrigin && !!formValues?.siglumDestination) {
      bothSiglumsEqual = formValues?.siglumOrigin === formValues?.siglumDestination;
    }
    return this.form.invalid || bothSiglumsOutside || bothSiglumsEqual;
  });

  siglumsEqual = computed<boolean>(() => {
    const formValues = this.formChanges();
    return !!(formValues?.siglumOrigin !== null && formValues?.siglumDestination !== null && formValues?.siglumOrigin === formValues?.siglumDestination);
  });

  showCopyCurrent = signal<boolean>(false);

  async ngOnInit() {
    await this.costCenterService.getAllCostCenters();
    this.countryChangesSubscription = this.form.controls.country.valueChanges.subscribe((value) => this.onCountryChange(value));
    if (this.editLever) {
      this.leversService.getLever(this.editLever.id).then((lever) => {
        this.lever = lever;
        this.setEditLeverValues();
      });
    }
  }

  ngAfterViewInit() {
    this.checkRedeploymentExists();
  }

  ngOnDestroy(): void {
    this.countryChangesSubscription?.unsubscribe();
  }

  private checkRedeploymentExists() {
    const redeployments = this.teamOutlookData()?.leaversSummary.filter((el) => el.title === 'Redeployments')[0].value;
    if (redeployments) {
      this.existRedeployments = redeployments !== 0;
    }
  }

  private onCountryChange(value: string | null) {
    if (value) {
      const foundSites = this.filterService.getFilterValues('site', [value!]);
      const foundCostCenters = this.costCenterService.allCostCenters().filter((cc) => cc.location && foundSites.find((site) => site === cc.location.site));
      this.allCostCenter.set(foundCostCenters);
      this.form.controls.costCenter.setValue(null);
      this.form.controls.costCenter.enable();
    } else {
      this.form.controls.costCenter.disable();
    }
  }

  private getFormGroup(): FormGroup<LeverForm> {
    const leverFG = new FormGroup({
      leverType: new FormControl<string | null>(this.editLever?.leverType ?? null, Validators.required),
      fte: new FormControl<number | null>(this.editLever?.fte ?? null, Validators.required),
      highlights: new FormControl<string | null>(this.editLever?.highlights ?? null),
      startDate: new FormControl<string | undefined>(this.editLever?.startDate ?? undefined),
      startDateValue: new FormControl<string | null>(this.editLever?.startDate ?? null, Validators.required),
      endDate: new FormControl<string | undefined>(this.editLever?.endDate ?? undefined),
      endDateValue: new FormControl<string | null>(this.editLever?.endDate ?? null, Validators.required),
      country: new FormControl<string | null>(this.editLever?.costCenter?.location?.country ?? null),
      siglumDestination: new FormControl<number | null>(this.editLever?.siglumDestination?.id ?? null),
      siglumOrigin: new FormControl<number | null>(this.editLever?.siglumOrigin?.id ?? null),
      direct: new FormControl<DIRECT_INDIRECT_VALUES | null>(this.editLever?.direct ?? null),
      activeWorkforce: new FormControl<string | null>(this.editLever?.activeWorkforce ?? null),
      costCenter: new FormControl<number | null>(this.editLever?.costCenter?.id ?? null),
    } as LeverForm);

    return leverFG;
  }

  private getLeverTypes() {
    const leverTypes = this.data.leverTypes?.sort();
    const cantAddInternalMobility = !this.isImpersonalLevers && !this.accessRuleService.canAddInternalMobility() && !this.editLever;
    if (cantAddInternalMobility) {
      return leverTypes?.filter((type) => type !== LEVER_TYPES.INTERNAL_MOBILITY);
    }

    const canAddPerimeterChange = this.isImpersonalLevers && !this.accessRuleService.canAddPerimeterChange() && !this.editLever;
    if (canAddPerimeterChange) {
      return leverTypes?.filter((type) => type !== LEVER_TYPES.PERIMETER_CHANGE);
    }
    return this.data.leverTypes?.sort();
  }

  private setEditLeverValues() {
    if (this.lever) {
      this.form.controls.leverType.disable();
      this.changeLeverType(this.lever.leverType);
      this.form.controls.country.setValue(this.lever.costCenter?.location?.country ?? null);
      const costCenterId = this.lever.costCenter?.id;
      if (costCenterId) {
        const siteCostCenterValue = this.allCostCenters().find((cc) => cc.costCenterId === costCenterId);
        this.form.controls.costCenter.setValue(siteCostCenterValue?.costCenterId ?? null);
      }
      this.form.controls.direct.setValue(this.lever.direct);
      this.form.controls.fte.setValue(this.lever.fte);
      this.form.controls.activeWorkforce.setValue(this.lever.activeWorkforce);
      if (this.lever.leverType === LEVER_TYPES.PERIMETER_CHANGE && this.lever.siglumOrigin === null) {
        this.originOutsideChange(true);
      } else {
        this.form.controls.siglumOrigin!.setValue(this.lever.siglumOrigin?.id ?? null);
      }
      if (this.lever.leverType === LEVER_TYPES.PERIMETER_CHANGE && this.lever.siglumDestination === null) {
        this.destinationOutsideChange(true);
      } else {
        this.form.controls.siglumDestination!.setValue(this.lever.siglumDestination?.id ?? null);
      }
      this.form.controls.highlights.setValue(this.lever.highlights);
      if (this.lever.startDate) {
        this.form.controls.startDateValue.setValue(moment(this.lever.startDate));
      }
      if (this.lever.endDate) {
        this.form.controls.endDateValue.setValue(moment(this.lever.endDate));
      }
      this.form.updateValueAndValidity();
    }
  }

  private enableFormField(fg: FormGroup, field: FIELDS) {
    fg.get(field)!.setValidators([Validators.required]);
    this.formFields[field] = true;
  }

  private disableFormField(fg: FormGroup, field: FIELDS) {
    fg.get(field)!.clearValidators();
    this.formFields[field] = false;
    if (!this.lever) {
      fg.get(field)!.setValue(null);
    }
  }

  private enableFTEValue() {
    this.form.controls.fte.enable();
    this.form.controls.fte.setValidators([
      Validators.max(this.maxFTE),
      Validators.min(this.minFTE),
      Validators.pattern(/^-?(\d+(\.\d{0,1})?|\.\d{1})$/),
      Validators.required,
    ]);
    this.fteWarningMsg = `FTE value must be between ${this.minFTE} and ${this.maxFTE}, not including 0. One decimal is allowed.`;
  }

  private get minFTE() {
    if (this.employeeFTE === 0 || this.isImpersonal()) {
      return -1;
    }
    return -1 * this.employeeFTE;
  }

  private get maxFTE() {
    if (this.employeeFTE === 0 || this.isImpersonal()) {
      return 1;
    }
    return (100 - Number(this.employeeFTE.toFixed(2)) * 100) / 100;
  }

  private isImpersonal() {
    return this.form.controls['leverType'].value === LEVER_TYPES.REDEPLOYMENT || this.form.controls['leverType'].value === LEVER_TYPES.PERIMETER_CHANGE;
  }

  formDefaultState(type: string) {
    this.form.reset();
    this.siglumDestinationOutside.set(false);
    this.siglumOriginOutside.set(false);
    this.form.controls.leverType.setValue(type);

    this.disableFormField(this.form, FIELDS.COUNTRY);
    this.disableFormField(this.form, FIELDS.ACTIVE_WORKFORCE);
    this.disableFormField(this.form, FIELDS.DIRECT);
    this.enableFormField(this.form, FIELDS.END_DATE);
    this.enableFormField(this.form, FIELDS.FTE);
    this.disableFormField(this.form, FIELDS.SIGLUM_DESTINATION);
    this.disableFormField(this.form, FIELDS.SIGLUM_ORIGIN);
    if (!this.lever) {
      this.form.controls.endDate.setValue(null);
      this.form.controls.endDateValue.setValue(null);
      this.form.controls.siglumDestination.setValue(null);
      this.form.controls.siglumOrigin.setValue(null);
      this.form.controls.fte.setValue(this.minFTE);
    }
    this.form.controls.fte.disable();
    this.form.controls.costCenter.disable();
    this.impersonalSelected = false;
  }

  changeLeverType(type: string) {
    this.formDefaultState(type);
    switch (type) {
      case LEVER_TYPES.INTERNAL_MOBILITY:
        this.enableFormField(this.form, FIELDS.SIGLUM_DESTINATION);
        this.disableFormField(this.form, FIELDS.END_DATE);
        this.form.controls.endDateValue.setValue(null);
        break;
      case LEVER_TYPES.TEMP_RENOVATION:
        this.disableFormField(this.form, FIELDS.FTE);
        this.form.controls.fte.setValue(0);
        break;
      case LEVER_TYPES.SHIFT_CHANGE:
        this.enableFTEValue();
        break;
      case LEVER_TYPES.LEASED:
        this.enableFTEValue();
        break;
      case LEVER_TYPES.MOBILITY_OUT:
      case LEVER_TYPES.RETIREMENT:
      case LEVER_TYPES.TEMP_RELEASE:
      case LEVER_TYPES.PRE_RETIREMENT:
        this.disableFormField(this.form, FIELDS.END_DATE);
        this.form.controls.endDateValue.setValue(null);
        break;
      case LEVER_TYPES.BORROWED:
        this.enableFTEValue();
        this.formFields[FIELDS.COUNTRY] = true;
        this.formFields[FIELDS.COST_CENTER] = true;
        this.formFields[FIELDS.ACTIVE_WORKFORCE] = true;
        this.formFields[FIELDS.DIRECT] = true;
        this.enableFormField(this.form, FIELDS.SIGLUM_ORIGIN);
        break;
      case LEVER_TYPES.PERIMETER_CHANGE:
      case LEVER_TYPES.REDEPLOYMENT:
        this.impersonalSelected = true;
        this.enableFTEValue();
        this.enableFormField(this.form, FIELDS.SIGLUM_ORIGIN);
        if (type === LEVER_TYPES.PERIMETER_CHANGE) {
          this.enableFormField(this.form, FIELDS.SIGLUM_DESTINATION);
        }
        this.disableFormField(this.form, FIELDS.END_DATE);
        this.form.controls.endDateValue.setValue(null);
        this.enableFormField(this.form, FIELDS.COUNTRY);
        this.enableFormField(this.form, FIELDS.COST_CENTER);
        this.enableFormField(this.form, FIELDS.ACTIVE_WORKFORCE);
        this.enableFormField(this.form, FIELDS.DIRECT);
        break;
      default:
        break;
    }
    this.form.updateValueAndValidity();
    this.checkCopyCurrentBtnState();
  }

  private checkCopyCurrentBtnState() {
    const displayButton = REPLACEMENT_LEVER_TYPES.includes(this.form.controls.leverType.value as LEVER_TYPES);
    this.showCopyCurrent.set(displayButton && this.employee !== undefined);
  }

  copyCurrentEmployee() {
    this.dialog.open(JobRequestDialogComponent, {
      ...DIALOG_CONFIG,
      data: {
        employee: this.employee,
      },
    });
  }

  private siglumsToSiglumsSelect(siglums: Siglum[]): siglumSelect[] {
    return siglums.map((siglum) => {
      return { siglumId: siglum.id, siglumHR: siglum.siglumHR };
    });
  }

  originOutsideChange(value: boolean) {
    if (value) {
      this.siglumOriginOutside.set(true);
      this.form.controls.siglumOrigin.setValue(0);
    } else {
      this.siglumOriginOutside.set(false);
      this.form.controls.siglumOrigin.setValue(null);
    }
  }

  destinationOutsideChange(value: boolean) {
    if (value) {
      this.siglumDestinationOutside.set(true);
      this.form.controls.siglumDestination.setValue(0);
    } else {
      this.siglumDestinationOutside.set(false);
      this.form.controls.siglumDestination.setValue(null);
    }
  }

  async submit() {
    const lever: Lever = this.formValuesToLever() as Lever;
    this.isLoading.set(true);
    await this.manageLeversService.upsertLever(lever, this.employee, this.lever);
    this.isLoading.set(false);
  }

  formValuesToLever(): Partial<Lever> {
    const formValues = this.form.getRawValue();
    const siglumOrigin = formValues['siglumOrigin'] ? ({ id: formValues['siglumOrigin'] } as Siglum) : null;
    const siglumDestination = formValues['siglumDestination'] ? ({ id: formValues['siglumDestination'] } as Siglum) : null;

    const newLever: Partial<Lever> = {
      ...formValues,
      costCenter: { id: this.form.get('costCenter')?.value } as CostCenter,
      siglumDestination,
      siglumOrigin,
      startDate: formValues.startDateValue instanceof moment ? formValues.startDateValue.toISOString() : undefined,
      endDate: formValues.endDateValue instanceof moment ? formValues.endDateValue.toISOString() : undefined,
      employee: this.employee || ({ impersonal: this.isImpersonalLevers } as Employee),
    };
    return newLever;
  }
}
