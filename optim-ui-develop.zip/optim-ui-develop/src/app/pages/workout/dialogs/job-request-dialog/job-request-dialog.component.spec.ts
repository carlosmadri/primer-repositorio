import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobRequestDialogComponent } from './job-request-dialog.component';
import { MockJobRequestDialogComponent } from '@src/app/mocks/components/workout-job-request-dialog-mock.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SiglumService } from '@src/app/services/siglum/siglum.service';
import { LocationService } from '@src/app/services/location/location.service';
import { signal } from '@angular/core';
import { AllSiglums, Siglum } from '@src/app/shared/models/siglum.model';
import { provideNativeDateAdapter } from '@angular/material/core';
import { Location } from '@src/app/shared/models/location.model';
import { JobRequestService } from '@src/app/services/job-request/job-request.service';
import { JobRequest, JobRequestCollarType, JobRequestStatus, JobRequestType, JobRequestWorkerType } from '@src/app/shared/models/job-request.model';
import { DialogService } from '@src/app/services/dialog-service/dialog.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ManageJobRequestService } from '@src/app/services/job-request/manage-job-request.service';
import { CostCenter } from '@src/app/shared/models/cost-center.model';
import { DIRECT_INDIRECT_VALUES, Employee } from '@src/app/shared/models/employee.model';
import { CostCenterService } from '@src/app/services/cost-center/cost-center.service';
import { AccessRuleService } from '@src/app/services/access-rule/access-rule.service';
import { User } from '@src/app/shared/models/user.model';

const mockLocations: Location[] = [
  {
    id: 1,
    country: 'Belgium',
    site: 'Diegem',
    kapisCode: '1000',
  } as Location,
  {
    id: 2,
    country: 'France',
    site: 'Elancourt',
    kapisCode: '2002',
  } as Location,
  {
    id: 3,
    country: 'France',
    site: 'Antibes',
    kapisCode: '2002',
  } as Location,
  {
    id: 4,
    country: 'Spain',
    site: 'Getafe',
    kapisCode: '2003',
  } as Location,
];

const mockCostCenters: Partial<CostCenter>[] = [
  {
    id: 1,
    costCenterCode: 'BE1000',
    location: mockLocations[0],
  },
  {
    id: 2,
    costCenterCode: 'FR2001',
    location: mockLocations[1],
  },
  {
    id: 3,
    costCenterCode: 'FR2002',
    location: mockLocations[1],
  },
  {
    id: 4,
    costCenterCode: 'FR2003',
    location: mockLocations[2],
  },
  {
    id: 5,
    costCenterCode: 'SP3004',
    location: mockLocations[3],
  },
  {
    id: 6,
    costCenterCode: 'SP3005',
    location: mockLocations[4],
  },
];

const mockJobRequestData: JobRequest = {
  id: 1,
  workdayNumber: '12345678',
  type: JobRequestType.CONVERSION,
  status: JobRequestStatus.OPENED,
  description: 'Test description',
  candidate: 'Test candidate',
  startDate: '2021-01-01',
  releaseDate: '2021-01-01',
  postingDate: '2021-01-01',
  external: false,
  earlyCareer: false,
  onTopHct: false,
  isCritical: false,
  activeWorkforce: JobRequestWorkerType.TEMP,
  approvedQMC: false,
  approvedSHRBPHOT1Q: false,
  approvedHOCOOHOHRCOO: false,
  approvedEmploymentCommitee: false,
  siglum: {
    id: 1,
  } as Siglum,
  direct: DIRECT_INDIRECT_VALUES.DIRECT,
  costCenter: mockCostCenters[0] as CostCenter,
  collar: JobRequestCollarType.BC,
};

const mockEmployee: Employee = {
  id: 1,
  employeeId: 1,
  direct: DIRECT_INDIRECT_VALUES.DIRECT,
  job: 'Test job',
  collar: 'BC',
  lastName: 'Test',
  firstName: 'Employee',
  activeWorkforce: 'TEMP',
  availabilityReason: 'Test reason',
  contractType: 'Unlimited',
  siglum: {
    id: 1,
  } as Siglum,
  costCenter: mockCostCenters[0] as CostCenter,
  fte: 1,
} as Employee;

describe('JobRequestDialogComponent', () => {
  let component: JobRequestDialogComponent;
  let fixture: ComponentFixture<JobRequestDialogComponent>;
  const allLocations = signal<Location[]>(mockLocations);
  const allSiglums = signal<Siglum[]>([]);
  const allVisibleSiglums = signal<Siglum[]>([]);
  const allFormattedSiglums = signal<AllSiglums | null>(null);
  const allFormattedVisibleSiglums = signal<AllSiglums | null>(null);
  const mockSiglumService: Partial<SiglumService> = {
    allSiglums: allSiglums,
    allVisibleSiglums: allVisibleSiglums,
    allFormattedSiglums: allFormattedSiglums,
    allFormattedVisibleSiglums: allFormattedVisibleSiglums,
    getAllSiglums: jest.fn(),
    getSiglumFilterFields: jest.fn(),
  };

  const mockLocationService: Partial<LocationService> = {
    getSitesFilterValues: jest.fn(),
    getCountriesFilterValues: jest.fn(),
    getAllLocations: jest.fn(),
    allLocations,
  };
  let mockCostCenterService: Partial<CostCenterService>;

  let mockJobRequestService: Partial<JobRequestService>;
  let mockDialogService: Partial<DialogService>;
  let mockAccessRuleService: Partial<AccessRuleService>;
  const mockUser = signal<User | null>(null);

  const mockDialogRef = {
    close: jest.fn(),
  };

  beforeEach(() => {
    mockAccessRuleService = {
      canAddJobRequisition: jest.fn().mockReturnValue(true),
      canValidateJobRequisition: jest.fn().mockReturnValue(true),
      canQMCApproveJobRequisition: jest.fn().mockReturnValue(true),
      canHOT1QApproveJobRequisition: jest.fn().mockReturnValue(true),
      canCOOApproveJobRequisition: jest.fn().mockReturnValue(true),
      user: mockUser,
    };

    const mockJobRequests = signal<JobRequest[]>([]);
    mockJobRequestService = {
      getTypesSummary: jest.fn().mockResolvedValue(undefined),
      createJobRequest: jest.fn().mockResolvedValue(undefined),
      updateJobRequest: jest.fn().mockResolvedValue(undefined),
      jobRequests: mockJobRequests,
    };

    mockDialogService = {
      openMessageDialog: jest.fn(),
    };

    mockCostCenterService = {
      allCostCenters: signal<CostCenter[]>(mockCostCenters as CostCenter[]),
      getAllCostCenters: jest.fn(),
    };
  });

  function createComponent(dialogData?: { jobRequest?: JobRequest; employee?: Employee }) {
    TestBed.configureTestingModule({
      imports: [JobRequestDialogComponent, MockJobRequestDialogComponent, NoopAnimationsModule],
      providers: [
        ManageJobRequestService,
        provideNativeDateAdapter(),
        { provide: LocationService, useValue: mockLocationService },
        { provide: SiglumService, useValue: mockSiglumService },
        { provide: JobRequestService, useValue: mockJobRequestService },
        { provide: CostCenterService, useValue: mockCostCenterService },
        { provide: DialogService, useValue: mockDialogService },
        { provide: MatDialogRef, useValue: mockDialogRef },
        { provide: MAT_DIALOG_DATA, useValue: dialogData },
        { provide: AccessRuleService, useValue: mockAccessRuleService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(JobRequestDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  afterEach(() => {
    TestBed.resetTestingModule();
  });

  describe('Create JR tests', () => {
    beforeEach(() => {
      createComponent();
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });

    describe('Default form state', () => {
      it('should display the externalised field selected as No', () => {
        expect(component.form()!.controls['external'].disabled).toBeTruthy();
      });

      it('should not display the releaseDate field', () => {
        expect(component.form()!.controls['releaseDate']).toBeUndefined();
      });

      it('should display On Top of HC Target as No', () => {
        expect(component.form()!.controls['onTopHct'].value).toBe(false);
      });

      it('should display display the externalised field as disabled', () => {
        expect(component.form()!.controls['external'].disabled).toBeTruthy();
      });
    });

    describe('On select WorkerType = TEMP', () => {
      beforeEach(() => {
        component.form()!.controls['activeWorkforce'].setValue(JobRequestWorkerType.TEMP);
        fixture.detectChanges();
        component.onWorkerTypeChange();
      });
      it('should display the externalised field selected as Yes', () => {
        expect(component.form()!.controls['external'].value).toBe(true);
      });

      it('should display the earlyCareer field selected as Yes', () => {
        expect(component.form()!.controls['earlyCareer'].value).toBe(true);
      });

      it('should display the releaseDate field', () => {
        expect(component.form()!.controls['releaseDate']).not.toBeUndefined();
      });
    });

    describe('Select location', () => {
      describe('Select by country / site', () => {
        it('should display an empty list of sites if there is no country selected', () => {
          component.form()!.controls['country'].setValue(null);

          fixture.detectChanges();

          expect(component.siteOptions().length).toBe(0);
        });

        it('should display the list of related sites when a country is selected', () => {
          component.form()!.controls['country'].setValue(mockLocations[1].country);

          component.onCountryChange();

          expect(component.siteOptions().length).toBe(2);
        });

        it('should display the list of related kapisCodes when a country is selected', () => {
          component.form()!.controls['country'].setValue(mockLocations[1].country);

          component.onCountryChange();

          expect(component.kapisCodeOptions().length).toBe(1);
        });

        it('should display the list of kapis codes of the selected site', () => {
          component.form()!.controls['country'].setValue(mockLocations[3].country);
          component.countryOptions();

          component.form()!.controls['site'].setValue(mockLocations[3].site);
          component.onSiteChange();

          expect(component.kapisCodeOptions().length).toBe(1);
        });

        it('should display the Cost center code of the selected kapis codes', () => {
          component.form()!.controls['country'].setValue(mockCostCenters[2].location!.country);
          component.onCountryChange();

          component.form()!.controls['site'].setValue(mockCostCenters[2].location!.site);
          component.onSiteChange();

          component.form()!.controls['kapisCode'].setValue(mockCostCenters[2].location!.kapisCode);
          component.onKapisCodeChange();

          expect(component.costCenterOptions().length).toBe(2);
        });
      });

      describe('Select by kapis code', () => {
        it('should set the Country, Site and Cost center when an existing kapicode is selected', async () => {
          component.form()!.controls['kapisCode'].setValue(mockLocations[0].kapisCode);

          component.onKapisCodeChange();

          expect(component.form()!.controls['country'].value).toEqual(mockLocations[0].country);
          expect(component.form()!.controls['site'].value).toEqual(mockLocations[0].site);
          expect(component.form()!.controls['costCenter'].value).toEqual(mockCostCenters[0].costCenterCode);

          component.form()!.controls['kapisCode'].setValue('');
          component.setValuesForKapisCode();

          expect(component.form()!.controls['country'].value).toBeNull();
          expect(component.form()!.controls['site'].value).toBeNull();
          expect(component.form()!.controls['costCenter'].value).toBeNull();
        });
      });
    });
  });

  describe('Edit JR tests', () => {
    describe('Load location', () => {
      beforeEach(() => {
        mockUser.set({
          siglum: { id: 1 } as Siglum,
        } as User);
        createComponent({ jobRequest: mockJobRequestData });
      });
      it('should load the location and cost center data', () => {
        expect(component.form()!.controls['country'].value).toEqual(mockJobRequestData.costCenter.location.country);
        expect(component.form()!.controls['site'].value).toEqual(mockJobRequestData.costCenter.location.site);
        expect(component.form()!.controls['kapisCode'].value).toEqual(mockJobRequestData.costCenter.location.kapisCode);
        expect(component.form()!.controls['costCenter'].value).toEqual(mockJobRequestData.costCenter.costCenterCode);
      });
    });

    describe('Enable Externalised field after JR is Open for 2 weeks', () => {
      const mockJobRequesEditData = {
        ...mockJobRequestData,
        postingDate: new Date(new Date().setDate(new Date().getDate() - 15)).toISOString(),
        status: JobRequestStatus.OPENED,
      };
      beforeEach(() => {
        createComponent({ jobRequest: mockJobRequesEditData });
      });
      it('should display display the externalised field as enabled if the JR status is Open and the postingDate is previous to two weeks ago', () => {
        expect(component.form()!.controls['external'].disabled).toBeFalsy();
      });
    });

    describe('Disable JR information and JR Profile fields if the validation is in progress', () => {
      const mockJobRequesEditData = {
        ...mockJobRequestData,
        status: JobRequestStatus.VALIDATION,
      };
      beforeEach(() => {
        createComponent({ jobRequest: mockJobRequesEditData });
      });
      it('should display display the externalised field as enabled if the JR status is Open and the postingDate is previous to two weeks ago', () => {
        const form = component.form()!;
        expect(form.controls['type'].disabled).toBeTruthy();
        expect(form!.controls['startDate'].disabled).toBeTruthy();
        expect(form!.controls['onTopHct'].disabled).toBeTruthy();
      });
    });

    describe('Set the JR to status OPENED on the right step', () => {
      const mockJobRequesEditData = {
        ...mockJobRequestData,
        status: JobRequestStatus.VALIDATION,
        candidate: '',
      };
      beforeEach(() => {
        createComponent({ jobRequest: mockJobRequesEditData });
      });
      it('should set the JR as Opened when the user save the form with status SHRBP/HO/T1Q Approved for TEMP activeWorkforce and no onTopHct', () => {
        component.form.update((form) => {
          form!.controls['approvedQMC'].setValue(true);
          form!.controls['approvedSHRBPHOT1Q'].setValue(true);
          form!.controls['activeWorkforce'].setValue(JobRequestWorkerType.TEMP);
          form!.controls['onTopHct'].setValue(false);
          form!.controls['isCritical'].setValue(false);
          form!.controls['status'].setValue(JobRequestStatus.SHRBP_HO_T1Q_APPROVED);
          return form;
        });
        const updateSpy = jest.spyOn(mockJobRequestService, 'updateJobRequest');

        component.save();

        expect(updateSpy).toHaveBeenCalledWith(expect.objectContaining({ status: JobRequestStatus.OPENED }), '1');
      });

      it('should set the JR as SHRBP/HO/T1Q Approved when the user save the form with status SHRBP/HO/T1Q Approved for TEMP activeWorkforce and is onTopHct', () => {
        component.form.update((form) => {
          form!.controls['approvedQMC'].setValue(true);
          form!.controls['approvedSHRBPHOT1Q'].setValue(true);
          form!.controls['activeWorkforce'].setValue(JobRequestWorkerType.TEMP);
          form!.controls['onTopHct'].setValue(true);
          form!.controls['isCritical'].setValue(false);
          form!.controls['status'].setValue(JobRequestStatus.SHRBP_HO_T1Q_APPROVED);
          return form;
        });
        const updateSpy = jest.spyOn(mockJobRequestService, 'updateJobRequest');

        component.save();

        expect(updateSpy).toHaveBeenCalledWith(expect.objectContaining({ status: JobRequestStatus.SHRBP_HO_T1Q_APPROVED }), '1');
      });

      it('should set the JR as SHRBP/HO/T1Q Approved when the user save the form with status SHRBP/HO/T1Q Approved for TEMP activeWorkforce and isCritical', () => {
        component.form.update((form) => {
          form!.controls['approvedQMC'].setValue(true);
          form!.controls['approvedSHRBPHOT1Q'].setValue(true);
          form!.controls['activeWorkforce'].setValue(JobRequestWorkerType.TEMP);
          form!.controls['onTopHct'].setValue(false);
          form!.controls['isCritical'].setValue(true);
          form!.controls['status'].setValue(JobRequestStatus.SHRBP_HO_T1Q_APPROVED);
          return form;
        });
        const updateSpy = jest.spyOn(mockJobRequestService, 'updateJobRequest');

        component.save();

        expect(updateSpy).toHaveBeenCalledWith(expect.objectContaining({ status: JobRequestStatus.SHRBP_HO_T1Q_APPROVED }), '1');
      });

      it('should set the JR as Opened when the user save the form with status Approved by Employment commitee for TEMP when the JR is onTopHct', () => {
        component.form.update((form) => {
          form!.controls['approvedQMC'].setValue(true);
          form!.controls['approvedSHRBPHOT1Q'].setValue(true);
          form!.controls['approvedHOCOOHOHRCOO'].setValue(true);
          form!.controls['approvedEmploymentCommitee'].setValue(true);
          form!.controls['activeWorkforce'].setValue(JobRequestWorkerType.TEMP);
          form!.controls['onTopHct'].setValue(true);
          form!.controls['isCritical'].setValue(false);
          form!.controls['status'].setValue(JobRequestStatus.COMMITEE_APPROVED);
          return form;
        });
        const updateSpy = jest.spyOn(mockJobRequestService, 'updateJobRequest');

        component.save();

        expect(updateSpy).toHaveBeenCalledWith(expect.objectContaining({ status: JobRequestStatus.OPENED }), '1');
      });

      it('should set the JR AWF as Opened when saving it with status Approved by the HO COO/HO HR COO when the JR is Critical', () => {
        component.form.update((form) => {
          form!.controls['approvedQMC'].setValue(true);
          form!.controls['approvedSHRBPHOT1Q'].setValue(true);
          form!.controls['approvedHOCOOHOHRCOO'].setValue(true);
          form!.controls['activeWorkforce'].setValue(JobRequestWorkerType.AWF);
          form!.controls['onTopHct'].setValue(false);
          form!.controls['isCritical'].setValue(true);
          form!.controls['status'].setValue(JobRequestStatus.COO_APPROVED);
          return form;
        });
        const updateSpy = jest.spyOn(mockJobRequestService, 'updateJobRequest');

        component.save();

        expect(updateSpy).toHaveBeenCalledWith(expect.objectContaining({ status: JobRequestStatus.OPENED }), '1');
      });

      it('should set the JR AWF as Opened when saving it with status Approved by the Employment Committee when the JR is not Critical', () => {
        component.form.update((form) => {
          form!.controls['approvedQMC'].setValue(true);
          form!.controls['approvedSHRBPHOT1Q'].setValue(true);
          form!.controls['approvedHOCOOHOHRCOO'].setValue(true);
          form!.controls['approvedEmploymentCommitee'].setValue(true);
          form!.controls['activeWorkforce'].setValue(JobRequestWorkerType.AWF);
          form!.controls['onTopHct'].setValue(false);
          form!.controls['isCritical'].setValue(false);
          form!.controls['status'].setValue(JobRequestStatus.COMMITEE_APPROVED);
          return form;
        });
        const updateSpy = jest.spyOn(mockJobRequestService, 'updateJobRequest');

        component.save();

        expect(updateSpy).toHaveBeenCalledWith(expect.objectContaining({ status: JobRequestStatus.OPENED }), '1');
      });
    });
  });

  describe('Load employee data to current JR', () => {
    beforeEach(() => {
      createComponent({ employee: mockEmployee });
    });
    it('should load the location and cost center data from employee', () => {
      expect(component.form()!.controls['country'].value).toEqual(mockCostCenters[0].location?.country);
      expect(component.form()!.controls['site'].value).toEqual(mockCostCenters[0].location?.site);
      expect(component.form()!.controls['kapisCode'].value).toEqual(mockCostCenters[0].location?.kapisCode);
      expect(component.form()!.controls['costCenter'].value).toEqual(mockCostCenters[0].costCenterCode);
    });
  });
});
