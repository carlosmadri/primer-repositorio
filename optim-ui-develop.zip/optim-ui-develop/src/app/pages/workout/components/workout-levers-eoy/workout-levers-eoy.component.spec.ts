import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkoutLeversEoyComponent } from './workout-levers-eoy.component';
import { LeversService } from '@app/services/levers/levers.service';
import { NO_ERRORS_SCHEMA, signal, WritableSignal } from '@angular/core';
import { LeversTotal } from '@app/shared/models/levers-total.model';
import { FiltersService } from '@app/services/filters/filters.service';
import { MockElementHeightDirective } from '@src/app/mocks/directives/ElementHeightDirective-mock';
import { ElementHeightDirective } from '@src/app/shared/directives/element-height.directive';
import { StackedBarsComponent } from '@src/app/shared/graphs/stacked-bars/stacked-bars.component';
import { MockStackedBarsComponent } from '@src/app/mocks/components/stacked-bars-mock.component';

describe('WorkoutLeversEoyComponent', () => {
  let component: WorkoutLeversEoyComponent;
  let fixture: ComponentFixture<WorkoutLeversEoyComponent>;
  let mockLeversService: Partial<LeversService>;

  const mockFiltersService: Partial<FiltersService> = {
    paramsFilter: signal<string[]>([]),
  };

  beforeEach(async () => {
    mockLeversService = {
      getTotalByEoY: jest.fn(),
      resetTotalByEoY: jest.fn(),
      totalByEoY: signal<LeversTotal[]>([]) as WritableSignal<LeversTotal[]>,
    };

    TestBed.overrideComponent(WorkoutLeversEoyComponent, {
      remove: {
        imports: [StackedBarsComponent, ElementHeightDirective],
      },
      add: {
        imports: [MockStackedBarsComponent, MockElementHeightDirective],
      },
    });

    await TestBed.configureTestingModule({
      imports: [WorkoutLeversEoyComponent, MockStackedBarsComponent, MockElementHeightDirective],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        { provide: LeversService, useValue: mockLeversService },
        { provide: FiltersService, useValue: mockFiltersService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(WorkoutLeversEoyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    jest.clearAllMocks();
    if (mockFiltersService.paramsFilter) {
      (mockFiltersService.paramsFilter as WritableSignal<string[]>).set([]);
    }
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getTotalByEoY with params from paramsFilter', () => {
    const params = ['someParam=value'];

    (mockFiltersService.paramsFilter as WritableSignal<string[]>).set(params);
    fixture.detectChanges();

    expect(mockLeversService.getTotalByEoY).toHaveBeenCalledWith(params);
  });

  it('should sort totalByEoY in descending order by leverType', () => {
    const mockData: LeversTotal[] = [
      { leverType: 'b', leaver: 300, recovery: 100 },
      { leverType: 'c', leaver: 200, recovery: 50 },
      { leverType: 'a', leaver: 100, recovery: 25 },
    ];
    (mockLeversService.totalByEoY as WritableSignal<LeversTotal[]>).set(mockData);

    const sortedData = component.sortedTotalByEoY();

    expect(sortedData).toEqual([
      { leverType: 'a', leaver: 100, recovery: 25 },
      { leverType: 'b', leaver: 300, recovery: 100 },
      { leverType: 'c', leaver: 200, recovery: 50 },
    ]);
  });

  it('should return an empty array if totalByEoY is empty', () => {
    (mockLeversService.totalByEoY as WritableSignal<LeversTotal[]>).set([]);

    const sortedData = component.sortedTotalByEoY();

    expect(sortedData).toEqual([]);
  });
});
