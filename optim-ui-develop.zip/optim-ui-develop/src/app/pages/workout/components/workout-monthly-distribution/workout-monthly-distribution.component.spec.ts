import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkoutMonthlyDistributionComponent } from './workout-monthly-distribution.component';
import { NO_ERRORS_SCHEMA, signal, WritableSignal } from '@angular/core';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { EmployeeService } from '@src/app/services/employee/employee.service';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MultiLineChartData } from '@src/app/shared/models/graphs/multiline-chart.model';
import { MockElementHeightDirective } from '@src/app/mocks/directives/ElementHeightDirective-mock';
import { ElementHeightDirective } from '@src/app/shared/directives/element-height.directive';
import { MultilineChartComponent } from '@src/app/shared/graphs/multiline-chart/multiline-chart.component';
import { MockMultilineChartComponent } from '@src/app/mocks/components/multiline-chart-mock.component';

describe('WorkoutMonthlyDistributionComponent', () => {
  let component: WorkoutMonthlyDistributionComponent;
  let fixture: ComponentFixture<WorkoutMonthlyDistributionComponent>;
  let mockEmployeeService: Partial<EmployeeService>;
  let mockFiltersService: Partial<FiltersService>;
  let mockLineChartData: WritableSignal<MultiLineChartData | null>;
  let mockParamsFilter: WritableSignal<string[]>;

  beforeEach(async () => {
    mockLineChartData = signal<MultiLineChartData | null>(null);
    mockParamsFilter = signal<string[]>([]);

    mockEmployeeService = {
      monthlyData: mockLineChartData,
      getMonthlyDistribution: jest.fn(),
      resetMonthlyData: jest.fn(),
    };

    mockFiltersService = {
      paramsFilter: mockParamsFilter,
    };

    TestBed.overrideComponent(WorkoutMonthlyDistributionComponent, {
      remove: {
        imports: [MultilineChartComponent, ElementHeightDirective],
      },
      add: {
        imports: [MockMultilineChartComponent, MockElementHeightDirective],
      },
    });

    await TestBed.configureTestingModule({
      imports: [WorkoutMonthlyDistributionComponent, ReactiveFormsModule, MatCheckboxModule, MockMultilineChartComponent, MockElementHeightDirective],
      providers: [FormBuilder, { provide: EmployeeService, useValue: mockEmployeeService }, { provide: FiltersService, useValue: mockFiltersService }],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(WorkoutMonthlyDistributionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    jest.clearAllMocks();
    mockParamsFilter.set([]);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getMonthlyDistribution on initialization', () => {
    expect(mockEmployeeService.getMonthlyDistribution).toHaveBeenCalledWith([]);
  });

  it('should react to changes in paramsFilter', () => {
    mockParamsFilter.set(['param1', 'param2']);

    fixture.detectChanges();

    expect(mockEmployeeService.getMonthlyDistribution).toHaveBeenCalledWith(['param1', 'param2']);
  });
});
