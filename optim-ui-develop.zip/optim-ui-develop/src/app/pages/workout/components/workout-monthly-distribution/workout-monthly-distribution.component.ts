import { ChangeDetectionStrategy, Component, effect, inject, OnDestroy, signal, Signal } from '@angular/core';
import { EmployeeService } from '@src/app/services/employee/employee.service';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { ElementHeightDirective } from '@src/app/shared/directives/element-height.directive';
import { MultilineChartComponent } from '@src/app/shared/graphs/multiline-chart/multiline-chart.component';
import { MultiLineChartData } from '@src/app/shared/models/graphs/multiline-chart.model';

@Component({
  selector: 'optim-workout-monthly-distribution',
  imports: [MultilineChartComponent, ElementHeightDirective],
  templateUrl: './workout-monthly-distribution.component.html',
  styleUrl: './workout-monthly-distribution.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkoutMonthlyDistributionComponent implements OnDestroy {
  private employeeService: EmployeeService = inject(EmployeeService);
  private filtersService: FiltersService = inject(FiltersService);

  chartElementHeight = signal(0);

  lineChartData: Signal<MultiLineChartData | null> = this.employeeService.monthlyData;

  constructor() {
    effect(() => {
      const params = this.filtersService.paramsFilter();
      this.employeeService.getMonthlyDistribution(params);
    });
  }

  onResize(newHeight: number): void {
    this.chartElementHeight.set(newHeight);
  }

  ngOnDestroy(): void {
    this.employeeService.resetMonthlyData();
  }
}
