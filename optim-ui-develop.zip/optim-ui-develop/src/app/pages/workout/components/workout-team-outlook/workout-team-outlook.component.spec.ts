import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WorkoutTeamOutlookComponent } from './workout-team-outlook.component';
import { signal, WritableSignal } from '@angular/core';
import { TeamOutlook } from '@app/shared/models/team-outlook.model';
import { TeamOutlookService } from '@app/services/team-outlook/team-outlook.service';
import { FiltersService } from '@app/services/filters/filters.service';

describe('WorkoutTeamOutlookComponent', () => {
  let component: WorkoutTeamOutlookComponent;
  let fixture: ComponentFixture<WorkoutTeamOutlookComponent>;
  let mockTeamOutlookService: Partial<TeamOutlookService>;
  let mockFiltersService: Partial<FiltersService>;

  beforeEach(async () => {
    mockTeamOutlookService = {
      teamOutlook: signal<TeamOutlook | null>(null),
      getTeamOutlook: jest.fn().mockResolvedValue(undefined),
      getTeamOutlookWorkload: jest.fn().mockResolvedValue(undefined),
      resetTeamOutlook: jest.fn(),
      resetTeamOutlookWorkload: jest.fn(),
    };

    mockFiltersService = {
      paramsFilter: signal<string[]>([]),
    };

    await TestBed.configureTestingModule({
      declarations: [],
      providers: [
        { provide: TeamOutlookService, useValue: mockTeamOutlookService },
        { provide: FiltersService, useValue: mockFiltersService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(WorkoutTeamOutlookComponent);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    jest.clearAllMocks();
    (mockFiltersService.paramsFilter as WritableSignal<string[]>).set([]);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Load data', () => {
    it("should initialize teamOutlookData with the service's teamOutlook signal", () => {
      expect(component['teamOutlookData']).toBe(mockTeamOutlookService.teamOutlook);
      expect(component['teamOutlookWorkloadData']).toBe(mockTeamOutlookService.teamOutlookWorkload);
    });

    it('should call getTeamOutlook and getTeamOutlookWorkload on initialization with empty params', async () => {
      fixture.detectChanges();
      await fixture.whenStable();

      expect(component.isLoading()).toBe(false);
      expect(mockTeamOutlookService.getTeamOutlook).toHaveBeenCalledWith([]);
      expect(mockTeamOutlookService.getTeamOutlookWorkload).toHaveBeenCalledWith([]);
    });

    it('should call getTeamOutlook adn getTeamOutlookWorkload when paramsFilter changes', async () => {
      const newParams = ['param1=value1', 'param2=value2'];
      (mockFiltersService.paramsFilter as WritableSignal<string[]>).set(newParams);

      fixture.detectChanges();
      await fixture.whenStable();

      expect(mockTeamOutlookService.getTeamOutlook).toHaveBeenCalledWith(newParams);
      expect(mockTeamOutlookService.getTeamOutlookWorkload).toHaveBeenCalledWith(newParams);
    });

    it('should handle errors when getTeamOutlook fails', async () => {
      const error = new Error('Test error');

      (mockTeamOutlookService.getTeamOutlook as jest.Mock).mockRejectedValue(error);

      (mockFiltersService.paramsFilter as WritableSignal<string[]>).set(['error=true']);

      await fixture.whenStable();

      await expect((mockTeamOutlookService.getTeamOutlook as jest.Mock)(['error=true'])).rejects.toThrow('Test error');
    });

    it('should call getTeamOutlook multiple times for different paramsFilter values', () => {
      const params1 = ['param1=value1'];
      const params2 = ['param2=value2'];

      (mockFiltersService.paramsFilter as WritableSignal<string[]>).set(params1);
      fixture.detectChanges();
      expect(mockTeamOutlookService.getTeamOutlook).toHaveBeenCalledWith(params1);

      (mockFiltersService.paramsFilter as WritableSignal<string[]>).set(params2);
      fixture.detectChanges();
      expect(mockTeamOutlookService.getTeamOutlook).toHaveBeenCalledWith(params2);

      expect(mockTeamOutlookService.getTeamOutlook).toHaveBeenCalledTimes(2);
    });
  });

  describe('Remove loader after data is loaded', () => {
    it('should set isLoading to false after data is loaded', async () => {
      fixture.detectChanges();
      expect(component.isLoading()).toBe(true);

      await fixture.whenStable();
      expect(component.isLoading()).toBe(false);
    });

    it('should set isLoading to false after an error occurs', async () => {
      (mockTeamOutlookService.getTeamOutlook as jest.Mock).mockRejectedValue(new Error('Test error'));

      fixture.detectChanges();
      expect(component.isLoading()).toBe(true);

      await fixture.whenStable();
      expect(component.isLoading()).toBe(false);
    });
  });
});
