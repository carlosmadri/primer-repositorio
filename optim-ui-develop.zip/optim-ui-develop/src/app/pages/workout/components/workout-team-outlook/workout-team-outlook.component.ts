import { NgClass } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject, OnDestroy, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FiltersService } from '@app/services/filters/filters.service';
import { TeamOutlookService } from '@app/services/team-outlook/team-outlook.service';
import { LoadingComponent } from '@src/app/shared/components/loading/loading.component';
import { TooltipComponent } from '@src/app/shared/components/tooltip/tooltip.component';
import * as numberUtils from '@src/utils/number-utils';

@Component({
  selector: 'optim-workout-team-outlook',
  imports: [NgClass, MatIconModule, MatButtonModule, TooltipComponent, LoadingComponent],
  templateUrl: './workout-team-outlook.component.html',
  styleUrl: './workout-team-outlook.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkoutTeamOutlookComponent implements OnDestroy {
  private teamOutlookService: TeamOutlookService = inject(TeamOutlookService);
  private filtersService: FiltersService = inject(FiltersService);

  protected readonly teamOutlookData = this.teamOutlookService.teamOutlook;
  protected readonly teamOutlookWorkloadData = this.teamOutlookService.teamOutlookWorkload;

  isLoading = signal(false);

  errorMsg = signal<string | null>(null);

  constructor() {
    effect(async () => {
      try {
        const params = this.filtersService.paramsFilter();
        this.isLoading.set(true);
        await Promise.all([this.teamOutlookService.getTeamOutlook(params), this.teamOutlookService.getTeamOutlookWorkload(params)]);
      } catch (err) {
        this.errorMsg.set(err instanceof Error ? err.message : 'An error occurred');
      } finally {
        this.isLoading.set(false);
      }
    });
  }

  hcCeilingFormerRef = computed<number>(() => {
    const dataWorkload = this.teamOutlookWorkloadData();
    return numberUtils.roundToDecimalPlaces(dataWorkload?.hcCeilingFormerRefference || 0, 1);
  });

  ngOnDestroy(): void {
    this.teamOutlookService.resetTeamOutlook();
    this.teamOutlookService.resetTeamOutlookWorkload();
  }
}
