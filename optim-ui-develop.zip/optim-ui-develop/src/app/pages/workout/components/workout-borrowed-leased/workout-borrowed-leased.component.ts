import { ChangeDetectionStrategy, Component, computed, effect, inject, OnDestroy, signal, Signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { EmployeeService } from '@src/app/services/employee/employee.service';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { TooltipComponent } from '@src/app/shared/components/tooltip/tooltip.component';
import { ElementHeightDirective } from '@src/app/shared/directives/element-height.directive';
import { MultilineChartComponent } from '@src/app/shared/graphs/multiline-chart/multiline-chart.component';
import { BorrowedLeased } from '@src/app/shared/models/borrowed-leased.model';
import { MultiLineChartData } from '@src/app/shared/models/graphs/multiline-chart.model';

@Component({
  selector: 'optim-workout-borrowed-leased',
  imports: [MultilineChartComponent, ElementHeightDirective, MatIconModule, TooltipComponent],
  templateUrl: './workout-borrowed-leased.component.html',
  styleUrl: './workout-borrowed-leased.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkoutBorrowedLeasedComponent implements OnDestroy {
  private employeeService: EmployeeService = inject(EmployeeService);
  private filtersService: FiltersService = inject(FiltersService);

  borrowedLeased: Signal<BorrowedLeased | null> = this.employeeService.borrowedData;

  chartElementHeight = signal(0);

  constructor() {
    effect(() => {
      const params = this.filtersService.paramsFilter();
      this.employeeService.getBorrowedLeased(params);
    });
  }

  borrowed = computed<string>(() => {
    const borrowedLeased = this.borrowedLeased();
    if (borrowedLeased?.averageBorrowed) {
      return borrowedLeased.averageBorrowed.toFixed(1);
    }
    return '0';
  });

  leased = computed<string>(() => {
    const borrowedLeased = this.borrowedLeased();
    if (borrowedLeased?.averageLeased) {
      return borrowedLeased.averageLeased.toFixed(1);
    }
    return '0';
  });

  balance = computed<string>(() => {
    const borrowedLeased = this.borrowedLeased();
    if (borrowedLeased?.netDifference) {
      return borrowedLeased.netDifference.toFixed(1);
    }
    return '0';
  });

  lineChartFiltered = computed<MultiLineChartData | null>(() => {
    const borrowedLeased = this.borrowedLeased();
    if (borrowedLeased?.chartData) {
      return borrowedLeased.chartData;
    }
    return null;
  });

  onResize(newHeight: number): void {
    this.chartElementHeight.set(newHeight);
  }

  ngOnDestroy(): void {
    this.employeeService.resetBorrowedLeased();
  }
}
