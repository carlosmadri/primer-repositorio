import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '@services/auth/auth.service';
import { LoadingComponent } from '@shared/components/loading/loading.component';

@Component({
  selector: 'optim-login',
  imports: [LoadingComponent, MatButtonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent {
  readonly authService = inject(AuthService);

  redirectingToCallback = this.authService.redirectingToCallback;
  isAuthorizing = this.authService.isAuthorizing;

  login() {
    this.authService.initLogin();
  }
}
