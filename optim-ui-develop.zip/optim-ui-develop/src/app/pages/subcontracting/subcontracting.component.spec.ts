import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubcontractingComponent } from './subcontracting.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { MockSubcontractingBarsGraphComponent } from '@src/app/mocks/components/subcontracting-bars-graph-mock.component';
import { MockSubcontractingBreakdownComponent } from '@src/app/mocks/components/subcontracting-breakdown-mock.component';
import { SubcontractingBreakdownComponent } from './components/subcontracting-breakdown/subcontracting-breakdown.component';
import { SubcontractingBarsGraphComponent } from './components/subcontracting-bars-graph/subcontracting-bars-graph.component';
import { SubcontractingFiltersComponent } from '@src/app/shared/components/subcontracting-filters/subcontracting-filters.component';
import { SubcontractingTableComponent } from '@src/app/tables/subcontracting-table/subcontracting-table.component';
import { MockSubcontractingTableComponent } from '@src/app/mocks/components/subcontracting-tablet-mock.componen';
import { AuthService } from '@src/app/services/auth/auth.service';
import { AuthTestingService } from '@src/app/services/auth/auth-testing.service';

describe('SubcontractingComponent', () => {
  let component: SubcontractingComponent;
  let fixture: ComponentFixture<SubcontractingComponent>;

  beforeEach(async () => {
    TestBed.overrideComponent(SubcontractingComponent, {
      remove: {
        imports: [SubcontractingBarsGraphComponent, SubcontractingBreakdownComponent, SubcontractingTableComponent],
      },
      add: {
        imports: [MockSubcontractingBarsGraphComponent, MockSubcontractingBreakdownComponent, MockSubcontractingTableComponent],
      },
    });
    await TestBed.configureTestingModule({
      imports: [
        SubcontractingComponent,
        MockSubcontractingBarsGraphComponent,
        MockSubcontractingBreakdownComponent,
        NoopAnimationsModule,
        SubcontractingFiltersComponent,
        MockSubcontractingTableComponent,
      ],
      providers: [provideHttpClient(withInterceptorsFromDi()), provideHttpClientTesting(), { provide: AuthService, useValue: AuthTestingService }],
    }).compileComponents();

    fixture = TestBed.createComponent(SubcontractingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
