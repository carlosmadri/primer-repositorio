import { ComponentFixture, TestBed } from '@angular/core/testing';

import { APPROVED_COLOR, NOT_APPROVED_COLOR, SubcontractingBarsGraphComponent } from './subcontracting-bars-graph.component';
import { SubcontractingService } from '@src/app/services/subcontracting/subcontracting.service';
import { signal } from '@angular/core';
import { SubcontractingGraphs } from '@src/app/shared/models/subcontracting.model';

describe('SubcontractingBarsGraphComponent', () => {
  let component: SubcontractingBarsGraphComponent;
  let fixture: ComponentFixture<SubcontractingBarsGraphComponent>;
  let mockSubcontractingService: Partial<SubcontractingService>;
  let mockGraphsData: SubcontractingGraphs;
  const mockGraphSignal = signal<SubcontractingGraphs | null>(null);

  beforeEach(async () => {
    mockGraphsData = {
      khrsPerQuarter: {
        purchaseAproved: [
          { quarter: 'Q1', keur: 100 },
          { quarter: 'Q2', keur: 200 },
        ],
        purchaseNotAproved: [
          { quarter: 'Q1', keur: 50 },
          { quarter: 'Q3', keur: 150 },
          { quarter: 'Q4', keur: 250 },
        ],
      },
      purchaseOrders: 1000,
      purchaseRequest: 500,
      baseline: 2000,
    };
    mockSubcontractingService = {
      graphs: mockGraphSignal,
      getSubcontractingGraphs: jest.fn(),
    };
    await TestBed.configureTestingModule({
      imports: [SubcontractingBarsGraphComponent],
      providers: [{ provide: SubcontractingService, useValue: mockSubcontractingService }],
    }).compileComponents();

    fixture = TestBed.createComponent(SubcontractingBarsGraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set chart data', () => {
    mockGraphSignal.set(mockGraphsData);

    const chartData = component.chartData();
    expect(chartData).toEqual({
      colors: [APPROVED_COLOR, NOT_APPROVED_COLOR],
      labels: ['Q1', 'Q2', 'Q3', 'Q4'],
      series: [
        { name: 'Approved', data: [100, 200, 0, 0] },
        { name: 'Not approved', data: [50, 0, 150, 250] },
      ],
    });
  });
});
