import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject, TemplateRef, viewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatAccordion, MatExpansionPanel, MatExpansionPanelDescription, MatExpansionPanelHeader, MatExpansionPanelTitle } from '@angular/material/expansion';
import { MatIcon } from '@angular/material/icon';
import { SubcontractingTableComponent } from '@tables/subcontracting-table/subcontracting-table.component';
import { NgClass } from '@angular/common';
import { SubcontractingFiltersComponent } from '@components/subcontracting-filters/subcontracting-filters.component';
import { SubcontractingBreakdownComponent } from './components/subcontracting-breakdown/subcontracting-breakdown.component';
import { SubcontractingBarsGraphComponent } from './components/subcontracting-bars-graph/subcontracting-bars-graph.component';
import { MatDialog, MatDialogConfig, MatDialogModule } from '@angular/material/dialog';
import { GenericDialogComponent } from '@src/app/shared/components/generic-dialog/generic-dialog.component';
import { HmgListComponent } from './components/hmg-list/hmg-list.component';
import { TooltipComponent } from '@src/app/shared/components/tooltip/tooltip.component';

const DIALOG_CONFIG: MatDialogConfig = {
  panelClass: 'no-border-radius-dialog',
  width: '35%',
  height: '75%',
  maxWidth: '100vw',
  maxHeight: '100vh',
};

@Component({
  selector: 'optim-subcontracting',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    MatButtonModule,
    MatAccordion,
    MatExpansionPanel,
    MatExpansionPanelDescription,
    MatExpansionPanelHeader,
    MatExpansionPanelTitle,
    MatIcon,
    SubcontractingFiltersComponent,
    SubcontractingBreakdownComponent,
    SubcontractingBarsGraphComponent,
    SubcontractingTableComponent,
    NgClass,
    MatButtonModule,
    MatDialogModule,
    TooltipComponent,
    HmgListComponent,
  ],
  templateUrl: './subcontracting.component.html',
  styleUrl: './subcontracting.component.scss',
})
export class SubcontractingComponent {
  readonly dialog = inject(MatDialog);
  readonly hmgDefinitionsDialog = viewChild.required<TemplateRef<unknown>>('hmgDefinitionsDialog');

  activeFilters = false;

  toggleActiveFilters(event: boolean) {
    this.activeFilters = event;
  }

  openHMGDefinitionsDialog() {
    this.dialog.open(GenericDialogComponent, {
      ...DIALOG_CONFIG,
      data: {
        title: 'HMG Definitions',
        content: this.hmgDefinitionsDialog(),
      },
    });
  }
}
