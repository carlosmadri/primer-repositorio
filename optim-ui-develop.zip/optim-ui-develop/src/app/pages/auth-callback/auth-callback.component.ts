import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'optim-auth-callback',
  standalone: true,
  template: '<p>Authenticating...</p>',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AuthCallbackComponent {}
