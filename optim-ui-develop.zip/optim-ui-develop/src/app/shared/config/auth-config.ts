import { environment } from '@src/environments/environment';
import { AuthConfig } from 'angular-oauth2-oidc';

export const authConfig: AuthConfig = {
  issuer: environment.issuerUrl,
  redirectUri: `${window.location.origin}/${environment.redirectUri}`,
  clientId: environment.clientId,
  responseType: 'code',
  scope: 'openid email',
  showDebugInformation: true,
  useSilentRefresh: true,
  disableAtHashCheck: true,
  oidc: true,
  requireHttps: environment.requireHttps,
  skipIssuerCheck: true,
};
