export const pageSizeOptions = [5, 10, 20, 50, 100];
export const defaultPageSize = pageSizeOptions[1];
