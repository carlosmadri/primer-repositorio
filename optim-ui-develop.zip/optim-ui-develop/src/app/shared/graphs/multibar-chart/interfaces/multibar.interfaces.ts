import { WorkloadEvolutionBarData } from '@src/app/shared/models/worksync.model';
import * as d3 from 'd3';

export const BAR_TYPE_OWN = 'Own';
export const BAR_TYPE_SUB = 'Sub';
export type BarTypeOwn = 'Own';
export type BarTypeSub = 'Sub';

export interface LegendItem {
  key: string;
  label: string;
  pattern: string;
  opacity: number;
}

export interface StackedBarData {
  key: string;
  value: d3.SeriesPoint<WorkloadEvolutionBarData>;
  data: WorkloadEvolutionBarData;
}

export interface ChartDimensions {
  width: number;
  height: number;
  margin: {
    top: number;
    right: number;
    bottom: number;
    left: number;
  };
}

export interface ChartScales {
  x: d3.ScaleBand<string>;
  xInner: d3.ScaleBand<string>;
  y: d3.ScaleLinear<number, number>;
  color: (exercise: string) => string;
  pattern: d3.ScaleOrdinal<string, string>;
  opacity: d3.ScaleOrdinal<string, string>;
}

export interface ChartElements {
  svg?: d3.Selection<SVGGElement, unknown, null, undefined>;
  tooltip?: d3.Selection<HTMLDivElement, unknown, null, undefined>;
}

export interface BarConfig {
  type: BarTypeOwn | BarTypeSub;
  getDirectValue: (d: WorkloadEvolutionBarData) => number;
  getIndirectValue: (d: WorkloadEvolutionBarData) => number;
  keys: [string, string];
}

export interface SegmentConfig {
  value: number;
  baseValue: number;
  key: string;
  opacity: number;
  isPattern?: boolean;
}
