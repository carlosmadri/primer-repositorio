import { ChangeDetectionStrategy, Component, effect, ElementRef, inject, input, OnDestroy, OnInit, viewChild } from '@angular/core';
import { animate, style, transition, trigger } from '@angular/animations';
import { WorkloadEvolutionBarData } from '../../models/worksync.model';
import { MultibarChartService } from './services/multibar-chart.service';
import { ExerciseColorService } from './services/exercise-color.service';
import { PatternService } from './services/pattern.service';
import { TooltipService } from './services/tooltip.service';

@Component({
  selector: 'optim-multibar-chart',
  imports: [],
  templateUrl: './multibar-chart.component.html',
  styleUrl: './multibar-chart.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [MultibarChartService, ExerciseColorService, PatternService, TooltipService],
  animations: [
    trigger('growChart', [
      // Initial animation
      transition(':enter', [style({ transform: 'scaleY(0)', transformOrigin: 'bottom' }), animate('600ms ease-out', style({ transform: 'scaleY(1)' }))]),
      // Update animation
      transition('* => *', [
        style({
          transform: 'scaleY(0.7)',
          transformOrigin: 'bottom',
          opacity: 0.3,
        }),
        animate(
          '600ms cubic-bezier(0.4, 0, 0.2, 1)',
          style({
            transform: 'scaleY(1)',
            opacity: 1,
          }),
        ),
      ]),
    ]),
  ],
})
export class MultibarChartComponent implements OnInit, OnDestroy {
  readonly chart = viewChild.required<ElementRef>('chart');

  animationState = 0;

  chartData = input.required<WorkloadEvolutionBarData[]>();

  chartService = inject(MultibarChartService);
  colorService = inject(ExerciseColorService);

  containerHeight = input<number>();

  constructor() {
    effect(() => {
      if (this.chartData() && this.chartData()!.length > 0 && this.containerHeight() !== 0) {
        const data = this.chartData();
        const element = this.chart().nativeElement;

        const exerciseNames = data.map((d) => d.exercise);
        const barTypes = data.map((d) => d.barType);
        const colorMap = this.colorService.getColorMap(barTypes, exerciseNames);

        this.chartService.setColorMap(colorMap);
        this.chartService.drawChart(element, data);
      } else {
        this.chartService.destroyChart();
      }
    });
  }

  ngOnInit(): void {
    window.addEventListener('resize', this.onResize.bind(this));
  }

  private onResize(): void {
    const data = this.chartData();
    if (data) {
      const element = this.chart().nativeElement;
      this.chartService.drawChart(element, data);
    }
  }

  ngOnDestroy(): void {
    this.chartService.destroyChart();
    window.removeEventListener('resize', this.onResize);
  }
}
