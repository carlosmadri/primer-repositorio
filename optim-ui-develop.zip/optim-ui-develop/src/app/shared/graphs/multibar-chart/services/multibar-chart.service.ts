import { Injectable } from '@angular/core';
import { WorkloadEvolutionBarData } from '@src/app/shared/models/worksync.model';
import * as d3 from 'd3';
import { Selection } from 'd3-selection';
import { CHART_CONSTANTS } from '../constants/multibar.constants';
import { BAR_TYPE_OWN, BAR_TYPE_SUB, BarConfig, BarTypeOwn, BarTypeSub, ChartScales, LegendItem, StackedBarData } from '../interfaces/multibar.interfaces';
import { ChartState } from '../models/multibar-state.model';
import { PatternService } from './pattern.service';
import { TooltipService } from './tooltip.service';

@Injectable()
export class MultibarChartService {
  private static readonly BAR_CONFIGS: BarConfig[] = [
    {
      type: BAR_TYPE_OWN,
      getDirectValue: (d) => d.ownDirect,
      getIndirectValue: (d) => d.ownIndirect,
      keys: ['ownDirect', 'ownIndirect'],
    },
    {
      type: BAR_TYPE_SUB,
      getDirectValue: (d) => d.subDirect,
      getIndirectValue: (d) => d.subIndirect,
      keys: ['subDirect', 'subIndirect'],
    },
  ];

  private chartState: ChartState;
  private element: HTMLElement | null = null;
  private originalData: WorkloadEvolutionBarData[] = [];

  constructor(
    private patternService: PatternService,
    private tooltipService: TooltipService,
  ) {
    this.chartState = new ChartState();
  }

  drawChart(element: HTMLElement, data: WorkloadEvolutionBarData[]): void {
    this.element = element;
    this.originalData = data;

    this.chartState.setData(data);
    this.chartState.setMaxValue(d3.max(data, (d) => Math.max(d.total)) || 0);
    this.updateMarginForNumbers();

    this.createSvg(element);
    this.createScales(data);
    this.createTooltip(element);
    this.drawBars();
    this.drawAxes();
    this.createLegend();
  }

  setColorMap(colorMap: Map<string, string>): void {
    this.chartState.setColorMap(colorMap);
  }

  destroyChart(): void {
    this.chartState.destroy();
    this.element = null;
    this.originalData = [];
  }

  private createSvg(element: HTMLElement): void {
    d3.select(element).selectAll('*').remove();

    const containerWidth = element.clientWidth || 300;
    const containerHeight = element.clientHeight || 200;
    const dimensions = this.chartState.getDimensions();

    this.chartState.setDimensions({
      width: containerWidth - dimensions.margin.left - dimensions.margin.right,
      height: containerHeight - dimensions.margin.top - dimensions.margin.bottom,
    });

    const svg = d3
      .select(element)
      .append('svg')
      .attr('width', containerWidth)
      .attr('height', containerHeight)
      .append('g')
      .attr('transform', `translate(${dimensions.margin.left},${dimensions.margin.top})`);

    this.chartState.setSvg(svg);
  }

  private createTooltip(element: HTMLElement): void {
    const tooltip = this.tooltipService.createTooltip(element);
    this.chartState.setTooltip(tooltip);
  }

  private createScales(data: WorkloadEvolutionBarData[]): void {
    const dimensions = this.chartState.getDimensions();
    const filteredData = this.getFilteredData();

    // Main scale for exercises (groups)
    const x = d3
      .scaleBand()
      .domain(data.map((d) => d.exercise))
      .range([0, dimensions.width])
      .padding(0.2);

    // Inner scale for own/sub bars
    const xInner = d3.scaleBand().domain([BAR_TYPE_OWN, BAR_TYPE_SUB]).range([0, x.bandwidth()]).padding(0);

    // Calculate max value considering Own and Sub columns separately
    const maxValue = d3.max(filteredData, (d) => Math.max(d.ownDirect + d.ownIndirect, d.subDirect + d.subIndirect)) || 0;

    const y = d3
      .scaleLinear()
      .domain([0, maxValue * 1.1])
      .range([dimensions.height, 0]);

    const pattern = d3
      .scaleOrdinal<string>()
      .domain(CHART_CONSTANTS.SEGMENT_KEYS)
      .range([
        `url(#${CHART_CONSTANTS.PATTERNS.TRANSPARENT})`,
        `url(#${CHART_CONSTANTS.PATTERNS.DIAGONAL})`,
        `url(#${CHART_CONSTANTS.PATTERNS.TRANSPARENT})`,
        `url(#${CHART_CONSTANTS.PATTERNS.DIAGONAL})`,
      ]);

    const opacity = d3.scaleOrdinal<string>().domain(CHART_CONSTANTS.SEGMENT_KEYS).range(['1', '0.7', '0.6', '0.4']);

    this.chartState.setScales({
      x,
      xInner,
      y,
      color: (exercise: string) => this.chartState.getColorMap().get(exercise) || '#000000',
      pattern,
      opacity,
    });
  }

  private drawBars(): void {
    const svg = this.chartState.getSvg();
    if (!svg) return;

    const filteredData = this.getFilteredData();
    const scales = this.chartState.getScales();

    this.patternService.createPatterns(svg);
    svg.selectAll('.bar-group').remove();

    const barGroups = svg
      .selectAll('.bar-group')
      .data(filteredData)
      .enter()
      .append('g')
      .attr('class', 'bar-group')
      .attr('transform', (d) => `translate(${scales.x(d.exercise)},0)`);

    barGroups
      .append('text')
      .attr('class', 'exercise-label')
      .attr('x', scales.x.bandwidth() / 2)
      .attr('y', -this.chartState.getDimensions().margin.top + 15)
      .attr('text-anchor', 'middle')
      .attr('fill', '#ccc')
      .attr('font-size', CHART_CONSTANTS.FONT_SIZES.EXERCISE)
      .text((d) => d.exercise);

    barGroups
      .append('text')
      .attr('class', 'total-label')
      .attr('x', scales.x.bandwidth() / 2)
      .attr('y', -this.chartState.getDimensions().margin.top + 35)
      .attr('text-anchor', 'middle')
      .attr('fill', 'white')
      .attr('font-size', CHART_CONSTANTS.FONT_SIZES.TOTAL)
      .text((d) => d3.format('.1f')(d.total));

    MultibarChartService.BAR_CONFIGS.forEach((config) => {
      this.createStackedBar(barGroups, config.type, config.getDirectValue, config.getIndirectValue, config.keys);
    });
  }

  private createStackedBar(
    barGroups: Selection<SVGGElement, WorkloadEvolutionBarData, SVGGElement, unknown>,
    type: BarTypeOwn | BarTypeSub,
    getDirectValue: (d: WorkloadEvolutionBarData) => number,
    getIndirectValue: (d: WorkloadEvolutionBarData) => number,
    [directKey, indirectKey]: [string, string],
  ): void {
    const scales = this.chartState.getScales();
    const barGroup = barGroups
      .append('g')
      .attr('class', `${type}-group`)
      .attr('transform', `translate(${scales.xInner(type)},0)`);

    // Direct value rectangle (bottom)
    const directValue = (d: WorkloadEvolutionBarData) => getDirectValue(d);

    barGroup
      .append('rect')
      .attr('class', `${type}-direct`)
      .attr('x', 0)
      .attr('y', (d) => scales.y(directValue(d)))
      .attr('height', (d) => scales.y(0) - scales.y(directValue(d)))
      .attr('width', scales.xInner.bandwidth())
      .attr('fill', (d) => scales.color(d.exercise))
      .attr('opacity', +scales.opacity(directKey))
      .on('mouseover', (event, d) => {
        const tooltipData = this.createStackedBarTooltipData(d, type, getDirectValue(d), getIndirectValue(d), false);
        this.tooltipService.showTooltip(this.chartState, event, tooltipData, this.chartState.getDimensions());
      })
      .on('mouseout', () => this.tooltipService.hideTooltip(this.chartState.getTooltip()!));

    // Add direct value label and title
    const directLabelGroup = barGroup.append('g').attr('class', 'value-label-group');

    const directHeight = (d: WorkloadEvolutionBarData) => scales.y(0) - scales.y(directValue(d));
    const directCenterY = (d: WorkloadEvolutionBarData) => scales.y(directValue(d) / 2);

    this.createSegmentLabels(directLabelGroup, {
      getValue: directValue,
      getHeight: directHeight,
      getCenterY: directCenterY,
      type,
      isIndirect: false,
      scales,
      tooltipConfig: {
        type,
        getDirectValue,
        getIndirectValue,
        isIndirect: false,
      },
    });

    // Indirect value rectangle
    const indirectValue = (d: WorkloadEvolutionBarData) => getIndirectValue(d);

    barGroup
      .append('rect')
      .attr('class', `${type}-indirect`)
      .attr('x', 0)
      .attr('y', (d) => scales.y(directValue(d) + indirectValue(d)))
      .attr('height', (d) => scales.y(directValue(d)) - scales.y(directValue(d) + indirectValue(d)))
      .attr('width', scales.xInner.bandwidth())
      .attr('fill', (d) => scales.color(d.exercise))
      .attr('opacity', +scales.opacity(indirectKey))
      .on('mouseover', (event, d) => {
        const tooltipData = this.createStackedBarTooltipData(d, type, getDirectValue(d), getIndirectValue(d), true);
        this.tooltipService.showTooltip(this.chartState, event, tooltipData, this.chartState.getDimensions());
      })
      .on('mouseout', () => this.tooltipService.hideTooltip(this.chartState.getTooltip()!));

    // Add pattern on top of indirect rectangle
    barGroup
      .append('rect')
      .attr('class', `${type}-indirect-pattern`)
      .attr('x', 0)
      .attr('y', (d) => scales.y(directValue(d) + indirectValue(d)))
      .attr('height', (d) => scales.y(directValue(d)) - scales.y(directValue(d) + indirectValue(d)))
      .attr('width', scales.xInner.bandwidth())
      .attr('fill', () => scales.pattern(indirectKey))
      .attr('opacity', CHART_CONSTANTS.OPACITY.PATTERN)
      .on('mouseover', (event, d) => {
        const tooltipData = this.createStackedBarTooltipData(d, type, getDirectValue(d), getIndirectValue(d), true);
        this.tooltipService.showTooltip(this.chartState, event, tooltipData, this.chartState.getDimensions());
      })
      .on('mouseout', () => this.tooltipService.hideTooltip(this.chartState.getTooltip()!));

    // Add indirect value label and title
    const indirectLabelGroup = barGroup.append('g').attr('class', 'value-label-group');

    const indirectHeight = (d: WorkloadEvolutionBarData) => scales.y(directValue(d)) - scales.y(directValue(d) + indirectValue(d));
    const indirectCenterY = (d: WorkloadEvolutionBarData) => scales.y(directValue(d) + indirectValue(d) - indirectValue(d) / 2);

    this.createSegmentLabels(indirectLabelGroup, {
      getValue: indirectValue,
      getHeight: indirectHeight,
      getCenterY: indirectCenterY,
      type,
      isIndirect: true,
      scales,
      tooltipConfig: {
        type,
        getDirectValue,
        getIndirectValue,
        isIndirect: true,
      },
    });
  }

  private createSegmentLabels(
    labelGroup: Selection<SVGGElement, WorkloadEvolutionBarData, SVGGElement, unknown>,
    params: {
      getValue: (d: WorkloadEvolutionBarData) => number;
      getHeight: (d: WorkloadEvolutionBarData) => number;
      getCenterY: (d: WorkloadEvolutionBarData) => number;
      type: BarTypeOwn | BarTypeSub;
      isIndirect: boolean;
      scales: ChartScales;
      tooltipConfig: {
        type: BarTypeOwn | BarTypeSub;
        getDirectValue: (d: WorkloadEvolutionBarData) => number;
        getIndirectValue: (d: WorkloadEvolutionBarData) => number;
        isIndirect: boolean;
      };
    },
  ): void {
    const { getValue, getHeight, getCenterY, type, isIndirect, scales, tooltipConfig } = params;
    const MIN_HEIGHT_PER_LABEL = CHART_CONSTANTS.MIN_BAR_HEIGHT_FOR_LABEL;
    const TOTAL_MIN_HEIGHT = MIN_HEIGHT_PER_LABEL * 2;

    // Value label
    labelGroup
      .append('text')
      .attr('class', 'value-label')
      .attr('x', scales.xInner.bandwidth() / 2)
      .attr('y', (d) => getCenterY(d))
      .attr('dy', (d) => (getHeight(d) > TOTAL_MIN_HEIGHT ? '0.7em' : '0.35em'))
      .attr('text-anchor', 'middle')
      .attr('fill', 'white')
      .attr('font-size', CHART_CONSTANTS.FONT_SIZES.LABELS)
      .text((d) => {
        const value = getValue(d);
        if (value === 0) return '';
        const height = getHeight(d);
        return height > MIN_HEIGHT_PER_LABEL ? d3.format('.1f')(value) : '';
      })
      .on('mouseover', (event, d) => {
        const tooltipData = this.createStackedBarTooltipData(
          d,
          tooltipConfig.type,
          tooltipConfig.getDirectValue(d),
          tooltipConfig.getIndirectValue(d),
          tooltipConfig.isIndirect,
        );
        this.tooltipService.showTooltip(this.chartState, event, tooltipData, this.chartState.getDimensions());
      })
      .on('mouseout', () => this.tooltipService.hideTooltip(this.chartState.getTooltip()!));

    // Secondary label (type)
    labelGroup
      .append('text')
      .attr('class', 'title-label')
      .attr('x', scales.xInner.bandwidth() / 2)
      .attr('y', (d) => getCenterY(d))
      .attr('dy', '-0.7em')
      .attr('text-anchor', 'middle')
      .attr('fill', '#eee')
      .attr('font-size', CHART_CONSTANTS.FONT_SIZES.SECONDARY_LABELS)
      .text((d) => {
        const value = getValue(d);
        if (value === 0) return '';
        const height = getHeight(d);
        return height > TOTAL_MIN_HEIGHT ? `${type} ${isIndirect ? 'Ind.' : 'Dir.'}` : '';
      })
      .on('mouseover', (event, d) => {
        const tooltipData = this.createStackedBarTooltipData(
          d,
          tooltipConfig.type,
          tooltipConfig.getDirectValue(d),
          tooltipConfig.getIndirectValue(d),
          tooltipConfig.isIndirect,
        );
        this.tooltipService.showTooltip(this.chartState, event, tooltipData, this.chartState.getDimensions());
      })
      .on('mouseout', () => this.tooltipService.hideTooltip(this.chartState.getTooltip()!));
  }

  private createStackedBarTooltipData(
    data: WorkloadEvolutionBarData,
    type: BarTypeOwn | BarTypeSub,
    directValue: number,
    indirectValue: number,
    isIndirect: boolean,
  ): StackedBarData {
    const tooltipData: Partial<WorkloadEvolutionBarData> = {
      exercise: data.exercise,
      ...(type === BAR_TYPE_OWN
        ? {
            ownDirect: data.ownDirect,
            ownIndirect: data.ownIndirect,
          }
        : {
            subDirect: data.subDirect,
            subIndirect: data.subIndirect,
          }),
    };

    return {
      key: `${type.toLowerCase()}${isIndirect ? 'Indirect' : 'Direct'}`,
      value: isIndirect
        ? ([directValue, directValue + indirectValue] as d3.SeriesPoint<WorkloadEvolutionBarData>)
        : ([0, directValue] as d3.SeriesPoint<WorkloadEvolutionBarData>),
      data: tooltipData as WorkloadEvolutionBarData,
    };
  }

  private drawAxes(): void {
    const svg = this.chartState.getSvg();
    if (!svg) return;

    // Remove existing axes and grid
    svg.selectAll('.y-axis, .x-axis, .grid').remove();

    const dimensions = this.chartState.getDimensions();
    const scales = this.chartState.getScales();
    const tickValues = this.calculateTickValues();

    // Grid lines
    svg
      .append('g')
      .attr('class', 'grid')
      .attr('opacity', 0.1)
      .call((g) => {
        const yAxis = d3
          .axisLeft(scales.y)
          .tickValues(tickValues)
          .tickSize(-dimensions.width)
          .tickFormat(() => '');
        return yAxis(g);
      });

    svg
      .append('g')
      .attr('class', 'y-axis')
      .call((g) => {
        const yAxis = d3.axisLeft(scales.y).tickValues(tickValues).tickFormat(d3.format('.0f'));
        return yAxis(g);
      })
      .attr('font-size', CHART_CONSTANTS.FONT_SIZES.AXIS)
      .call((g) => {
        g.select('.domain').remove();
        g.selectAll('.tick line').remove();
      });

    svg
      .append('g')
      .attr('class', 'x-axis')
      .attr('transform', `translate(0,${dimensions.height})`)
      .call((g) => {
        const xAxis = d3
          .axisBottom(scales.x)
          .tickSize(0)
          .tickFormat(() => '');
        return xAxis(g);
      })
      .call((g) => {
        g.select('.domain').attr('stroke', '#555').attr('stroke-width', 1);
        g.selectAll('.tick').remove();
      });
  }

  private calculateTickValues(): number[] {
    const filteredData = this.getFilteredData();
    const maxValue = d3.max(filteredData, (d) => Math.max(d.ownDirect + d.ownIndirect, d.subDirect + d.subIndirect)) || 0;

    const tickStep = this.calculateTickStep(maxValue);
    const highestTick = Math.floor(maxValue / tickStep) * tickStep;

    return d3.range(0, highestTick + tickStep / 2, tickStep).filter((tick) => tick <= highestTick);
  }

  private calculateTickStep(max: number): number {
    const targetTickCount = CHART_CONSTANTS.TARGET_TICK_COUNT - 1;
    let step = Math.pow(10, Math.floor(Math.log10(max)));

    while (max / step < targetTickCount) {
      step /= 2;
    }

    while (max / step > targetTickCount) {
      step *= 2;
    }

    return step;
  }

  private createLegend(): void {
    const svg = this.chartState.getSvg();
    if (!svg) return;

    const legendData = [
      { key: 'ownDirect', label: 'Own Direct', pattern: 'none', opacity: +this.chartState.getScales().opacity('ownDirect') },
      {
        key: 'ownIndirect',
        label: 'Own Indirect',
        pattern: `url(#${CHART_CONSTANTS.PATTERNS.DIAGONAL})`,
        opacity: +this.chartState.getScales().opacity('ownIndirect'),
      },
      { key: 'subDirect', label: 'Sub Direct', pattern: 'none', opacity: +this.chartState.getScales().opacity('subDirect') },
      {
        key: 'subIndirect',
        label: 'Sub Indirect',
        pattern: `url(#${CHART_CONSTANTS.PATTERNS.DIAGONAL})`,
        opacity: +this.chartState.getScales().opacity('subIndirect'),
      },
    ];

    svg.selectAll('.legend').remove();

    const dimensions = this.chartState.getDimensions();
    const totalLegendWidth = CHART_CONSTANTS.LEGEND_ITEM_WIDTH * CHART_CONSTANTS.SEGMENT_KEYS.length;
    const startX = (dimensions.width - totalLegendWidth) / 2;

    const legendGroup = svg
      .append('g')
      .attr('class', 'legend')
      .attr('transform', `translate(${startX}, ${dimensions.height + 20})`);

    const legendItems = legendGroup
      .selectAll('.legend-item')
      .data(legendData)
      .enter()
      .append('g')
      .attr('class', 'legend-item')
      .attr('transform', (d, i) => `translate(${i * CHART_CONSTANTS.LEGEND_ITEM_WIDTH}, 0)`)
      .style('opacity', (d) => (this.chartState.isKeyDisabled(d.key) ? CHART_CONSTANTS.OPACITY.DIMMED : CHART_CONSTANTS.OPACITY.NORMAL))
      .style('cursor', 'pointer')
      .on('mouseover', (event, d) => this.handleLegendMouseOver(d))
      .on('mouseleave', () => this.handleLegendMouseLeave())
      .on('click', (event, d) => this.handleLegendClick(d));

    // Add stroke
    legendItems
      .append('circle')
      .attr('r', 10)
      .attr('cx', 5)
      .attr('cy', 8)
      .attr('stroke', '#ccc')
      .attr('stroke-width', 1)
      .attr('opacity', CHART_CONSTANTS.OPACITY.NORMAL);

    // Add white background
    legendItems
      .append('circle')
      .attr('r', 10)
      .attr('cx', 5)
      .attr('cy', 8)
      .attr('fill', '#ccc')
      .attr('opacity', (d) => d.opacity);

    // Add pattern
    legendItems
      .append('circle')
      .attr('r', 10)
      .attr('cx', 5)
      .attr('cy', 8)
      .attr('fill', (d) => (d.pattern === 'none' ? 'white' : d.pattern))
      .attr('opacity', (d) => (d.pattern === 'none' ? d.opacity : CHART_CONSTANTS.OPACITY.NORMAL));

    legendItems
      .append('text')
      .attr('x', 20)
      .attr('y', 12)
      .text((d) => d.label)
      .style('font-size', CHART_CONSTANTS.FONT_SIZES.LEGEND)
      .attr('fill', 'white');
  }

  private handleLegendMouseOver(d: LegendItem): void {
    const svg = this.chartState.getSvg();
    if (!svg || this.chartState.isKeyDisabled(d.key)) return;

    const type = d.key.toLowerCase().startsWith(BAR_TYPE_OWN.toLowerCase()) ? BAR_TYPE_OWN : BAR_TYPE_SUB;
    const isIndirect = d.key.includes('Indirect');
    const selector = isIndirect ? `.${type}-indirect, .${type}-indirect-pattern` : `.${type}-direct`;

    svg
      .selectAll<
        SVGRectElement,
        WorkloadEvolutionBarData
      >('.own-direct, .own-indirect, .own-indirect-pattern, .sub-direct, .sub-indirect, .sub-indirect-pattern')
      .style('opacity', CHART_CONSTANTS.OPACITY.HOVER_DIMMED);

    svg.selectAll<SVGRectElement, WorkloadEvolutionBarData>(selector).style('opacity', (data, i, nodes) => {
      const element = nodes[i];
      if (isIndirect) {
        return element.classList.contains('pattern') ? CHART_CONSTANTS.OPACITY.PATTERN : +this.chartState.getScales().opacity(d.key);
      }
      return +this.chartState.getScales().opacity(d.key);
    });
  }

  private handleLegendMouseLeave(): void {
    const svg = this.chartState.getSvg();
    if (!svg) return;

    this.drawBars();
  }

  private handleLegendClick(d: LegendItem): void {
    this.chartState.toggleKey(d.key);

    if (this.element) {
      this.drawChart(this.element, this.originalData);
    }
  }

  private updateMarginForNumbers(): void {
    const dimensions = this.chartState.getDimensions();
    const digits = Math.ceil(this.chartState.getMaxValue()).toString().length;

    this.chartState.setDimensions({
      margin: {
        ...dimensions.margin,
        left: CHART_CONSTANTS.DEFAULT_MARGIN_LEFT + digits * 6,
      },
    });
  }

  private getFilteredData(): WorkloadEvolutionBarData[] {
    return this.originalData.map((item) => {
      const filteredItem = { ...item };

      if (this.chartState.isKeyDisabled('ownDirect')) {
        filteredItem.ownDirect = 0;
      }
      if (this.chartState.isKeyDisabled('ownIndirect')) {
        filteredItem.ownIndirect = 0;
      }
      if (this.chartState.isKeyDisabled('subDirect')) {
        filteredItem.subDirect = 0;
      }
      if (this.chartState.isKeyDisabled('subIndirect')) {
        filteredItem.subIndirect = 0;
      }

      filteredItem.total = filteredItem.ownDirect + filteredItem.ownIndirect + filteredItem.subDirect + filteredItem.subIndirect;

      return filteredItem;
    });
  }
}
