import { Injectable } from '@angular/core';
import { Selection } from 'd3-selection';
import * as d3 from 'd3';
import { BAR_TYPE_OWN, BAR_TYPE_SUB, ChartDimensions, ChartScales, StackedBarData } from '../interfaces/multibar.interfaces';
import { CHART_CONSTANTS } from '../constants/multibar.constants';
import { ChartState } from '../models/multibar-state.model';

@Injectable()
export class TooltipService {
  createTooltip(element: HTMLElement): Selection<HTMLDivElement, unknown, null, undefined> {
    return d3.select(element).append('div').attr('class', 'workload-tooltip-title');
  }

  showTooltip(chartState: ChartState, event: MouseEvent, d: StackedBarData, charDimensions: ChartDimensions): void {
    const tooltip = chartState.getTooltip();
    const svg = chartState.getSvg();
    const scales = chartState.getScales();

    if (!tooltip || !svg || !scales.x || !scales.y) return;

    const tooltipContent = this.generateTooltipContent(d);
    const position = this.calculateTooltipPosition(svg, scales, d, charDimensions);

    tooltip.html(tooltipContent).style('left', `${position.x}px`).style('top', `${position.y}px`).style('transform', 'translateY(-50%)');

    tooltip.transition().duration(100).style('opacity', 0.9);
  }

  hideTooltip(tooltip: Selection<HTMLDivElement, unknown, null, undefined>): void {
    tooltip.transition().duration(100).style('opacity', 0);
  }

  private generateTooltipContent(d: StackedBarData): string {
    const formatKey = (key: string) => {
      const parts = key.split(/(?=[A-Z])/);
      return parts.map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join(' ');
    };

    const formatValue = (value: number) => d3.format(',')(value);

    return `
      ${Object.entries(d.data)
        .reverse()
        .filter(([key]) => !CHART_CONSTANTS.TOOLTIP_EXCLUDED_KEYS.has(key))
        .map(([key, value]) => {
          const formattedKey = formatKey(key);
          const formattedValue = formatValue(value as number);
          if (key === d.key) {
            return `<p class="selected-value"><span>${formattedKey}:</span> <span>${formattedValue} khours</span></p>`;
          }
          return `<p><span>${formattedKey}:</span> <span>${formattedValue} khours</span></p>`;
        })
        .join('')}
    `;
  }

  private calculateTooltipPosition(
    svg: Selection<SVGGElement, unknown, null, undefined>,
    scales: ChartScales,
    d: StackedBarData,
    charDimensions: ChartDimensions,
  ): { x: number; y: number } {
    const svgNode = svg.node() as SVGGElement;
    const svgRect = svgNode.getBoundingClientRect();
    const chartLeftMargin = charDimensions?.margin?.left || 0;

    const type = d.key.toLowerCase().startsWith(BAR_TYPE_OWN.toLowerCase()) ? BAR_TYPE_OWN : BAR_TYPE_SUB;
    const isIndirect = d.key.includes('Indirect');

    return {
      x: chartLeftMargin + scales.x(d.data.exercise)! + scales.xInner(type)! + scales.xInner.bandwidth() + 39,
      y:
        svgRect.top +
        scales.y(isIndirect ? d.value[1] : d.value[1]) +
        (scales.y(isIndirect ? d.value[0] : 0) - scales.y(isIndirect ? d.value[1] : d.value[1])) / 2 +
        26,
    };
  }
}
