import { ChangeDetectionStrategy, Component, effect, input, signal } from '@angular/core';
import {
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  NgApexchartsModule,
  ApexYAxis,
  ApexGrid,
  ApexTheme,
  ApexLegend,
  ApexPlotOptions,
  ApexTooltip,
  ApexOptions,
  ApexDataLabels,
  ApexStroke,
} from 'ng-apexcharts';
import { LeversTotal } from '../../models/levers-total.model';

export interface ChartOptions {
  theme: ApexTheme;
  series: ApexAxisChartSeries;
  chart: ApexChart;
  xaxis: ApexXAxis;
  yaxis: ApexYAxis;
  grid: ApexGrid;
  dataLabels: ApexDataLabels;
  colors: string[];
  stroke: ApexStroke;
  legend: ApexLegend;
  plotOptions: ApexPlotOptions;
  tooltip: ApexTooltip;
}

@Component({
  selector: 'optim-stacked-bars',
  imports: [NgApexchartsModule],
  templateUrl: './stacked-bars.component.html',
  styleUrl: './stacked-bars.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StackedBarsComponent {
  chartData = input<LeversTotal[]>();
  colors = input<string[]>(['#044B70', '#0AAEC7']);
  containerHeight = input<number>();
  public chartOptions = signal<Partial<ApexOptions> | null>(null);

  constructor() {
    effect(() => {
      const chartData = this.chartData();
      const containerHeight = this.containerHeight();
      if ((chartData?.length ?? 0) === 0 || containerHeight === 0) {
        this.chartOptions.set(null);
      } else {
        this.setChartOptions();
      }
    });
  }

  setChartOptions(): void {
    const categories = this.chartData()!.map((data) => data.leverType);
    const leavers: number[] = this.chartData()!.map((data) => data.leaver);
    const recoveries: number[] = this.chartData()!.map((data) => data.recovery);
    const colors = this.colors()!;
    const min: number = Math.min(...leavers) || 0;
    const max: number = Math.max(...recoveries) || 0;

    const chartOptions: ChartOptions = {
      theme: {
        mode: 'dark',
      },
      series: [
        {
          name: 'Leavers',
          data: leavers,
        },
        {
          name: 'Recoveries',
          data: recoveries,
        },
      ],
      chart: {
        height: this.containerHeight()! - 15,
        offsetX: 0,
        offsetY: 10,
        type: 'bar',
        stacked: true,
        background: '#2a3547',
        foreColor: '#cccccc',
        toolbar: {
          show: false,
        },
        sparkline: {
          enabled: false,
        },
      },
      dataLabels: {
        enabled: true,
        textAnchor: 'middle',
        distributed: true,
      },
      stroke: {
        width: 1,
        colors: ['#2a3547'],
      },
      xaxis: {
        axisBorder: {
          show: false,
        },
        axisTicks: {
          show: false,
        },
        categories: categories,
        labels: {
          style: {
            colors: '#cccccc',
          },
        },
        min: min,
        max: max,
      },
      yaxis: {
        labels: {
          style: {
            colors: '#cccccc',
          },
        },
      },
      grid: {
        borderColor: '#3f4d63',
        xaxis: {
          lines: {
            show: false,
          },
        },
        yaxis: {
          lines: {
            show: true,
          },
        },
      },
      plotOptions: {
        bar: {
          horizontal: true,
          borderRadius: 10,
          borderRadiusApplication: 'end',
          barHeight: '80%',
        },
      },
      colors: colors,
      legend: {
        show: true,
        position: 'top',
      },
      tooltip: {
        enabled: true,
        theme: 'dark',
      },
    };

    this.chartOptions.set(chartOptions);
  }
}
