import { ChangeDetectionStrategy, Component, effect, input, signal } from '@angular/core';
import {
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  NgApexchartsModule,
  ApexYAxis,
  ApexGrid,
  ApexTheme,
  ApexLegend,
  ApexPlotOptions,
  ApexTooltip,
  ApexOptions,
  ApexDataLabels,
  ApexStroke,
  ApexMarkers,
} from 'ng-apexcharts';
import { MultiLineChartData } from '../../models/graphs/multiline-chart.model';
import { ChartIds } from '../../models/worksync.model';
import { MONTHLY_CHART_DATA } from '../../models/monthly-distribution.model';
import * as numberUtils from '@src/utils/number-utils';

export interface ChartOptions {
  theme: ApexTheme;
  series: ApexAxisChartSeries;
  chart: ApexChart;
  xaxis: ApexXAxis;
  yaxis: ApexYAxis;
  grid: ApexGrid;
  dataLabels: ApexDataLabels;
  colors: string[];
  stroke: ApexStroke;
  legend: ApexLegend;
  plotOptions: ApexPlotOptions;
  tooltip: ApexTooltip;
  markers: ApexMarkers;
}

@Component({
  selector: 'optim-multiline-chart',
  imports: [NgApexchartsModule],
  templateUrl: './multiline-chart.component.html',
  styleUrl: './multiline-chart.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MultilineChartComponent {
  chartData = input<MultiLineChartData>();
  containerHeight = input<number>();
  markers = input<boolean>(false);
  public chartOptions = signal<Partial<ApexOptions> | null>(null);

  constructor() {
    effect(() => {
      if (!this.chartData() || this.containerHeight() === 0) {
        this.chartOptions.set(null);
      } else {
        this.setChartOptions();
      }
    });
  }

  setChartOptions(): void {
    const labels = this.chartData()!.labels;
    const values: number[][] = this.chartData()!.values;
    const colors = this.chartData()!.colors;
    const months: string[] = this.chartData()!.month;
    const lineDashes: number[] = (this.chartData()!.isAvg || []).map((isAvg) => (isAvg ? 8 : 0));
    const lineWidth: number[] = (this.chartData()!.isAvg || []).map((isAvg) => (isAvg ? 1 : 2));

    let series: ApexAxisChartSeries = labels?.map((label, index) => ({
      name: label,
      data: values[index],
      type: 'line',
      hidden: this.chartData()!.isAvg?.[index],
    })) as ApexAxisChartSeries;

    let hcCeilingIndex: number | undefined;
    if (this.markers()) {
      hcCeilingIndex = this.getHcCeilingIndex(series);

      if (series?.length > 1 && hcCeilingIndex !== undefined && hcCeilingIndex !== -1) {
        series = this.convertHcCeilingToColumn(series, hcCeilingIndex);
      }
    }
    const minMax = numberUtils.getOverallMinMax(values);

    const chartOptions: ChartOptions = {
      theme: {
        mode: 'dark',
      },
      series: series || [],
      chart: {
        height: this.containerHeight()! - 15,
        offsetX: 0,
        offsetY: 0,
        type: 'line',
        background: '#2a3547',
        foreColor: '#cccccc',
        toolbar: {
          show: false,
        },
      },
      dataLabels: {
        enabled: false,
      },
      stroke: {
        curve: 'smooth',
        width: lineWidth,
        dashArray: lineDashes,
      },
      xaxis: {
        axisBorder: {
          show: false,
        },
        axisTicks: {
          show: false,
        },
        categories: months,
        labels: {
          style: {
            colors: '#cccccc',
          },
        },
      },
      yaxis: {
        min: minMax.min,
        max: minMax.max,
        labels: {
          style: {
            colors: '#cccccc',
          },
        },
      },
      grid: {
        borderColor: '#3f4d63',
        xaxis: {
          lines: {
            show: false,
          },
        },
        yaxis: {
          lines: {
            show: true,
          },
        },
      },
      plotOptions: {
        bar: {
          columnWidth: '10%',
        },
      },
      colors: colors,
      legend: this.markers()
        ? {
            show: true,
            position: 'right',
          }
        : { show: false },
      tooltip: {
        enabled: true,
        theme: 'dark',
        style: {
          fontSize: '0.8em',
        },
      },
      markers: {
        size: [6, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        hover: {
          size: 8,
          sizeOffset: 3,
        },
        discrete: [
          this.markers() && hcCeilingIndex !== undefined
            ? {
                seriesIndex: hcCeilingIndex,
                dataPointIndex: series[hcCeilingIndex!].data.length - 1 || 0,
                size: 6,
                fillColor: colors[hcCeilingIndex!] || '#fff',
                strokeColor: '#fff',
              }
            : {},
        ],
      },
    };

    this.chartOptions.set(chartOptions);
  }

  private getHcCeilingIndex(series: ApexAxisChartSeries | undefined): number | undefined {
    const hcLabel = MONTHLY_CHART_DATA.find((data) => data.name === ChartIds.HC_CEILING);
    return series?.findIndex((serie) => serie.name === hcLabel?.label);
  }

  private convertHcCeilingToColumn(series: ApexAxisChartSeries, hcCeilingIndex: number): ApexAxisChartSeries {
    const hcCeiling: number = series[hcCeilingIndex].data[0] as number;
    const hcCeilingIndexData: unknown[] = series[hcCeilingIndex].data.map(() => null);
    hcCeilingIndexData[hcCeilingIndexData.length - 1] = hcCeiling;
    series[hcCeilingIndex].data = hcCeilingIndexData as number[];
    series[hcCeilingIndex].type = 'scatter';
    return series;
  }
}
