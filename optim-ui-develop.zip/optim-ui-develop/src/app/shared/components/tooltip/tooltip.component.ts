import { ChangeDetectionStrategy, Component, effect, ElementRef, HostListener, Renderer2, signal } from '@angular/core';

@Component({
  selector: 'optim-tooltip',
  standalone: true,
  templateUrl: './tooltip.component.html',
  styleUrl: './tooltip.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TooltipComponent {
  visible = signal<boolean>(false);
  position = signal<'left' | 'right'>('right');

  constructor(
    private elementRef: ElementRef,
    private renderer: Renderer2,
  ) {
    effect(() => {
      if (this.visible()) {
        const buttonElement = this.elementRef.nativeElement.parentElement;
        const buttonRect = buttonElement.getBoundingClientRect();

        // Set initial position of the tooltip container
        this.renderer.setStyle(this.elementRef.nativeElement, 'top', `${buttonRect.top}px`);
        this.renderer.setStyle(this.elementRef.nativeElement, 'left', `${buttonRect.left}px`);
        this.renderer.setStyle(this.elementRef.nativeElement, 'height', `${buttonRect.height}px`);
        this.renderer.setStyle(this.elementRef.nativeElement, 'width', `${buttonRect.width}px`);

        // Calculate available space
        const windowWidth = window.innerWidth;
        const tooltipWidth = 200;
        const spaceToRight = windowWidth - buttonRect.right;

        // Update position based on available space
        this.position.set(spaceToRight >= tooltipWidth ? 'right' : 'left');
      }
    });
  }

  @HostListener('mouseenter', ['$event'])
  onMouseEnter() {
    this.visible.set(true);
  }

  @HostListener('mouseleave')
  onMouseLeave() {
    this.visible.set(false);
  }
}
