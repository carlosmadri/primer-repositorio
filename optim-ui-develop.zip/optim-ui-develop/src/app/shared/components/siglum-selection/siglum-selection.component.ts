import { ChangeDetectionStrategy, Component, inject, input, OnInit, output, signal, Signal, TemplateRef, viewChild } from '@angular/core';
import { MatListModule, MatSelectionListChange } from '@angular/material/list';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';
import {
  SubmitRequestResult,
  WorkloadAvailableSiglumLists,
  WorkloadPostResponse,
  WorkloadSubmitSiglumLists,
  WorkloadValidationSiglumLists,
} from '../../models/worksync.model';
import { AuthService } from '@src/app/services/auth/auth.service';
import { ClickStopPropagationDirective } from '../../directives/click-stop-propagation/click-stop-propagation.directive';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import { GenericDialogComponent } from '../generic-dialog/generic-dialog.component';
import { USER_NAME_FILTER } from '../../models/user.model';
import { LoadingComponent } from '../loading/loading.component';

interface SiglumsList {
  id: number;
  name: string;
  checked: boolean;
  disabled?: boolean;
}

export enum SiglumCategory {
  PENDING = 'pendingList',
  APPROVED = 'approvedList',
  REJECTED = 'rejectedList',
}

const COMMENT_CONFIG: MatDialogConfig = {
  panelClass: 'no-border-radius-dialog',
  width: '500px',
  height: '285px',
  maxWidth: '100vw',
  maxHeight: '100vh',
};

@Component({
  selector: 'optim-siglum-selection',
  imports: [
    MatListModule,
    LoadingComponent,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    ClickStopPropagationDirective,
  ],
  templateUrl: './siglum-selection.component.html',
  styleUrl: './siglum-selection.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SiglumSelectionComponent implements OnInit {
  private worksyncService: WorksyncService = inject(WorksyncService);
  private authService: AuthService = inject(AuthService);

  readonly dialog = inject(MatDialog);
  commentDialog: MatDialogRef<GenericDialogComponent, unknown> | undefined;

  readonly commentTemplate = viewChild.required<TemplateRef<unknown>>('commentTemplate');

  protected readonly siglumLists: Signal<WorkloadAvailableSiglumLists | null> = this.worksyncService.siglumValidationLists;

  isSubmit = input<boolean>(false);

  validationCompleted = output<WorkloadPostResponse>();
  submitCompleted = output<SubmitRequestResult[]>();

  SiglumCategory = SiglumCategory;

  private siglumIdIndex = 0;

  hasChanges = signal<boolean>(false);

  commentContent: string | null = null;

  private fb: FormBuilder = inject(FormBuilder);

  form = signal<FormGroup | null>(null);

  private initialPendingList: string[] = [];
  private initialApprovedList: string[] = [];
  private initialRejectedList: string[] = [];

  private userSelected: string | undefined;

  isLoading = signal<boolean>(false);

  async ngOnInit() {
    this.userSelected = this.authService.getUserNameFilter();
    if (this.isSubmit()) {
      await this.worksyncService.getWorkloadSiglumsToSubmit([this.userSelected!]);
    } else {
      await this.worksyncService.getWorkloadSiglumsToValidate([this.userSelected!]);
    }
    this.initializeForm();
  }

  getSiglums(category: SiglumCategory): SiglumsList[] {
    return this.form()!.get(category)?.value || [];
  }

  private initializeForm(): void {
    this.siglumIdIndex = 0;
    if (this.isSubmit()) {
      const rejectedList = this.siglumLists()?.rejectedList || [];
      const pendingList = this.siglumLists()?.pendingList || [];
      this.initialPendingList = [...rejectedList, ...pendingList];
      this.initialApprovedList = this.siglumLists()?.approvedList || [];
      this.initialRejectedList = [];
    } else {
      this.initialPendingList = this.siglumLists()?.pendingList || [];
      this.initialApprovedList = this.siglumLists()?.approvedList || [];
      this.initialRejectedList = this.siglumLists()?.rejectedList || [];
    }
    const form: FormGroup = this.fb.group({
      [SiglumCategory.PENDING]: [this.getSiglumCategoryList(this.initialPendingList)],
      [SiglumCategory.APPROVED]: [this.getSiglumCategoryList(this.initialApprovedList, true)],
      [SiglumCategory.REJECTED]: [this.getSiglumCategoryList(this.initialRejectedList, true)],
    });

    this.form.set(form);
  }

  private getSiglumCategoryList(siglumNames: string[], disabled = false): SiglumsList[] {
    return siglumNames.map((name) => ({
      id: this.siglumIdIndex++,
      name,
      checked: false,
      disabled,
    }));
  }

  addToApproved(): void {
    this.moveItems(SiglumCategory.PENDING, SiglumCategory.APPROVED);
  }

  removeFromApproved(): void {
    this.moveItems(SiglumCategory.APPROVED, SiglumCategory.PENDING);
  }

  addToRejected(): void {
    this.moveItems(SiglumCategory.PENDING, SiglumCategory.REJECTED);
  }

  removeFromRejected(): void {
    this.moveItems(SiglumCategory.REJECTED, SiglumCategory.PENDING);
  }

  onSelectionChange(event: MatSelectionListChange, category: SiglumCategory): void {
    const siglums = this.getSiglums(category);
    const selectedValues = new Set(event.source.selectedOptions.selected.map((option) => option.value));
    siglums.forEach((siglum) => (siglum.checked = selectedValues.has(siglum.id)));
    this.form()!.get(category)?.setValue(siglums);
  }

  private moveItems(fromList: SiglumCategory, toList: SiglumCategory): void {
    const fromSiglums = this.getSiglums(fromList);
    const toSiglums = this.getSiglums(toList);

    const itemsToMove = fromSiglums.filter((siglum) => siglum.checked);
    const remainingItems = fromSiglums.filter((siglum) => !siglum.checked);

    itemsToMove.forEach((siglum) => (siglum.checked = false));

    this.form()!.get(fromList)?.setValue(remainingItems);
    this.form()!
      .get(toList)
      ?.setValue([...toSiglums, ...itemsToMove]);
    this.checkChanges();
  }

  private checkChanges(): void {
    const pendingSiglums = this.getSiglums(SiglumCategory.PENDING).map((siglum) => siglum.name);
    const approvedSiglums = this.getSiglums(SiglumCategory.APPROVED).map((siglum) => siglum.name);

    this.hasChanges.set(!this.arraysEqual(pendingSiglums, this.initialPendingList) || !this.arraysEqual(approvedSiglums, this.initialApprovedList));
  }

  private arraysEqual(a: string[], b: string[]): boolean {
    return a.length === b.length && a.every((value, index) => value === b[index]);
  }

  async confirm() {
    this.isLoading.set(true);
    try {
      if (this.isSubmit()) {
        await this.submitSiglums();
      } else {
        await this.validateSiglums();
      }
    } finally {
      this.isLoading.set(false);
    }
  }

  async submitSiglums() {
    const approvedSiglums = this.getApprovedSiglums();
    const requests = this.createRequests(approvedSiglums);

    try {
      const results = await Promise.allSettled(requests);
      const processedResults = this.processResults(results);
      this.submitCompleted.emit(processedResults);
    } catch (error) {
      this.handleOverallError(error, approvedSiglums);
    }
  }

  private getApprovedSiglums(): string[] {
    return this.getSiglums(SiglumCategory.APPROVED)
      .filter((siglum) => !siglum.disabled)
      .map((siglum) => siglum.name);
  }

  private createRequests(siglums: string[]): Promise<SubmitRequestResult>[] {
    return siglums.map((siglum) => this.processSingleRequest(siglum));
  }

  private async processSingleRequest(siglum: string): Promise<SubmitRequestResult> {
    const submitData: WorkloadSubmitSiglumLists = {
      approvedList: [siglum],
    };
    const userForSiglum = this.determineUserForSiglum(siglum);
    const userParam = `${USER_NAME_FILTER}=${userForSiglum}`;

    try {
      const response = await this.worksyncService.postWorkloadSiglumsToSubmit(submitData, [userParam]);

      return {
        siglum,
        user: userForSiglum,
        error: response.error,
        message: response.message,
      };
    } catch (error) {
      return {
        siglum,
        user: userForSiglum,
        error: true,
        message: (error as Error)?.message || 'An error occurred',
      };
    }
  }

  private processResults(results: PromiseSettledResult<SubmitRequestResult>[]): SubmitRequestResult[] {
    return results.filter((result): result is PromiseFulfilledResult<SubmitRequestResult> => result.status === 'fulfilled').map((result) => result.value);
  }

  private handleOverallError(error: unknown, siglums: string[]): void {
    const errorResults: SubmitRequestResult[] = siglums.map((siglum) => ({
      siglum,
      user: this.determineUserForSiglum(siglum),
      error: true,
      message: 'Failed to process requests: ' + ((error as Error)?.message || 'Unknown error'),
    }));

    this.submitCompleted.emit(errorResults);
  }

  private determineUserForSiglum(siglum: string): string {
    const userName = `HO.${siglum.split(' ')[0]}`;
    return userName;
  }

  async validateSiglums() {
    const validateData: WorkloadValidationSiglumLists = {
      approvedList: this.getApprovedSiglums(),
      rejectedList: this.getSiglums(SiglumCategory.REJECTED)
        .filter((siglum) => !siglum.disabled)
        .map((siglum) => siglum.name),
    };
    const response: WorkloadPostResponse = await this.worksyncService.postWorkloadSiglumsToValidate(validateData, [this.userSelected!]);
    this.validationCompleted.emit(response);
  }

  viewComment(siglumName: string): void {
    this.commentContent = 'Comment for siglum';
    this.commentDialog = this.dialog.open(GenericDialogComponent, {
      ...COMMENT_CONFIG,
      data: {
        title: `Comments for ${siglumName}`,
        content: this.commentTemplate(),
      },
    });
  }
}
