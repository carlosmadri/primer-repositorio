import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportSelectionComponent } from './report-selection.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { AuthService } from '@src/app/services/auth/auth.service';
import { FiltersService } from '@services/filters/filters.service';
import { ReportService } from '@src/app/services/reports/report.service';
import { AuthTestingService } from '@src/app/services/auth/auth-testing.service';

describe('ReportSelectionComponent', () => {
  let component: ReportSelectionComponent;
  let fixture: ComponentFixture<ReportSelectionComponent>;
  let mockFiltersService: Partial<FiltersService>;
  let mockReportService: Partial<ReportService>;

  beforeEach(async () => {
    mockFiltersService = {
      getYearParams: jest.fn().mockReturnValue(''),
    };
    mockReportService = {
      generateReport: jest.fn(),
    };
    await TestBed.configureTestingModule({
      imports: [ReportSelectionComponent, NoopAnimationsModule],
      providers: [
        { provide: AuthService, useValue: AuthTestingService },
        { provide: FiltersService, useValue: mockFiltersService },
        { provide: ReportService, useValue: mockReportService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(ReportSelectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
