import { AfterViewInit, ChangeDetectionStrategy, Component, effect, inject, signal, viewChildren } from '@angular/core';
import { Location } from '@angular/common';
import { MatNestedTreeNode, MatTreeModule, MatTreeNestedDataSource } from '@angular/material/tree';
import { RouterLinkActive, RouterLinkWithHref } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { NestedTreeControl } from '@angular/cdk/tree';
import { AccessRuleService } from '@src/app/services/access-rule/access-rule.service';

interface RoutesNode {
  name: string;
  url: string;
  children?: RoutesNode[];
  isRoot?: boolean;
}

export const WORKOUT_TREE_DATA: RoutesNode = {
  name: 'Workout',
  url: '/workout',
  children: [
    {
      name: 'Manage Team',
      url: '/workout/manage-team',
    },
    {
      name: 'Manage Job Requisition',
      url: '/workout/manage-job-requisitions',
    },
  ],
};

export const WORKSYNC_TREE_DATA: RoutesNode = {
  name: 'Worksync',
  url: '/worksync',
  children: [
    {
      name: 'Manage Workload',
      url: '/worksync/manage-workload',
    },
  ],
};

export const SUBCONTRACTING_TREE_DATA: RoutesNode = {
  name: 'Subcontracting',
  url: '/subcontracting',
  isRoot: true,
};

@Component({
  selector: 'optim-sidenav',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLinkWithHref, MatTreeModule, MatButtonModule, MatIconModule, RouterLinkActive],
  templateUrl: './sidenav.component.html',
  styleUrl: './sidenav.component.scss',
  animations: [
    trigger('slideVertical', [
      state(
        '*',
        style({
          height: 0,
        }),
      ),
      state(
        'show',
        style({
          height: '*',
        }),
      ),
      transition('* => *', [animate('400ms cubic-bezier(0.25, 0.8, 0.25, 1)')]),
    ]),
  ],
})
export class SidenavComponent implements AfterViewInit {
  accessRuleService = inject(AccessRuleService);
  canSeeWorkoutPages = this.accessRuleService.canSeeWorkoutPages;
  canSeeManageWorkloadPage = this.accessRuleService.canSeeManageWorkloadPage;
  readonly treeNodes = viewChildren('treeNodes', { read: MatNestedTreeNode });
  menuOptions = signal<RoutesNode[]>([]);
  treeControl = new NestedTreeControl<RoutesNode>((node) => node.children);
  dataSource = new MatTreeNestedDataSource<RoutesNode>();

  hasChild = (_: number, node: RoutesNode) => !!node.children && node.children.length > 0;

  location: Location = inject(Location);

  constructor() {
    effect(() => {
      const menuOptions: RoutesNode[] = [];
      if (this.canSeeWorkoutPages()) {
        menuOptions.push(WORKOUT_TREE_DATA);
      }
      if (this.canSeeManageWorkloadPage()) {
        menuOptions.push(WORKSYNC_TREE_DATA);
      } else {
        const WorksyncWithoutManageWorkload = {
          name: WORKSYNC_TREE_DATA.name,
          url: WORKSYNC_TREE_DATA.url,
          isRoot: true,
        };
        menuOptions.push(WorksyncWithoutManageWorkload);
      }
      menuOptions.push(SUBCONTRACTING_TREE_DATA);

      this.dataSource.data = menuOptions;
      this.menuOptions.set(menuOptions);
    });
  }

  ngAfterViewInit() {
    this.treeControl.dataNodes = this.dataSource.data;
    this.checkInitUrl();
  }

  private checkInitUrl() {
    const currentUrl = this.location.path();
    if (currentUrl && this.treeNodes().length > 0) {
      this.expandNodeByUrl(currentUrl);
    }
  }

  private expandNodeByUrl(url: string) {
    const nodeToExpand = this.findNodeByUrl(this.dataSource.data, url);
    if (nodeToExpand) {
      this.expandNode(nodeToExpand);
    }
  }

  private findNodeByUrl(nodes: RoutesNode[], targetUrl: string): RoutesNode | undefined {
    return nodes.find((node: RoutesNode) => {
      if (node.url === targetUrl) {
        return true;
      } else {
        const activeChildren = node.children?.find((children) => children.url === targetUrl);
        return activeChildren;
      }
    });
  }

  private expandNode(nodeToExpand: RoutesNode) {
    const expNode = this.treeControl.dataNodes.find((node) => node.name === nodeToExpand.name);
    if (expNode) {
      this.treeControl.expand(expNode);
    }
  }
}
