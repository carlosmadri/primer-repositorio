import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SidenavComponent, SUBCONTRACTING_TREE_DATA, WORKOUT_TREE_DATA, WORKSYNC_TREE_DATA } from './sidenav.component';
import { RouterModule } from '@angular/router';
import { Location } from '@angular/common';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { AccessRuleService } from '@src/app/services/access-rule/access-rule.service';
import { signal } from '@angular/core';

describe('SidenavComponent', () => {
  let component: SidenavComponent;
  let fixture: ComponentFixture<SidenavComponent>;
  let mockAccessRuleService: Partial<AccessRuleService>;
  const mockCanSeeWorkoutPages = signal<boolean>(true);
  const mockCanSeeManageWorkloadPage = signal<boolean>(true);

  const locationMock: Partial<Location> = {
    path: jest.fn(),
  };

  beforeEach(async () => {
    mockAccessRuleService = {
      isAdmin: signal<boolean>(true),
      canSeeWorkoutPages: mockCanSeeWorkoutPages,
      canSeeManageWorkloadPage: mockCanSeeManageWorkloadPage,
    };

    await TestBed.configureTestingModule({
      imports: [SidenavComponent, RouterModule.forRoot([]), NoopAnimationsModule],
      providers: [
        { provide: Location, useValue: locationMock },
        { provide: AccessRuleService, useValue: mockAccessRuleService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(SidenavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    jest.clearAllMocks();
    mockCanSeeWorkoutPages.set(true);
    mockCanSeeManageWorkloadPage.set(true);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should expand the current node  after reload', () => {
    jest.spyOn(locationMock, 'path').mockImplementationOnce(() => component.dataSource.data[0].url);

    expect(component.treeNodes()[0].isExpanded).toBeFalsy();

    component.ngAfterViewInit();

    expect(component.treeNodes()[0].isExpanded).toBeTruthy();
  });

  it('should expand the parent node of the active child route after reload', () => {
    jest.spyOn(locationMock, 'path').mockImplementationOnce(() => component.dataSource.data[0].children![0].url);

    expect(component.treeNodes()[0].isExpanded).toBeFalsy();

    component.ngAfterViewInit();

    expect(component.treeNodes()[0].isExpanded).toBeTruthy();
  });

  it('should not expand the parent node of non active child route after reload', () => {
    jest.spyOn(locationMock, 'path').mockImplementationOnce(() => component.dataSource.data[1].children![0].url);

    expect(component.treeNodes()[0].isExpanded).toBeFalsy();

    component.ngAfterViewInit();

    expect(component.treeNodes()[0].isExpanded).toBeFalsy();
  });

  describe('menuOptions', () => {
    it('should set all the menu options if the user canSeeWorkoutPages', () => {
      const menuOptions = component.menuOptions();

      expect(menuOptions).toEqual([WORKOUT_TREE_DATA, WORKSYNC_TREE_DATA, SUBCONTRACTING_TREE_DATA]);
    });

    it('should not display the Workout pages in the menu options if the user do not have permission', () => {
      mockCanSeeWorkoutPages.set(false);

      fixture.detectChanges();
      const menuOptions = component.menuOptions();

      expect(menuOptions).toEqual([WORKSYNC_TREE_DATA, SUBCONTRACTING_TREE_DATA]);
    });

    it('should not display the Manage Workload page in the menu options if the user do not have permission', () => {
      const WorksyncWithoutManageWorkload = {
        name: WORKSYNC_TREE_DATA.name,
        url: WORKSYNC_TREE_DATA.url,
        isRoot: true,
      };
      mockCanSeeManageWorkloadPage.set(false);

      fixture.detectChanges();
      const menuOptions = component.menuOptions();

      expect(menuOptions).toEqual([WORKOUT_TREE_DATA, WorksyncWithoutManageWorkload, SUBCONTRACTING_TREE_DATA]);
    });
  });
});
