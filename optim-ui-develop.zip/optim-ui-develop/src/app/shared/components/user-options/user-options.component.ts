import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { AuthService } from '@src/app/services/auth/auth.service';
import { SnackbarService } from '@src/app/services/snackbar/snackbar.service';

@Component({
  selector: 'optim-user-options',
  imports: [MatButtonModule, MatIconModule, MatMenuModule],
  templateUrl: './user-options.component.html',
  styleUrl: './user-options.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserOptionsComponent {
  authService = inject(AuthService);

  user = this.authService.user;
  snackbar: SnackbarService = inject(SnackbarService);

  logout(): void {
    this.authService.logout();
    this.snackbar.showInfo('You have been logged out successfully.');
  }
}
