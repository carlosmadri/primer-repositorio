import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GeneralFilterComponent } from './general-filter.component';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { IAuthService } from '@src/app/services/auth/auth.service.interface';
import { AuthService } from '@src/app/services/auth/auth.service';
import { signal } from '@angular/core';

describe('GeneralFilterComponent', () => {
  let component: GeneralFilterComponent;
  let fixture: ComponentFixture<GeneralFilterComponent>;
  let mockAuthService: Partial<IAuthService>;

  beforeEach(async () => {
    mockAuthService = {
      getUserNameFilter: jest.fn().mockReturnValue(''),
      user: signal(null),
    };
    await TestBed.configureTestingModule({
      imports: [GeneralFilterComponent, NoopAnimationsModule],
      providers: [provideHttpClient(withInterceptorsFromDi()), provideHttpClientTesting(), { provide: AuthService, useValue: mockAuthService }],
    }).compileComponents();

    fixture = TestBed.createComponent(GeneralFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
