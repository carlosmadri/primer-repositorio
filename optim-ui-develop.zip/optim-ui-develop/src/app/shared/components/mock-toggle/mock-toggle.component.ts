import { Component } from '@angular/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MockStateService } from '@src/app/services/mock-api/mock-state.service';

@Component({
  selector: 'optim-mock-toggle',
  imports: [MatSlideToggleModule],
  template: `
    <div class="mock-toggle">
      <mat-slide-toggle [checked]="mockStateService.currentState" (change)="mockStateService.toggleMockState($event.checked)"> Demo Data </mat-slide-toggle>
    </div>
  `,
  styles: [
    `
      .mock-toggle {
        padding: 1rem;
        margin-right: 20px;
      }
    `,
  ],
})
export class MockToggleComponent {
  constructor(public mockStateService: MockStateService) {}
}
