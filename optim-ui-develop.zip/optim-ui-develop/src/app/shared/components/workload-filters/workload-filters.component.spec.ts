import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkloadFiltersComponent } from './workload-filters.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { AuthService } from '@src/app/services/auth/auth.service';
import { AuthTestingService } from '@src/app/services/auth/auth-testing.service';

describe('WorkloadFiltersComponent', () => {
  let component: WorkloadFiltersComponent;
  let fixture: ComponentFixture<WorkloadFiltersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WorkloadFiltersComponent, NoopAnimationsModule],
      providers: [provideHttpClient(withInterceptorsFromDi()), provideHttpClientTesting(), { provide: AuthService, useValue: AuthTestingService }],
    }).compileComponents();

    fixture = TestBed.createComponent(WorkloadFiltersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
