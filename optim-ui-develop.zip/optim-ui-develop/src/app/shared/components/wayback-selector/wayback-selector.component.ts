import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { FiltersService } from '@src/app/services/filters/filters.service';

@Component({
  selector: 'optim-wayback-selector',
  imports: [MatDatepickerModule, MatFormFieldModule, MatButtonModule, MatIconModule, MatInputModule, CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './wayback-selector.component.html',
  styleUrl: './wayback-selector.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WaybackSelectorComponent {
  private filtersService: FiltersService = inject(FiltersService);

  waybackDate = signal<Date | undefined>(undefined);

  readonly today = new Date();

  formatDateValue() {
    const waybackDate = this.waybackDate() ? this.waybackDate()!.toISOString().split('T')[0] : '';

    this.filtersService.setWaybackFilter(waybackDate);
  }

  clearDate() {
    this.waybackDate.set(undefined);
    this.formatDateValue();
  }
}
