import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WaybackSelectorComponent } from './wayback-selector.component';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { signal } from '@angular/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';
import { provideNoopAnimations } from '@angular/platform-browser/animations';

describe('WaybackSelectorComponent', () => {
  let component: WaybackSelectorComponent;
  let fixture: ComponentFixture<WaybackSelectorComponent>;
  let mockFiltersService: Partial<FiltersService>;
  const mockWaybackFilter = signal<string | undefined>(undefined);

  beforeEach(async () => {
    mockFiltersService = {
      waybackFilter: mockWaybackFilter.asReadonly(),
      setWaybackFilter: jest.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [WaybackSelectorComponent, MatDatepickerModule],
      providers: [{ provide: FiltersService, useValue: mockFiltersService }, provideNativeDateAdapter(), provideNoopAnimations()],
    }).compileComponents();

    fixture = TestBed.createComponent(WaybackSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
