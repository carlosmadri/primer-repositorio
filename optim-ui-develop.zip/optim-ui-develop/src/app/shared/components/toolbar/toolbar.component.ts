import { ChangeDetectionStrategy, Component, inject, OnInit, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDialogModule } from '@angular/material/dialog';
import { Event, NavigationStart, Router } from '@angular/router';
import { MatExpansionModule } from '@angular/material/expansion';
import { GeneralFilterComponent } from '@components/general-filter/general-filter.component';
import { FilterYearComponent } from '@components/filter-year/filter-year.component';
import { NgClass } from '@angular/common';
import { ClickStopPropagationDirective } from '@app/shared/directives/click-stop-propagation/click-stop-propagation.directive';
import { MatOption, MatSelect } from '@angular/material/select';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '@services/auth/auth.service';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';
import { ReportSelectionComponent } from '@components/report-selection/report-selection.component';
import { MockToggleComponent } from '../mock-toggle/mock-toggle.component';
import { WaybackSelectorComponent } from '../wayback-selector/wayback-selector.component';
import { UserOptionsComponent } from '../user-options/user-options.component';

@Component({
  selector: 'optim-toolbar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatExpansionModule,
    GeneralFilterComponent,
    FilterYearComponent,
    NgClass,
    ClickStopPropagationDirective,
    MatSelect,
    ReactiveFormsModule,
    MatOption,
    MatDialogModule,
    ReportSelectionComponent,
    WaybackSelectorComponent,
    MockToggleComponent,
    UserOptionsComponent,
  ],
  templateUrl: './toolbar.component.html',
  styleUrl: './toolbar.component.scss',
})
export class ToolbarComponent implements OnInit {
  worksyncService = inject(WorksyncService);
  router: Router = inject(Router);
  notHome = signal(false);
  readonly panelOpenState = signal(false);
  activeFilters = false;

  authService = inject(AuthService);

  USER_NAMES_TESTING = [
    'admin',
    'hrBoss.superboss',
    'hr.colleague',
    'finance.colleague1',
    'qmc.member.T1QA',
    'HO.T1QAA',
    'HO.T1QAC',
    'WL.Delegate',
    'HO T1Q',
    'HO.T1QAA1',
    'HO.T1QAS',
    'HO.T1QAS11',
    'HO.T1QAS1',
    'HO.T1QAS2',
    'HO.T1QAS21',
    'HO.T1QAS22',
    'HO.T1QAS3',
    'HO.T1QAE',
    'HO.T1QAE1',
    'HO.T1QAE2',
    'HO.T1QAE2-TL1',
    'HR.Colleague',
    'Finance.Colleague',
    'WL.Delegate',
  ];
  userControl = new FormControl<string | undefined>(undefined);

  ngOnInit(): void {
    this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationStart) {
        this.notHome.set(event.url !== '/');
      }
    });

    this.loadUser();
  }

  loadUser() {
    const userName = this.authService.user()?.userName;
    if (userName) {
      this.userControl.setValue(userName);
    }

    this.userControl.valueChanges.subscribe((value) => {
      this.authService.setLoginUserName(value!);
      this.authService.initLogin();
    });
  }

  toggleActiveFilters(event: boolean) {
    this.activeFilters = event;
  }

  closeFiltersPanel(close: boolean) {
    if (this.panelOpenState()) {
      this.panelOpenState.set(!close);
    }
  }

  openHelpPage(): void {
    this.router.navigate(['/help']);
  }
}
