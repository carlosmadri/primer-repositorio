import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ToolbarComponent } from './toolbar.component';
import { RouterModule } from '@angular/router';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { WaybackSelectorComponent } from '../wayback-selector/wayback-selector.component';
import { MockWaybackSelectorComponent } from '@src/app/mocks/components/wayback-selector-mock.component';
import { IAuthService } from '@src/app/services/auth/auth.service.interface';
import { signal } from '@angular/core';
import { AuthService } from '@src/app/services/auth/auth.service';

describe('ToolbarComponent', () => {
  let component: ToolbarComponent;
  let fixture: ComponentFixture<ToolbarComponent>;
  let authServiceMock: Partial<IAuthService>;

  beforeEach(async () => {
    authServiceMock = {
      user: signal(null),
      logout: jest.fn(),
      initLogin: jest.fn(),
    };
    TestBed.overrideComponent(ToolbarComponent, {
      remove: {
        imports: [WaybackSelectorComponent],
      },
      add: {
        imports: [MockWaybackSelectorComponent],
      },
    });
    await TestBed.configureTestingModule({
      imports: [ToolbarComponent, MockWaybackSelectorComponent, RouterModule.forRoot([]), NoopAnimationsModule],
      providers: [provideHttpClient(withInterceptorsFromDi()), provideHttpClientTesting(), { provide: AuthService, useValue: authServiceMock }],
    }).compileComponents();

    fixture = TestBed.createComponent(ToolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
