import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubcontractingFiltersComponent } from './subcontracting-filters.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { AuthService } from '@src/app/services/auth/auth.service';
import { AuthTestingService } from '@src/app/services/auth/auth-testing.service';

describe('SubcontractingFiltersComponent', () => {
  let component: SubcontractingFiltersComponent;
  let fixture: ComponentFixture<SubcontractingFiltersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SubcontractingFiltersComponent, NoopAnimationsModule],
      providers: [provideHttpClient(withInterceptorsFromDi()), provideHttpClientTesting(), { provide: AuthService, useValue: AuthTestingService }],
    }).compileComponents();

    fixture = TestBed.createComponent(SubcontractingFiltersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
