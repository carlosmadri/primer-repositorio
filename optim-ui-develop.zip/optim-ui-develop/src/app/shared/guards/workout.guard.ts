import { Injectable, inject } from '@angular/core';
import { CanActivate } from '@angular/router';
import { AccessRuleService } from '@src/app/services/access-rule/access-rule.service';
import { BaseGuard } from './base.guard';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class WorkoutGuard extends BaseGuard implements CanActivate {
  private accessRuleService = inject(AccessRuleService);

  async canActivate(): Promise<boolean> {
    await firstValueFrom(this.authCompleted$);
    if (this.accessRuleService.canSeeWorkoutPages()) {
      return true;
    }

    return false;
  }
}
