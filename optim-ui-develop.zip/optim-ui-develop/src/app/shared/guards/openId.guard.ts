import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { BaseGuard } from './base.guard';

@Injectable({
  providedIn: 'root',
})
export class OpenIdGuard extends BaseGuard implements CanActivate {
  async canActivate(): Promise<boolean> {
    // Wait until the authorization process is completed
    await firstValueFrom(this.authCompleted$);

    // Check if the user is authorized
    if (this.authService.isAuth() && this.authService.getUserDataFromToken()?.JWT) {
      return true;
    } else {
      this.authService.checkAuthState();
      return false;
    }
  }
}
