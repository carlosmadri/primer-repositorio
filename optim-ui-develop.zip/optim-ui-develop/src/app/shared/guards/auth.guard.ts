import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { BaseGuard } from './base.guard';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard extends BaseGuard implements CanActivate {
  async canActivate(): Promise<boolean> {
    // Wait until the authorization process is completed
    await firstValueFrom(this.authCompleted$);
    if (this.authService.isAuth()) {
      return true;
    }

    return false;
  }
}
