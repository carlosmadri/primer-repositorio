import { inject } from '@angular/core';
import { toObservable } from '@angular/core/rxjs-interop';
import { filter } from 'rxjs/operators';
import { AuthService } from '@app/services/auth/auth.service';
import { Observable } from 'rxjs';

export class BaseGuard {
  protected authService: AuthService = inject(AuthService);
  protected authCompleted$: Observable<boolean>;

  constructor() {
    this.authCompleted$ = toObservable(this.authService.isAuthorizing).pipe(filter((isAuthorizing) => !isAuthorizing));
  }
}
