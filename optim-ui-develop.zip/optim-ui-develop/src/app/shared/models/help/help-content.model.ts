export interface HelpContent {
  title: string;
  description: string;
  reasons?: string[];
  types?: string[];
  scenarios?: string[];
}
