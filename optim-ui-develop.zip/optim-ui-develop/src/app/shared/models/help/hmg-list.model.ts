export interface HgmList {
  title: string;
  definitions: [
    {
      name: string;
      definition: string;
    },
  ];
}
