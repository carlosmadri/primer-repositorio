import { ChartColors, ChartIds, ChartSelectorData } from './worksync.model';

export interface MonthlyDistributionAPI {
  optimisticView: number[];
  validationView: number[];
  realisticView: number[];
  wip?: number[];
  firstSubmission?: number[];
  fcii: number[];
  op: number[];
  hcCeiling: number;
  wipValue: 'WIP' | 'First Submission' | 'QMC' | 'HOT1Q' | '';
}

export const MONTHLY_CHART_DATA: ChartSelectorData[] = [
  { label: 'HC Ceiling', isAvg: false, name: ChartIds.HC_CEILING, color: ChartColors.HC_CEILING },
  { label: 'Optimistic', isAvg: false, name: ChartIds.OPTIMISTIC, color: ChartColors.OPTIMISTIC },
  { label: 'Avg Optimistic', isAvg: true, name: ChartIds.OPTIMISTIC, color: ChartColors.OPTIMISTIC },
  { label: 'Validation', isAvg: false, name: ChartIds.VALIDATION, color: ChartColors.VALIDATION },
  { label: 'Avg Validation', isAvg: true, name: ChartIds.VALIDATION, color: ChartColors.VALIDATION },
  { label: 'Realistic', isAvg: false, name: ChartIds.REALISTIC, color: ChartColors.REALISTIC },
  { label: 'Avg Realistic', isAvg: true, name: ChartIds.REALISTIC, color: ChartColors.REALISTIC },
  { label: 'OP', isAvg: false, name: ChartIds.OP, color: ChartColors.OP },
  { label: 'FCII', isAvg: false, name: ChartIds.FCII, color: ChartColors.FCII },
  { label: 'WIP', isAvg: false, name: ChartIds.WIP, color: ChartColors.WIP },
  { label: 'First Sub.', isAvg: false, name: ChartIds.FIRST_SUBMISSION, color: ChartColors.FIRST_SUBMISSION },
];
