import { Siglum } from '@models/siglum.model';
import { CostCenter } from '@models/cost-center.model';

export interface WorksyncOwnSub {
  own: number;
  sub: number;
}

export interface WorkloadPerProgramAPI {
  programName: string;
  programKHrsSum: number;
  programsCount: number;
}

export enum WorkloadEvolutionStatusAPI {
  APPROVED = 'APPROVED',
  OPENED = 'OPENED',
  SUBMIT = 'SUBMIT',
  REJECTED = 'REJECTED',
}

export interface WorkloadEvolutionListAPI {
  exercise: string;
  khrsOwnDirect: number;
  khrsOwnIndirect: number;
  khrsSubDirect: number;
  khrsSubIndirect: number;
}

export const VALIDATION_STATUS_SELECTOR = 'validationStatus';

export enum EvolutionValidationOptions {
  ALL = 'all',
  APPROVED = 'approved',
  REJECTED = 'rejected',
}

export interface WorkloadEvolutionAPI {
  workloadEvolutionList: WorkloadEvolutionListAPI[];
  lastStatus: WorkloadEvolutionStatusAPI | undefined;
  multipleSiglums: boolean;
  wipValue?: 'BU' | 'QMC' | 'HOT1Q' | 'First Submission' | '';
  validationStatusParam?: EvolutionValidationOptions;
}

export enum WorkloadEvolutionBarType {
  OP = 'OP',
  FCII = 'FCII',
  WIP = 'WIP',
  FIRST_SUBMISSION = 'First Submission',
  SUBMIT = 'SUBMIT',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  MULTIPLE = 'MULTIPLE',
}

export interface WorkloadEvolution {
  data: WorkloadEvolutionBarData[];
  multipleSiglums: boolean;
  submissionStatus: WorkloadSubmissionStatus;
  validationStatus: WorkloadValidationStatus | undefined;
  nextExerciseType: WorkloadEvolutionBarType.OP | WorkloadEvolutionBarType.FCII;
  nextExerciseNumber: number;
}
export interface WorkloadEvolutionBarData {
  exercise: string;
  id: ChartIds;
  barType: WorkloadEvolutionBarType;
  ownDirect: number;
  ownIndirect: number;
  subDirect: number;
  subIndirect: number;
  total: number;
}

export enum WorkloadSubmissionStatus {
  SUBMITTED = 'Submitted',
  NOT_SUBMITTED = 'Not Submitted',
  MULTIPLE = 'Multiple siglums',
}

export enum WorkloadValidationStatus {
  PENDING = 'Pending',
  VALIDATED = 'Validated',
  NOT_VALIDATED = 'Not Validated',
  CHALLENGED = 'Challenged',
  MULTIPLE = 'Multiple siglums',
}

export enum WorkloadExerciseStatus {
  OPENABLE = 'Openable',
  IN_PROGRESS = 'In Progress',
  CLOSEABLE = 'Closeable',
}

export interface WorkloadWorkforceAPI {
  exerciseOP: number;
  exerciseFCII: number;
  exerciseBU?: number;
  exerciseFirstSubmission?: number;
  exerciseQMC?: number;
  exerciseT1Q?: number;
  optimisticView: number;
  validationView: number;
  realisticView: number;
  hcCeiling: number;
  fciiFirst: boolean;
}

export interface WorkloadWorkforce {
  id: ChartIds;
  label: string;
  value: number;
  color: ChartColors;
}

export enum ChartColors {
  OP = '#5F5F5F',
  FCII = '#7F7F7F',
  WIP = '#d8a200',
  FIRST_SUBMISSION = '#9BB864',
  QMC = '#86B874',
  HOT1Q = '#6DC297',
  OPTIMISTIC = '#054E7C',
  VALIDATION = '#05779C',
  REALISTIC = '#069BB3',
  HC_CEILING = '#ffff00',
  REJECTED = '#D6490B',
  ACCEPTED = '#4CAF50',
  PENDING = '#DFA800',
}

export enum ChartIds {
  OP = 'op',
  FCII = 'fcII',
  WIP = 'WIP',
  FIRST_SUBMISSION = 'firstSubmission',
  QMC = 'QMC',
  HOT1Q = 'HOT1Q',
  OPTIMISTIC = 'optimistic',
  VALIDATION = 'validation',
  REALISTIC = 'realistic',
  HC_CEILING = 'hcCeiling',
}

export interface ChartSelectorData {
  label: string;
  isAvg: boolean;
  name: ChartIds;
  color: ChartColors;
}

export const CHART_SELECTORS_DATA: readonly Readonly<ChartSelectorData>[] = [
  { label: 'Realistic', isAvg: true, name: ChartIds.REALISTIC, color: ChartColors.REALISTIC },
  { label: 'Validation', isAvg: true, name: ChartIds.VALIDATION, color: ChartColors.VALIDATION },
  { label: 'Optimistic', isAvg: true, name: ChartIds.OPTIMISTIC, color: ChartColors.OPTIMISTIC },
  { label: 'OP', isAvg: false, name: ChartIds.OP, color: ChartColors.OP },
  { label: 'FCII', isAvg: false, name: ChartIds.FCII, color: ChartColors.FCII },
  { label: 'First Submission', isAvg: false, name: ChartIds.FIRST_SUBMISSION, color: ChartColors.FIRST_SUBMISSION },
  { label: 'QMC', isAvg: false, name: ChartIds.QMC, color: ChartColors.PENDING },
  { label: 'HOT1Q', isAvg: false, name: ChartIds.HOT1Q, color: ChartColors.PENDING },
  { label: 'WIP', isAvg: false, name: ChartIds.WIP, color: ChartColors.WIP },
  { label: 'HC Ceiling', isAvg: false, name: ChartIds.HC_CEILING, color: ChartColors.HC_CEILING },
];

export interface WorkloadPreview {
  exercise: string;
  previsionkHrs: number;
  previsionFte: number;
  vlActualsEoY: number;
  realisticViewAVG: number;
  fte: number;
  khrs: number;
  hcmaxCelling: number;
}

export interface WorkloadAvailableSiglumLists {
  pendingList: string[];
  approvedList: string[];
  rejectedList?: string[];
}

export interface WorkloadSubmitSiglumLists {
  approvedList: string[];
}

export interface WorkloadValidationSiglumLists extends WorkloadSubmitSiglumLists {
  rejectedList: string[];
}

export interface WorkloadPostResponse {
  error: boolean;
  message: string;
}

export interface SubmitRequestResult extends WorkloadPostResponse {
  siglum: string;
  user: string;
}

export const ownSubValues = ['OWN', 'SUB'];

export const coreNonCoreValues = ['Core', 'Non Core'];

export const collarValues = ['WC', 'BC'];

export const backlogOrderIntakeValues = ['Backlog', 'Order Intake'];

export interface Ppsid {
  id: number;
  ppsid: string;
  ppsidName: string;
  muCode: string;
  muText: string;
  businessLine: string;
  programLine: string;
  productionCenter: string;
  businessActivity: string;
  backlogOrderIntake: string;
  workload: string;
  scenario?: string;
}

export interface Workload {
  id: number;
  direct: string;
  collar: string;
  own: string;
  core: string;
  go: boolean;
  description: string;
  exercise: string;
  startDate: string;
  endDate: string;
  siglum: Siglum;
  costCenter: CostCenter;
  ppsid: Ppsid;
  fte: number;
  khrs: number;
  keur: number;
  eac: boolean;
  readonly?: boolean;
}

export interface WorkloadsApiResponse {
  content: Workload[];
  page: {
    number: number;
    size: number;
    totalElements: number;
    totalPages: number;
  };
}
