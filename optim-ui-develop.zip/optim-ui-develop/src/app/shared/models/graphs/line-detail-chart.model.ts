export interface LineDetailChartData {
  name: string;
  khours: number;
  programs: number;
  selected?: boolean;
}
