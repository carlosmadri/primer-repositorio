import { Siglum } from '@models/siglum.model';
import { DIRECT_INDIRECT_VALUES, Employee } from '@models/employee.model';
import { CostCenter } from '@models/cost-center.model';

export interface Lever {
  id: number;
  leverType: string;
  highlights: string;
  startDate: string;
  endDate: string;
  fte: number;
  siglumDestination: Siglum | null;
  siglumOrigin?: Siglum | null;
  activeWorkforce: string;
  direct: DIRECT_INDIRECT_VALUES;
  employee?: Employee;
  costCenter?: CostCenter;
}

export enum LEVER_TYPES {
  LONG_TERM_SICKNESS = 'Long-term sickness',
  PARENTAL_LEAVE = 'Parental leave',
  MOBILITY_OUT = 'Mobility Out',
  RETIREMENT = 'Retirement',
  PRE_RETIREMENT = 'Pre-Retirement',
  SHIFT_CHANGE = 'Shift Change',
  TEMP_RELEASE = 'Temp release',
  TEMP_RENOVATION = 'Temp renovation',
  OTHER_ABSENCE = 'Other absence',
  BORROWED = 'Borrowed',
  LEASED = 'Leased',
  PERIMETER_CHANGE = 'Perimeter Change',
  REDEPLOYMENT = 'Redeployment',
  INTERNAL_MOBILITY = 'Internal mobility',
}

export const personalLeverTypes = [
  LEVER_TYPES.LONG_TERM_SICKNESS,
  LEVER_TYPES.PARENTAL_LEAVE,
  LEVER_TYPES.MOBILITY_OUT,
  LEVER_TYPES.RETIREMENT,
  LEVER_TYPES.PRE_RETIREMENT,
  LEVER_TYPES.SHIFT_CHANGE,
  LEVER_TYPES.TEMP_RELEASE,
  LEVER_TYPES.TEMP_RENOVATION,
  LEVER_TYPES.OTHER_ABSENCE,
  LEVER_TYPES.BORROWED,
  LEVER_TYPES.LEASED,
  LEVER_TYPES.INTERNAL_MOBILITY,
];

export const impersonalLeverTypes = [LEVER_TYPES.PERIMETER_CHANGE, LEVER_TYPES.REDEPLOYMENT];

export const FILTERS_WITH_LEVERS_PARAM = 'hasLevers=true';
