import { Injectable } from '@angular/core';
import { MONTHLY_CHART_DATA, MonthlyDistributionAPI } from '../../models/monthly-distribution.model';
import { Adapter } from '../adapter.interface';
import { ChartIds, ChartSelectorData } from '../../models/worksync.model';
import * as numberUtils from '@src/utils/number-utils';
import { MultiLineChartData, MONTHS_LIST } from '../../models/graphs/multiline-chart.model';

@Injectable({
  providedIn: 'root',
})
export class MonthlyDistributionAdapter implements Adapter<MonthlyDistributionAPI, MultiLineChartData> {
  adapt(data: MonthlyDistributionAPI): MultiLineChartData | null {
    if (!data) {
      return null;
    }

    const hasFirstSubmission = data.firstSubmission != null;
    const hasWIP = data.wip != null;

    const monthlyData: ChartSelectorData[] = this.getMonthlyChartWithData(MONTHLY_CHART_DATA, hasFirstSubmission, hasWIP);
    const monthlyLabels: string[] = this.getMonthlyLabels(data);
    const monthlyLineIds: ChartIds[] = this.getMonthlyLineIds(data);
    const monthlyValues: number[][] = this.getMonthlyValues(data);

    const chartData: MultiLineChartData = {
      month: [...MONTHS_LIST, 'EoY'],
      labels: monthlyLabels,
      ids: monthlyLineIds,
      colors: monthlyData.map((data) => data.color),
      values: monthlyValues,
      isAvg: monthlyData.map((data) => data.isAvg),
    };
    return chartData;
  }

  private getMonthlyChartWithData(data: ChartSelectorData[], hasFirstSubmission: boolean, hasWIP: boolean) {
    const chartData: ChartSelectorData[] = data.filter((data) => {
      if (data.name === ChartIds.WIP) {
        return hasWIP;
      }
      if (data.name === ChartIds.FIRST_SUBMISSION) {
        return hasFirstSubmission;
      }
      return true;
    });
    return chartData;
  }

  private getMonthlyLabels(data: MonthlyDistributionAPI): string[] {
    const labels: string[] = MONTHLY_CHART_DATA.filter((data) => data.name !== ChartIds.WIP && data.name !== ChartIds.FIRST_SUBMISSION).map(
      (data) => data.label,
    );
    if (data.wip != null) {
      labels.push(data.wipValue || 'WIP');
    }
    if (data.firstSubmission != null) {
      labels.push('First Sub.');
    }
    return labels;
  }

  private getMonthlyValues(data: MonthlyDistributionAPI): number[][] {
    const hcCeiling = Array(13).fill(numberUtils.roundToDecimalPlaces(data.hcCeiling, 1));
    const optimisticView = numberUtils.roundArrayToDecimalPlaces(data.optimisticView, 1);
    const optimisticViewAvg = numberUtils.fillArrayWithRoundToDecimalAvg(data.optimisticView);
    const validationView = numberUtils.roundArrayToDecimalPlaces(data.validationView, 1);
    const validationViewAvg = numberUtils.fillArrayWithRoundToDecimalAvg(data.validationView);
    const realisticView = numberUtils.roundArrayToDecimalPlaces(data.realisticView, 1);
    const realisticViewAvg = numberUtils.fillArrayWithRoundToDecimalAvg(data.realisticView);
    const op = numberUtils.roundArrayToDecimalPlaces(data.op, 1);
    const fcii = numberUtils.roundArrayToDecimalPlaces(data.fcii, 1);
    const values: number[][] = [hcCeiling, optimisticView, optimisticViewAvg, validationView, validationViewAvg, realisticView, realisticViewAvg, op, fcii];
    if (data.firstSubmission != undefined) {
      const firstSubmission = numberUtils.roundArrayToDecimalPlaces(data.firstSubmission, 1);
      values.push(firstSubmission);
    }
    if (data.wip != undefined) {
      const wip = numberUtils.roundArrayToDecimalPlaces(data.wip, 1);
      values.push(wip);
    }
    return values;
  }

  private getMonthlyLineIds(data: MonthlyDistributionAPI): ChartIds[] {
    const names: ChartIds[] = [
      ChartIds.HC_CEILING,
      ChartIds.OPTIMISTIC,
      ChartIds.OPTIMISTIC, //  AVG
      ChartIds.VALIDATION,
      ChartIds.VALIDATION, //  AVG
      ChartIds.REALISTIC,
      ChartIds.REALISTIC, //  AVG
      ChartIds.OP,
      ChartIds.FCII,
    ];
    if (data.wip != null) {
      if (!!data.wipValue && data.wipValue !== 'WIP') {
        const wipValueId = this.getWipValueId(data.wipValue);
        names.push(wipValueId);
      } else {
        names.push(ChartIds.WIP);
      }
    }
    if (data.firstSubmission != null) {
      names.push(ChartIds.FIRST_SUBMISSION);
    }
    return names;
  }

  private getWipValueId(wipValue: string): ChartIds {
    if (wipValue === 'First Submission') {
      return ChartIds.FIRST_SUBMISSION;
    } else if (wipValue === 'QMC') {
      return ChartIds.QMC;
    } else if (wipValue === 'HOT1Q') {
      return ChartIds.HOT1Q;
    } else {
      return ChartIds.WIP;
    }
  }
}
