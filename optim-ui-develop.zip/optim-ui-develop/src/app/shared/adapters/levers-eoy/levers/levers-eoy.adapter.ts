import { Injectable } from '@angular/core';
import { LeversTotal, LeversTotalAPI } from '@src/app/shared/models/levers-total.model';
import { Adapter } from '../../adapter.interface';
import * as numberUtils from '@src/utils/number-utils';

@Injectable({
  providedIn: 'root',
})
export class LeversEoyAdapter implements Adapter<LeversTotalAPI[], LeversTotal[]> {
  adapt(apiData: LeversTotalAPI[]): LeversTotal[] {
    return apiData.reduce((acc: LeversTotal[], item: LeversTotalAPI) => {
      if ((item.leaver !== 0 || item.recovery !== 0) && item.leverType !== 'Borrowed' && item.leverType !== 'Leased') {
        acc.push({
          leverType: item.leverType,
          leaver: numberUtils.roundToDecimalPlaces(item.leaver, 1),
          recovery: numberUtils.roundToDecimalPlaces(item.recovery, 1),
        });
      }

      return acc;
    }, []);
  }
}
