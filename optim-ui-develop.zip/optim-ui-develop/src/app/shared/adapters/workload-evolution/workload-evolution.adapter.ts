import { inject, Injectable } from '@angular/core';
import { Adapter } from '../adapter.interface';
import {
  ChartIds,
  EvolutionValidationOptions,
  WorkloadEvolution,
  WorkloadEvolutionAPI,
  WorkloadEvolutionBarData,
  WorkloadEvolutionBarType,
  WorkloadEvolutionListAPI,
  WorkloadEvolutionStatusAPI,
  WorkloadSubmissionStatus,
  WorkloadValidationStatus,
} from '../../models/worksync.model';
import * as numberUtils from '@src/utils/number-utils';
import { ChartSelectorService } from '@src/app/services/chart-selector/chart-selector.service';

export const REJECTED = 'rejected';
export const APPROVED = 'approved';
export const PENDING = 'pending';

@Injectable({
  providedIn: 'root',
})
export class WorkloadEvolutionAdapter implements Adapter<WorkloadEvolutionAPI, WorkloadEvolution | null> {
  chartSelectorService = inject(ChartSelectorService);

  OpPattern = /^OP\d+$/;
  FCPattern = /^FCII\d+$/;

  adapt(data: WorkloadEvolutionAPI | null): WorkloadEvolution | null {
    if (!data || !data.workloadEvolutionList || data.workloadEvolutionList.length === 0) {
      return null;
    }

    const chartData: WorkloadEvolutionBarData[] = data.workloadEvolutionList.map((item) => {
      const isLastStep = this.isLastStep(item.exercise, data.workloadEvolutionList);
      return {
        exercise: data.multipleSiglums ? this.setBUasWIP(item.exercise) : this.getExerciseName(item.exercise, data.lastStatus, isLastStep),
        id: this.getIdFromExerciseName(item.exercise),
        barType: data.multipleSiglums
          ? this.setMultipleBarType(data.lastStatus, item.exercise, data.validationStatusParam)
          : this.setIndividualBarType(data.lastStatus, item.exercise, isLastStep),
        ownDirect: numberUtils.roundToDecimalPlaces(item.khrsOwnDirect, 1),
        ownIndirect: numberUtils.roundToDecimalPlaces(item.khrsOwnIndirect, 1),
        subDirect: numberUtils.roundToDecimalPlaces(item.khrsSubDirect, 1),
        subIndirect: numberUtils.roundToDecimalPlaces(item.khrsSubIndirect, 1),
        total: numberUtils.roundToDecimalPlaces(item.khrsOwnDirect + item.khrsOwnIndirect + item.khrsSubDirect + item.khrsSubIndirect, 1),
      };
    });

    const submissionStatus = this.submissionStatus(data);
    const validationStatus = this.validationStatus(data);
    const nextExerciseType = this.nextExerciseType(chartData);
    const nextExerciseNumber = this.nextExerciseNumber(chartData);

    const evolutionData: WorkloadEvolution = {
      data: chartData,
      multipleSiglums: data.multipleSiglums,
      submissionStatus,
      validationStatus,
      nextExerciseType,
      nextExerciseNumber,
    };

    return evolutionData;
  }

  private setIndividualBarType(status: WorkloadEvolutionStatusAPI | undefined, exercise: string, isLastStep: boolean): WorkloadEvolutionBarType {
    if (this.isOpExercise(exercise)) {
      return WorkloadEvolutionBarType.OP;
    } else if (this.isFcExercise(exercise)) {
      return WorkloadEvolutionBarType.FCII;
    } else if (this.isWIPExercise(exercise)) {
      return WorkloadEvolutionBarType.WIP;
    } else if (!isLastStep) {
      return WorkloadEvolutionBarType.APPROVED;
    } else if (status === WorkloadEvolutionStatusAPI.REJECTED) {
      return WorkloadEvolutionBarType.REJECTED;
    } else if (status === WorkloadEvolutionStatusAPI.APPROVED) {
      return WorkloadEvolutionBarType.APPROVED;
    } else if (status === WorkloadEvolutionStatusAPI.OPENED) {
      return WorkloadEvolutionBarType.WIP;
    } else if (status === WorkloadEvolutionStatusAPI.SUBMIT) {
      return WorkloadEvolutionBarType.SUBMIT;
    } else {
      return WorkloadEvolutionBarType.WIP;
    }
  }

  private setMultipleBarType(
    status: WorkloadEvolutionStatusAPI | undefined,
    exercise: string,
    validationSelector?: EvolutionValidationOptions,
  ): WorkloadEvolutionBarType {
    if (validationSelector === EvolutionValidationOptions.APPROVED || validationSelector === EvolutionValidationOptions.REJECTED) {
      // Validation selector applied
      if (this.isOpExercise(exercise)) {
        return WorkloadEvolutionBarType.OP;
      } else if (this.isFcExercise(exercise)) {
        return WorkloadEvolutionBarType.FCII;
      }
      if (validationSelector === EvolutionValidationOptions.REJECTED) {
        return WorkloadEvolutionBarType.REJECTED;
      } else if (validationSelector === EvolutionValidationOptions.APPROVED) {
        return WorkloadEvolutionBarType.APPROVED;
      }
    }
    // View All
    return WorkloadEvolutionBarType.MULTIPLE;
  }

  private submissionStatus(data: WorkloadEvolutionAPI): WorkloadSubmissionStatus {
    if (data.multipleSiglums) {
      return WorkloadSubmissionStatus.MULTIPLE;
    }
    const hasFirstSubmission = data.workloadEvolutionList.some((value) => value.exercise === 'First Submission');
    if (hasFirstSubmission && data.lastStatus !== WorkloadEvolutionStatusAPI.REJECTED) {
      return WorkloadSubmissionStatus.SUBMITTED;
    }
    return WorkloadSubmissionStatus.NOT_SUBMITTED;
  }

  private validationStatus(data: WorkloadEvolutionAPI): WorkloadValidationStatus | undefined {
    if (data.multipleSiglums) {
      return WorkloadValidationStatus.MULTIPLE;
    }
    if (data.workloadEvolutionList.length === 2) {
      return WorkloadValidationStatus.NOT_VALIDATED;
    }
    const hasFirstSubmission = data.workloadEvolutionList.some((value) => value.exercise === 'First Submission');
    const isLastStep = data.workloadEvolutionList[data.workloadEvolutionList.length - 1].exercise === 'HOT1Q';
    if (hasFirstSubmission && data.lastStatus === WorkloadEvolutionStatusAPI.REJECTED) {
      return WorkloadValidationStatus.CHALLENGED;
    } else if (hasFirstSubmission && isLastStep && data.lastStatus === WorkloadEvolutionStatusAPI.APPROVED) {
      return WorkloadValidationStatus.VALIDATED;
    } else if (hasFirstSubmission) {
      return WorkloadValidationStatus.PENDING;
    }
    return WorkloadValidationStatus.NOT_VALIDATED;
  }

  private nextExerciseType(chartData: WorkloadEvolutionBarData[]): WorkloadEvolutionBarType.FCII | WorkloadEvolutionBarType.OP {
    const lastCompletedExercise = chartData[1];
    if (lastCompletedExercise?.id === ChartIds.OP) {
      return WorkloadEvolutionBarType.FCII;
    }
    return WorkloadEvolutionBarType.OP;
  }

  private nextExerciseNumber(chartData: WorkloadEvolutionBarData[]): number {
    const lastCompletedExercise = chartData[1];
    const lastCompletedExerciseNumber = lastCompletedExercise?.exercise.slice(-2);
    if (!isNaN(+lastCompletedExerciseNumber)) {
      return lastCompletedExercise?.barType === WorkloadEvolutionBarType.OP ? +lastCompletedExerciseNumber + 1 : +lastCompletedExerciseNumber;
    }
    return 0;
  }

  private getExerciseName(exercise: string, lastStatus: WorkloadEvolutionStatusAPI | undefined, isLastStep: boolean): string {
    if (exercise === 'BU') {
      return this.setBUasWIP(exercise);
    }
    if (exercise === 'WIP') {
      return exercise;
    }
    if (this.isOpExercise(exercise) || this.isFcExercise(exercise)) {
      return exercise;
    }

    if (!isLastStep || lastStatus === WorkloadEvolutionStatusAPI.APPROVED) {
      return `${exercise} ${APPROVED}`;
    } else if (lastStatus === WorkloadEvolutionStatusAPI.REJECTED) {
      return `${exercise} ${REJECTED}`;
    } else if (lastStatus === WorkloadEvolutionStatusAPI.SUBMIT) {
      return `${exercise} ${PENDING}`;
    }
    return exercise;
  }

  private setBUasWIP(exercise: string): string {
    return exercise === 'BU' ? 'WIP' : exercise;
  }

  private getIdFromExerciseName(exercise: string): ChartIds {
    if (this.isOpExercise(exercise)) {
      return ChartIds.OP;
    } else if (this.isFcExercise(exercise) || exercise === 'FCII') {
      return ChartIds.FCII;
    } else if (exercise === 'First Submission') {
      return ChartIds.FIRST_SUBMISSION;
    } else if (exercise === 'QMC') {
      return ChartIds.QMC;
    } else if (exercise === 'HOT1Q') {
      return ChartIds.HOT1Q;
    }
    return ChartIds.WIP;
  }

  filterWorkloadEvolutionLines(data: WorkloadEvolutionBarData[], selectedChecksIds: ChartIds[]): WorkloadEvolutionBarData[] {
    const exerciseIds = data.map((value) => value.id);

    const result = data.filter((value, index) => selectedChecksIds.includes(exerciseIds[index]));
    return result;
  }

  private isOpExercise(exercise: string): boolean {
    return this.OpPattern.test(exercise);
  }

  private isFcExercise(exercise: string): boolean {
    return this.FCPattern.test(exercise);
  }

  private isWIPExercise(exercise: string): boolean {
    return exercise === 'BU' || exercise === 'WIP';
  }

  private isLastStep(exercise: string, workLoadEvolutionList: WorkloadEvolutionListAPI[]): boolean {
    const exercisesList = workLoadEvolutionList.map((value) => value.exercise);
    if (exercise === ChartIds.HOT1Q) {
      return true;
    }
    if (exercise === ChartIds.QMC && exercisesList.includes(ChartIds.HOT1Q)) {
      return false;
    }
    if (exercise === 'BU' && (exercisesList.includes('First Submission') || exercisesList.includes('First Submition'))) {
      return false;
    }
    if (exercise === 'First Submission' && exercisesList.includes(ChartIds.QMC)) {
      return false;
    }
    return true;
  }
}
