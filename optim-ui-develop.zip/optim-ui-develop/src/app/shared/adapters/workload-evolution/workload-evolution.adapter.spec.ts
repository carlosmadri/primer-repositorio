import { TestBed } from '@angular/core/testing';

import { APPROVED, PENDING, REJECTED, WorkloadEvolutionAdapter } from './workload-evolution.adapter';
import {
  ChartIds,
  EvolutionValidationOptions,
  WorkloadEvolution,
  WorkloadEvolutionAPI,
  WorkloadEvolutionBarData,
  WorkloadEvolutionBarType,
  WorkloadEvolutionListAPI,
  WorkloadEvolutionStatusAPI,
  WorkloadSubmissionStatus,
  WorkloadValidationStatus,
} from '../../models/worksync.model';

const EXERCISE_OP_API: WorkloadEvolutionListAPI = {
  exercise: 'OP23',
  khrsOwnDirect: 10,
  khrsOwnIndirect: 11,
  khrsSubDirect: 12,
  khrsSubIndirect: 13.18,
};

const EXERCISE_FCII_API: WorkloadEvolutionListAPI = {
  exercise: 'FCII24',
  khrsOwnDirect: 20,
  khrsOwnIndirect: 21,
  khrsSubDirect: 22,
  khrsSubIndirect: 22.99,
};

const EXERCISE_FIRST_API: WorkloadEvolutionListAPI = {
  exercise: 'First Submission',
  khrsOwnDirect: 30,
  khrsOwnIndirect: 31,
  khrsSubDirect: 32,
  khrsSubIndirect: 33.18,
};

const EXERCISE_QMC_API: WorkloadEvolutionListAPI = {
  exercise: 'QMC',
  khrsOwnDirect: 40,
  khrsOwnIndirect: 41,
  khrsSubDirect: 42,
  khrsSubIndirect: 43,
};

const EXERCISE_HOT1Q_API: WorkloadEvolutionListAPI = {
  exercise: 'HOT1Q',
  khrsOwnDirect: 50,
  khrsOwnIndirect: 51,
  khrsSubDirect: 52,
  khrsSubIndirect: 53.11,
};

const EXERCISE_WIP_API: WorkloadEvolutionListAPI = {
  exercise: 'BU',
  khrsOwnDirect: 60,
  khrsOwnIndirect: 61,
  khrsSubDirect: 62,
  khrsSubIndirect: 63,
};

const EXERCISE_OP: WorkloadEvolutionBarData = {
  exercise: 'OP23',
  id: ChartIds.OP,
  barType: WorkloadEvolutionBarType.OP,
  ownDirect: 10,
  ownIndirect: 11,
  subDirect: 12,
  subIndirect: 13.2,
  total: 46.2,
};

const EXERCISE_FCII: WorkloadEvolutionBarData = {
  exercise: 'FCII24',
  id: ChartIds.FCII,
  barType: WorkloadEvolutionBarType.FCII,
  ownDirect: 20,
  ownIndirect: 21,
  subDirect: 22,
  subIndirect: 23,
  total: 86,
};

const EXERCISE_FIRST: WorkloadEvolutionBarData = {
  exercise: 'First Submission',
  id: ChartIds.FIRST_SUBMISSION,
  barType: WorkloadEvolutionBarType.APPROVED,
  ownDirect: 30,
  ownIndirect: 31,
  subDirect: 32,
  subIndirect: 33.2,
  total: 126.2,
};

const EXERCISE_QMC: WorkloadEvolutionBarData = {
  exercise: 'QMC',
  barType: WorkloadEvolutionBarType.APPROVED,
  id: ChartIds.QMC,
  ownDirect: 40,
  ownIndirect: 41,
  subDirect: 42,
  subIndirect: 43,
  total: 166,
};

const EXERCISE_HOT1Q: WorkloadEvolutionBarData = {
  exercise: 'HOT1Q',
  barType: WorkloadEvolutionBarType.APPROVED,
  id: ChartIds.HOT1Q,
  ownDirect: 50,
  ownIndirect: 51,
  subDirect: 52,
  subIndirect: 53.1,
  total: 206.1,
};

const EXERCISE_WIP: WorkloadEvolutionBarData = {
  exercise: 'WIP',
  barType: WorkloadEvolutionBarType.WIP,
  id: ChartIds.WIP,
  ownDirect: 60,
  ownIndirect: 61,
  subDirect: 62,
  subIndirect: 63,
  total: 246,
};

describe('WorkloadEvolutionAdapter', () => {
  let service: WorkloadEvolutionAdapter;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WorkloadEvolutionAdapter);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('adapt', () => {
    it('should return an empty array if data is empty', () => {
      const result = service.adapt(null);
      expect(result).toEqual(null);
    });

    it('should adapt data in closed state', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [EXERCISE_OP_API, EXERCISE_FCII_API],
        lastStatus: WorkloadEvolutionStatusAPI.APPROVED,
        multipleSiglums: false,
        wipValue: '',
      };

      const expected: WorkloadEvolution = {
        data: [EXERCISE_OP, EXERCISE_FCII],
        multipleSiglums: false,
        submissionStatus: WorkloadSubmissionStatus.NOT_SUBMITTED,
        validationStatus: WorkloadValidationStatus.NOT_VALIDATED,
        nextExerciseNumber: 24,
        nextExerciseType: WorkloadEvolutionBarType.OP,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });

    it('should adapt data after open an exercise', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [EXERCISE_OP_API, EXERCISE_FCII_API, EXERCISE_WIP_API],
        lastStatus: WorkloadEvolutionStatusAPI.APPROVED,
        multipleSiglums: false,
        wipValue: '',
      };

      const expected: WorkloadEvolution = {
        data: [EXERCISE_OP, EXERCISE_FCII, EXERCISE_WIP],
        multipleSiglums: false,
        submissionStatus: WorkloadSubmissionStatus.NOT_SUBMITTED,
        validationStatus: WorkloadValidationStatus.NOT_VALIDATED,
        nextExerciseNumber: 24,
        nextExerciseType: WorkloadEvolutionBarType.OP,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });

    it('should adapt data after first submission', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [EXERCISE_OP_API, EXERCISE_FCII_API, EXERCISE_FIRST_API],
        lastStatus: WorkloadEvolutionStatusAPI.SUBMIT,
        multipleSiglums: false,
        wipValue: '',
      };

      const expected: WorkloadEvolution = {
        data: [EXERCISE_OP, EXERCISE_FCII, { ...EXERCISE_FIRST, barType: WorkloadEvolutionBarType.SUBMIT, exercise: `${EXERCISE_FIRST.exercise} ${PENDING}` }],
        multipleSiglums: false,
        submissionStatus: WorkloadSubmissionStatus.SUBMITTED,
        validationStatus: WorkloadValidationStatus.PENDING,
        nextExerciseNumber: 24,
        nextExerciseType: WorkloadEvolutionBarType.OP,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });

    it('should adapt data after first submission rejected', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [EXERCISE_OP_API, EXERCISE_FCII_API, EXERCISE_FIRST_API, EXERCISE_WIP_API],
        lastStatus: WorkloadEvolutionStatusAPI.REJECTED,
        multipleSiglums: false,
        wipValue: '',
      };

      const expected: WorkloadEvolution = {
        data: [
          EXERCISE_OP,
          EXERCISE_FCII,
          { ...EXERCISE_FIRST, barType: WorkloadEvolutionBarType.REJECTED, exercise: `${EXERCISE_FIRST.exercise} ${REJECTED}` },
          EXERCISE_WIP,
        ],
        multipleSiglums: false,
        submissionStatus: WorkloadSubmissionStatus.NOT_SUBMITTED,
        validationStatus: WorkloadValidationStatus.CHALLENGED,
        nextExerciseNumber: 24,
        nextExerciseType: WorkloadEvolutionBarType.OP,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });

    it('should adapt data approved by previous approvers to QMC', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [EXERCISE_OP_API, EXERCISE_FCII_API, EXERCISE_FIRST_API, EXERCISE_QMC_API],
        lastStatus: WorkloadEvolutionStatusAPI.SUBMIT,
        multipleSiglums: false,
        wipValue: '',
      };

      const expected: WorkloadEvolution = {
        data: [
          EXERCISE_OP,
          EXERCISE_FCII,
          { ...EXERCISE_FIRST, exercise: `${EXERCISE_FIRST.exercise} ${APPROVED}` },
          { ...EXERCISE_QMC, barType: WorkloadEvolutionBarType.SUBMIT, exercise: `${EXERCISE_QMC.exercise} ${PENDING}` },
        ],
        multipleSiglums: false,
        submissionStatus: WorkloadSubmissionStatus.SUBMITTED,
        validationStatus: WorkloadValidationStatus.PENDING,
        nextExerciseNumber: 24,
        nextExerciseType: WorkloadEvolutionBarType.OP,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });

    it('should adapt data in QMC rejected state', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [EXERCISE_OP_API, EXERCISE_FCII_API, EXERCISE_FIRST_API, EXERCISE_QMC_API, EXERCISE_WIP_API],
        lastStatus: WorkloadEvolutionStatusAPI.REJECTED,
        multipleSiglums: false,
        wipValue: '',
      };

      const expected: WorkloadEvolution = {
        data: [
          EXERCISE_OP,
          EXERCISE_FCII,
          { ...EXERCISE_FIRST, exercise: `${EXERCISE_FIRST.exercise} ${APPROVED}` },
          { ...EXERCISE_QMC, barType: WorkloadEvolutionBarType.REJECTED, exercise: `${EXERCISE_QMC.exercise} ${REJECTED}` },
          EXERCISE_WIP,
        ],
        multipleSiglums: false,
        submissionStatus: WorkloadSubmissionStatus.NOT_SUBMITTED,
        validationStatus: WorkloadValidationStatus.CHALLENGED,
        nextExerciseNumber: 24,
        nextExerciseType: WorkloadEvolutionBarType.OP,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });

    it('should adapt data in QMC approved state', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [EXERCISE_OP_API, EXERCISE_FCII_API, EXERCISE_FIRST_API, EXERCISE_QMC_API, EXERCISE_HOT1Q_API],
        lastStatus: WorkloadEvolutionStatusAPI.SUBMIT,
        multipleSiglums: false,
        wipValue: '',
      };

      const expected: WorkloadEvolution = {
        data: [
          EXERCISE_OP,
          EXERCISE_FCII,
          { ...EXERCISE_FIRST, exercise: `${EXERCISE_FIRST.exercise} ${APPROVED}` },
          { ...EXERCISE_QMC, exercise: `${EXERCISE_QMC.exercise} ${APPROVED}` },
          { ...EXERCISE_HOT1Q, barType: WorkloadEvolutionBarType.SUBMIT, exercise: `${EXERCISE_HOT1Q.exercise} ${PENDING}` },
        ],
        multipleSiglums: false,
        submissionStatus: WorkloadSubmissionStatus.SUBMITTED,
        validationStatus: WorkloadValidationStatus.PENDING,
        nextExerciseNumber: 24,
        nextExerciseType: WorkloadEvolutionBarType.OP,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });

    it('should adapt data when HOT1Q rejects the workload', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [EXERCISE_OP_API, EXERCISE_FCII_API, EXERCISE_FIRST_API, EXERCISE_QMC_API, EXERCISE_HOT1Q_API, EXERCISE_WIP_API],
        lastStatus: WorkloadEvolutionStatusAPI.REJECTED,
        multipleSiglums: false,
        wipValue: '',
      };

      const expected: WorkloadEvolution = {
        data: [
          EXERCISE_OP,
          EXERCISE_FCII,
          { ...EXERCISE_FIRST, exercise: `${EXERCISE_FIRST.exercise} ${APPROVED}` },
          { ...EXERCISE_QMC, exercise: `${EXERCISE_QMC.exercise} ${APPROVED}` },
          { ...EXERCISE_HOT1Q, barType: WorkloadEvolutionBarType.REJECTED, exercise: `${EXERCISE_HOT1Q.exercise} ${REJECTED}` },
          EXERCISE_WIP,
        ],
        multipleSiglums: false,
        submissionStatus: WorkloadSubmissionStatus.NOT_SUBMITTED,
        validationStatus: WorkloadValidationStatus.CHALLENGED,
        nextExerciseNumber: 24,
        nextExerciseType: WorkloadEvolutionBarType.OP,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });

    it('should adapt data validated', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [EXERCISE_OP_API, EXERCISE_FCII_API, EXERCISE_FIRST_API, EXERCISE_QMC_API, EXERCISE_HOT1Q_API],
        lastStatus: WorkloadEvolutionStatusAPI.APPROVED,
        multipleSiglums: false,
        wipValue: '',
      };

      const expected: WorkloadEvolution = {
        data: [
          EXERCISE_OP,
          EXERCISE_FCII,
          { ...EXERCISE_FIRST, exercise: `${EXERCISE_FIRST.exercise} ${APPROVED}` },
          { ...EXERCISE_QMC, exercise: `${EXERCISE_QMC.exercise} ${APPROVED}` },
          { ...EXERCISE_HOT1Q, exercise: `${EXERCISE_HOT1Q.exercise} ${APPROVED}` },
        ],
        multipleSiglums: false,
        submissionStatus: WorkloadSubmissionStatus.SUBMITTED,
        validationStatus: WorkloadValidationStatus.VALIDATED,
        nextExerciseNumber: 24,
        nextExerciseType: WorkloadEvolutionBarType.OP,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });

    it('should adapt multisiglum data', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [EXERCISE_OP_API, EXERCISE_FCII_API, EXERCISE_FIRST_API, EXERCISE_QMC_API, EXERCISE_HOT1Q_API],
        lastStatus: undefined,
        multipleSiglums: true,
        wipValue: '',
      };

      const expected: WorkloadEvolution = {
        data: [
          { ...EXERCISE_OP, barType: WorkloadEvolutionBarType.MULTIPLE },
          { ...EXERCISE_FCII, barType: WorkloadEvolutionBarType.MULTIPLE },
          { ...EXERCISE_FIRST, barType: WorkloadEvolutionBarType.MULTIPLE },
          { ...EXERCISE_QMC, barType: WorkloadEvolutionBarType.MULTIPLE },
          { ...EXERCISE_HOT1Q, barType: WorkloadEvolutionBarType.MULTIPLE },
        ],
        multipleSiglums: true,
        submissionStatus: WorkloadSubmissionStatus.MULTIPLE,
        validationStatus: WorkloadValidationStatus.MULTIPLE,
        nextExerciseNumber: 24,
        nextExerciseType: WorkloadEvolutionBarType.OP,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });

    it('should adapt multisiglum data filtered by view Approved', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [EXERCISE_OP_API, EXERCISE_FCII_API, EXERCISE_FIRST_API, EXERCISE_QMC_API, EXERCISE_HOT1Q_API],
        lastStatus: undefined,
        multipleSiglums: true,
        wipValue: '',
        validationStatusParam: EvolutionValidationOptions.APPROVED,
      };

      const expected: WorkloadEvolution = {
        data: [
          { ...EXERCISE_OP, barType: WorkloadEvolutionBarType.OP },
          { ...EXERCISE_FCII, barType: WorkloadEvolutionBarType.FCII },
          { ...EXERCISE_FIRST, barType: WorkloadEvolutionBarType.APPROVED },
          { ...EXERCISE_QMC, barType: WorkloadEvolutionBarType.APPROVED },
          { ...EXERCISE_HOT1Q, barType: WorkloadEvolutionBarType.APPROVED },
        ],
        multipleSiglums: true,
        submissionStatus: WorkloadSubmissionStatus.MULTIPLE,
        validationStatus: WorkloadValidationStatus.MULTIPLE,
        nextExerciseNumber: 24,
        nextExerciseType: WorkloadEvolutionBarType.OP,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });

    it('should adapt multisiglum data filtered by view Rejected', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [EXERCISE_OP_API, EXERCISE_FCII_API, EXERCISE_FIRST_API, EXERCISE_QMC_API, EXERCISE_HOT1Q_API],
        lastStatus: undefined,
        multipleSiglums: true,
        wipValue: '',
        validationStatusParam: EvolutionValidationOptions.REJECTED,
      };

      const expected: WorkloadEvolution = {
        data: [
          { ...EXERCISE_OP, barType: WorkloadEvolutionBarType.OP },
          { ...EXERCISE_FCII, barType: WorkloadEvolutionBarType.FCII },
          { ...EXERCISE_FIRST, barType: WorkloadEvolutionBarType.REJECTED },
          { ...EXERCISE_QMC, barType: WorkloadEvolutionBarType.REJECTED },
          { ...EXERCISE_HOT1Q, barType: WorkloadEvolutionBarType.REJECTED },
        ],
        multipleSiglums: true,
        submissionStatus: WorkloadSubmissionStatus.MULTIPLE,
        validationStatus: WorkloadValidationStatus.MULTIPLE,
        nextExerciseNumber: 24,
        nextExerciseType: WorkloadEvolutionBarType.OP,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });
  });
});
