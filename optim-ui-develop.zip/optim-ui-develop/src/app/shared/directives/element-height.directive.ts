import { AfterViewInit, Directive, ElementRef, EventEmitter, OnDestroy, Output } from '@angular/core';

@Directive({
  selector: '[optimElementHeight]',
  standalone: true,
})
export class ElementHeightDirective implements AfterViewInit, OnDestroy {
  @Output() heightChange = new EventEmitter<number>();

  currentHeight = 0;

  private resizeObserver: ResizeObserver;

  constructor(private elementRef: ElementRef) {
    this.resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const height = Math.round(entry.contentRect.height);
        if (height > 0 && height !== this.currentHeight) {
          this.currentHeight = height;
          this.heightChange.emit(height);
        }
      }
    });
  }

  ngAfterViewInit() {
    this.resizeObserver.observe(this.elementRef.nativeElement);
  }

  ngOnDestroy() {
    this.resizeObserver.disconnect();
  }
}
