import { HttpHandlerFn, HttpInterceptorFn, HttpRequest } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';
import { inject, Injector } from '@angular/core';
import { Router } from '@angular/router';
import { StorageService } from '@src/app/services/storage/storage.service';
import { OAuthService } from 'angular-oauth2-oidc';
import { RouterService } from '@src/app/services/router/router.service';

export const tokenValidationInterceptor: HttpInterceptorFn = (req: HttpRequest<unknown>, next: HttpHandlerFn) => {
  const injector = inject(Injector);
  const storageService = injector.get(StorageService);
  const oauthService = injector.get(OAuthService);
  const router = inject(Router);

  let clonedRequest = req.clone();

  if (!RouterService.isTestServer()) {
    const token = oauthService.getAccessToken();
    if (token) {
      clonedRequest = clonedRequest.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`,
        },
      });
    }
  } else {
    const localToken = storageService.getToken();
    if (localToken) {
      clonedRequest = clonedRequest.clone({
        setHeaders: {
          token: localToken,
          'Access-Control-Allow-Origin': '*',
        },
      });
    }
  }

  return next(clonedRequest).pipe(
    catchError((err) => {
      console.error('Interceptor Error:', err);
      if (err?.status === 401) {
        storageService.clearToken();
        router.navigateByUrl('404');
      }
      return throwError(() => err);
    }),
  );
};
