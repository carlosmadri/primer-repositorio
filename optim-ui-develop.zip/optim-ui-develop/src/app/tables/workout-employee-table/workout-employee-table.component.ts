import { DatePipe, NgClass } from '@angular/common';
import { AfterViewInit, ChangeDetectionStrategy, Component, inject, computed, OnInit, viewChild, OnDestroy, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AccessRuleService } from '@src/app/services/access-rule/access-rule.service';
import { AuthService } from '@src/app/services/auth/auth.service';
import { EmployeeService } from '@src/app/services/employee/employee.service';
import { ManageLeversService } from '@src/app/services/levers/manage-levers.service';
import { FilterNameComponent } from '@src/app/shared/components/filter-name/filter-name.component';
import { LoadingComponent } from '@src/app/shared/components/loading/loading.component';
import { defaultPageSize, pageSizeOptions } from '@src/app/shared/config/pagination.config';
import { Employee } from '@src/app/shared/models/employee.model';
import { impersonalLeverTypes, personalLeverTypes } from '@src/app/shared/models/lever.model';
import { merge } from 'rxjs';

export interface EmployeeWithLeversTable {
  id: number;
  firstName: string;
  leverId: number;
  leverType: string;
  startDate: string;
  endDate: string;
  fte: number;
  hasMoreLever: boolean;
}
@Component({
  selector: 'optim-workout-employee-table',
  imports: [
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    FilterNameComponent,
    NgClass,
    LoadingComponent,
  ],
  providers: [DatePipe],
  templateUrl: './workout-employee-table.component.html',
  styleUrl: './workout-employee-table.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkoutEmployeeTableComponent implements OnInit, AfterViewInit, OnDestroy {
  private employeeService = inject(EmployeeService);
  private datePipe = inject(DatePipe);
  readonly dialog = inject(MatDialog);
  private manageLeversService = inject(ManageLeversService);
  private authService = inject(AuthService);
  private accessRuleService = inject(AccessRuleService);

  pageSizeOptions = pageSizeOptions;
  defaultPageSize = defaultPageSize;

  columnsToDisplay: string[] = ['Name', 'Lever', 'Start Date', 'End Date', 'FTE', 'Actions'];
  elementKeys: string[] = ['firstName', 'leverType', 'startDate', 'endDate', 'fte', 'actions'];

  employees = this.employeeService.employeesWithLevers;
  totalEmployees = this.employeeService.totalEmployeesWithLevers;

  sortByName = 'firstName,lastName,levers.startDate';
  sortById = 'id,levers.startDate';

  lastEmployeeId: number | null = null;

  tableDataSource = new MatTableDataSource<EmployeeWithLeversTable>();

  firstName: string | undefined;
  lastName: string | undefined;

  readonly paginator = viewChild.required(MatPaginator);
  readonly sort = viewChild.required(MatSort);

  isLoading = signal(false);

  dataSource = computed(() => {
    if (this.employees()?.length > 0) {
      return this.formatTableData(this.employees());
    }
    return;
  });

  ngOnInit() {
    this.updateTable();
  }

  ngAfterViewInit() {
    this.sort().sortChange.subscribe(() => this.paginator().firstPage());
    merge(this.sort().sortChange, this.paginator().page).subscribe(() => {
      this.updateTable();
    });
  }

  ngOnDestroy(): void {
    this.employeeService.resetEmployeesWithLevers();
  }

  private getSortParams() {
    const sortDirection = this.sort()?.direction || '';
    const sortActive = sortDirection ? this.sortByName : this.sortById;
    return [`sort=${sortActive},${sortDirection}`, `page=${this.paginator()?.pageIndex || 0}`, `size=${this.paginator()?.pageSize || this.defaultPageSize}`];
  }

  async updateTable() {
    const sortParams = this.getSortParams();
    const filterParams = [this.firstName ? `employee.firstName=${this.firstName}` : '', this.lastName ? `employee.lastName=${this.lastName}` : ''].filter(
      (item) => item,
    );

    const userFilter = this.authService.getUserNameFilter();
    this.isLoading.set(true);

    await this.employeeService.getEmployeesWithLevers([...filterParams, ...sortParams, userFilter!]).catch((err) => console.error(err));
    this.isLoading.set(false);
  }

  filterByName(filters: { firstName: string | null; lastName: string | null }) {
    this.firstName = filters.firstName?.trim();
    this.lastName = filters.lastName?.trim();

    this.paginator().firstPage();
    this.updateTable();
  }

  private formatTableData(employees: Employee[]): MatTableDataSource<EmployeeWithLeversTable> {
    this.lastEmployeeId = null;
    const tableData: EmployeeWithLeversTable[] = employees.flatMap((employee): EmployeeWithLeversTable[] => {
      return employee.levers.map((lever, index): EmployeeWithLeversTable => {
        const tableRow = {
          id: employee.id,
          firstName: this.lastEmployeeId !== employee.id ? `${employee.firstName} ${employee.lastName || ''}` : '',
          leverId: lever.id,
          leverType: lever.leverType,
          startDate: this.datePipe.transform(lever.startDate, 'dd/MM/yyyy') || '',
          endDate: this.datePipe.transform(lever.endDate, 'dd/MM/yyyy') || '',
          fte: lever.fte | 0,
          hasMoreLever: employee.levers.length > index + 1,
          canEdit: this.accessRuleService.canEditLevers(),
        };
        this.lastEmployeeId = employee.id;
        return tableRow;
      });
    });
    return new MatTableDataSource<EmployeeWithLeversTable>(tableData);
  }

  onEditClick(employeeId: number, leverId: number) {
    const el = this.employees().find((e) => e.id === employeeId)!;
    const lever = el.levers.find((l) => l.id === leverId);
    const types = el.impersonal ? impersonalLeverTypes : personalLeverTypes;
    this.manageLeversService
      .openLeverDialog({ leverTypes: types, employeeFTE: el.fte, employee: el, editLever: lever })
      .then(() => this.updateTable())
      .catch((err: unknown) => console.error(err));
  }
}
