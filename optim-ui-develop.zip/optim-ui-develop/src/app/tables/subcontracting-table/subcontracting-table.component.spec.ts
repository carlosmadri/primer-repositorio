import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubcontractingTableComponent } from './subcontracting-table.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { AuthService } from '@src/app/services/auth/auth.service';
import { SubcontractingService } from '@src/app/services/subcontracting/subcontracting.service';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { Signal } from '@angular/core';
import { Subcontracting } from '@src/app/shared/models/subcontracting.model';

describe('SubcontractingTableComponent', () => {
  let component: SubcontractingTableComponent;
  let fixture: ComponentFixture<SubcontractingTableComponent>;
  let mockAuthService: Partial<AuthService>;
  let mockFiltersService: Partial<FiltersService>;
  let mockSubcontractingService: Partial<SubcontractingService>;

  beforeEach(async () => {
    mockAuthService = {
      getUserNameFilter: jest.fn(),
    };

    mockFiltersService = {
      subcontractingParamsFilter: jest.fn() as unknown as Signal<string[] | undefined>,
    };

    mockSubcontractingService = {
      getSubcontracts: jest.fn().mockResolvedValue(null),
      resetSubcontracts: jest.fn(),
      subcontracts: jest.fn() as unknown as Signal<Subcontracting[]>,
      totalSubcontracts: jest.fn() as unknown as Signal<number>,
    };

    await TestBed.configureTestingModule({
      imports: [SubcontractingTableComponent, NoopAnimationsModule],
      providers: [
        { provide: AuthService, useValue: mockAuthService },
        { provide: FiltersService, useValue: mockFiltersService },
        { provide: SubcontractingService, useValue: mockSubcontractingService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(SubcontractingTableComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
