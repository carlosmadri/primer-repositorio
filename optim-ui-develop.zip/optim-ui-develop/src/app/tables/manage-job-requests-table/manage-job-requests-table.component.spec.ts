import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageJobRequestsTableComponent } from './manage-job-requests-table.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { AuthService } from '@src/app/services/auth/auth.service';
import { MatPaginatorModule } from '@angular/material/paginator';
import { JobRequestService } from '@src/app/services/job-request/job-request.service';
import { signal } from '@angular/core';
import { FiltersService } from '@src/app/services/filters/filters.service';

describe('ManageJobRequestsTableComponent', () => {
  let component: ManageJobRequestsTableComponent;
  let fixture: ComponentFixture<ManageJobRequestsTableComponent>;
  let mockAuthService: Partial<AuthService>;

  beforeEach(async () => {
    mockAuthService = {
      getUserNameFilter: jest.fn(),
    };

    const mockJobRequestService: Partial<JobRequestService> = {
      jobRequests: signal([]),
      totalJobRequests: signal(0),
      getJobRequests: jest.fn().mockResolvedValue([]),
      resetJobRequests: jest.fn(),
    };

    const mockFiltersService: Partial<FiltersService> = {
      jobRequestParamsFilter: signal([]),
    };

    await TestBed.configureTestingModule({
      imports: [ManageJobRequestsTableComponent, NoopAnimationsModule, MatPaginatorModule],
      providers: [
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting(),
        { provide: AuthService, useValue: mockAuthService },
        { provide: JobRequestService, useValue: mockJobRequestService },
        { provide: FiltersService, useValue: mockFiltersService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(ManageJobRequestsTableComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
