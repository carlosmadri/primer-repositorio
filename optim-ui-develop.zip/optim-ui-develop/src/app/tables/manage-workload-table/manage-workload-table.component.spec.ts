import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageWorkloadTableComponent, WorkloadTable } from './manage-workload-table.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { AuthService } from '@services/auth/auth.service';
import { WorksyncService } from '@services/worksync/worksync.service';
import { WritableSignal, signal } from '@angular/core';
import { Workload } from '@src/app/shared/models/worksync.model';
import { FiltersService } from '@services/filters/filters.service';
import { CostCenterService } from '@services/cost-center/cost-center.service';
import { CostCenter } from '@src/app/shared/models/cost-center.model';
import { Location } from '@src/app/shared/models/location.model';

describe('ManageWorkloadTableComponent', () => {
  let component: ManageWorkloadTableComponent;
  let fixture: ComponentFixture<ManageWorkloadTableComponent>;
  let mockAuthService: Partial<AuthService>;
  let mockWorksyncService: Partial<WorksyncService>;
  let mockFiltersService: Partial<FiltersService>;
  let mockCostCenterService: Partial<CostCenterService>;
  let mockAllCostCenters: WritableSignal<CostCenter[]>;
  let mockWorkloads: WritableSignal<Workload[]>;

  const mockCostCenter1 = { id: 1, costCenterCode: 'Cost Center 1', location: { id: 1, site: 'Site 1' } as Location } as CostCenter;
  const mockCostCenter2 = { id: 2, costCenterCode: 'Cost Center 2', location: { id: 1, site: 'Site 2' } as Location } as CostCenter;
  const mockWorkload1 = { id: 1, costCenter: mockCostCenter1 } as Workload;
  const mockWorkload2 = { id: 2, costCenter: mockCostCenter2 } as Workload;

  beforeEach(async () => {
    mockAuthService = {
      getUserNameFilter: jest.fn(),
    };

    mockWorkloads = signal<Workload[]>([]);
    mockWorksyncService = {
      ppsids: signal<string[]>([]),
      workloads: mockWorkloads,
      totalWorkloads: signal<number>(0),
      getPpsids: jest.fn(),
      resetWorkloads: jest.fn(),
      editWorkloads: jest.fn(),
      editWorkload: jest.fn(),
      getWorkloads: jest.fn(),
      addEmptyWorkload: jest.fn(),
      addWorkload: jest.fn(),
      editPpsid: jest.fn(),
    };

    mockFiltersService = {
      getAllVisibleSiglumsHR: jest.fn(),
      workloadParamsFilter: signal<string[]>([]),
      reloadData: jest.fn(),
      getSiglumId: jest.fn(),
    };

    mockAllCostCenters = signal<CostCenter[]>([]);
    mockCostCenterService = {
      allCostCenters: mockAllCostCenters,
      getAllCostCenters: jest.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [ManageWorkloadTableComponent, NoopAnimationsModule],
      providers: [
        { provide: AuthService, useValue: mockAuthService },
        { provide: WorksyncService, useValue: mockWorksyncService },
        { provide: FiltersService, useValue: mockFiltersService },
        { provide: CostCenterService, useValue: mockCostCenterService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(ManageWorkloadTableComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  afterEach(() => {
    jest.clearAllMocks();
    mockAllCostCenters.set([]);
    mockWorkloads.set([]);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Format the list of Sites and Cost centers', () => {
    beforeEach(() => {
      mockAllCostCenters.set([mockCostCenter1, mockCostCenter2]);
    });

    it('should format the list of Sites', () => {
      const expectedSiteName1 = `${mockCostCenter1.location.site}${component.siteCostCenterSeparator}${mockCostCenter1.costCenterCode}`;
      const expectedSiteName2 = `${mockCostCenter2.location.site}${component.siteCostCenterSeparator}${mockCostCenter2.costCenterCode}`;

      component.dataSource();
      const sites = component.allSites();

      expect(sites).toEqual([expectedSiteName1, expectedSiteName2]);
    });

    it('should format the list of Cost center codes', () => {
      const expectedSiteName1 = `${mockCostCenter1.costCenterCode}${component.siteCostCenterSeparator}${mockCostCenter1.location.site}`;
      const expectedSiteName2 = `${mockCostCenter2.costCenterCode}${component.siteCostCenterSeparator}${mockCostCenter2.location.site}`;

      component.dataSource();
      const sites = component.allCostCenterCodes();

      expect(sites).toEqual([expectedSiteName1, expectedSiteName2]);
    });
  });

  describe('Add data to workload', () => {
    beforeEach(() => {
      mockWorkloads.set([mockWorkload1, mockWorkload2]);
      mockAllCostCenters.set([mockCostCenter1, mockCostCenter2]);
    });
    it('should add Site to workload', async () => {
      const mockSiteName = `${mockCostCenter1.location.site}${component.siteCostCenterSeparator}${mockCostCenter1.costCenterCode}`;
      const mockSiteData = { site: mockSiteName } as Partial<WorkloadTable>;

      component.dataSource();
      await component.editElement(mockSiteData, mockWorkload1.id, 'location');

      expect(mockWorksyncService.editWorkloads).toHaveBeenCalledWith([
        expect.objectContaining({ id: mockWorkload1.id, costCenter: { id: mockCostCenter1.id } } as Partial<Workload>),
      ]);
    });

    it('should add Cost center to workload', async () => {
      const mockCostCenterName = `${mockCostCenter1.costCenterCode}${component.siteCostCenterSeparator}${mockCostCenter1.location.site}`;
      const mockCostCenterData = { costCenter: mockCostCenterName } as Partial<WorkloadTable>;

      component.dataSource();
      await component.editElement(mockCostCenterData, mockWorkload1.id, 'costCenter');

      expect(mockWorksyncService.editWorkloads).toHaveBeenCalledWith([
        expect.objectContaining({ id: mockWorkload1.id, costCenter: { id: mockCostCenter1.id } } as Partial<Workload>),
      ]);
    });
  });
});
