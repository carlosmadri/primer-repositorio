import { AfterViewInit, ChangeDetectionStrategy, Component, computed, effect, inject, OnDestroy, signal, viewChild } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { WorksyncService } from '@services/worksync/worksync.service';
import { backlogOrderIntakeValues, collarValues, coreNonCoreValues, ownSubValues, Ppsid, Workload } from '@models/worksync.model';
import * as _moment from 'moment';
import { default as _rollupMoment } from 'moment';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { CustomSelect, DynamicInputComponent } from '@components/dynamic-input/dynamic-input.component';
import { FiltersService } from '@services/filters/filters.service';
import { MatSlideToggleChange, MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatDatepickerInputEvent, MatDatepickerModule } from '@angular/material/datepicker';
import { merge } from 'rxjs';
import { directIndirectValues } from '@models/employee.model';
import { CostCenterService } from '@services/cost-center/cost-center.service';
import { CostCenter } from '@models/cost-center.model';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { SelectionModel } from '@angular/cdk/collections';
const moment = _rollupMoment || _moment;
import { Moment } from 'moment/moment';
import { AuthService } from '@src/app/services/auth/auth.service';
import { LoadingComponent } from '@src/app/shared/components/loading/loading.component';
import { defaultPageSize, pageSizeOptions } from '@src/app/shared/config/pagination.config';

export interface WorkloadTable {
  id: number;
  costCenterId?: number;
  checked: boolean;
  siglum: string;
  description: string;
  own: string;
  site?: string; //costCenter.location.site
  costCenter: string;
  direct: string;
  timeline: string;
  khrs: number;
  go: boolean;
  ppsid_id: number; //ppsid table
  ppsid: string;
  ppsidName: string;
  businessLine: string;
  programLine: string;
  productionCenter: string;
  businessActivity: string;
  backlogOrderIntake: string;
  muCode: string;
  scenario: string;
  muText: string; //ppsid table end
  core: string;
  collar: string; //workload.collar
  efficiency?: number; //costCenter.efficiency
  rateOwn?: number; //costCenter.rateOwn
  fte: number; //workload.fte
  keur: number; //workload.keur
  eac: boolean; //workload.eac
  expanded: boolean;
  editable: boolean;
}

@Component({
  selector: 'optim-manage-workload-table',
  imports: [
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatPaginatorModule,
    MatSortModule,
    CommonModule,
    DynamicInputComponent,
    MatSlideToggleModule,
    MatDatepickerModule,
    MatCheckboxModule,
    LoadingComponent,
  ],
  templateUrl: './manage-workload-table.component.html',
  styleUrl: './manage-workload-table.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('detailExpand', [
      state('collapsed,void', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ManageWorkloadTableComponent implements AfterViewInit, OnDestroy {
  private authService = inject(AuthService);
  private worksyncService = inject(WorksyncService);
  private filtersService = inject(FiltersService);
  private costCenterService = inject(CostCenterService);
  siteCostCenterSeparator = ' / ';
  allCostCenter: CostCenter[] = [];
  allSiglumHR = computed<string[]>(() => this.filtersService.getAllVisibleSiglumsHR());
  allSites = computed<string[]>(() => {
    return this.allCostCenter
      .map((cc) => {
        return `${cc.location.site}${this.siteCostCenterSeparator}${cc.costCenterCode}`;
      })
      ?.sort();
  });
  allCostCenterCodes = computed<string[]>(() => {
    return this.allCostCenter
      .map((cc) => {
        return `${cc.costCenterCode}${this.siteCostCenterSeparator}${cc.location.site}`;
      })
      ?.sort();
  });
  allPpsids = computed<string[]>(() => this.worksyncService.ppsids());
  allOwns = ownSubValues;
  allDirect = directIndirectValues;
  allCores = coreNonCoreValues;
  allCollar = collarValues;
  allBacklogOrderIntake = backlogOrderIntakeValues;
  private workloads: Workload[] = [];
  private tableElements: WorkloadTable[] = [];
  newWorkloadDates: { startDate: string; endDate: string } = { startDate: moment().format('DD/MM/YYYY'), endDate: '' };
  newWorkload: Partial<Workload> = { go: true };
  newCostCenterCode = 'Select site';
  totalWorkloads = 0;
  workloadHeaderKeys: string[] = ['select', 'siglum', 'description', 'own', 'site', 'costCenter', 'direct', 'timeline', 'khrs', 'go', 'expand'];
  ppsidExpandedKeys: string[] = ['ppsidName', 'businessLine', 'programLine', 'productionCenter', 'businessActivity', 'backlogOrderIntake', 'muCode', 'muText'];
  ppsidLabels: string[] = ['PPSID Name', 'Business Line', 'Program Line', 'Production Center', 'Business Activity', 'Backlog / Order Intake', 'MU', 'MU Text'];
  readonly paginator = viewChild.required(MatPaginator);

  pageSizeOptions = pageSizeOptions;
  defaultPageSize = defaultPageSize;

  readonly sort = viewChild.required(MatSort);
  selection = new SelectionModel<WorkloadTable>(true, []);

  isLoading = signal(false);

  dataSource = computed(() => {
    this.workloads = this.worksyncService.workloads();
    this.totalWorkloads = this.worksyncService.totalWorkloads();
    this.allCostCenter = this.costCenterService.allCostCenters().filter((cc) => cc.location);
    if (this.workloads?.length > 0) {
      const dataSource = this.formatTableData(this.workloads);
      this.tableElements = dataSource.data;
      return dataSource;
    }
    return;
  });

  constructor() {
    this.costCenterService.getAllCostCenters();
    effect(() => {
      this.worksyncService.getPpsids();
      this.paginator().firstPage();
      this.updateTable(this.filtersService.workloadParamsFilter());
    });
  }

  ngAfterViewInit() {
    this.sort().sortChange.subscribe(() => {
      this.paginator().firstPage();
    });
    merge(this.sort().sortChange, this.paginator().page).subscribe(() => {
      this.updateTable(this.filtersService.workloadParamsFilter());
    });
  }

  ngOnDestroy(): void {
    this.worksyncService.resetWorkloads();
  }

  async dateEvent(type: 'startDate' | 'endDate', event: MatDatepickerInputEvent<Date>, id: number) {
    if (event.value) {
      if (!id) {
        this.newWorkloadDates[type] = moment(event.value).format('DD/MM/YYYY');
        await this.addWorkload({
          [type]: event.value.toISOString(),
        });
      } else {
        const elIndex = this.workloads.findIndex((el) => el.id === id);
        if (type === 'startDate') {
          this.workloads[elIndex].startDate = event.value.toISOString();
        }
        if (type === 'endDate') {
          const partialDateRange = {
            startDate: this.workloads[elIndex].startDate,
            endDate: event.value.toISOString(),
          };
          await this.editWorkload(id, partialDateRange as Partial<Workload>);
        }
      }
    }
  }
  rangePickerFilter(date: Moment | null): boolean {
    if (!date) {
      return false;
    }
    const day = (date || moment())?.date();
    const lastDayOfMonth = date.daysInMonth();
    // Prevent any day but the first and the last of each month.
    return day === 1 || day === lastDayOfMonth;
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const allSelected = this.tableElements.filter((el) => el.checked);
    const numElements = this.dataSource()?.data.filter((el) => el.go).length;
    return allSelected.length === numElements;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  toggleAllRows() {
    if (this.isAllSelected()) {
      this.tableElements = this.tableElements.map((el) => {
        return { ...el, checked: false } as WorkloadTable;
      });
    } else {
      this.tableElements = this.tableElements.map((el) => {
        return { ...el, checked: el.editable } as WorkloadTable;
      });
    }
    this.updateTable(this.filtersService.workloadParamsFilter());
  }

  someSelected() {
    return !!this.tableElements.find((el) => el.checked);
  }

  private getSortParams() {
    let sortActive = this.sort().active;
    let sortDirection = this.sort().direction;
    if (this.sort().direction === '') {
      sortActive = 'id';
      sortDirection = 'desc';
    }
    return [`sort=${sortActive},${sortDirection}`, `page=${this.paginator().pageIndex || 0}`, `size=${this.paginator().pageSize || this.defaultPageSize}`];
  }

  async editWorkload(id: number, workload: Partial<Workload>) {
    const selectedElements = this.tableElements.filter((el) => el.checked || el.id === id);
    if (selectedElements.length > 0) {
      const selectedWorkloads = this.workloads.filter((wl) => selectedElements.find((tableElement) => tableElement.id === wl.id));
      const editedWorkloads = selectedWorkloads.map((wl) => {
        return { ...workload, id: wl.id } as Partial<Workload>;
      });
      await this.worksyncService.editWorkloads(editedWorkloads);
    } else {
      await this.worksyncService.editWorkload(id, workload);
    }
    await this.updateTable(this.filtersService.workloadParamsFilter());
    this.filtersService.reloadData();
  }

  async updateTable(filterParams: string[] = []) {
    const sortParams = this.getSortParams();
    const userParam = this.authService.getUserNameFilter();

    this.isLoading.set(true);
    await this.worksyncService.getWorkloads([...sortParams, ...filterParams, userParam!]).catch((err) => console.error(err));
    this.isLoading.set(false);
  }

  async addPpsid(value: Partial<Ppsid>, id: number) {
    const ppsid = await this.worksyncService.getPpsid(value.ppsid!);
    if (ppsid) {
      const partialWorkload = {
        ppsid: {
          id: ppsid.id,
        },
      };
      await this.editWorkload(id, partialWorkload as Partial<Workload>);
    }
  }

  async addEmptyWorkload() {
    await this.updateTable(this.filtersService.workloadParamsFilter());
    this.worksyncService.addEmptyWorkload();
  }

  async addWorkload(workload?: Partial<Workload>) {
    if (workload) {
      Object.assign(this.newWorkload, workload);
    }
    if (
      this.newWorkload.siglum &&
      this.newWorkload.description &&
      this.newWorkload.own &&
      this.newWorkload.costCenter &&
      this.newWorkload.direct &&
      this.newWorkloadDates.endDate &&
      this.newWorkload.khrs
    ) {
      await this.worksyncService.addWorkload(this.newWorkload);
      await this.updateTable(this.filtersService.workloadParamsFilter());
      this.newWorkload = { go: true };
      this.newCostCenterCode = 'Select site';
      this.newWorkloadDates = { startDate: moment().format('DD/MM/YYYY'), endDate: '' };
    }
  }

  async editElement(value: Partial<Workload | Ppsid | WorkloadTable | CustomSelect | string>, id: number, objName: string) {
    switch (objName) {
      case 'workload':
        this.saveWorkload(value, id);
        break;
      case 'ppsid':
        await this.worksyncService.editPpsid(id, value as Ppsid);
        break;
      case 'siglum': {
        const tableElement = value as WorkloadTable;
        const siglumId = this.filtersService.getSiglumId(tableElement.siglum);
        const partialSiglum = {
          siglum: {
            id: siglumId,
          },
        };
        this.saveWorkload(partialSiglum as Partial<Workload>, id);
        break;
      }
      case 'costCenter': {
        const partialCostCenter = this.extractCostCenter(value, true);
        this.saveWorkload(partialCostCenter as Partial<Workload>, id);
        break;
      }
      case 'location': {
        const partialCostCenter = this.extractCostCenter(value, false);
        this.saveWorkload(partialCostCenter as Partial<Workload>, id);
        break;
      }
    }
  }

  private extractCostCenter(value: Partial<string | Workload | WorkloadTable | Ppsid | CustomSelect>, costCenterFirst: boolean) {
    const selectObject = value as object;
    const selectedString = Object.values(selectObject).join('');
    const selectObjectSplit = selectedString.split(this.siteCostCenterSeparator);
    const [selectObjectCostCenter, selectObjectSite] = costCenterFirst ? selectObjectSplit : selectObjectSplit.reverse();
    const selectCostCenter = this.allCostCenter.find((cc) => cc.costCenterCode === selectObjectCostCenter && cc.location.site === selectObjectSite);
    const partialCostCenter = {
      costCenter: {
        id: selectCostCenter!.id,
      },
    };
    return partialCostCenter;
  }

  private async saveWorkload(value: Partial<Workload | Ppsid | WorkloadTable | CustomSelect | string>, id: number) {
    if (id) {
      await this.editWorkload(id, value as Workload);
    } else {
      await this.addWorkload(value as Partial<Workload>);
    }
  }

  async toggleGo(workloadId: number, event: MatSlideToggleChange) {
    const partialWorkload = {
      go: event.checked,
    };
    await this.editWorkload(workloadId, partialWorkload as Workload);
    if (!partialWorkload.go) {
      this.tableElements = this.tableElements.map((el) => {
        return { ...el, checked: false } as WorkloadTable;
      });
    }
  }

  private formatTableData(workloads: Workload[]): MatTableDataSource<WorkloadTable> {
    const tableData: WorkloadTable[] = workloads.map((workload: Workload, index: number): WorkloadTable => {
      return {
        id: workload.id,
        costCenterId: workload.costCenter?.id,
        checked: !!this.tableElements.find((el) => el.id === workload.id)?.checked,
        siglum: workload.siglum?.siglumHR,
        description: workload.description,
        own: workload.own,
        site: workload.costCenter?.location?.site, //location.site
        costCenter: workload.costCenter?.costCenterCode ?? '', //costCenter.costCenterCode
        direct: workload.direct,
        timeline: `${moment(workload.startDate).format('DD/MM/YYYY')}\n${moment(workload.endDate).format('DD/MM/YYYY')}`,
        khrs: workload.khrs,
        go: workload.go,
        ppsid_id: workload.ppsid?.id, //ppsid table
        ppsid: workload.ppsid?.ppsid,
        ppsidName: workload.ppsid?.ppsidName ?? '',
        businessLine: workload.ppsid?.businessLine ?? '',
        programLine: workload.ppsid?.programLine ?? '',
        productionCenter: workload.ppsid?.productionCenter ?? '',
        businessActivity: workload.ppsid?.businessActivity ?? '',
        backlogOrderIntake: workload.ppsid?.backlogOrderIntake ?? '',
        muCode: workload.ppsid?.muCode ?? '',
        scenario: workload.ppsid?.scenario ?? '',
        muText: workload.ppsid?.muText ?? '', //ppsid table end
        core: workload.core, //workload.core
        collar: workload.collar, //workload.collar
        efficiency: workload.costCenter?.efficiency, //costCenter.efficiency
        rateOwn: workload.costCenter?.rateOwn, //costCenter.rateOwn
        fte: workload.fte, //workload.fte FTEs = Hrs / ( Efficiency x (duración de la actividad/ 12))
        keur: workload.keur, //workload.keur
        eac: workload.eac, //workload.eac
        expanded: this.tableElements[index] ? this.tableElements[index].expanded : false,
        editable: !workload?.readonly && workload.go,
      };
    });
    return new MatTableDataSource<WorkloadTable>(tableData);
  }
}
