import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ManageTableComponent } from './manage-table.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { AuthService } from '@src/app/services/auth/auth.service';
import { EmployeeService } from '@src/app/services/employee/employee.service';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { signal, WritableSignal } from '@angular/core';
import { ManageLeversService } from '@src/app/services/levers/manage-levers.service';
import { AccessRuleService } from '@src/app/services/access-rule/access-rule.service';

describe('ManageTableComponent', () => {
  let component: ManageTableComponent;
  let fixture: ComponentFixture<ManageTableComponent>;
  let mockAuthService: Partial<AuthService>;
  let mockAccessRuleService: Partial<AccessRuleService>;
  let mockEmployeeService: Partial<EmployeeService>;
  let mockFiltersService: Partial<FiltersService>;
  let mockManageLeversService: Partial<ManageLeversService>;
  let mockParamsFilter: WritableSignal<string[]>;

  beforeEach(async () => {
    mockParamsFilter = signal<string[]>([]);

    mockFiltersService = {
      paramsFilter: mockParamsFilter,
      employeeParamsFilter: signal<string[]>([]),
    };

    mockAuthService = {
      getUserNameFilter: jest.fn(),
    };

    mockAccessRuleService = {
      canEditLevers: jest.fn(),
    };

    mockEmployeeService = {
      resetEmployees: jest.fn(),
      getEmployees: jest.fn().mockResolvedValue(null),
      employees: signal([]),
      totalEmployees: signal(0),
    };

    mockManageLeversService = {
      openLeverDialog: jest.fn(),
      deleteLever: jest.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [ManageTableComponent, NoopAnimationsModule],
      providers: [
        { provide: EmployeeService, useValue: mockEmployeeService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: FiltersService, useValue: mockFiltersService },
        { provide: ManageLeversService, useValue: mockManageLeversService },
        { provide: AccessRuleService, useValue: mockAccessRuleService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(ManageTableComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
