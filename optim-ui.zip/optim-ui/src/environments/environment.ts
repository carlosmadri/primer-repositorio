export const environment = {
  production: true,
  apiUrl: 'http://10.49.2.215:8080/api/optim/',
};
