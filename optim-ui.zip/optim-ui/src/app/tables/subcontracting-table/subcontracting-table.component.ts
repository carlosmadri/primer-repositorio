import { AfterViewInit, ChangeDetectionStrategy, Component, computed, effect, inject, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { Employee } from '@models/employee.model';
import { FiltersService } from '@services/filters/filters.service';
import { SubcontractingService } from '@services/subcontracting/subcontracting.service';
import { Subcontracting } from '@models/subcontracting.model';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { merge } from 'rxjs';
import { AuthService } from '@src/app/services/auth/auth.service';

export interface SubcontractingTable {
  id: number;
  siglum: string;
  site: string;
  description: string;
  provider: string;
  approved: string;
  quarter: string;
  year: string;
  keur: number;
  orderRequest: string;
  orderId: number;
  hmg: string;
  pep: string;
  expanded: boolean;
}

@Component({
  selector: 'optim-subcontracting-table',
  standalone: true,
  imports: [MatTableModule, MatButtonModule, MatIconModule, MatPaginatorModule, MatSortModule, CommonModule],
  templateUrl: './subcontracting-table.component.html',
  styleUrl: './subcontracting-table.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('detailExpand', [
      state('collapsed,void', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class SubcontractingTableComponent implements AfterViewInit {
  private filtersService = inject(FiltersService);
  private authService = inject(AuthService);
  private subcontractingService = inject(SubcontractingService);
  private tableElements: SubcontractingTable[] = [];
  totalSubcontracts = 0;
  columnsToDisplay: string[] = ['Siglum', 'Site', 'Description', 'Provider', 'Approved', 'Quarter', 'Year', 'k€'];
  elementKeys: string[] = ['siglum', 'site', 'description', 'provider', 'approved', 'quarter', 'year', 'keur'];
  columnsToDisplayWithExpand = [...this.columnsToDisplay, 'expand'];
  expandedElement!: Employee | null;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  subcontracts: Subcontracting[] = [];

  dataSource = computed(() => {
    this.subcontracts = this.subcontractingService.subcontracts();
    this.totalSubcontracts = this.subcontractingService.totalSubcontracts();
    if (this.subcontracts?.length > 0) {
      const dataSource = this.formatTableData(this.subcontracts);
      this.tableElements = dataSource.data;
      return dataSource;
    }
    return;
  });

  constructor() {
    effect(() => {
      this.paginator.pageIndex = 0;
      this.updateTable(this.filtersService.subcontractingParamsFilter());
    });
  }

  ngAfterViewInit() {
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
    merge(this.sort.sortChange, this.paginator.page).subscribe(() => {
      this.updateTable(this.filtersService.subcontractingParamsFilter());
    });
  }

  private getSortParams() {
    let sortActive = this.sort.active;
    let sortDirection = this.sort.direction;
    if (!this.sort.active || sortDirection === '') {
      sortActive = 'id';
      this.sort.active = 'id';
      sortDirection = 'desc';
    }
    return [`sort=${sortActive},${sortDirection}`, `page=${this.paginator.pageIndex}`, `size=${this.paginator.pageSize}`];
  }

  updateTable(filterParams: string[] = []) {
    const sortParams = this.getSortParams();
    const params = this.authService.getUserNameFilter();
    this.subcontractingService.getSubcontracts([params!, ...sortParams, ...filterParams]).catch((err) => console.error(err));
  }

  private formatTableData(subcontracts: Subcontracting[]): MatTableDataSource<SubcontractingTable> {
    const tableData: SubcontractingTable[] = subcontracts.map((subcontract, index: number): SubcontractingTable => {
      return {
        id: subcontract.id,
        siglum: subcontract.siglum,
        description: subcontract.description,
        site: subcontract.site,
        quarter: subcontract.quarter,
        keur: subcontract.keur,
        year: subcontract.year,
        approved: subcontract.approved === 'true' ? 'Yes' : 'No',
        provider: subcontract.provider,
        orderRequest: subcontract.orderRequest,
        orderId: subcontract.orderId,
        hmg: subcontract.hmg,
        pep: subcontract.pep,
        expanded: this.tableElements[index] ? this.tableElements[index].expanded : false,
      };
    });
    return new MatTableDataSource<SubcontractingTable>(tableData);
  }
}
