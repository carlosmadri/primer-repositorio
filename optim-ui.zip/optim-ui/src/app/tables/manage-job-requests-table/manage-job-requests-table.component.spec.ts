import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageJobRequestsTableComponent } from './manage-job-requests-table.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { AuthService } from '@src/app/services/auth/auth.service';

describe('ManageJobRequestsTableComponent', () => {
  let component: ManageJobRequestsTableComponent;
  let fixture: ComponentFixture<ManageJobRequestsTableComponent>;
  let mockAuthService: Partial<AuthService>;

  beforeEach(async () => {
    mockAuthService = {
      getUserNameFilter: jest.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [ManageJobRequestsTableComponent, NoopAnimationsModule],
      providers: [provideHttpClient(withInterceptorsFromDi()), provideHttpClientTesting(), { provide: AuthService, useValue: mockAuthService }],
    }).compileComponents();

    fixture = TestBed.createComponent(ManageJobRequestsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
