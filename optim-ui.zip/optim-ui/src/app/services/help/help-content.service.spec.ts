import { TestBed } from '@angular/core/testing';

import { HelpContentService } from './help-content.service';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';

describe('HelpContentService', () => {
  let service: HelpContentService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(withInterceptorsFromDi()), provideHttpClientTesting()],
    });
    service = TestBed.inject(HelpContentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
