import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { WorkloadEvolutionAdapter } from '@src/app/shared/adapters/workload-evolution/workload-evolution.adapter';
import { WorkloadPerProgramAdapter } from '@src/app/shared/adapters/workload-per-program.adapter';
import { WorkloadWorkforceAdapter } from '@src/app/shared/adapters/workload-workforce/workload-workforce.adapter';
import {
  CRUD_PPSID,
  CRUD_WORKLOAD,
  CRUD_WORKLOAD_EXERCISE_SUBMIT,
  CRUD_WORKLOAD_EXERCISE_VALIDATE,
  GET_WORKLOAD_DIRECT_RATIO,
  GET_WORKLOAD_EVOLUTION,
  GET_WORKLOAD_EXERCISE_CLOSE,
  GET_WORKLOAD_EXERCISE_OPEN,
  GET_WORKLOAD_EXPORT,
  GET_WORKLOAD_OWN_SUB_RATIO,
  GET_WORKLOAD_PER_PROGRAM,
  GET_WORKLOAD_PREVIEW,
  GET_WORKLOAD_WORKFORCE,
  POST_WORKLOAD_IMPORT,
  WORKLOAD_CAN_UPDATE,
  WORKLOAD_OPEN_EXERCISE,
} from '@src/app/shared/api.urls';
import { DirectIndirect } from '@src/app/shared/models/employee.model';
import { LineDetailChartData } from '@src/app/shared/models/graphs/line-detail-chart.model';
import {
  Ppsid,
  Workload,
  WorkloadsApiResponse,
  WorkloadEvolution,
  WorkloadEvolutionAPI,
  WorkloadPerProgramAPI,
  WorkloadWorkforce,
  WorkloadWorkforceAPI,
  WorksyncOwnSub,
  WorkloadPreview,
  WorkloadAvailableSiglumLists,
  WorkloadValidationSiglumLists,
  WorkloadPostResponse,
  WorkloadSubmitSiglumLists,
} from '@src/app/shared/models/worksync.model';
import { catchError, firstValueFrom, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class WorksyncService {
  #workloads = signal<Workload[]>([]);
  workloads = this.#workloads.asReadonly();

  #ppsids = signal<string[]>([]);
  ppsids = this.#ppsids.asReadonly();

  #totalWorkloads = signal<number>(0);
  totalWorkloads = this.#totalWorkloads.asReadonly();

  #directRatio = signal<DirectIndirect | null>(null);
  directRatio = this.#directRatio.asReadonly();

  #ownSub = signal<WorksyncOwnSub | null>(null);
  ownSub = this.#ownSub.asReadonly();

  #perProgram = signal<LineDetailChartData[]>([]);
  perProgram = this.#perProgram.asReadonly();

  #evolution = signal<WorkloadEvolution | null>(null);
  evolution = this.#evolution.asReadonly();

  #workloadWorkforce = signal<WorkloadWorkforce[]>([]);
  workloadWorkforce = this.#workloadWorkforce.asReadonly();

  #workloadPreview = signal<WorkloadPreview | null>(null);
  workloadPreview = this.#workloadPreview.asReadonly();

  #siglumValidationLists = signal<WorkloadAvailableSiglumLists | null>(null);
  siglumValidationLists = this.#siglumValidationLists.asReadonly();

  #canUpdate = signal<boolean>(false);
  canUpdate = this.#canUpdate.asReadonly();

  #hasOpenExercise = signal<boolean>(false);
  hasOpenExercise = this.#hasOpenExercise.asReadonly();

  private http: HttpClient = inject(HttpClient);
  private workloadEvolutionAdaper: WorkloadEvolutionAdapter = inject(WorkloadEvolutionAdapter);
  private workloadPerProgramAdaper: WorkloadPerProgramAdapter = inject(WorkloadPerProgramAdapter);
  private workloadWorkforceAdaper: WorkloadWorkforceAdapter = inject(WorkloadWorkforceAdapter);

  async getWorkloads(params?: string[]): Promise<void> {
    try {
      const workloadsAPI$ = this.http.get<WorkloadsApiResponse>(`${CRUD_WORKLOAD}${params ? `?${params.join('&')}` : ''}`).pipe(catchError(this.handleError));
      const workloadsAPI = await firstValueFrom(workloadsAPI$);
      this.#workloads.set(workloadsAPI.content);
      return this.#totalWorkloads.set(workloadsAPI.page?.totalElements);
    } catch (error) {
      this.#workloads.set([]);
      throw error;
    }
  }

  async addWorkload(workload: Partial<Workload>): Promise<Workload> {
    const workload$ = this.http.post<Workload>(`${CRUD_WORKLOAD}`, workload);
    return firstValueFrom(workload$);
  }

  addEmptyWorkload() {
    this.#workloads.set([{ go: true } as Workload, ...this.workloads()]);
  }

  async editWorkload(id: number, workload: Partial<Workload>): Promise<Workload> {
    const workload$ = this.http.put<Workload>(`${CRUD_WORKLOAD}/${id}`, workload);
    return firstValueFrom(workload$);
  }

  async editWorkloads(workloads: Partial<Workload>[]): Promise<Workload> {
    const workload$ = this.http.put<Workload>(`${CRUD_WORKLOAD}/batch`, workloads);
    return firstValueFrom(workload$);
  }

  async getPpsids(): Promise<void> {
    try {
      const ppsids$ = this.http.get<string[]>(`${CRUD_PPSID}/all`).pipe(catchError(this.handleError));
      this.#ppsids.set(await firstValueFrom(ppsids$));
    } catch (error) {
      this.#ppsids.set([]);
      throw error;
    }
  }

  async getPpsid(ppsid: string): Promise<Ppsid> {
    const response$ = this.http.get<Ppsid>(`${CRUD_PPSID}/ppsid/${ppsid}`).pipe(catchError(this.handleError));
    return firstValueFrom(response$);
  }

  async editPpsid(id: number, ppsid: Partial<Ppsid>): Promise<Workload> {
    const workload$ = this.http.put<Workload>(`${CRUD_PPSID}/${id}`, ppsid);
    return firstValueFrom(workload$);
  }

  async getDirectRatio(params?: string[]): Promise<void> {
    try {
      const ratioAPI$ = this.http.get<DirectIndirect>(`${GET_WORKLOAD_DIRECT_RATIO}${params ? `?${params.join('&')}` : ''}`).pipe(catchError(this.handleError));
      const ratioAPI = await firstValueFrom(ratioAPI$);
      this.#directRatio.set(ratioAPI);
    } catch (error) {
      this.#directRatio.set(null);
      throw error;
    }
  }

  async getOwnSubRatio(params?: string[]): Promise<void> {
    try {
      const ratioAPI$ = this.http
        .get<WorksyncOwnSub>(`${GET_WORKLOAD_OWN_SUB_RATIO}${params ? `?${params.join('&')}` : ''}`)
        .pipe(catchError(this.handleError));
      const ratioAPI = await firstValueFrom(ratioAPI$);
      this.#ownSub.set(ratioAPI);
    } catch (error) {
      this.#ownSub.set(null);
      throw error;
    }
  }

  async getWorkLoadPerProgram(params?: string[]): Promise<void> {
    try {
      const programsAPI$ = this.http
        .get<WorkloadPerProgramAPI[]>(`${GET_WORKLOAD_PER_PROGRAM}${params ? `?${params.join('&')}` : ''}`)
        .pipe(catchError(this.handleError));
      const programsAPI = await firstValueFrom(programsAPI$);
      const perProgramData = this.workloadPerProgramAdaper.adapt(programsAPI);
      this.#perProgram.set(perProgramData);
    } catch (error) {
      this.#perProgram.set([]);
      throw error;
    }
  }

  async getWorkLoadEvolution(params?: string[]): Promise<void> {
    try {
      const dataAPI$ = this.http
        .get<WorkloadEvolutionAPI>(`${GET_WORKLOAD_EVOLUTION}${params ? `?${params.join('&')}` : ''}`)
        .pipe(catchError(this.handleError));
      const dataAPI = await firstValueFrom(dataAPI$);
      const evolution: WorkloadEvolution | null = this.workloadEvolutionAdaper.adapt(dataAPI);
      this.#evolution.set(evolution);
    } catch (error) {
      this.#evolution.set(null);
      throw error;
    }
  }

  async getWorkLoadWorkforce(params?: string[]): Promise<void> {
    try {
      const dataAPI$ = this.http
        .get<WorkloadWorkforceAPI>(`${GET_WORKLOAD_WORKFORCE}${params ? `?${params.join('&')}` : ''}`)
        .pipe(catchError(this.handleError));
      const dataAPI = await firstValueFrom(dataAPI$);
      const workloadWorkforce: WorkloadWorkforce[] = this.workloadWorkforceAdaper.adapt(dataAPI);
      this.#workloadWorkforce.set(workloadWorkforce);
    } catch (error) {
      this.#workloadWorkforce.set([]);
      throw error;
    }
  }

  async getWorkloadPreview(params?: string[]): Promise<void> {
    try {
      const dataPreview$ = this.http.get<WorkloadPreview>(`${GET_WORKLOAD_PREVIEW}${params ? `?${params.join('&')}` : ''}`).pipe(catchError(this.handleError));
      const dataPreview = await firstValueFrom(dataPreview$);
      this.#workloadPreview.set(dataPreview);
    } catch (error) {
      this.#workloadPreview.set(null);
      throw error;
    }
  }

  async closeExercise(): Promise<WorkloadPostResponse> {
    const closeExercise$ = this.http
      .post(`${GET_WORKLOAD_EXERCISE_CLOSE}`, null, {
        headers: new HttpHeaders({
          Accept: 'application/json',
        }),
        observe: 'response',
        responseType: 'json',
      })
      .pipe(
        catchError((error: HttpErrorResponse) => {
          return throwError(() => ({
            status: error.status,
            message: error?.error?.error || error.message,
          }));
        }),
      );

    try {
      const response = (await firstValueFrom(closeExercise$)) as HttpResponse<string>;
      return {
        error: response.status !== 200,
        message: response.body || 'Success',
      };
    } catch (error) {
      return {
        error: true,
        message: (error as HttpErrorResponse).message || 'Error closing exercise',
      };
    }
  }

  async openExercise(exercise: string): Promise<WorkloadPostResponse> {
    const openExercise$ = this.http
      .post(`${GET_WORKLOAD_EXERCISE_OPEN}?exercise=${exercise}`, null, {
        headers: new HttpHeaders({
          Accept: 'application/json',
        }),
        observe: 'response',
        responseType: 'json',
      })
      .pipe(
        catchError((error: HttpErrorResponse) => {
          return throwError(() => ({
            status: error.status,
            message: error?.error?.error || error.message,
          }));
        }),
      );

    try {
      const response = await firstValueFrom(openExercise$);
      return {
        error: response.status !== 200,
        message: 'Success',
      };
    } catch (error) {
      return {
        error: true,
        message: (error as HttpErrorResponse).message || 'Error opening exercise',
      };
    }
  }

  async getWorkloadExport(params?: string[]): Promise<void> {
    const excelFile$ = this.http
      .get(`${GET_WORKLOAD_EXPORT}${params ? `?${params.join('&')}` : ''}`, {
        responseType: 'blob',
        observe: 'response',
        headers: new HttpHeaders({
          Accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        }),
      })
      .pipe(catchError(this.handleError));

    const response = await firstValueFrom(excelFile$);

    if (!response.body || response.body.size === 0) {
      throw new Error('Downloaded file is empty');
    }

    window.location.href = window.URL.createObjectURL(
      new Blob([response.body], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      }),
    );
  }

  async uploadWorkload(file: File, params?: string[]): Promise<WorkloadPostResponse> {
    const url = `${POST_WORKLOAD_IMPORT}${params ? `?${params.join('&')}` : ''}`;
    const formData = new FormData();
    formData.append('file', file);

    const upload$ = this.http
      .post(url, formData, {
        headers: new HttpHeaders({
          Accept: 'application/json',
        }),
        observe: 'response',
        responseType: 'json',
      })
      .pipe(
        catchError((error: HttpErrorResponse) => {
          return throwError(() => ({
            status: error.status,
            message: error?.error?.error || error.message,
          }));
        }),
      );

    try {
      const response = await firstValueFrom(upload$);
      return {
        error: response.status !== 200,
        message: 'Success',
      };
    } catch (error) {
      return {
        error: true,
        message: (error as HttpErrorResponse).message || 'Error importing file',
      };
    }
  }

  async getWorkloadSiglumsToSubmit(params?: string[]): Promise<void> {
    this.#siglumValidationLists.set(null);
    try {
      const siglumLists$ = this.http
        .get<WorkloadAvailableSiglumLists>(`${CRUD_WORKLOAD_EXERCISE_SUBMIT}${params ? `?${params.join('&')}` : ''}`)
        .pipe(catchError(this.handleError));
      const siglumLists = await firstValueFrom(siglumLists$);
      this.#siglumValidationLists.set(siglumLists);
    } catch (error) {
      this.#siglumValidationLists.set(null);
      throw error;
    }
  }

  async postWorkloadSiglumsToSubmit(siglums: WorkloadSubmitSiglumLists, params?: string[]): Promise<WorkloadPostResponse> {
    const siglumLists$ = this.http
      .post<WorkloadAvailableSiglumLists>(`${CRUD_WORKLOAD_EXERCISE_SUBMIT}${params ? `?${params.join('&')}` : ''}`, siglums, {
        headers: new HttpHeaders({
          Accept: 'application/json',
        }),
        observe: 'response',
        responseType: 'json',
      })
      .pipe(
        catchError((error: HttpErrorResponse) => {
          return throwError(() => ({
            status: error.status,
            message: error?.error?.error || error.message,
          }));
        }),
      );

    try {
      const response = await firstValueFrom(siglumLists$);
      return {
        error: response.status !== 200,
        message: 'Success',
      };
    } catch (error) {
      return {
        error: true,
        message: (error as HttpErrorResponse).message || 'Error submitting siglums',
      };
    }
  }

  async getWorkloadSiglumsToValidate(params?: string[]): Promise<void> {
    this.#siglumValidationLists.set(null);
    try {
      const siglumLists$ = this.http
        .get<WorkloadAvailableSiglumLists>(`${CRUD_WORKLOAD_EXERCISE_VALIDATE}${params ? `?${params.join('&')}` : ''}`)
        .pipe(catchError(this.handleError));
      const siglumLists = await firstValueFrom(siglumLists$);
      this.#siglumValidationLists.set(siglumLists);
    } catch (error) {
      console.log(error);
      this.#siglumValidationLists.set(null);
      throw error;
    }
  }

  async postWorkloadSiglumsToValidate(siglums: WorkloadValidationSiglumLists, params?: string[]): Promise<WorkloadPostResponse> {
    const siglumLists$ = this.http
      .post<WorkloadAvailableSiglumLists>(`${CRUD_WORKLOAD_EXERCISE_VALIDATE}${params ? `?${params.join('&')}` : ''}`, siglums, {
        headers: new HttpHeaders({
          Accept: 'application/json',
        }),
        observe: 'response',
        responseType: 'json',
      })
      .pipe(
        catchError((error: HttpErrorResponse) => {
          return throwError(() => ({
            status: error.status,
            message: error?.error?.error || error.message,
          }));
        }),
      );

    try {
      const response = await firstValueFrom(siglumLists$);
      return {
        error: response.status !== 200,
        message: 'Success',
      };
    } catch (error) {
      return {
        error: true,
        message: (error as HttpErrorResponse).message || 'Error validating siglums',
      };
    }
  }

  async getCanUpdate(userName: string): Promise<void> {
    try {
      const canUpdate$ = this.http.get<{ canUpdateWorkload: boolean }>(`${WORKLOAD_CAN_UPDATE}?userSelected=${userName}`).pipe(catchError(this.handleError));
      const canUpdate = await firstValueFrom(canUpdate$);
      this.#canUpdate.set(canUpdate?.canUpdateWorkload || false);
    } catch (error) {
      this.#canUpdate.set(false);
      throw error;
    }
  }

  async getOpenExercise(): Promise<void> {
    try {
      const openExercise$ = this.http.get<{ existsOpenedExercise: boolean }>(`${WORKLOAD_OPEN_EXERCISE}`).pipe(catchError(this.handleError));
      const openExercise = await firstValueFrom(openExercise$);
      this.#hasOpenExercise.set(openExercise?.existsOpenedExercise || false);
    } catch (error) {
      this.#hasOpenExercise.set(false);
      throw error;
    }
  }

  private handleError(error: HttpErrorResponse) {
    console.error('An error occurred:', error.message, error);
    return throwError(() => new Error('Something bad happened; please try again later.' + error.message));
  }
}
