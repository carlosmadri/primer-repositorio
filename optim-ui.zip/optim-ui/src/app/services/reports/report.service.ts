import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '@services/auth/auth.service';
import { API_URL } from '@app/shared/api.urls';

@Injectable({
  providedIn: 'root',
})
export class ReportService {
  private http: HttpClient = inject(HttpClient);
  private auth = inject(AuthService);

  protected readonly user = this.auth.user;

  async generateReport(reportName: string, params: string[]) {
    const report$ = this.http.get<Blob>(`${API_URL}${reportName}?${params.join('&')}`, {
      headers: new HttpHeaders({
        Accept: 'application/octet-stream',
      }),
      observe: 'response',
      responseType: 'blob' as 'json',
    });
    try {
      const response = (await firstValueFrom(report$)) as HttpResponse<Blob>;
      const a = document.createElement('a');
      document.body.appendChild(a);
      const blob = response.body!;
      const url = window.URL.createObjectURL(blob);
      a.href = url;
      a.download = `${reportName}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
      return {
        error: false,
      };
    } catch (error) {
      return {
        error: true,
        message: (error as HttpErrorResponse).message || 'Error generating report',
      };
    }
  }
}
