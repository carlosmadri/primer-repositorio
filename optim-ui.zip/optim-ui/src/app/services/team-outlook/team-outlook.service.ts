import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { GET_TEAM_OUTLOOK, GET_TEAM_OUTLOOK_WORKLOAD } from '@app/shared/api.urls';
import { TeamOutlookApi, TeamOutlook, TeamOutlookWorkload } from '@app/shared/models/team-outlook.model';
import { TeamOutlookAdapter } from '@src/app/shared/adapters/team-outlook/team-outlook.adapter';
import { firstValueFrom, catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class TeamOutlookService {
  #teamOutlook = signal<TeamOutlook | null>(null);
  teamOutlook = this.#teamOutlook.asReadonly();

  #teamOutlookWorkload = signal<TeamOutlookWorkload | null>(null);
  teamOutlookWorkload = this.#teamOutlookWorkload.asReadonly();

  private http: HttpClient = inject(HttpClient);
  private teamOutlookAdapter: TeamOutlookAdapter = inject(TeamOutlookAdapter);

  async getTeamOutlook(params?: string[]): Promise<void> {
    try {
      const apiData$ = this.http.get<TeamOutlookApi>(`${GET_TEAM_OUTLOOK}${params ? `?${params.join('&')}` : ''}`).pipe(catchError(this.handleError));
      const response = await firstValueFrom(apiData$);
      const teamOutlook = this.teamOutlookAdapter.adapt(response);
      this.#teamOutlook.set(teamOutlook);
    } catch (error) {
      this.#teamOutlook.set(null);
      throw error;
    }
  }

  async getTeamOutlookWorkload(params?: string[]): Promise<void> {
    try {
      const apiData$ = this.http
        .get<TeamOutlookWorkload>(`${GET_TEAM_OUTLOOK_WORKLOAD}${params ? `?${params.join('&')}` : ''}`)
        .pipe(catchError(this.handleError));
      const response = await firstValueFrom(apiData$);
      const exerciseType = response.lastExerciseName.substring(0, 2).toLowerCase() === 'fc' ? 'fc' : 'op';
      response.exerciseType = exerciseType;
      this.#teamOutlookWorkload.set(response);
    } catch (error) {
      this.#teamOutlookWorkload.set(null);
      throw error;
    }
  }

  private handleError(error: HttpErrorResponse) {
    console.error('An error occurred:', error.message);
    return throwError(() => new Error('Something bad happened; please try again later.' + error.message));
  }
}
