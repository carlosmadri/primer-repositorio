export interface MockConfig {
  url: string;
  mockFile: string;
}

export const MOCK_ENDPOINTS: MockConfig[] = [
  {
    url: '/employee/team-outlook?',
    mockFile: 'team-outlook.json',
  },
  {
    url: '/workloads/home-team-outlook-workload?',
    mockFile: 'team-outlook-workload.json',
  },
  {
    url: '/employee/sum-levers-by-type?',
    mockFile: 'sum-levers-by-type.json',
  },
  {
    url: '/job-requests/count-by-type?',
    mockFile: 'count-by-type.json',
  },
  {
    url: '/workloads/evolution?',
    mockFile: 'evolution.json',
  },
  {
    url: '/workloads/own-sub-ratio?',
    mockFile: 'own-sub-ratio.json',
  },
  {
    url: '/workloads/indirect-ratio?',
    mockFile: 'workload-indirect-ratio.json',
  },
  {
    url: '/workloads/workforce?',
    mockFile: 'workload-workforce.json',
  },
  {
    url: '/workloads/per-program?',
    mockFile: 'per-program.json',
  },
  {
    url: '/workloads/preview?',
    mockFile: 'preview.json',
  },
  {
    url: '/purchase-orders/subcontracting-graphics?',
    mockFile: 'subcontracting-graphics.json',
  },
  {
    url: '/employee/monthly-distribution?',
    mockFile: 'monthly-distribution.json',
  },
  {
    url: '/employee/borrowed-vs-leased?',
    mockFile: 'borrowed-vs-leased.json',
  },
];
