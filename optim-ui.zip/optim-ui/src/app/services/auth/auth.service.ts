import { computed, inject, Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Role, User, USER_NAME_FILTER, UserAPI } from '@models/user.model';
import { GET_USER } from '@src/app/shared/api.urls';
import { firstValueFrom } from 'rxjs';
import { StorageService } from '../storage/storage.service';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  storageService = inject(StorageService);
  http = inject(HttpClient);

  #user = signal<User | null>(null);
  user = this.#user.asReadonly();

  isAuth = computed(() => this.user() !== null);

  constructor() {
    if (!this.loadUser()) {
      this.login('admin');
    } else {
      this.login(this.user()!.userName);
    }
  }

  async login(userName: string): Promise<void> {
    try {
      const user$ = this.http.get<UserAPI>(`${GET_USER}?userSelected=${userName}`);
      const userAPI = await firstValueFrom(user$);
      const user: User = { siglum: userAPI.siglum, visibleSiglums: userAPI.visibleSiglums, userName, role: userAPI.userRol as Role, JWT: '' };
      this.saveUser(user);
    } catch (error) {
      console.log(error);
      this.storageService.clearToken();
      throw error;
    }
  }

  loadUser(): boolean {
    const user = this.storageService.getUser();
    if (user) {
      this.#user.set(user);
      return true;
    }
    return false;
  }

  saveUser(user: User) {
    this.#user.set(user);
    this.storageService.saveUser(user);
  }

  clearToken() {
    this.#user.set(null);
    this.storageService.clearToken();
  }

  getUserNameFilter() {
    const user = this.user();
    if (user?.userName) {
      return `${USER_NAME_FILTER}=${user.userName}`;
    }
    return;
  }
}
