import { Injectable } from '@angular/core';
import { BORROWED_CHART_DATA, BorrowedLeased, BorrowedLeasedAPI } from '../../models/borrowed-leased.model';
import { Adapter } from '../adapter.interface';
import { MultiLineChartData, MONTHS_LIST } from '../../models/graphs/multiline-chart.model';

@Injectable({
  providedIn: 'root',
})
export class BorrowedLeasedAdapter implements Adapter<BorrowedLeasedAPI, BorrowedLeased> {
  adapt(data: BorrowedLeasedAPI): BorrowedLeased | null {
    if (!data) {
      return null;
    }

    const chartData: MultiLineChartData = {
      month: MONTHS_LIST,
      labels: ['Borrowed', 'Leased'],
      colors: BORROWED_CHART_DATA.map((data) => data.color),
      isAvg: BORROWED_CHART_DATA.map(() => false),
      values: [data.borrowedMonthlyDistribution, data.leasedMonthlyDistribution],
    };

    const borrowedLeased: BorrowedLeased = {
      chartData: chartData,
      averageBorrowed: data.averageBorrowed,
      averageLeased: data.averageLeased,
      netDifference: data.netDifference,
    };

    return borrowedLeased;
  }
}
