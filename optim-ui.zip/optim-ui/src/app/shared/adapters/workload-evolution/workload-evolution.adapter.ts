import { inject, Injectable } from '@angular/core';
import { Adapter } from '../adapter.interface';
import {
  ChartIds,
  WorkloadEvolution,
  WorkloadEvolutionAPI,
  WorkloadEvolutionBarData,
  WorkloadEvolutionBarType,
  WorkloadEvolutionListAPI,
  WorkloadEvolutionStatusAPI,
  WorkloadSubmissionStatus,
  WorkloadValidationStatus,
} from '../../models/worksync.model';
import * as numberUtils from '@src/utils/number-utils';
import { ChartSelectorService } from '@src/app/services/chart-selector/chart-selector.service';

@Injectable({
  providedIn: 'root',
})
export class WorkloadEvolutionAdapter implements Adapter<WorkloadEvolutionAPI, WorkloadEvolution | null> {
  chartSelectorService = inject(ChartSelectorService);

  OpPattern = /^OP\d+$/;
  FCPattern = /^FCII\d+$/;

  adapt(data: WorkloadEvolutionAPI | null): WorkloadEvolution | null {
    if (!data || !data.workloadEvolutionList || data.workloadEvolutionList.length === 0) {
      return null;
    }

    const chartData: WorkloadEvolutionBarData[] = data.workloadEvolutionList.map((item) => {
      return {
        exercise: this.getExerciseName(item, data.wipValue),
        id: this.getIdFromExerciseName(item.exercise),
        barType: data.multipleSiglums
          ? this.setMultipleBarType(data.lastStatus)
          : this.setIndividualBarType(data.lastStatus, item.exercise, data.workloadEvolutionList),
        ownDirect: numberUtils.roundToDecimalPlaces(item.khrsOwnDirect, 1),
        ownIndirect: numberUtils.roundToDecimalPlaces(item.khrsOwnIndirect, 1),
        subDirect: numberUtils.roundToDecimalPlaces(item.khrsSubDirect, 1),
        subIndirect: numberUtils.roundToDecimalPlaces(item.khrsSubIndirect, 1),
        total: numberUtils.roundToDecimalPlaces(item.khrsOwnDirect + item.khrsOwnIndirect + item.khrsSubDirect + item.khrsSubIndirect, 1),
      };
    });

    const submissionStatus = this.submissionStatus(data);
    const validationStatus = this.validationStatus(data);

    const evolutionData: WorkloadEvolution = {
      data: chartData,
      multipleSiglums: data.multipleSiglums,
      submissionStatus,
      validationStatus,
    };

    return evolutionData;
  }

  private setIndividualBarType(
    status: WorkloadEvolutionStatusAPI,
    exercise: string,
    workLoadEvolutionList: WorkloadEvolutionListAPI[],
  ): WorkloadEvolutionBarType {
    if (this.isOpExercise(exercise)) {
      return WorkloadEvolutionBarType.OP;
    } else if (this.isFcExercise(exercise)) {
      return WorkloadEvolutionBarType.FCII;
    } else if (!this.isLastStep(exercise, workLoadEvolutionList)) {
      return WorkloadEvolutionBarType.APPROVED;
    } else if (status === WorkloadEvolutionStatusAPI.REJECTED) {
      return WorkloadEvolutionBarType.REJECTED;
    } else if (status === WorkloadEvolutionStatusAPI.APPROVED) {
      return WorkloadEvolutionBarType.APPROVED;
    } else if (status === WorkloadEvolutionStatusAPI.OPENED) {
      return WorkloadEvolutionBarType.WIP;
    } else if (status === WorkloadEvolutionStatusAPI.SUBMIT) {
      return WorkloadEvolutionBarType.SUBMIT;
    } else {
      return WorkloadEvolutionBarType.WIP;
    }
  }

  private setMultipleBarType(status: WorkloadEvolutionStatusAPI): WorkloadEvolutionBarType {
    if (status === WorkloadEvolutionStatusAPI.REJECTED) {
      return WorkloadEvolutionBarType.REJECTED;
    } else if (status === WorkloadEvolutionStatusAPI.APPROVED) {
      return WorkloadEvolutionBarType.APPROVED;
    } else {
      return WorkloadEvolutionBarType.MULTIPLE;
    }
  }

  private submissionStatus(data: WorkloadEvolutionAPI): WorkloadSubmissionStatus {
    if (data.multipleSiglums) {
      return WorkloadSubmissionStatus.MULTIPLE;
    }
    const hasFirstSubmission = data.workloadEvolutionList.some((value) => value.exercise === 'First Submission');
    if (hasFirstSubmission && data.lastStatus !== WorkloadEvolutionStatusAPI.REJECTED) {
      return WorkloadSubmissionStatus.SUBMITTED;
    }
    return WorkloadSubmissionStatus.NOT_SUBMITTED;
  }

  private validationStatus(data: WorkloadEvolutionAPI): WorkloadValidationStatus | undefined {
    if (data.multipleSiglums) {
      return WorkloadValidationStatus.MULTIPLE;
    }
    const hasFirstSubmission = data.workloadEvolutionList.some((value) => value.exercise === 'First Submission');
    const isLastStep = data.workloadEvolutionList[data.workloadEvolutionList.length - 1].exercise === 'HOT1Q';
    if (hasFirstSubmission && data.lastStatus === WorkloadEvolutionStatusAPI.REJECTED) {
      return WorkloadValidationStatus.CHALLENGED;
    } else if (hasFirstSubmission && isLastStep && data.lastStatus === WorkloadEvolutionStatusAPI.APPROVED) {
      return WorkloadValidationStatus.VALIDATED;
    } else if (hasFirstSubmission) {
      return WorkloadValidationStatus.PENDING;
    }
    return;
  }

  private getExerciseName(data: WorkloadEvolutionListAPI, wipValue: string): string {
    if (data.exercise === wipValue) {
      return 'WIP';
    } else if (this.isFcExercise(data.exercise)) {
      return WorkloadEvolutionBarType.FCII;
    }
    return data.exercise;
  }

  private getIdFromExerciseName(exercise: string): ChartIds {
    if (this.isOpExercise(exercise)) {
      return ChartIds.OP;
    } else if (this.isFcExercise(exercise) || exercise === 'FCII') {
      return ChartIds.FCII;
    } else if (exercise === 'First Submission') {
      return ChartIds.FIRST_SUBMISSION;
    } else if (exercise === 'QMC') {
      return ChartIds.QMC;
    } else if (exercise === 'HOT1Q') {
      return ChartIds.HOT1Q;
    }
    return ChartIds.WIP;
  }

  filterWorkloadEvolutionLines(data: WorkloadEvolutionBarData[], selectedChecksIds: ChartIds[]): WorkloadEvolutionBarData[] {
    const exerciseIds = data.map((value) => value.id);

    const result = data.filter((value, index) => selectedChecksIds.includes(exerciseIds[index]));
    return result;
  }

  private isOpExercise(exercise: string): boolean {
    return this.OpPattern.test(exercise);
  }

  private isFcExercise(exercise: string): boolean {
    return this.FCPattern.test(exercise);
  }

  private isLastStep(exercise: string, workLoadEvolutionList: WorkloadEvolutionListAPI[]): boolean {
    const exercisesList = workLoadEvolutionList.map((value) => value.exercise);
    if (exercise === ChartIds.HOT1Q) {
      return true;
    }
    if (exercise === ChartIds.QMC && exercisesList.includes(ChartIds.HOT1Q)) {
      return false;
    }
    if (exercise === 'BU' && (exercisesList.includes('First Submission') || exercisesList.includes('First Submition'))) {
      return false;
    }
    if (exercise === 'First Submission' && exercisesList.includes(ChartIds.QMC)) {
      return false;
    }
    return true;
  }
}
