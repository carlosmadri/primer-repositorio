import { TestBed } from '@angular/core/testing';

import { WorkloadEvolutionAdapter } from './workload-evolution.adapter';
import {
  ChartIds,
  WorkloadEvolution,
  WorkloadEvolutionAPI,
  WorkloadEvolutionBarType,
  WorkloadEvolutionStatusAPI,
  WorkloadSubmissionStatus,
  WorkloadValidationStatus,
} from '../../models/worksync.model';

describe('WorkloadEvolutionAdapter', () => {
  let service: WorkloadEvolutionAdapter;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WorkloadEvolutionAdapter);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('adapt', () => {
    it('should return an empty array if data is empty', () => {
      const result = service.adapt(null);
      expect(result).toEqual(null);
    });

    it('should correctly adapt data validated', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [
          {
            exercise: 'OP24',
            khrsOwnDirect: 1,
            khrsOwnIndirect: 2,
            khrsSubDirect: 3,
            khrsSubIndirect: 4.18,
          },
          {
            exercise: 'First Submission',
            khrsOwnDirect: 1,
            khrsOwnIndirect: 2,
            khrsSubDirect: 3,
            khrsSubIndirect: 4.18,
          },
          {
            exercise: 'QMC',
            khrsOwnDirect: 5,
            khrsOwnIndirect: 6,
            khrsSubDirect: 7,
            khrsSubIndirect: 8,
          },
          {
            exercise: 'HOT1Q',
            khrsOwnDirect: 5,
            khrsOwnIndirect: 6,
            khrsSubDirect: 7,
            khrsSubIndirect: 10,
          },
        ],
        lastStatus: WorkloadEvolutionStatusAPI.APPROVED,
        multipleSiglums: false,
        wipValue: '',
      };

      const expected: WorkloadEvolution = {
        data: [
          {
            exercise: 'OP24',
            id: ChartIds.OP,
            barType: WorkloadEvolutionBarType.OP,
            ownDirect: 1,
            ownIndirect: 2,
            subDirect: 3,
            subIndirect: 4.2,
            total: 10.2,
          },
          {
            exercise: 'First Submission',
            id: ChartIds.FIRST_SUBMISSION,
            barType: WorkloadEvolutionBarType.APPROVED,
            ownDirect: 1,
            ownIndirect: 2,
            subDirect: 3,
            subIndirect: 4.2,
            total: 10.2,
          },
          {
            exercise: 'QMC',
            barType: WorkloadEvolutionBarType.APPROVED,
            id: ChartIds.QMC,
            ownDirect: 5,
            ownIndirect: 6,
            subDirect: 7,
            subIndirect: 8,
            total: 26,
          },
          {
            exercise: 'HOT1Q',
            barType: WorkloadEvolutionBarType.APPROVED,
            id: ChartIds.HOT1Q,
            ownDirect: 5,
            ownIndirect: 6,
            subDirect: 7,
            subIndirect: 10,
            total: 28,
          },
        ],
        multipleSiglums: false,
        submissionStatus: WorkloadSubmissionStatus.SUBMITTED,
        validationStatus: WorkloadValidationStatus.VALIDATED,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });

    it('should correctly adapt data in QMC state', () => {
      const input: WorkloadEvolutionAPI = {
        workloadEvolutionList: [
          {
            exercise: 'OP24',
            khrsOwnDirect: 1,
            khrsOwnIndirect: 2,
            khrsSubDirect: 3,
            khrsSubIndirect: 4.18,
          },
          {
            exercise: 'First Submission',
            khrsOwnDirect: 1,
            khrsOwnIndirect: 2,
            khrsSubDirect: 3,
            khrsSubIndirect: 4.18,
          },
          {
            exercise: 'QMC',
            khrsOwnDirect: 5,
            khrsOwnIndirect: 6,
            khrsSubDirect: 7,
            khrsSubIndirect: 8,
          },
        ],
        lastStatus: WorkloadEvolutionStatusAPI.REJECTED,
        multipleSiglums: false,
        wipValue: 'QMC',
      };

      const expected: WorkloadEvolution = {
        data: [
          {
            exercise: 'OP24',
            id: ChartIds.OP,
            barType: WorkloadEvolutionBarType.OP,
            ownDirect: 1,
            ownIndirect: 2,
            subDirect: 3,
            subIndirect: 4.2,
            total: 10.2,
          },
          {
            exercise: 'First Submission',
            id: ChartIds.FIRST_SUBMISSION,
            barType: WorkloadEvolutionBarType.APPROVED,
            ownDirect: 1,
            ownIndirect: 2,
            subDirect: 3,
            subIndirect: 4.2,
            total: 10.2,
          },
          {
            exercise: 'WIP',
            barType: WorkloadEvolutionBarType.REJECTED,
            id: ChartIds.QMC,
            ownDirect: 5,
            ownIndirect: 6,
            subDirect: 7,
            subIndirect: 8,
            total: 26,
          },
        ],
        multipleSiglums: false,
        submissionStatus: WorkloadSubmissionStatus.NOT_SUBMITTED,
        validationStatus: WorkloadValidationStatus.CHALLENGED,
      };

      const result = service.adapt(input);
      expect(result).toEqual(expected);
    });
  });
});
