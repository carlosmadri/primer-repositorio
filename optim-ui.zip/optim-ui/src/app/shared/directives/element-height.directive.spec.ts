import { ElementHeightDirective } from './element-height.directive';
import { ElementRef } from '@angular/core';

describe('ElementHeightDirective', () => {
  beforeEach(() => {
    // Define the mock ResizeObserver with proper types
    const MockResizeObserver: typeof ResizeObserver = jest.fn().mockImplementation(() => ({
      observe: jest.fn(),
      disconnect: jest.fn(),
      unobserve: jest.fn(),
    }));

    // Assign the mock to window
    Object.defineProperty(window, 'ResizeObserver', {
      writable: true,
      configurable: true,
      value: MockResizeObserver,
    });
  });

  it('should create an instance', () => {
    const mockElementRef = {
      nativeElement: document.createElement('div'),
    } as ElementRef;

    const directive = new ElementHeightDirective(mockElementRef);

    expect(directive).toBeTruthy();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });
});
