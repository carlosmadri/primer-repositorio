export interface LeversTotal {
  leverType: string;
  leaver: number;
  recovery: number;
}

export interface LeversTotalAPI {
  leverType: string;
  leaver: number;
  recovery: number;
}
