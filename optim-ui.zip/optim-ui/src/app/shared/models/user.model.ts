import { Siglum } from './siglum.model';

export enum Role {
  ADMIN = 'admin',
  REGULAR = 'regular',
}

export interface UserAPI {
  userRol: string;
  siglum?: Siglum;
  visibleSiglums?: Siglum[];
}

export interface User {
  role: Role.ADMIN | Role.REGULAR;
  userName: string;
  siglum?: Siglum;
  visibleSiglums?: Siglum[];
  JWT: string;
}

export const USER_NAME_FILTER = 'userSelected';
