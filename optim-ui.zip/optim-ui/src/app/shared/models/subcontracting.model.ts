export interface Subcontracting {
  id: number;
  siglum: string;
  site: string;
  description: string;
  provider: string;
  approved: string;
  quarter: string;
  year: string;
  orderRequest: string;
  hmg: string;
  pep: string;
  keur: number;
  orderId: number;
}

export interface SubcontractsApiResponse {
  content: Subcontracting[];
  page: {
    number: number;
    size: number;
    totalElements: number;
    totalPages: number;
  };
}

export interface SubcontractingGraphs {
  purchaseOrders: number;
  purchaseRequest: number;
  baseline: number;
  khrsPerQuarter: {
    purchaseNotAproved: SubcontractingKhrsPerQuarter[];
    purchaseAproved: SubcontractingKhrsPerQuarter[];
  };
}

export interface SubcontractingKhrsPerQuarter {
  quarter: string;
  keur: number;
}
