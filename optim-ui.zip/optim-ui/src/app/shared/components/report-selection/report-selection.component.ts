import { ChangeDetectionStrategy, Component, inject, TemplateRef, ViewChild } from '@angular/core';
import { MatFormField } from '@angular/material/form-field';
import { MatSelect, MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { MatDialog, MatDialogConfig, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { GenericDialogComponent } from '@components/generic-dialog/generic-dialog.component';
import { ReportService } from '@services/reports/report.service';
import { DialogService } from '@services/dialog-service/dialog.service';
import { MatButton } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { FiltersService } from '@services/filters/filters.service';
import { MatListModule, MatListOption } from '@angular/material/list';
import { MatCardModule } from '@angular/material/card';
import { AuthService } from '@services/auth/auth.service';

interface Report {
  value: string;
  label: string;
}

interface Param extends Report {
  id: number;
  checked: boolean;
}

const DIALOG_CONFIG: MatDialogConfig = {
  panelClass: 'no-border-radius-dialog',
  width: '25%',
  height: '25%',
  maxWidth: '100vw',
  maxHeight: '100vh',
};
const CUSTOM_DIALOG_CONFIG: MatDialogConfig = {
  panelClass: 'no-border-radius-dialog',
  width: '700px',
  height: '90%',
  maxWidth: '100vw',
  maxHeight: '100vh',
};

@Component({
  selector: 'optim-report-selection',
  standalone: true,
  imports: [
    MatInputModule,
    MatFormField,
    MatSelect,
    FormsModule,
    MatButton,
    MatDialogModule,
    MatIconModule,
    MatSelectModule,
    MatListOption,
    MatListModule,
    MatCardModule,
  ],
  templateUrl: './report-selection.component.html',
  styleUrl: './report-selection.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReportSelectionComponent {
  readonly dialog = inject(MatDialog);
  private dialogService = inject(DialogService);
  private reportService = inject(ReportService);
  private filtersService = inject(FiltersService);
  private authService = inject(AuthService);
  reportSelectDialog: MatDialogRef<GenericDialogComponent, unknown> | undefined;
  @ViewChild('reportSelectionTemplate') reportSelectionTemplate!: TemplateRef<unknown>;
  @ViewChild('workforceCustomReportTemplate') workforceCustomReportTemplate!: TemplateRef<unknown>;

  selectedReport!: string;
  selectedFields: string[] = [];
  selectedProjection = 'endOfYear';

  reports: Report[] = [
    { value: 'employee/reports/siglum4-end-of-year', label: 'Siglum4 - EoY' },
    { value: 'employee/reports/siglum5-end-of-year', label: 'Siglum5 - EoY' },
    { value: 'employee/reports/site-end-of-year', label: 'Site - EoY' },
    { value: 'employee/reports/employees-end-of-year', label: 'Employees' },
    { value: 'job-requests/reports/jobRequest-closed', label: 'All JR' },
    { value: 'job-requests/reports/jobRequest-by-status', label: 'JR Pending Validation' },
    { value: 'purchase-orders/report/subcontracting-table', label: 'Purchase Orders' },
    { value: 'employee/reports/employee-workforce', label: 'Workforce Custom Report' },
  ];

  allParams: Param[] = [
    { id: 1, value: 'SiglumHR', label: 'Siglum HR', checked: false },
    { id: 2, value: 'Siglum6', label: 'Siglum 6', checked: false },
    { id: 3, value: 'Siglum5', label: 'Siglum 5', checked: false },
    { id: 4, value: 'Siglum4', label: 'Siglum 4', checked: false },
    { id: 5, value: 'Country', label: 'Country', checked: false },
    { id: 6, value: 'Site', label: 'Site', checked: false },
    { id: 7, value: 'WorkerId', label: 'Worker ID', checked: false },
    { id: 8, value: 'ActiveWorkforce', label: 'Active Workforce', checked: false },
    { id: 9, value: 'KAPIS Code', label: 'KAPIS Code', checked: false },
    { id: 10, value: 'WC/BC', label: 'WC / BC', checked: false },
    { id: 11, value: 'LastName', label: 'Lastname', checked: false },
    { id: 12, value: 'FirstName', label: 'Firstname', checked: false },
    { id: 13, value: 'Job', label: 'Job', checked: false },
    { id: 14, value: 'AvailabilityReason', label: 'Availability Reason', checked: false },
    { id: 15, value: 'Direct', label: 'Direct / Indirect', checked: false },
    { id: 16, value: 'ContractType', label: 'Contract Type', checked: false },
    { id: 17, value: 'CostCenter', label: 'KAPIS Code', checked: false },
  ];

  availableParams = this.allParams;
  selectedParams: Param[] = [];
  checkedSelected: Param[] = [];
  checkedAvailable: Param[] = [];

  checkedSelectedParams() {
    return this.selectedParams.filter((param) => param.checked);
  }

  checkedAvailableParams() {
    return this.availableParams.filter((param) => param.checked);
  }

  openSelectionDialog() {
    this.reportSelectDialog = this.dialog.open(GenericDialogComponent, {
      ...DIALOG_CONFIG,
      data: {
        title: 'Select Report',
        content: this.reportSelectionTemplate,
      },
    });
  }

  async generateReport() {
    if (this.selectedReport === 'employee/reports/employee-workforce') {
      this.reportSelectDialog?.close();
      this.openWFCustomReportDialog();
    } else {
      const response = await this.reportService.generateReport(this.selectedReport, [
        this.authService.getUserNameFilter()!,
        this.filtersService.getYearParams()!,
      ]);
      if (!response.error) {
        this.reportSelectDialog?.close();
      } else {
        await this.dialogService.openMessageDialog('Report error', response.message as string, 'error');
      }
    }
  }

  openWFCustomReportDialog() {
    this.reportSelectDialog = this.dialog.open(GenericDialogComponent, {
      ...CUSTOM_DIALOG_CONFIG,
      data: {
        title: 'Custom Workforce report',
        content: this.workforceCustomReportTemplate,
      },
    });
  }

  async generateWFCustomReport() {
    this.selectedParams.sort((a, b) => (a.id < b.id ? -1 : 1));
    const fields: string[] = this.selectedParams.map((param) => `fields=${param.value}`);
    fields.push(`projection=${this.selectedProjection}`);
    const response = await this.reportService.generateReport(this.selectedReport, [
      ...fields,
      this.authService.getUserNameFilter()!,
      this.filtersService.getYearParams()!,
    ]);
    if (!response.error) {
      this.reportSelectDialog?.close();
    } else {
      await this.dialogService.openMessageDialog('Report error', response.message as string, 'error');
    }
  }

  availableClicked(idx: number) {
    this.availableParams[idx].checked = !this.availableParams[idx].checked;
  }

  selectedClicked(idx: number) {
    this.selectedParams[idx].checked = !this.selectedParams[idx].checked;
  }

  checkAllAvailable() {
    this.availableParams.forEach((param) => {
      param.checked = true;
    });
  }

  checkAllSelected() {
    this.selectedParams.forEach((param) => {
      param.checked = true;
    });
  }

  addToSelected() {
    const checked = this.checkedAvailableParams().map((el) => {
      return { ...el, checked: false };
    });
    this.availableParams = this.availableParams.filter((param) => !param.checked);
    this.selectedParams = this.selectedParams.concat(checked);
  }

  removeFromSelected() {
    const checked = this.checkedSelectedParams().map((el) => {
      return { ...el, checked: false };
    });
    this.selectedParams = this.selectedParams.filter((param) => !param.checked);
    this.availableParams = this.availableParams.concat(checked);
  }
}
