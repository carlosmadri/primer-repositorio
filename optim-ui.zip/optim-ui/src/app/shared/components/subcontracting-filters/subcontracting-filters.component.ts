import { ChangeDetectionStrategy, Component, computed, inject, output } from '@angular/core';
import { ClickStopPropagationDirective } from '@app/shared/directives/click-stop-propagation/click-stop-propagation.directive';
import { MatOption } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButton, MatFabButton } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { FiltersService, SubcontractingFilter } from '@services/filters/filters.service';
import { directIndirectValues } from '@models/employee.model';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { provideMomentDateAdapter } from '@angular/material-moment-adapter';
import { Moment } from 'moment';

export const MY_FORMATS = {
  parse: {
    dateInput: 'YYYY',
  },
  display: {
    dateInput: 'YYYY',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY',
  },
};

export interface SubcontractingFormFilter {
  siglum: FormControl<string | null>;
  site: FormControl<string[]>;
  description: FormControl<string | null>;
  approved: FormControl<string | null>;
  quarter: FormControl<string | null>;
  year: FormControl<string | null>;
  keur: FormControl<number | null>;
  provider: FormControl<string | null>;
  orderRequest: FormControl<string | null>;
  orderId: FormControl<number | null>;
  hmg: FormControl<string | null>;
  pep: FormControl<string | null>;
}

@Component({
  selector: 'optim-subcontracting-filters',
  standalone: true,
  imports: [
    ClickStopPropagationDirective,
    MatOption,
    MatFormFieldModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatButton,
    MatIconModule,
    MatFabButton,
    MatInputModule,
    MatDatepickerModule,
  ],
  providers: [
    // Moment can be provided globally to your app by adding `provideMomentDateAdapter`
    // to your app config. We provide it at the component level here, due to limitations
    // of our example generation script.
    provideMomentDateAdapter(MY_FORMATS),
  ],
  templateUrl: './subcontracting-filters.component.html',
  styleUrl: './subcontracting-filters.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SubcontractingFiltersComponent {
  private filterService = inject(FiltersService);
  form: FormGroup<SubcontractingFormFilter> = this.getFormGroup();
  activeFilters = output<boolean>();
  allQuarters = ['Q1', 'Q2', 'Q3', 'Q4'];
  allSiglumsHR = computed<string[]>(() => this.filterService.getAllSiglumsHR());
  allSites = computed<string[]>(() => this.filterService.getFilterValues('site'));
  allDirects = directIndirectValues;

  private getFormGroup(): FormGroup<SubcontractingFormFilter> {
    const fg = new FormGroup({
      siglum: new FormControl<string | null>(null),
      site: new FormControl<string[]>([]),
      description: new FormControl<string | null>(null),
      approved: new FormControl<string | null>(null),
      quarter: new FormControl<string | null>(null),
      year: new FormControl<string | null>(null),
      keur: new FormControl<number | null>(null),
      provider: new FormControl<string | null>(null),
      orderRequest: new FormControl<string | null>(null),
      orderId: new FormControl<number | null>(null),
      hmg: new FormControl<string | null>(null),
      pep: new FormControl<string | null>(null),
    } as SubcontractingFormFilter);

    return fg;
  }

  onSubmit() {
    this.filterService.updateSubcontractingFilter(this.form.value as SubcontractingFilter);
    this.activeFilters.emit(this.hasActiveFilters);
  }

  get hasActiveFilters() {
    return this.filterService.subcontractingFilter().length > 0;
  }

  onClear() {
    this.filterService.clearSubcontractingFilters();
    this.form.reset();
    this.activeFilters.emit(false);
  }

  public onYearSelected(date: Moment, datepicker: MatDatepicker<Moment>) {
    const normalizedYear = date.year().toString();
    this.form.controls.year.setValue(normalizedYear);
    datepicker.close();
  }
}
