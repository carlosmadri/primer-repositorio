import { ChangeDetectionStrategy, Component, inject, input, OnInit, output, signal, Signal } from '@angular/core';
import { MatListModule, MatSelectionListChange } from '@angular/material/list';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialogClose } from '@angular/material/dialog';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';
import { WorkloadAvailableSiglumLists, WorkloadPostResponse, WorkloadSubmitSiglumLists, WorkloadValidationSiglumLists } from '../../models/worksync.model';
import { AuthService } from '@src/app/services/auth/auth.service';

interface SiglumsList {
  id: number;
  name: string;
  checked: boolean;
  disabled?: boolean;
}

export enum SiglumCategory {
  PENDING = 'pendingList',
  APPROVED = 'approvedList',
  REJECTED = 'rejectedList',
}

@Component({
  selector: 'optim-siglum-selection',
  standalone: true,
  imports: [MatListModule, FormsModule, ReactiveFormsModule, CommonModule, MatIconModule, MatButtonModule, MatCardModule, MatDialogClose],
  templateUrl: './siglum-selection.component.html',
  styleUrl: './siglum-selection.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SiglumSelectionComponent implements OnInit {
  private worksyncService: WorksyncService = inject(WorksyncService);
  private authService: AuthService = inject(AuthService);

  protected readonly siglumLists: Signal<WorkloadAvailableSiglumLists | null> = this.worksyncService.siglumValidationLists;

  isSubmit = input<boolean>(false);

  requestCompleted = output<WorkloadPostResponse>();

  SiglumCategory = SiglumCategory;

  private siglumIdIndex = 0;

  hasChanges = signal<boolean>(false);

  private fb: FormBuilder = inject(FormBuilder);

  form = signal<FormGroup | null>(null);

  private initialPendingList: string[] = [];
  private initialApprovedList: string[] = [];
  private initialRejectedList: string[] = [];

  private userSelected: string | undefined;

  async ngOnInit() {
    this.userSelected = this.authService.getUserNameFilter();
    if (this.isSubmit()) {
      await this.worksyncService.getWorkloadSiglumsToSubmit([this.userSelected!]);
    } else {
      await this.worksyncService.getWorkloadSiglumsToValidate([this.userSelected!]);
    }
    this.initializeForm();
  }

  getSiglums(category: SiglumCategory): SiglumsList[] {
    return this.form()!.get(category)?.value || [];
  }

  private initializeForm(): void {
    this.siglumIdIndex = 0;
    this.initialPendingList = this.siglumLists()?.pendingList || [];
    this.initialApprovedList = this.siglumLists()?.approvedList || [];
    this.initialRejectedList = this.siglumLists()?.rejectedList || [];
    const form: FormGroup = this.fb.group({
      [SiglumCategory.PENDING]: [this.getSiglumCategoryList(this.initialPendingList)],
      [SiglumCategory.APPROVED]: [this.getSiglumCategoryList(this.initialApprovedList, true)],
      [SiglumCategory.REJECTED]: [this.getSiglumCategoryList(this.initialRejectedList, true)],
    });

    this.form.set(form);
  }

  private getSiglumCategoryList(siglumNames: string[], disabled = false): SiglumsList[] {
    return siglumNames.map((name) => ({
      id: this.siglumIdIndex++,
      name,
      checked: false,
      disabled,
    }));
  }

  addToApproved(): void {
    this.moveItems(SiglumCategory.PENDING, SiglumCategory.APPROVED);
  }

  removeFromApproved(): void {
    this.moveItems(SiglumCategory.APPROVED, SiglumCategory.PENDING);
  }

  addToRejected(): void {
    this.moveItems(SiglumCategory.PENDING, SiglumCategory.REJECTED);
  }

  removeFromRejected(): void {
    this.moveItems(SiglumCategory.REJECTED, SiglumCategory.PENDING);
  }

  onSelectionChange(event: MatSelectionListChange, category: SiglumCategory): void {
    const siglums = this.getSiglums(category);
    const selectedValues = new Set(event.source.selectedOptions.selected.map((option) => option.value));
    siglums.forEach((siglum) => (siglum.checked = selectedValues.has(siglum.id)));
    this.form()!.get(category)?.setValue(siglums);
  }

  private moveItems(fromList: SiglumCategory, toList: SiglumCategory): void {
    const fromSiglums = this.getSiglums(fromList);
    const toSiglums = this.getSiglums(toList);

    const itemsToMove = fromSiglums.filter((siglum) => siglum.checked);
    const remainingItems = fromSiglums.filter((siglum) => !siglum.checked);

    itemsToMove.forEach((siglum) => (siglum.checked = false));

    this.form()!.get(fromList)?.setValue(remainingItems);
    this.form()!
      .get(toList)
      ?.setValue([...toSiglums, ...itemsToMove]);
    this.checkChanges();
  }

  private checkChanges(): void {
    const pendingSiglums = this.getSiglums(SiglumCategory.PENDING).map((siglum) => siglum.name);
    const approvedSiglums = this.getSiglums(SiglumCategory.APPROVED).map((siglum) => siglum.name);

    this.hasChanges.set(!this.arraysEqual(pendingSiglums, this.initialPendingList) || !this.arraysEqual(approvedSiglums, this.initialApprovedList));
  }

  private arraysEqual(a: string[], b: string[]): boolean {
    return a.length === b.length && a.every((value, index) => value === b[index]);
  }

  confirm() {
    if (this.isSubmit()) {
      this.submitSiglums();
    } else {
      this.validateSiglums();
    }
  }

  async submitSiglums() {
    const submiData: WorkloadSubmitSiglumLists = {
      approvedList: this.getSiglums(SiglumCategory.APPROVED)
        .filter((siglum) => !siglum.disabled)
        .map((siglum) => siglum.name),
    };
    const response: WorkloadPostResponse = await this.worksyncService.postWorkloadSiglumsToSubmit(submiData, [this.userSelected!]);
    this.requestCompleted.emit(response);
  }

  async validateSiglums() {
    const validateData: WorkloadValidationSiglumLists = {
      approvedList: this.getSiglums(SiglumCategory.APPROVED)
        .filter((siglum) => !siglum.disabled)
        .map((siglum) => siglum.name),
      rejectedList: this.getSiglums(SiglumCategory.REJECTED)
        .filter((siglum) => !siglum.disabled)
        .map((siglum) => siglum.name),
    };
    const response: WorkloadPostResponse = await this.worksyncService.postWorkloadSiglumsToValidate(validateData, [this.userSelected!]);
    this.requestCompleted.emit(response);
  }
}
