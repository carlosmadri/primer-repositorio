import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatListModule } from '@angular/material/list';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SiglumCategory, SiglumSelectionComponent } from './siglum-selection.component';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';
import { signal } from '@angular/core';
import { WorkloadAvailableSiglumLists } from '../../models/worksync.model';
import { AuthService } from '@src/app/services/auth/auth.service';

describe('SiglumSelectionComponent', () => {
  let component: SiglumSelectionComponent;
  let fixture: ComponentFixture<SiglumSelectionComponent>;
  let mockWorksyncService: Partial<WorksyncService>;
  let mockAuthService: Partial<AuthService>;

  const mockSiglums: WorkloadAvailableSiglumLists = {
    pendingList: ['T1QA1', 'T1QAA', 'T1QA', 'T1QAA', 'T1QAA1', 'T1QAC', 'T1QAE2-TL2', 'T1QAE3', 'T1QAB', 'T1QAA2', 'T1QAC2', 'T1QACF2'],
    approvedList: [],
    rejectedList: [],
  };

  beforeEach(async () => {
    mockWorksyncService = {
      getWorkloadSiglumsToValidate: jest.fn(),
      getWorkloadSiglumsToSubmit: jest.fn(),
      siglumValidationLists: signal<WorkloadAvailableSiglumLists | null>(mockSiglums),
      postWorkloadSiglumsToSubmit: jest.fn(),
      postWorkloadSiglumsToValidate: jest.fn(),
    };

    mockAuthService = {
      getUserNameFilter: jest.fn(),
    };
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, MatListModule, NoopAnimationsModule, SiglumSelectionComponent],
      providers: [
        { provide: WorksyncService, useValue: mockWorksyncService },
        { provide: AuthService, useValue: mockAuthService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(SiglumSelectionComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('isSubmit', false);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize with all siglums in pendingSiglums list', () => {
    expect(component.getSiglums(SiglumCategory.PENDING).length).toBe(mockSiglums.pendingList.length);
    expect(component.getSiglums(SiglumCategory.APPROVED).length).toBe(0);
    expect(component.getSiglums(SiglumCategory.REJECTED).length).toBe(0);
  });

  it('should move checked items from pendingSiglums to approvedSiglums', () => {
    const pendingSiglums = component.getSiglums(SiglumCategory.PENDING);
    pendingSiglums[0].checked = true;
    pendingSiglums[1].checked = true;
    component.addToApproved();

    expect(component.getSiglums(SiglumCategory.PENDING).length).toBe(mockSiglums.pendingList.length - 2);
    expect(component.getSiglums(SiglumCategory.APPROVED).length).toBe(2);
  });

  it('should move checked items from pendingSiglums to rejectedSiglums', () => {
    const pendingSiglums = component.getSiglums(SiglumCategory.PENDING);
    pendingSiglums[2].checked = true;
    pendingSiglums[3].checked = true;
    component.addToRejected();

    expect(component.getSiglums(SiglumCategory.PENDING).length).toBe(mockSiglums.pendingList.length - 2);
    expect(component.getSiglums(SiglumCategory.REJECTED).length).toBe(2);
  });

  it('should move checked items from approvedSiglums back to pendingSiglums', () => {
    // First, move items to approvedSiglums
    const pendingSiglums = component.getSiglums(SiglumCategory.PENDING);
    pendingSiglums[0].checked = true;
    pendingSiglums[1].checked = true;
    component.addToApproved();

    // Then, check and move them back
    const approvedSiglums = component.getSiglums(SiglumCategory.APPROVED);
    approvedSiglums[0].checked = true;
    approvedSiglums[1].checked = true;
    component.removeFromApproved();

    expect(component.getSiglums(SiglumCategory.PENDING).length).toBe(mockSiglums.pendingList.length);
    expect(component.getSiglums(SiglumCategory.APPROVED).length).toBe(0);
  });

  it('should move checked items from rejectedSiglums back to pendingSiglums', () => {
    // First, move items to rejectedSiglums
    const pendingSiglums = component.getSiglums(SiglumCategory.PENDING);
    pendingSiglums[2].checked = true;
    pendingSiglums[3].checked = true;
    component.addToRejected();

    // Then, check and move them back
    const rejectedSiglums = component.getSiglums(SiglumCategory.REJECTED);
    rejectedSiglums[0].checked = true;
    rejectedSiglums[1].checked = true;
    component.removeFromRejected();

    expect(component.getSiglums(SiglumCategory.PENDING).length).toBe(mockSiglums.pendingList.length);
    expect(component.getSiglums(SiglumCategory.REJECTED).length).toBe(0);
  });

  it('should not move items when none are checked', () => {
    component.addToApproved();
    component.addToRejected();

    expect(component.getSiglums(SiglumCategory.PENDING).length).toBe(mockSiglums.pendingList.length);
    expect(component.getSiglums(SiglumCategory.APPROVED).length).toBe(0);
    expect(component.getSiglums(SiglumCategory.REJECTED).length).toBe(0);
  });

  it('should uncheck items after moving', () => {
    const pendingSiglums = component.getSiglums(SiglumCategory.PENDING);
    pendingSiglums[0].checked = true;
    pendingSiglums[1].checked = true;
    component.addToApproved();

    const approvedSiglums = component.getSiglums(SiglumCategory.APPROVED);
    expect(approvedSiglums[0].checked).toBeFalsy();
    expect(approvedSiglums[1].checked).toBeFalsy();
  });
});
