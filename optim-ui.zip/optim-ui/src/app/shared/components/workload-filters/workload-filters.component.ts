import { AfterViewInit, ChangeDetectionStrategy, Component, computed, inject, output, signal } from '@angular/core';
import { MatOption } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButton, MatFabButton } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { FiltersService, WorkloadFilter } from '@services/filters/filters.service';
import { backlogOrderIntakeValues, collarValues, coreNonCoreValues, ownSubValues } from '@models/worksync.model';
import { directIndirectValues } from '@models/employee.model';
import { WorksyncService } from '@services/worksync/worksync.service';
import { ClickStopPropagationDirective } from '@app/shared/directives/click-stop-propagation/click-stop-propagation.directive';
import { CostCenterService } from '@services/cost-center/cost-center.service';

export interface WorkloadFormFilter {
  siglumHR: FormControl<string[]>;
  description: FormControl<string | null>;
  own: FormControl<string[]>;
  country: FormControl<string[]>;
  site: FormControl<string[]>;
  costCenter: FormControl<string[]>;
  direct: FormControl<string[]>;
  khrs: FormControl<number | null>;
  scenario: FormControl<string | null>;
  core: FormControl<string[]>;
  collar: FormControl<string[]>;
  efficiency: FormControl<number | null>;
  rateOwn: FormControl<number | null>;
  fte: FormControl<number | null>;
  keur: FormControl<number | null>;
  eac: FormControl<string | null>;
  ppsid: FormControl<string[]>;
}

@Component({
  selector: 'optim-workload-filters',
  standalone: true,
  imports: [
    ClickStopPropagationDirective,
    MatOption,
    MatFormFieldModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatButton,
    MatIconModule,
    MatFabButton,
    MatInputModule,
  ],
  templateUrl: './workload-filters.component.html',
  styleUrl: './workload-filters.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkloadFiltersComponent implements AfterViewInit {
  private filterService = inject(FiltersService);
  private worksyncService = inject(WorksyncService);
  private costCenterService = inject(CostCenterService);
  form: FormGroup<WorkloadFormFilter> = this.getFormGroup();
  activeFilters = output<boolean>();
  allSiglumsHR = computed<string[]>(() => this.filterService.getAllSiglumsHR());
  allCostCenters = computed<string[]>(() => this.costCenterService.allCostCenters().map((cc) => cc.costCenterCode));
  allCountries = computed<string[]>(() => this.filterService.getFilterValues('country'));
  allSites = computed<string[]>(() => this.sites());
  sites = signal<string[]>([]);
  allPpsids = computed<string[]>(() => this.worksyncService.ppsids());
  allOwns = ownSubValues;
  allDirects = directIndirectValues;
  allCores = coreNonCoreValues;
  allCollar = collarValues;
  allBacklogOrderIntake = backlogOrderIntakeValues;

  private getFormGroup(): FormGroup<WorkloadFormFilter> {
    const fg = new FormGroup({
      siglumHR: new FormControl<string[]>([]),
      description: new FormControl<string | null>(null),
      own: new FormControl<string[]>([]),
      country: new FormControl<string[]>([]),
      site: new FormControl<string[]>([]),
      costCenter: new FormControl<string[]>([]),
      direct: new FormControl<string[]>([]),
      khrs: new FormControl<number | null>(null),
      scenario: new FormControl<string | null>(null),
      core: new FormControl<string[]>([]),
      collar: new FormControl<string[]>([]),
      efficiency: new FormControl<number | null>(null),
      rateOwn: new FormControl<number | null>(null),
      fte: new FormControl<number | null>(null),
      keur: new FormControl<number | null>(null),
      eac: new FormControl<string | null>(null),
      ppsid: new FormControl<string[]>([]),
    } as WorkloadFormFilter);

    return fg;
  }

  ngAfterViewInit() {
    this.sites.set(this.filterService.getFilterValues('site'));
    this.form.controls.country.valueChanges.subscribe((value) => {
      if (value) {
        this.sites.set(this.filterService.getFilterValues('site', value));
      }
    });
  }

  get hasActiveFilters() {
    return this.filterService.workloadFilter().length > 0;
  }

  onSubmit() {
    this.filterService.updateWorkloadFilter(this.form.value as WorkloadFilter);
    this.activeFilters.emit(this.hasActiveFilters);
  }

  onClear() {
    this.filterService.clearWorkloadFilters();
    this.form.reset();
    this.activeFilters.emit(false);
  }
}
