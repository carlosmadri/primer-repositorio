import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkloadFiltersComponent } from './workload-filters.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

describe('WorkloadFiltersComponent', () => {
  let component: WorkloadFiltersComponent;
  let fixture: ComponentFixture<WorkloadFiltersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WorkloadFiltersComponent, NoopAnimationsModule],
      providers: [provideHttpClient(withInterceptorsFromDi()), provideHttpClientTesting()],
    }).compileComponents();

    fixture = TestBed.createComponent(WorkloadFiltersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
