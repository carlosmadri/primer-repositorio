export const CHART_CONSTANTS = {
  DEFAULT_MARGIN_LEFT: 10,
  MAIN_COLOR: '#2a3547',
  ANIMATION_DURATION: 300,
  TARGET_TICK_COUNT: 6,
  SEGMENT_KEYS: ['ownDirect', 'ownIndirect', 'subDirect', 'subIndirect'] as const,
  TOOLTIP_EXCLUDED_KEYS: new Set(['exercise', 'total', 'barType', 'id']),
  PATTERNS: {
    TRANSPARENT: 'transparentPattern',
    DIAGONAL: 'diagonalHatch',
    DOT: 'dotPattern',
  },
  LEGEND_ITEM_WIDTH: 120,
  MIN_BAR_HEIGHT_FOR_LABEL: 15,
  OPACITY: {
    NORMAL: 1,
    DIMMED: 0.3,
    HOVER_DIMMED: 0.2,
    PATTERN: 0.7,
  },
  FONT_SIZES: {
    LABELS: '0.9em',
    EXERCISE: '0.8em',
    TOTAL: '1.2em',
    AXIS: '0.7em',
    LEGEND: '0.7em',
  },
} as const;
