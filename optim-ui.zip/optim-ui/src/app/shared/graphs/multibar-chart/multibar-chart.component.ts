import { AfterViewInit, ChangeDetectionStrategy, Component, effect, ElementRef, inject, Injector, input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { animate, style, transition, trigger } from '@angular/animations';
import { WorkloadEvolutionBarData } from '../../models/worksync.model';
import { MultibarChartService } from './services/multibar-chart.service';
import { ExerciseColorService } from './services/exercise-color.service';
import { PatternService } from './services/pattern.service';
import { TooltipService } from './services/tooltip.service';

@Component({
  selector: 'optim-multibar-chart',
  standalone: true,
  imports: [],
  templateUrl: './multibar-chart.component.html',
  styleUrl: './multibar-chart.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [MultibarChartService, ExerciseColorService, PatternService, TooltipService],
  animations: [
    trigger('growChart', [
      // Initial animation
      transition(':enter', [style({ transform: 'scaleY(0)', transformOrigin: 'bottom' }), animate('600ms ease-out', style({ transform: 'scaleY(1)' }))]),
      // Update animation
      transition('* => *', [
        style({
          transform: 'scaleY(0.7)',
          transformOrigin: 'bottom',
          opacity: 0.3,
        }),
        animate(
          '600ms cubic-bezier(0.4, 0, 0.2, 1)',
          style({
            transform: 'scaleY(1)',
            opacity: 1,
          }),
        ),
      ]),
    ]),
  ],
})
export class MultibarChartComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('chart') chart!: ElementRef;

  animationState = 0;

  chartData = input.required<WorkloadEvolutionBarData[]>();

  chartService = inject(MultibarChartService);
  colorService = inject(ExerciseColorService);
  private injector = inject(Injector);

  ngOnInit(): void {
    window.addEventListener('resize', this.onResize.bind(this));
  }

  ngAfterViewInit(): void {
    effect(
      () => {
        if (this.chartData()) {
          this.updateChart();
        } else {
          this.chartService.destroyChart();
        }
      },
      {
        injector: this.injector,
      },
    );
  }

  private updateChart(): void {
    const chartElement = this.chart.nativeElement;
    const data = this.chartData();

    const exerciseNames = data.map((d) => d.exercise);
    const barTypes = data.map((d) => d.barType);
    const colorMap = this.colorService.getColorMap(barTypes, exerciseNames);

    this.chartService.setColorMap(colorMap);

    if (this.chartService.hasChart()) {
      this.chartService.updateChart(data);
    } else {
      this.chartService.createChart(chartElement, data);
    }
    this.animationState++;
  }

  private onResize(): void {
    const chartElement = this.chart.nativeElement;
    const data = this.chartData();
    this.chartService.resizeChart(chartElement, data);
    this.animationState++;
  }

  ngOnDestroy(): void {
    this.chartService.destroyChart();
    window.removeEventListener('resize', this.onResize);
  }
}
