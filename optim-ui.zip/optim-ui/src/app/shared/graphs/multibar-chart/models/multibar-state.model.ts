import { Selection } from 'd3-selection';
import { ChartDimensions, ChartScales, ChartElements } from '../interfaces/multibar.interfaces';
import { WorkloadEvolutionBarData } from '@src/app/shared/models/worksync.model';
import { CHART_CONSTANTS } from '../constants/multibar.constants';
import * as d3 from 'd3';

export class ChartState {
  private elements: ChartElements = {};
  private dimensions: ChartDimensions;
  private scales: ChartScales;
  private colorMap = new Map<string, string>();
  private disabledKeys = new Set<string>();
  private data: WorkloadEvolutionBarData[] = [];
  private maxValue = 0;

  constructor() {
    this.dimensions = this.getInitialDimensions();
    this.scales = this.getInitialScales();
  }

  private getInitialDimensions(): ChartDimensions {
    return {
      width: 0,
      height: 0,
      margin: {
        top: 45,
        right: 0,
        bottom: 40,
        left: CHART_CONSTANTS.DEFAULT_MARGIN_LEFT,
      },
    };
  }

  private getInitialScales(): ChartScales {
    return {
      x: d3.scaleBand(),
      y: d3.scaleLinear(),
      color: () => '#000000',
      pattern: d3.scaleOrdinal(),
      opacity: d3.scaleOrdinal(),
    };
  }

  getSvg(): Selection<SVGGElement, unknown, null, undefined> | undefined {
    return this.elements.svg;
  }

  setSvg(svg: Selection<SVGGElement, unknown, null, undefined>): void {
    this.elements.svg = svg;
  }

  getTooltip(): Selection<HTMLDivElement, unknown, null, undefined> | undefined {
    return this.elements.tooltip;
  }

  setTooltip(tooltip: Selection<HTMLDivElement, unknown, null, undefined>): void {
    this.elements.tooltip = tooltip;
  }

  getDimensions(): ChartDimensions {
    return this.dimensions;
  }

  setDimensions(dimensions: Partial<ChartDimensions>): void {
    this.dimensions = { ...this.dimensions, ...dimensions };
  }

  getScales(): ChartScales {
    return this.scales;
  }

  setScales(scales: Partial<ChartScales>): void {
    this.scales = { ...this.scales, ...scales };
  }

  getData(): WorkloadEvolutionBarData[] {
    return this.data;
  }

  setData(data: WorkloadEvolutionBarData[]): void {
    this.data = data;
  }

  getMaxValue(): number {
    return this.maxValue;
  }

  setMaxValue(value: number): void {
    this.maxValue = value;
  }

  getColorMap(): Map<string, string> {
    return this.colorMap;
  }

  setColorMap(colorMap: Map<string, string>): void {
    this.colorMap = colorMap;
  }

  isKeyDisabled(key: string): boolean {
    return this.disabledKeys.has(key);
  }

  toggleKey(key: string): void {
    if (this.disabledKeys.has(key)) {
      this.disabledKeys.delete(key);
    } else {
      this.disabledKeys.add(key);
    }
  }

  getEnabledKeys(): string[] {
    return CHART_CONSTANTS.SEGMENT_KEYS.filter((key) => !this.disabledKeys.has(key));
  }

  getDisabledKeys(): Set<string> {
    return this.disabledKeys;
  }

  clearDisabledKeys(): void {
    this.disabledKeys.clear();
  }

  calculateEnabledTotal(data: WorkloadEvolutionBarData): number {
    return Object.entries(data)
      .filter(([key]) => !this.disabledKeys.has(key) && CHART_CONSTANTS.SEGMENT_KEYS.includes(key as (typeof CHART_CONSTANTS.SEGMENT_KEYS)[number]))
      .reduce((sum, [, value]) => {
        const numValue = typeof value === 'string' ? parseFloat(value) : (value as number);
        return sum + numValue;
      }, 0);
  }

  destroy(): void {
    if (this.elements.svg) {
      const svgElement = this.elements.svg.node()?.parentElement;
      if (svgElement?.parentNode) {
        svgElement.parentNode.removeChild(svgElement);
      }
      this.elements.svg = undefined;
    }
    if (this.elements.tooltip) {
      this.elements.tooltip.remove();
      this.elements.tooltip = undefined;
    }
    this.clearDisabledKeys();
  }
}
