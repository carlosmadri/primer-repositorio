import { TestBed } from '@angular/core/testing';

import { MultibarChartService } from './multibar-chart.service';
import { TooltipService } from './tooltip.service';
import { PatternService } from './pattern.service';

describe('MultibarChartService', () => {
  let service: MultibarChartService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MultibarChartService, PatternService, TooltipService],
    });
    service = TestBed.inject(MultibarChartService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
