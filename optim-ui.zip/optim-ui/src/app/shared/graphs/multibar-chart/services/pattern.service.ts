import { Injectable } from '@angular/core';
import { Selection } from 'd3-selection';
import { CHART_CONSTANTS } from '../constants/multibar.constants';

@Injectable()
export class PatternService {
  createPatterns(svg: Selection<SVGGElement, unknown, null, undefined>): void {
    const defs = svg.append('defs');

    this.createTransparentPattern(defs);
    this.createDiagonalHatchPattern(defs);
    this.createDotPattern(defs);
  }

  private createTransparentPattern(defs: Selection<SVGDefsElement, unknown, null, undefined>): void {
    defs
      .append('pattern')
      .attr('id', CHART_CONSTANTS.PATTERNS.TRANSPARENT)
      .attr('patternUnits', 'userSpaceOnUse')
      .attr('width', 1)
      .attr('height', 1)
      .append('rect')
      .attr('width', 1)
      .attr('height', 1)
      .attr('fill', 'transparent');
  }

  private createDiagonalHatchPattern(defs: Selection<SVGDefsElement, unknown, null, undefined>): void {
    defs
      .append('pattern')
      .attr('id', CHART_CONSTANTS.PATTERNS.DIAGONAL)
      .attr('patternUnits', 'userSpaceOnUse')
      .attr('width', 4)
      .attr('height', 4)
      .append('path')
      .attr('d', 'M-1,1 l2,-2 M0,4 l4,-4 M3,5 l2,-2')
      .attr('stroke', CHART_CONSTANTS.MAIN_COLOR)
      .attr('stroke-width', 1);
  }

  private createDotPattern(defs: Selection<SVGDefsElement, unknown, null, undefined>): void {
    defs
      .append('pattern')
      .attr('id', CHART_CONSTANTS.PATTERNS.DOT)
      .attr('patternUnits', 'userSpaceOnUse')
      .attr('width', 4)
      .attr('height', 4)
      .append('circle')
      .attr('cx', 2)
      .attr('cy', 2)
      .attr('r', 1)
      .attr('fill', CHART_CONSTANTS.MAIN_COLOR);
  }
}
