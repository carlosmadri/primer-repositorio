import { Injectable } from '@angular/core';
import { WorkloadEvolutionBarData } from '@src/app/shared/models/worksync.model';
import * as d3 from 'd3';
import { Selection } from 'd3-selection';
import { CHART_CONSTANTS } from '../constants/multibar.constants';
import { ChartDimensions, ChartScales, LegendItem, StackedBarData } from '../interfaces/multibar.interfaces';
import { ChartState } from '../models/multibar-state.model';
import { PatternService } from './pattern.service';
import { TooltipService } from './tooltip.service';

@Injectable()
export class MultibarChartService {
  private chartState: ChartState;

  constructor(
    private patternService: PatternService,
    private tooltipService: TooltipService,
  ) {
    this.chartState = new ChartState();
  }

  hasChart(): boolean {
    return !!this.chartState.getSvg();
  }

  createChart(element: HTMLElement, data: WorkloadEvolutionBarData[]): void {
    this.chartState.setData(data);
    this.chartState.setMaxValue(d3.max(data, (d) => Math.max(d.total)) || 0);
    this.updateMarginForNumbers();

    this.createSvg(element);
    this.createScales(data);
    this.createTooltip(element);
    this.drawBars(data);
    this.drawAxes();
    this.createLegend();
  }

  updateChart(data: WorkloadEvolutionBarData[]): void {
    this.chartState.setData(data);
    this.createScales(data);
    this.drawBars(data);
    this.drawAxes();
    this.createLegend();
  }

  resizeChart(element: HTMLElement, data: WorkloadEvolutionBarData[]): void {
    this.createSvg(element);
    this.createScales(data);
    this.createTooltip(element);
    this.drawBars(data);
    this.drawAxes();
    this.createLegend();
  }

  destroyChart(): void {
    this.chartState.destroy();
  }

  setColorMap(colorMap: Map<string, string>): void {
    this.chartState.setColorMap(colorMap);
  }

  private createSvg(element: HTMLElement): void {
    d3.select(element).selectAll('*').remove();

    const containerWidth = element.clientWidth || 300;
    const containerHeight = element.clientHeight || 200;
    const dimensions = this.chartState.getDimensions();

    this.chartState.setDimensions({
      width: containerWidth - dimensions.margin.left - dimensions.margin.right,
      height: containerHeight - dimensions.margin.top - dimensions.margin.bottom,
    });

    const svg = d3
      .select(element)
      .append('svg')
      .attr('width', containerWidth)
      .attr('height', containerHeight)
      .append('g')
      .attr('transform', `translate(${dimensions.margin.left},${dimensions.margin.top})`);

    this.chartState.setSvg(svg);
  }

  private createScales(data: WorkloadEvolutionBarData[]): void {
    const dimensions = this.chartState.getDimensions();

    const x = d3
      .scaleBand()
      .domain(data.map((d) => d.exercise))
      .range([0, dimensions.width])
      .padding(0.1);

    const maxValue = d3.max(data, (d) => this.chartState.calculateEnabledTotal(d)) || 0;

    const y = d3.scaleLinear().domain([0, maxValue]).range([dimensions.height, 0]);

    const pattern = d3
      .scaleOrdinal<string>()
      .domain(CHART_CONSTANTS.SEGMENT_KEYS)
      .range([
        `url(#${CHART_CONSTANTS.PATTERNS.TRANSPARENT})`,
        `url(#${CHART_CONSTANTS.PATTERNS.DIAGONAL})`,
        `url(#${CHART_CONSTANTS.PATTERNS.TRANSPARENT})`,
        `url(#${CHART_CONSTANTS.PATTERNS.DOT})`,
      ]);

    const opacity = d3.scaleOrdinal<string>().domain(CHART_CONSTANTS.SEGMENT_KEYS).range(['1', '0.8', '0.4', '0.8']);

    this.chartState.setScales({
      x,
      y,
      color: (exercise: string) => this.chartState.getColorMap().get(exercise) || '#000000',
      pattern,
      opacity,
    });
  }

  private createTooltip(element: HTMLElement): void {
    const tooltip = this.tooltipService.createTooltip(element);
    this.chartState.setTooltip(tooltip);
  }

  private drawBars(data: WorkloadEvolutionBarData[]): void {
    const svg = this.chartState.getSvg();
    if (!svg) return;

    const enabledKeys = this.chartState.getEnabledKeys();
    const stack = d3.stack<WorkloadEvolutionBarData>().keys(enabledKeys);
    const stackedData = stack(data);

    this.patternService.createPatterns(svg);
    svg.selectAll('.bar-group').remove();

    this.createBarGroups(svg, data, stackedData);
  }

  private createBarGroups(
    svg: Selection<SVGGElement, unknown, null, undefined>,
    data: WorkloadEvolutionBarData[],
    stackedData: d3.Series<WorkloadEvolutionBarData, string>[],
  ): void {
    const scales = this.chartState.getScales();

    const barGroups = svg
      .selectAll('.bar-group')
      .data(data)
      .enter()
      .append('g')
      .attr('class', 'bar-group')
      .attr('transform', (d) => `translate(${scales.x(d.exercise)},0)`)
      .on('mouseover', this.createHighlightHandler(CHART_CONSTANTS.OPACITY.HOVER_DIMMED))
      .on('mouseleave', this.createHighlightHandler(CHART_CONSTANTS.OPACITY.NORMAL));

    this.createBars(barGroups, stackedData);
    this.createLabels(barGroups);
  }

  private createBars(
    barGroups: Selection<SVGGElement, WorkloadEvolutionBarData, SVGGElement, unknown>,
    stackedData: d3.Series<WorkloadEvolutionBarData, string>[],
  ): void {
    const scales = this.chartState.getScales();

    const bars = barGroups
      .selectAll('g')
      .data(
        (d) =>
          stackedData.map((layer) => ({
            key: layer.key,
            value: layer.find((item) => item.data === d)!,
            data: d,
          })) as StackedBarData[],
      )
      .enter()
      .append('g');

    // Colored rectangles
    this.createColoredRectangles(bars, scales);

    // Patterned rectangles
    this.createPatternedRectangles(bars, scales);

    // Value labels
    this.createValueLabels(bars, scales);
  }

  private createColoredRectangles(bars: Selection<SVGGElement, StackedBarData, SVGGElement, WorkloadEvolutionBarData>, scales: ChartScales): void {
    bars
      .append('rect')
      .attr('x', 0)
      .attr('y', (d) => scales.y(d.value[1]))
      .attr('height', (d) => scales.y(d.value[0]) - scales.y(d.value[1]))
      .attr('width', scales.x.bandwidth())
      .attr('fill', (d) => scales.color(d.data.exercise))
      .attr('opacity', (d) => (this.chartState.isKeyDisabled(d.key) ? 0 : +scales.opacity(d.key)));
  }

  private createPatternedRectangles(bars: Selection<SVGGElement, StackedBarData, SVGGElement, WorkloadEvolutionBarData>, scales: ChartScales): void {
    bars
      .append('rect')
      .attr('x', 0)
      .attr('y', (d) => scales.y(d.value[1]))
      .attr('height', (d) => scales.y(d.value[0]) - scales.y(d.value[1]))
      .attr('width', scales.x.bandwidth())
      .attr('fill', (d) => scales.pattern(d.key))
      .attr('opacity', (d) => (this.chartState.isKeyDisabled(d.key) ? 0 : CHART_CONSTANTS.OPACITY.PATTERN))
      .on('mouseover', (event, d) => this.tooltipService.showTooltip(this.chartState, event, d))
      .on('mouseout', () => this.tooltipService.hideTooltip(this.chartState.getTooltip()!));
  }

  private createValueLabels(bars: Selection<SVGGElement, StackedBarData, SVGGElement, WorkloadEvolutionBarData>, scales: ChartScales): void {
    bars
      .append('text')
      .attr('x', scales.x.bandwidth() / 2)
      .attr('y', (d) => (scales.y(d.value[0]) + scales.y(d.value[1])) / 2)
      .attr('dy', '0.35em')
      .attr('text-anchor', 'middle')
      .attr('fill', 'white')
      .attr('font-size', CHART_CONSTANTS.FONT_SIZES.LABELS)
      .text((d) => {
        if (this.chartState.isKeyDisabled(d.key)) return '';
        const value = +(d.value[1] - d.value[0]).toFixed(10);
        const height = scales.y(d.value[0]) - scales.y(d.value[1]);
        return height > CHART_CONSTANTS.MIN_BAR_HEIGHT_FOR_LABEL ? d3.format('.1f')(value) : '';
      });
  }

  private createLabels(barGroups: Selection<SVGGElement, WorkloadEvolutionBarData, SVGGElement, unknown>): void {
    const dimensions = this.chartState.getDimensions();
    const scales = this.chartState.getScales();

    // Exercise labels
    barGroups
      .append('text')
      .attr('class', 'exercise-label')
      .attr('x', scales.x.bandwidth() / 2)
      .attr('y', -dimensions.margin.top + 15)
      .attr('text-anchor', 'middle')
      .attr('fill', '#ccc')
      .attr('font-size', CHART_CONSTANTS.FONT_SIZES.EXERCISE)
      .text((d) => d.exercise);

    // Total labels
    barGroups
      .append('text')
      .attr('class', 'total-label')
      .attr('x', scales.x.bandwidth() / 2)
      .attr('y', -dimensions.margin.top + 35)
      .attr('text-anchor', 'middle')
      .attr('fill', 'white')
      .attr('font-size', CHART_CONSTANTS.FONT_SIZES.TOTAL)
      .text((d) => d3.format('.1f')(this.chartState.calculateEnabledTotal(d)));
  }

  private drawAxes(): void {
    const svg = this.chartState.getSvg();
    if (!svg) return;

    // Remove existing axes and grid
    svg.selectAll('.y-axis, .x-axis, .grid').remove();

    const dimensions = this.chartState.getDimensions();
    const scales = this.chartState.getScales();
    const tickValues = this.calculateTickValues();

    // Grid lines
    this.createGridLines(svg, tickValues, dimensions, scales);

    // Y axis
    this.createYAxis(svg, tickValues, scales);

    // X axis
    this.createXAxis(svg, dimensions, scales);
  }

  private calculateTickValues(): number[] {
    const data = this.chartState.getData();
    const yMax = Math.ceil(d3.max(data, (d) => this.chartState.calculateEnabledTotal(d)) || 0);

    const tickStep = this.calculateTickStep(yMax);
    const tickValues = d3.range(0, yMax, tickStep);

    while (tickValues[tickValues.length - 1] > yMax) {
      tickValues.pop();
    }

    return tickValues;
  }

  private createGridLines(svg: Selection<SVGGElement, unknown, null, undefined>, tickValues: number[], dimensions: ChartDimensions, scales: ChartScales): void {
    svg
      .append('g')
      .attr('class', 'grid')
      .attr('opacity', 0.1)
      .call((g) => {
        const yAxis = d3
          .axisLeft(scales.y)
          .tickValues(tickValues)
          .tickSize(-dimensions.width)
          .tickFormat(() => '');
        return yAxis(g);
      });
  }

  private createYAxis(svg: Selection<SVGGElement, unknown, null, undefined>, tickValues: number[], scales: ChartScales): void {
    svg
      .append('g')
      .attr('class', 'y-axis')
      .call((g) => {
        const yAxis = d3.axisLeft(scales.y).tickValues(tickValues).tickFormat(d3.format('.0f'));
        return yAxis(g);
      })
      .attr('font-size', CHART_CONSTANTS.FONT_SIZES.AXIS)
      .call((g) => {
        g.select('.domain').remove();
        g.selectAll('.tick line').remove();
      });
  }

  private createXAxis(svg: Selection<SVGGElement, unknown, null, undefined>, dimensions: ChartDimensions, scales: ChartScales): void {
    svg
      .append('g')
      .attr('class', 'x-axis')
      .attr('transform', `translate(0,${dimensions.height})`)
      .call((g) => {
        const xAxis = d3
          .axisBottom(scales.x)
          .tickSize(0)
          .tickFormat(() => '');
        return xAxis(g);
      })
      .call((g) => {
        g.select('.domain').attr('stroke', '#555').attr('stroke-width', 1);
        g.selectAll('.tick').remove();
      });
  }

  private createLegendData(): LegendItem[] {
    const scales = this.chartState.getScales();
    return [
      { key: 'ownDirect', label: 'Own Direct', pattern: 'none', opacity: +scales.opacity('ownDirect') },
      { key: 'ownIndirect', label: 'Own Indirect', pattern: `url(#${CHART_CONSTANTS.PATTERNS.DIAGONAL})`, opacity: +scales.opacity('ownIndirect') },
      { key: 'subDirect', label: 'Sub Direct', pattern: 'none', opacity: +scales.opacity('subDirect') },
      { key: 'subIndirect', label: 'Sub Indirect', pattern: `url(#${CHART_CONSTANTS.PATTERNS.DOT})`, opacity: +scales.opacity('subIndirect') },
    ];
  }

  private createLegend(): void {
    const svg = this.chartState.getSvg();
    if (!svg) return;

    const legendData = this.createLegendData();
    svg.selectAll('.legend').remove();

    const legendGroup = this.createLegendGroup(svg);
    const legendItems = this.createLegendItems(legendGroup, legendData);

    this.addLegendSymbols(legendItems);
    this.addLegendLabels(legendItems);
  }

  private createLegendGroup(svg: Selection<SVGGElement, unknown, null, undefined>): Selection<SVGGElement, unknown, null, undefined> {
    const dimensions = this.chartState.getDimensions();
    const totalLegendWidth = CHART_CONSTANTS.LEGEND_ITEM_WIDTH * CHART_CONSTANTS.SEGMENT_KEYS.length;
    const startX = (dimensions.width - totalLegendWidth) / 2;

    return svg
      .append('g')
      .attr('class', 'legend')
      .attr('transform', `translate(${startX}, ${dimensions.height + 20})`);
  }

  private createLegendItems(
    legendGroup: Selection<SVGGElement, unknown, null, undefined>,
    legendData: LegendItem[],
  ): Selection<SVGGElement, LegendItem, SVGGElement, unknown> {
    return legendGroup
      .selectAll('.legend-item')
      .data(legendData)
      .enter()
      .append('g')
      .attr('class', 'legend-item')
      .attr('transform', (d, i) => `translate(${i * CHART_CONSTANTS.LEGEND_ITEM_WIDTH}, 0)`)
      .style('opacity', (d) => (this.chartState.isKeyDisabled(d.key) ? CHART_CONSTANTS.OPACITY.DIMMED : CHART_CONSTANTS.OPACITY.NORMAL))
      .style('cursor', 'pointer')
      .on('mouseover', (event, d) => this.handleLegendMouseOver(d))
      .on('mouseleave', () => this.handleLegendMouseLeave())
      .on('click', (event, d) => this.handleLegendClick(d));
  }

  private handleLegendMouseOver(d: LegendItem): void {
    const svg = this.chartState.getSvg();
    if (!svg || this.chartState.isKeyDisabled(d.key)) return;

    svg
      .selectAll<SVGRectElement, StackedBarData>('.bar-group rect')
      .style('opacity', (rectD) => (rectD.key === d.key ? CHART_CONSTANTS.OPACITY.NORMAL : CHART_CONSTANTS.OPACITY.HOVER_DIMMED));
  }

  private handleLegendMouseLeave(): void {
    const svg = this.chartState.getSvg();
    if (!svg) return;

    svg
      .selectAll<SVGRectElement, StackedBarData>('.bar-group rect')
      .style('opacity', (d) => (this.chartState.isKeyDisabled(d.key) ? 0 : +this.chartState.getScales().opacity(d.key)));
  }

  private handleLegendClick(d: LegendItem): void {
    this.chartState.toggleKey(d.key);
    this.updateLegendOpacity();
    this.updateBarsVisibility();
  }

  private updateLegendOpacity(): void {
    const svg = this.chartState.getSvg();
    if (!svg) return;

    svg
      .selectAll<SVGGElement, LegendItem>('.legend-item')
      .style('opacity', (item) => (this.chartState.isKeyDisabled(item.key) ? CHART_CONSTANTS.OPACITY.DIMMED : CHART_CONSTANTS.OPACITY.NORMAL));
  }

  private updateBarsVisibility(): void {
    this.createScales(this.chartState.getData());
    this.drawAxes();
    this.drawBars(this.chartState.getData());
  }

  private addLegendSymbols(legendItems: Selection<SVGGElement, LegendItem, SVGGElement, unknown>): void {
    // Add stroke
    legendItems
      .append('circle')
      .attr('r', 10)
      .attr('cx', 5)
      .attr('cy', 8)
      .attr('stroke', 'white')
      .attr('stroke-width', 1)
      .attr('opacity', CHART_CONSTANTS.OPACITY.NORMAL);

    // Add white background
    legendItems
      .append('circle')
      .attr('r', 10)
      .attr('cx', 5)
      .attr('cy', 8)
      .attr('fill', 'white')
      .attr('opacity', (d) => d.opacity);

    // Add pattern
    legendItems
      .append('circle')
      .attr('r', 10)
      .attr('cx', 5)
      .attr('cy', 8)
      .attr('fill', (d) => (d.pattern === 'none' ? 'white' : d.pattern))
      .attr('opacity', (d) => (d.pattern === 'none' ? d.opacity : CHART_CONSTANTS.OPACITY.NORMAL));
  }

  private addLegendLabels(legendItems: Selection<SVGGElement, LegendItem, SVGGElement, unknown>): void {
    legendItems
      .append('text')
      .attr('x', 20)
      .attr('y', 12)
      .text((d) => d.label)
      .style('font-size', CHART_CONSTANTS.FONT_SIZES.LEGEND)
      .attr('fill', 'white');
  }

  private createHighlightHandler(opacity: number) {
    return (event: MouseEvent, d: WorkloadEvolutionBarData) => {
      const svg = this.chartState.getSvg();
      if (!svg) return;

      const currentExercise = d.exercise;

      svg
        .selectAll<SVGGElement, WorkloadEvolutionBarData>('.bar-group')
        .style('opacity', (d) => (d.exercise === currentExercise ? CHART_CONSTANTS.OPACITY.NORMAL : opacity));

      svg
        .selectAll<SVGGElement, LegendItem>('.legend-item')
        .style('opacity', () => (opacity === CHART_CONSTANTS.OPACITY.NORMAL ? CHART_CONSTANTS.OPACITY.NORMAL : CHART_CONSTANTS.OPACITY.PATTERN));
    };
  }

  private updateMarginForNumbers(): void {
    const dimensions = this.chartState.getDimensions();
    const digits = Math.ceil(this.chartState.getMaxValue()).toString().length;

    this.chartState.setDimensions({
      margin: {
        ...dimensions.margin,
        left: CHART_CONSTANTS.DEFAULT_MARGIN_LEFT + digits * 6,
      },
    });
  }

  private calculateTickStep(max: number): number {
    let step = Math.pow(10, Math.floor(Math.log10(max)));

    while (max / step < CHART_CONSTANTS.TARGET_TICK_COUNT) {
      step /= 2;
    }

    while (max / step > CHART_CONSTANTS.TARGET_TICK_COUNT) {
      step *= 2;
    }

    return step;
  }
}
