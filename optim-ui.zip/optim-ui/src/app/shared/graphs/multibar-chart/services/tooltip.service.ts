import { Injectable } from '@angular/core';
import { Selection } from 'd3-selection';
import * as d3 from 'd3';
import { ChartScales, StackedBarData } from '../interfaces/multibar.interfaces';
import { CHART_CONSTANTS } from '../constants/multibar.constants';
import { ChartState } from '../models/multibar-state.model';

@Injectable()
export class TooltipService {
  createTooltip(element: HTMLElement): Selection<HTMLDivElement, unknown, null, undefined> {
    return d3
      .select(element)
      .append('div')
      .attr('class', 'workload-tooltip-title')
      .style('opacity', 0)
      .style('position', 'absolute')
      .style('border-radius', '5px')
      .style('padding', '10px')
      .style('pointer-events', 'none')
      .style('font-size', '1.0em')
      .style('color', '#ddd')
      .style('transition', 'opacity 0.1s ease-in-out')
      .style('white-space', 'nowrap')
      .style('z-index', '1000');
  }

  showTooltip(chartState: ChartState, event: MouseEvent, d: StackedBarData): void {
    const tooltip = chartState.getTooltip();
    const svg = chartState.getSvg();
    const scales = chartState.getScales();

    if (!tooltip || !svg || !scales.x || !scales.y) return;

    const tooltipContent = this.generateTooltipContent(d);
    const position = this.calculateTooltipPosition(svg, scales, d);

    tooltip.html(tooltipContent).style('left', `${position.x}px`).style('top', `${position.y}px`).style('transform', 'translateY(-50%)');

    tooltip.transition().duration(100).style('opacity', 0.9);
  }

  hideTooltip(tooltip: Selection<HTMLDivElement, unknown, null, undefined>): void {
    tooltip.transition().duration(100).style('opacity', 0);
  }

  private generateTooltipContent(d: StackedBarData): string {
    const formatKey = (key: string) => {
      const parts = key.split(/(?=[A-Z])/);
      return parts.map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join(' ');
    };

    const formatValue = (value: number) => d3.format(',')(value);

    return `
      ${Object.entries(d.data)
        .reverse()
        .filter(([key]) => !CHART_CONSTANTS.TOOLTIP_EXCLUDED_KEYS.has(key))
        .map(([key, value]) => {
          const formattedKey = formatKey(key);
          const formattedValue = formatValue(value as number);
          if (key === d.key) {
            return `<p class="selected-value"><span>${formattedKey}:</span> <span>${formattedValue} khours</span></p>`;
          }
          return `<p><span>${formattedKey}:</span> <span>${formattedValue} khours</span></p>`;
        })
        .join('')}
    `;
  }

  private calculateTooltipPosition(svg: Selection<SVGGElement, unknown, null, undefined>, scales: ChartScales, d: StackedBarData): { x: number; y: number } {
    const svgNode = svg.node() as SVGGElement;
    const svgRect = svgNode.getBoundingClientRect();

    return {
      x: svgRect.left + scales.x(d.data.exercise)! + scales.x.bandwidth() + 41,
      y: svgRect.top + scales.y(d.value[1]) + (scales.y(d.value[0]) - scales.y(d.value[1])) / 2 + 15,
    };
  }
}
