import { WorkloadEvolutionBarData } from '@src/app/shared/models/worksync.model';
import * as d3 from 'd3';

export interface LegendItem {
  key: string;
  label: string;
  pattern: string;
  opacity: number;
}

export interface StackedBarData {
  key: string;
  value: d3.SeriesPoint<WorkloadEvolutionBarData>;
  data: WorkloadEvolutionBarData;
}

export interface ChartDimensions {
  width: number;
  height: number;
  margin: {
    top: number;
    right: number;
    bottom: number;
    left: number;
  };
}

export interface ChartScales {
  x: d3.ScaleBand<string>;
  y: d3.ScaleLinear<number, number>;
  color: (exercise: string) => string;
  pattern: d3.ScaleOrdinal<string, string>;
  opacity: d3.ScaleOrdinal<string, string>;
}

export interface ChartElements {
  svg?: d3.Selection<SVGGElement, unknown, null, undefined>;
  tooltip?: d3.Selection<HTMLDivElement, unknown, null, undefined>;
}
