import { ChangeDetectionStrategy, Component, effect, input, signal } from '@angular/core';
import {
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  NgApexchartsModule,
  ApexYAxis,
  ApexGrid,
  ApexTheme,
  ApexLegend,
  ApexTooltip,
  ApexOptions,
} from 'ng-apexcharts';

export interface ChartOptions {
  theme: ApexTheme;
  series: ApexAxisChartSeries;
  chart: ApexChart;
  xaxis: ApexXAxis;
  yaxis: ApexYAxis;
  grid: ApexGrid;
  colors: string[];
  legend: ApexLegend;
  tooltip: ApexTooltip;
}

export interface MultiColumnCharData {
  series: MultiColumnSerieData[];
  labels: string[];
  colors: string[];
}

export interface MultiColumnSerieData {
  name: string;
  data: number[];
}

@Component({
  selector: 'optim-multi-column-chart',
  standalone: true,
  imports: [NgApexchartsModule],
  templateUrl: './multi-column-chart.component.html',
  styleUrl: './multi-column-chart.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MultiColumnChartComponent {
  chartData = input<MultiColumnCharData>();
  containerHeight = input<number>();
  public chartOptions = signal<Partial<ApexOptions> | null>(null);

  constructor() {
    effect(
      () => {
        if (!this.chartData() || this.containerHeight() === 0) {
          this.chartOptions.set(null);
        } else {
          this.setChartOptions();
        }
      },
      { allowSignalWrites: true },
    );
  }

  setChartOptions(): void {
    const series = this.chartData()!.series;
    const labels = this.chartData()!.labels;
    const colors = this.chartData()!.colors;
    const chartOptions: ChartOptions = {
      theme: {
        mode: 'dark',
      },
      series: series,
      chart: {
        height: this.containerHeight(),
        type: 'bar',
        stacked: true,
        background: '#2a3547',
        foreColor: '#cccccc',
        toolbar: {
          show: false,
        },
      },
      xaxis: {
        axisBorder: {
          show: false,
        },
        axisTicks: {
          show: false,
        },
        categories: labels,
        labels: {
          style: {
            colors: '#cccccc',
          },
        },
      },
      yaxis: {
        labels: {
          style: {
            colors: '#cccccc',
          },
        },
      },
      grid: {
        borderColor: '#555555',
        xaxis: {
          lines: {
            show: false,
          },
        },
        yaxis: {
          lines: {
            show: true,
          },
        },
      },
      colors: colors,
      legend: {
        show: false,
      },
      tooltip: {
        enabled: true,
      },
    };
    this.chartOptions.set(chartOptions);
  }
}
