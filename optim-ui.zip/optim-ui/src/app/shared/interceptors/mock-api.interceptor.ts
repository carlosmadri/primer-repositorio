import { HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { MOCK_ENDPOINTS } from '@src/app/services/mock-api/mock-endpoints';
import { MockStateService } from '@src/app/services/mock-api/mock-state.service';
import { from, of } from 'rxjs';
import { switchMap, take, mergeMap } from 'rxjs/operators';

async function getMockData(mockFile: string): Promise<unknown> {
  const response = await fetch(`/assets/mocks/${mockFile}`);
  return await response.json();
}

export const mockApiInterceptor: HttpInterceptorFn = (req, next) => {
  const mockStateService = inject(MockStateService);

  return mockStateService.useMocks$.pipe(
    take(1),
    mergeMap((useMocks) => {
      if (!useMocks) {
        return next(req);
      }

      const mockEndpoint = MOCK_ENDPOINTS.find((endpoint) => req.url.includes(endpoint.url));

      if (!mockEndpoint) {
        return next(req);
      }

      return from(getMockData(mockEndpoint.mockFile)).pipe(
        switchMap((data) => {
          return of(
            new HttpResponse({
              status: 200,
              body: data,
            }),
          );
        }),
      );
    }),
  );
};
