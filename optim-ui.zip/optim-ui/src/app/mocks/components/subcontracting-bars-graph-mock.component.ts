import { Component } from '@angular/core';

@Component({
  selector: 'optim-subcontracting-bars-graph',
  template: ``,
  standalone: true,
})
export class MockSubcontractingBarsGraphComponent {}
