import { Component } from '@angular/core';

@Component({
  selector: 'optim-employee-dialog',
  template: ``,
  standalone: true,
})
export class MockWorkoutEmployeeDialogComponent {}
