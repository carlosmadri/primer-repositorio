import { Component } from '@angular/core';

@Component({
  selector: 'optim-workout-levers-eoy',
  template: ``,
  standalone: true,
})
export class MockWorkoutLeversEoyComponent {}
