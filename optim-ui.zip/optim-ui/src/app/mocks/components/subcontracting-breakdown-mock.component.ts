import { Component } from '@angular/core';

@Component({
  selector: 'optim-subcontracting-breakdown',
  template: ``,
  standalone: true,
})
export class MockSubcontractingBreakdownComponent {}
