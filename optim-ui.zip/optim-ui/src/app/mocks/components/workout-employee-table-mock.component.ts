import { Component } from '@angular/core';

@Component({
  selector: 'optim-workout-employee-table',
  template: ``,
  standalone: true,
})
export class MockWorkoutEmployeeTableComponent {}
