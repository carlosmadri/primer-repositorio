import { Component } from '@angular/core';

@Component({
  selector: 'optim-worksync-direct-indirect',
  template: ``,
  standalone: true,
})
export class MockWorksyncDirectIndirectComponent {}
