import { Component } from '@angular/core';

@Component({
  selector: 'optim-workload-evolution',
  template: ``,
  standalone: true,
})
export class MockWorkloadEvolutionComponent {}
