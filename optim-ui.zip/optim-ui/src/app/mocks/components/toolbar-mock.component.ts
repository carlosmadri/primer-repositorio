import { Component } from '@angular/core';

@Component({
  selector: 'optim-toolbar',
  template: ``,
  standalone: true,
})
export class MockToolbarComponent {}
