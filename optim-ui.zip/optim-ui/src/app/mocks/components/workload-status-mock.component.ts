import { Component, input } from '@angular/core';

@Component({
  selector: 'optim-workload-status',
  template: ``,
  standalone: true,
})
export class MockWorkloadStatusComponent {
  loadEvolutionStatusData = input<boolean>(false);
}
