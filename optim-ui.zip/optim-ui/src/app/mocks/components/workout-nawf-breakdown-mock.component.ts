import { Component } from '@angular/core';

@Component({
  selector: 'optim-workout-nawf-breakdown',
  template: ``,
  standalone: true,
})
export class MockWorkoutNawfBreakdownComponent {}
