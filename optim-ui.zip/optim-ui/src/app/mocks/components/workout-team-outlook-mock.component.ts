import { Component } from '@angular/core';

@Component({
  selector: 'optim-workout-team-outlook',
  template: ``,
  standalone: true,
})
export class MockWorkoutTeamOutlookComponent {}
