import { Component } from '@angular/core';

@Component({
  selector: 'optim-workload-workforce',
  template: ``,
  standalone: true,
})
export class MockWorkloadWorkforceComponent {}
