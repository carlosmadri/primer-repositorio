import { Component } from '@angular/core';

@Component({
  selector: 'optim-home-team-outlook',
  template: ``,
  standalone: true,
})
export class MockHomeTeamOutlookComponent {}
