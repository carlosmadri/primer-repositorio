import { Component } from '@angular/core';

@Component({
  selector: 'optim-workout-fte-location',
  template: ``,
  standalone: true,
})
export class MockWorkoutFteLocationComponent {}
