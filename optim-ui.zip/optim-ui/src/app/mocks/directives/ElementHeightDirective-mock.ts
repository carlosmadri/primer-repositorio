import { Directive, EventEmitter } from '@angular/core';

@Directive({
  selector: '[optimElementHeight]',
  standalone: true,
})
export class MockElementHeightDirective {
  heightChange = new EventEmitter<number>();

  constructor() {
    this.heightChange.emit(100);
  }
}
