import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubcontractingComponent } from './subcontracting.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { MockSubcontractingBarsGraphComponent } from '@src/app/mocks/components/subcontracting-bars-graph-mock.component';
import { MockSubcontractingBreakdownComponent } from '@src/app/mocks/components/subcontracting-breakdown-mock.component';
import { SubcontractingBreakdownComponent } from './components/subcontracting-breakdown/subcontracting-breakdown.component';
import { SubcontractingBarsGraphComponent } from './components/subcontracting-bars-graph/subcontracting-bars-graph.component';

describe('SubcontractingComponent', () => {
  let component: SubcontractingComponent;
  let fixture: ComponentFixture<SubcontractingComponent>;

  beforeEach(async () => {
    TestBed.overrideComponent(SubcontractingComponent, {
      remove: {
        imports: [SubcontractingBarsGraphComponent, SubcontractingBreakdownComponent],
      },
      add: {
        imports: [MockSubcontractingBarsGraphComponent, MockSubcontractingBreakdownComponent],
      },
    });
    await TestBed.configureTestingModule({
      imports: [SubcontractingComponent, MockSubcontractingBarsGraphComponent, MockSubcontractingBreakdownComponent, NoopAnimationsModule],
      providers: [provideHttpClient(withInterceptorsFromDi()), provideHttpClientTesting()],
    }).compileComponents();

    fixture = TestBed.createComponent(SubcontractingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
