import { ChangeDetectionStrategy, Component, computed, effect, inject, Signal, ViewChild } from '@angular/core';
import { MatIcon } from '@angular/material/icon';
import { MatMenuTrigger } from '@angular/material/menu';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { SubcontractingService } from '@src/app/services/subcontracting/subcontracting.service';
import { DonutChartComponent } from '@src/app/shared/graphs/donut-chart/donut-chart.component';
import { SubcontractingGraphs, SubcontractingKhrsPerQuarter } from '@src/app/shared/models/subcontracting.model';
import * as numberUtils from '@src/utils/number-utils';
import { MatMenuModule } from '@angular/material/menu';

@Component({
  selector: 'optim-subcontracting-breakdown',
  standalone: true,
  imports: [DonutChartComponent, MatIcon, MatMenuModule],
  templateUrl: './subcontracting-breakdown.component.html',
  styleUrl: './subcontracting-breakdown.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SubcontractingBreakdownComponent {
  @ViewChild(MatMenuTrigger) menuTrigger!: MatMenuTrigger;
  private filtersService: FiltersService = inject(FiltersService);
  private subcontractingService: SubcontractingService = inject(SubcontractingService);

  protected readonly graphsData: Signal<SubcontractingGraphs | null> = this.subcontractingService.graphs;

  colors = ['#0AAEC7', '#098FBA', '#fff'];

  constructor() {
    effect(() => {
      const params = this.filtersService.paramsFilter();
      this.loadData(params);
    });
  }

  async loadData(params?: string[]) {
    await this.subcontractingService.getSubcontractingGraphs(params);
  }

  totalProgress = computed(() => {
    const data = this.graphsData();
    const totalValue = ((data?.purchaseOrders ?? 0) + (data?.purchaseRequest ?? 0)) / (data?.baseline ?? 0);

    const totalValueNumber = isNaN(totalValue) ? 0 : numberUtils.roundToDecimalPlaces(totalValue * 100, 1);
    return `${totalValueNumber}%`;
  });

  graphDataFormatted = computed(() => {
    const data = this.graphsData();
    const pending = numberUtils.roundToDecimalPlaces(data?.baseline || 0 - (data?.purchaseOrders || 0) - (data?.purchaseRequest || 0), 1);
    const formattedData = {
      ...data,
      purchaseOrders: numberUtils.roundToDecimalPlaces(data?.purchaseOrders || 0, 1),
      purchaseRequest: numberUtils.roundToDecimalPlaces(data?.purchaseRequest || 0, 1),
      baseline: numberUtils.roundToDecimalPlaces(data?.baseline || 0, 1),
      pending: pending > 0 ? pending : 0,
      khrsPerQuarter: {
        purchaseNotAproved: this.formatKhrsPerQuarter(data?.khrsPerQuarter?.purchaseNotAproved || []),
      },
    };
    return formattedData;
  });

  private formatKhrsPerQuarter(data: SubcontractingKhrsPerQuarter[]): SubcontractingKhrsPerQuarter[] {
    return data.map((value) => ({ ...value, keus: numberUtils.roundToDecimalPlaces(value?.keur || 0, 1) }));
  }
}
