import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubcontractingBreakdownComponent } from './subcontracting-breakdown.component';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { SubcontractingService } from '@src/app/services/subcontracting/subcontracting.service';
import { signal } from '@angular/core';
import { SubcontractingGraphs } from '@src/app/shared/models/subcontracting.model';

describe('SubcontractingBreakdownComponent', () => {
  let component: SubcontractingBreakdownComponent;
  let fixture: ComponentFixture<SubcontractingBreakdownComponent>;
  let mockSubcontractingService: Partial<SubcontractingService>;
  let mockFiltersService: Partial<FiltersService>;

  beforeEach(async () => {
    mockSubcontractingService = {
      graphs: signal<SubcontractingGraphs | null>(null),
      getSubcontractingGraphs: jest.fn(),
    };

    mockFiltersService = {
      paramsFilter: signal<string[]>([]),
    };

    await TestBed.configureTestingModule({
      imports: [SubcontractingBreakdownComponent],
      providers: [
        { provide: SubcontractingService, useValue: mockSubcontractingService },
        { provide: FiltersService, useValue: mockFiltersService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(SubcontractingBreakdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
