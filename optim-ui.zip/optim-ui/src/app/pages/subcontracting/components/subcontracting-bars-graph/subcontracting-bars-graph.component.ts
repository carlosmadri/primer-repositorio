import { AfterViewInit, ChangeDetectionStrategy, Component, computed, ElementRef, inject, OnDestroy, OnInit, signal, Signal, ViewChild } from '@angular/core';
import { SubcontractingService } from '@src/app/services/subcontracting/subcontracting.service';
import { MultiColumnCharData, MultiColumnChartComponent, MultiColumnSerieData } from '@src/app/shared/graphs/multi-column-chart/multi-column-chart.component';
import { SubcontractingGraphs, SubcontractingKhrsPerQuarter } from '@src/app/shared/models/subcontracting.model';
import * as numberUtils from '@src/utils/number-utils';

@Component({
  selector: 'optim-subcontracting-bars-graph',
  standalone: true,
  imports: [MultiColumnChartComponent],
  templateUrl: './subcontracting-bars-graph.component.html',
  styleUrl: './subcontracting-bars-graph.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SubcontractingBarsGraphComponent implements OnInit, AfterViewInit, OnDestroy {
  private subcontractingService: SubcontractingService = inject(SubcontractingService);

  protected readonly graphsData: Signal<SubcontractingGraphs | null> = this.subcontractingService.graphs;

  @ViewChild('chart') chart?: ElementRef;
  chartElementHeight = signal(0);

  ngOnInit(): void {
    window.addEventListener('resize', this.onResize.bind(this));
  }

  ngOnDestroy(): void {
    window.removeEventListener('resize', this.onResize);
  }

  private onResize(): void {
    const containerHeight = this.chart?.nativeElement?.offsetHeight || 0;
    this.chartElementHeight.set(containerHeight);
  }

  ngAfterViewInit() {
    this.onResize();
  }

  chartData = computed<MultiColumnCharData | null>(() => {
    if (!this.graphsData() || !this.graphsData()!.khrsPerQuarter) {
      return null;
    }

    const approvedData: SubcontractingKhrsPerQuarter[] = this.graphsData()!.khrsPerQuarter.purchaseAproved || [];
    const notApprovedData: SubcontractingKhrsPerQuarter[] = this.graphsData()!.khrsPerQuarter.purchaseNotAproved || [];

    const approvedLabels: string[] = approvedData.map((data) => data.quarter);
    const notApprovedDataLabels: string[] = notApprovedData.map((data) => data.quarter);
    const allUniqueLabels: string[] = [...new Set([...approvedLabels, ...notApprovedDataLabels])];
    const sortedLabels = this.sortLabels(allUniqueLabels);

    const approvedDataForLabels = this.mapDataToLabels(sortedLabels, approvedData);
    const notApprovedDataForLabels = this.mapDataToLabels(sortedLabels, notApprovedData);

    const series: MultiColumnSerieData[] = [
      {
        name: 'Approved',
        data: approvedDataForLabels.map((data) => numberUtils.roundToDecimalPlaces(data.keur, 1)),
      },
      {
        name: 'Not approved',
        data: notApprovedDataForLabels.map((data) => numberUtils.roundToDecimalPlaces(data.keur, 1)),
      },
    ];

    const chartData: MultiColumnCharData = {
      labels: sortedLabels,
      series,
      colors: ['#00AEC7', '#FF6B6B'],
    };
    return chartData;
  });

  private sortLabels(labels: string[]): string[] {
    return labels.sort((a, b) => {
      const aQuarter = a.split('Q');
      const bQuarter = b.split('Q');
      if (aQuarter[1] === bQuarter[1]) {
        return Number(aQuarter[0]) - Number(bQuarter[0]);
      }
      return Number(aQuarter[1]) - Number(bQuarter[1]);
    });
  }

  private mapDataToLabels(labels: string[], sourceData: SubcontractingKhrsPerQuarter[]): SubcontractingKhrsPerQuarter[] {
    return labels.reduce((acc, label) => {
      const found = sourceData.find((d) => d.quarter === label);
      acc.push(found || { quarter: label, keur: 0 });
      return acc;
    }, [] as SubcontractingKhrsPerQuarter[]);
  }
}
