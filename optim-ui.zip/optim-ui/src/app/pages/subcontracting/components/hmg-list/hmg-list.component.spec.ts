import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HmgListComponent } from './hmg-list.component';
import { HelpContentService } from '@src/app/services/help/help-content.service';
import { of } from 'rxjs';
import { HgmList } from '@src/app/shared/models/help/hmg-list.model';

describe('HmgListComponent', () => {
  let component: HmgListComponent;
  let fixture: ComponentFixture<HmgListComponent>;
  let mockHelpContentService: Partial<HelpContentService>;

  beforeEach(async () => {
    mockHelpContentService = {
      loadHmgDefinitionsContent: () => of({} as HgmList),
    };

    await TestBed.configureTestingModule({
      imports: [HmgListComponent],
      providers: [{ provide: HelpContentService, useValue: mockHelpContentService }],
    }).compileComponents();

    fixture = TestBed.createComponent(HmgListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
