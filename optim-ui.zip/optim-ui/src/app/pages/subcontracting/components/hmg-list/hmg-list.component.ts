import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject, OnInit, signal } from '@angular/core';
import { HelpContentService } from '@src/app/services/help/help-content.service';
import { HgmList } from '@src/app/shared/models/help/hmg-list.model';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'optim-hmg-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './hmg-list.component.html',
  styleUrl: './hmg-list.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HmgListComponent implements OnInit {
  content = signal<HgmList | null>(null);

  private helpContentService = inject(HelpContentService);

  async ngOnInit() {
    const data: HgmList = await firstValueFrom(this.helpContentService.loadHmgDefinitionsContent());
    if (data) {
      this.content.set(data);
    }
  }
}
