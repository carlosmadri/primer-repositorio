import { ChangeDetectionStrategy, Component, inject, computed, effect } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';
import * as numberUtils from '@src/utils/number-utils';
import { MatMenu, MatMenuTrigger } from '@angular/material/menu';

@Component({
  selector: 'optim-workload-preview',
  standalone: true,
  imports: [MatIconModule, MatMenu, MatMenuTrigger],
  templateUrl: './workload-preview.component.html',
  styleUrl: './workload-preview.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkloadPreviewComponent {
  constructor() {
    effect(() => {
      const params = this.filtersService.paramsFilter();
      this.loadData(params);
    });
  }

  private filtersService: FiltersService = inject(FiltersService);
  private worksyncService: WorksyncService = inject(WorksyncService);

  protected readonly previewData = this.worksyncService.workloadPreview;

  async loadData(params?: string[]) {
    await this.worksyncService.getWorkloadPreview(params);
  }

  previewDataFormatted = computed(() => {
    const data = this.previewData();
    const formattedData = {
      ...data,
      khrs: numberUtils.roundToDecimalPlaces(data?.khrs || 0, 1),
      previsionkHrs: numberUtils.roundToDecimalPlaces(data?.previsionkHrs || 0, 1),
      fte: numberUtils.roundToDecimalPlaces(data?.fte || 0, 1),
      previsionFte: numberUtils.roundToDecimalPlaces(data?.previsionFte || 0, 1),
      realisticViewAVG: numberUtils.roundToDecimalPlaces(data?.realisticViewAVG || 0, 1),
      vlActualsEoY: numberUtils.roundToDecimalPlaces(data?.vlActualsEoY || 0, 1),
      hcmaxCelling: numberUtils.roundToDecimalPlaces(data?.hcmaxCelling || 0, 1),
    };
    return formattedData;
  });
}
