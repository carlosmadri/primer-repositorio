import { ChangeDetectionStrategy, Component, inject, signal, TemplateRef, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';
import { GenericDialogComponent } from '@src/app/shared/components/generic-dialog/generic-dialog.component';
import { SiglumSelectionComponent } from '@src/app/shared/components/siglum-selection/siglum-selection.component';
import { WorkloadUploadComponent } from '@src/app/shared/components/workload-upload/workload-upload.component';
import { WorkloadPostResponse } from '@src/app/shared/models/worksync.model';
import { take } from 'rxjs';

const DIALOG_CONFIG: MatDialogConfig = {
  panelClass: 'no-border-radius-dialog',
  minWidth: '40%',
  height: '70%',
  maxWidth: '100vw',
  maxHeight: '100vh',
};

const CONFIRM_CONFIG: MatDialogConfig = {
  panelClass: 'no-border-radius-dialog',
  height: '25%',
  maxWidth: '100vw',
  maxHeight: '100vh',
};

@Component({
  selector: 'optim-workload-submission',
  standalone: true,
  imports: [MatButtonModule, MatIconModule, SiglumSelectionComponent, WorkloadUploadComponent],
  templateUrl: './workload-submission.component.html',
  styleUrl: './workload-submission.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkloadSubmissionComponent {
  private filtersService: FiltersService = inject(FiltersService);
  private worksyncService: WorksyncService = inject(WorksyncService);
  protected readonly evolutionData = this.worksyncService.evolution;
  protected readonly canUpdate = this.worksyncService.canUpdate;
  protected readonly hasOpenExercise = this.worksyncService.hasOpenExercise;

  readonly dialog = inject(MatDialog);
  selectSiglumDialog: MatDialogRef<GenericDialogComponent, unknown> | undefined;
  uploadDialog: MatDialogRef<GenericDialogComponent, unknown> | undefined;
  reloadDialog: MatDialogRef<GenericDialogComponent, unknown> | undefined;

  @ViewChild('submitTemplate') submitTemplate!: TemplateRef<unknown>;
  @ViewChild('validateTemplate') validateTemplate!: TemplateRef<unknown>;
  @ViewChild('uploadTemplate') uploadTemplate!: TemplateRef<unknown>;
  @ViewChild('messageTemplate') messageTemplate!: TemplateRef<unknown>;

  modalMessage = signal<string>('');

  submissionCompleted(response: WorkloadPostResponse) {
    if (!response.error) {
      this.reloadDialog = this.openMessageDialog('Confirmation', 'Submission completed');
      this.reloadOnClose();
    } else {
      this.openMessageDialog('Error submitting', response.message);
    }
    this.selectSiglumDialog?.close();
  }

  validationCompleted(response: WorkloadPostResponse) {
    if (!response.error) {
      this.reloadDialog = this.openMessageDialog('Confirmation', 'Validation completed');
      this.reloadOnClose();
    } else {
      this.openMessageDialog('Error validating', response.message);
    }
    this.selectSiglumDialog?.close();
  }

  openSubmitDialog() {
    this.selectSiglumDialog = this.dialog.open(GenericDialogComponent, {
      ...DIALOG_CONFIG,
      data: {
        title: 'Submit teams',
        content: this.submitTemplate,
      },
    });
  }

  openValidateDialog() {
    this.selectSiglumDialog = this.dialog.open(GenericDialogComponent, {
      ...DIALOG_CONFIG,
      data: {
        title: 'Validate teams',
        content: this.validateTemplate,
      },
    });
  }

  openUploadDialog() {
    this.uploadDialog = this.dialog.open(GenericDialogComponent, {
      ...CONFIRM_CONFIG,
      data: {
        title: 'Confirm upload',
        content: this.uploadTemplate,
      },
    });
  }

  async uploadFile(file: File) {
    this.uploadDialog?.close();
    const userSelected = this.getUserSelected();
    if (userSelected) {
      const response: WorkloadPostResponse = await this.worksyncService.uploadWorkload(file, [userSelected]);
      if (!response.error) {
        this.reloadDialog = this.openMessageDialog('Confirmation', 'Import completed successfully');
        this.reloadOnClose();
      } else {
        this.openMessageDialog('Error importing', response.message);
      }
    }
  }

  async downloadFile() {
    const userSelected = this.getUserSelected();
    if (userSelected) {
      await this.worksyncService.getWorkloadExport([userSelected]);
    }
  }

  private openMessageDialog(title: string, message: string) {
    const dialog = this.dialog.open(GenericDialogComponent, {
      ...CONFIRM_CONFIG,
      data: {
        title: title,
        content: this.messageTemplate,
      },
    });
    this.modalMessage.set(message);
    return dialog;
  }

  private getUserSelected(): string {
    const filters = this.filtersService.paramsFilter();
    if (filters && filters.length > 0) {
      const userName = filters.find((filter) => filter.includes('userSelected'));
      return userName!;
    }
    return '';
  }

  private reloadOnClose() {
    this.reloadDialog!.afterClosed()
      .pipe(take(1))
      .subscribe(() => {
        this.reloadPage();
      });
  }

  private reloadPage() {
    this.filtersService.reloadData();
  }
}
