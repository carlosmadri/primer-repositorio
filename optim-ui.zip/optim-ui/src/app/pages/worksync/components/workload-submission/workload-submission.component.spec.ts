import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkloadSubmissionComponent } from './workload-submission.component';
import { signal } from '@angular/core';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { WorksyncService } from '@src/app/services/worksync/worksync.service';

describe('WorkloadSubmissionComponent', () => {
  let component: WorkloadSubmissionComponent;
  let fixture: ComponentFixture<WorkloadSubmissionComponent>;
  let mockWorksyncService: Partial<WorksyncService>;
  let mockFiltersService: Partial<FiltersService>;

  beforeEach(async () => {
    mockWorksyncService = {
      getWorkloadExport: jest.fn(),
      uploadWorkload: jest.fn(),
      canUpdate: signal<boolean>(true),
      hasOpenExercise: signal<boolean>(true),
    };

    mockFiltersService = {
      paramsFilter: signal<string[]>([]),
      reloadData: jest.fn(),
    };

    await TestBed.configureTestingModule({
      imports: [WorkloadSubmissionComponent],
      providers: [
        { provide: WorksyncService, useValue: mockWorksyncService },
        { provide: FiltersService, useValue: mockFiltersService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(WorkloadSubmissionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
