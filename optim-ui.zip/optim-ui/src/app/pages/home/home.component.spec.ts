import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeComponent } from './home.component';
import { MockWorkoutMonthlyDistributionComponent } from '@src/app/mocks/components';
import { MockWorkloadEvolutionComponent } from '@src/app/mocks/components/workload-evolution-mock.component';
import { WorkloadEvolutionComponent } from '../worksync/components/workload-evolution/workload-evolution.component';
import { WorkoutMonthlyDistributionComponent } from '../workout/components/workout-monthly-distribution/workout-monthly-distribution.component';
import { HomeTeamOutlookComponent } from './components/home-team-outlook/home-team-outlook.component';
import { MockHomeTeamOutlookComponent } from '@src/app/mocks/components/home-team-outlook-mock.component';
import { SubcontractingBreakdownComponent } from '../subcontracting/components/subcontracting-breakdown/subcontracting-breakdown.component';
import { MockSubcontractingBreakdownComponent } from '@src/app/mocks/components/subcontracting-breakdown-mock.component';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(async () => {
    TestBed.overrideComponent(HomeComponent, {
      remove: {
        imports: [WorkloadEvolutionComponent, WorkoutMonthlyDistributionComponent, HomeTeamOutlookComponent, SubcontractingBreakdownComponent],
      },
      add: {
        imports: [MockWorkloadEvolutionComponent, MockWorkoutMonthlyDistributionComponent, MockHomeTeamOutlookComponent, MockSubcontractingBreakdownComponent],
      },
    });
    await TestBed.configureTestingModule({
      imports: [
        HomeComponent,
        MockHomeTeamOutlookComponent,
        MockWorkoutMonthlyDistributionComponent,
        MockWorkloadEvolutionComponent,
        MockSubcontractingBreakdownComponent,
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
