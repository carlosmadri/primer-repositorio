import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeTeamOutlookComponent } from './home-team-outlook.component';
import { TeamOutlookService } from '@src/app/services/team-outlook/team-outlook.service';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { TeamOutlook, TeamOutlookWorkload } from '@src/app/shared/models/team-outlook.model';
import { signal, WritableSignal } from '@angular/core';

describe('HomeTeamOutlookComponent', () => {
  let component: HomeTeamOutlookComponent;
  let fixture: ComponentFixture<HomeTeamOutlookComponent>;
  let mockTeamOutlookService: Partial<TeamOutlookService>;
  let mockFiltersService: Partial<FiltersService>;

  const mockTeamOutlook: TeamOutlook = {
    fteTotalValue: 1369.72,
    fteNAWF: 80.32,
    leaversSummary: [
      { title: 'Leavers', value: -97 },
      { title: 'Redeployment', value: -3 },
      { title: 'Recoveries', value: 40 },
      { title: 'Perimeter Changes', value: 0 },
    ],
    jrSummary: [
      { title: 'Filled', value: 20 },
      { title: 'Opened', value: 12 },
      { title: 'Validation Process', value: 40 },
      { title: 'On Hold', value: 350 },
    ],
    eoySummary: [
      { title: 'Realistic View', value: 1341.7, increase: false },
      { title: 'Validation View', value: 1381.7, increase: true },
    ],
    avgSummary: [
      { title: 'Realistic View Average', value: 111.75 },
      { title: 'Validation View Average', value: 115.08 },
    ],
    hcCeiling: 1350,
  };

  const mockTeamOutlookWorkload: TeamOutlookWorkload = {
    current: 115.5,
    lastExerciseName: 'Previous Exercise',
    lastExerciseKhrs: 110.2,
    hcCeilingFormerRefference: 1300,
    exerciseType: 'op',
  };

  beforeEach(async () => {
    mockTeamOutlookService = {
      teamOutlook: signal<TeamOutlook | null>(null),
      teamOutlookWorkload: signal<TeamOutlookWorkload | null>(null),
      getTeamOutlook: jest.fn(),
      getTeamOutlookWorkload: jest.fn(),
    };

    mockFiltersService = {
      paramsFilter: signal<string[]>([]),
    };
    await TestBed.configureTestingModule({
      imports: [HomeTeamOutlookComponent],
      providers: [
        { provide: TeamOutlookService, useValue: mockTeamOutlookService },
        { provide: FiltersService, useValue: mockFiltersService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(HomeTeamOutlookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    jest.clearAllMocks();
    (mockFiltersService.paramsFilter as WritableSignal<string[]>).set([]);
    (mockTeamOutlookService.teamOutlook as WritableSignal<TeamOutlook | null>).set(null);
    (mockTeamOutlookService.teamOutlookWorkload as WritableSignal<TeamOutlookWorkload | null>).set(null);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('filteredTeamOutlookData', () => {
    beforeEach(() => {
      (mockTeamOutlookService.teamOutlook as WritableSignal<TeamOutlook | null>).set(mockTeamOutlook);
      (mockTeamOutlookService.teamOutlookWorkload as WritableSignal<TeamOutlookWorkload | null>).set(mockTeamOutlookWorkload);
      fixture.detectChanges();
    });

    it('should sum all the the positive levers data as recoveries and rest the negative as leavers correctly', () => {
      const result = component.filteredTeamOutlookData();

      expect(result?.leaversSummary).toEqual([
        { title: 'Leavers', value: -100 }, // Sum of Leavers (-97) and Redeployment (-3)
        { title: 'Recoveries', value: 40 },
      ]);
    });

    it('should return null when teamOutlook is null', () => {
      (mockTeamOutlookService.teamOutlook as WritableSignal<TeamOutlook | null>).set(null);
      fixture.detectChanges();

      const result = component.filteredTeamOutlookData();

      expect(result).toBeNull();
    });

    it('should return null when teamOutlookWorkload is null', () => {
      (mockTeamOutlookService.teamOutlookWorkload as WritableSignal<TeamOutlookWorkload | null>).set(null);
      fixture.detectChanges();

      const result = component.filteredTeamOutlookData();

      expect(result).toBeNull();
    });

    it('should only include Leavers and Recoveries in leaversSummary', () => {
      const result = component.filteredTeamOutlookData();

      expect(result?.leaversSummary.length).toBe(2);
      expect(result?.leaversSummary.every((item) => ['Leavers', 'Recoveries'].includes(item.title))).toBeTruthy();
    });

    it('should round workload values to 1 decimal place', () => {
      const result = component.filteredTeamOutlookData();

      expect(result?.current).toBe(115.5);
      expect(result?.lastExerciseKhrs).toBe(110.2);
      expect(result?.hcCeilingFormerRefference).toBe(1300.0);
    });
  });
});
