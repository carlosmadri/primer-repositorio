import { NgClass } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { TeamOutlookService } from '@src/app/services/team-outlook/team-outlook.service';
import { TeamOutlook, TeamOutlookHome } from '@src/app/shared/models/team-outlook.model';
import * as numberUtils from '@src/utils/number-utils';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'optim-home-team-outlook',
  standalone: true,
  imports: [NgClass, MatIconModule, MatButtonModule, MatMenuModule],
  templateUrl: './home-team-outlook.component.html',
  styleUrl: './home-team-outlook.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HomeTeamOutlookComponent {
  private teamOutlookService: TeamOutlookService = inject(TeamOutlookService);
  private filtersService: FiltersService = inject(FiltersService);

  protected readonly teamOutlookData = this.teamOutlookService.teamOutlook;
  protected readonly teamOutlookWorkloadData = this.teamOutlookService.teamOutlookWorkload;

  constructor() {
    effect(() => {
      const params = this.filtersService.paramsFilter();
      this.teamOutlookService.getTeamOutlook(params);
      this.teamOutlookService.getTeamOutlookWorkload(params);
    });
  }

  filteredTeamOutlookData = computed<TeamOutlookHome | null>(() => {
    const data = this.teamOutlookData();
    const dataWorkload = this.teamOutlookWorkloadData();
    if (!data || !dataWorkload) {
      return null;
    }

    const newData = { ...data };

    newData.leaversSummary = [
      { title: 'Leavers', value: this.calculateLeavers(data) },
      { title: 'Recoveries', value: this.calculateRecoveries(data) },
    ];

    newData.jrSummary = data.jrSummary.filter((jr) => jr.title !== 'On Hold') || [];
    newData.eoySummary = data.eoySummary.slice(0, 2) || [];
    newData.avgSummary = data.avgSummary.slice(0, 2) || [];

    const fullData = {
      ...newData,
      ...dataWorkload,
      current: numberUtils.roundToDecimalPlaces(dataWorkload.current || 0, 1),
      lastExerciseKhrs: numberUtils.roundToDecimalPlaces(dataWorkload.lastExerciseKhrs || 0, 1),
      hcCeilingFormerRefference: numberUtils.roundToDecimalPlaces(dataWorkload.hcCeilingFormerRefference || 0, 1),
    };
    return fullData;
  });

  private calculateLeavers(data: TeamOutlook) {
    return data.leaversSummary.reduce((acc, curr) => acc + (curr.value < 0 ? curr.value : 0), 0);
  }

  private calculateRecoveries(data: TeamOutlook) {
    return data.leaversSummary.reduce((acc, curr) => acc + (curr.value > 0 ? curr.value : 0), 0);
  }
}
