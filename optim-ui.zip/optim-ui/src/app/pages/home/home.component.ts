import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { WorkloadEvolutionComponent } from '../worksync/components/workload-evolution/workload-evolution.component';
import { WorkoutMonthlyDistributionComponent } from '../workout/components/workout-monthly-distribution/workout-monthly-distribution.component';
import { ChartSelectorComponent } from '@src/app/shared/components/chart-selector/chart-selector.component';
import { HomeTeamOutlookComponent } from './components/home-team-outlook/home-team-outlook.component';
import { SubcontractingBreakdownComponent } from '../subcontracting/components/subcontracting-breakdown/subcontracting-breakdown.component';
import { MatDialogModule } from '@angular/material/dialog';

@Component({
  selector: 'optim-home',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [
    CommonModule,
    WorkloadEvolutionComponent,
    WorkoutMonthlyDistributionComponent,
    ChartSelectorComponent,
    HomeTeamOutlookComponent,
    SubcontractingBreakdownComponent,
    MatDialogModule,
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
})
export class HomeComponent {}
