import { NgClass } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, effect, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenu, MatMenuTrigger } from '@angular/material/menu';
import { FiltersService } from '@app/services/filters/filters.service';
import { TeamOutlookService } from '@app/services/team-outlook/team-outlook.service';
import * as numberUtils from '@src/utils/number-utils';

@Component({
  selector: 'optim-workout-team-outlook',
  standalone: true,
  imports: [NgClass, MatIconModule, MatMenu, MatMenuTrigger, MatButtonModule],
  templateUrl: './workout-team-outlook.component.html',
  styleUrl: './workout-team-outlook.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkoutTeamOutlookComponent {
  private teamOutlookService: TeamOutlookService = inject(TeamOutlookService);
  private filtersService: FiltersService = inject(FiltersService);

  protected readonly teamOutlookData = this.teamOutlookService.teamOutlook;
  protected readonly teamOutlookWorkloadData = this.teamOutlookService.teamOutlookWorkload;

  constructor() {
    effect(() => {
      const params = this.filtersService.paramsFilter();
      this.teamOutlookService.getTeamOutlook(params);
      this.teamOutlookService.getTeamOutlookWorkload(params);
    });
  }

  hcCeilingFormerRef = computed<number>(() => {
    const dataWorkload = this.teamOutlookWorkloadData();
    return numberUtils.roundToDecimalPlaces(dataWorkload!.hcCeilingFormerRefference || 0, 1);
  });
}
