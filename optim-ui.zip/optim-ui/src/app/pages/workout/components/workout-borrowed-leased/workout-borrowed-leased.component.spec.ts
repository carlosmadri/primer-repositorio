import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WorkoutBorrowedLeasedComponent } from './workout-borrowed-leased.component';
import { NO_ERRORS_SCHEMA, signal, WritableSignal } from '@angular/core';
import { FiltersService } from '@src/app/services/filters/filters.service';
import { EmployeeService } from '@src/app/services/employee/employee.service';
import { BorrowedLeased } from '@src/app/shared/models/borrowed-leased.model';
import { ElementHeightDirective } from '@src/app/shared/directives/element-height.directive';
import { MultilineChartComponent } from '@src/app/shared/graphs/multiline-chart/multiline-chart.component';
import { MockElementHeightDirective } from '@src/app/mocks/directives/ElementHeightDirective-mock';

describe('WorkoutBorrowedLeasedComponent', () => {
  let component: WorkoutBorrowedLeasedComponent;
  let fixture: ComponentFixture<WorkoutBorrowedLeasedComponent>;
  let mockEmployeeService: Partial<EmployeeService>;
  let mockFiltersService: Partial<FiltersService>;
  let mockBorrowedLeasedData: WritableSignal<BorrowedLeased | null>;
  let mockParamsFilter: WritableSignal<string[]>;

  beforeEach(async () => {
    mockBorrowedLeasedData = signal<BorrowedLeased | null>(null);
    mockParamsFilter = signal<string[]>([]);

    mockEmployeeService = {
      borrowedData: mockBorrowedLeasedData,
      getBorrowedLeased: jest.fn(),
    };

    mockFiltersService = {
      paramsFilter: mockParamsFilter,
    };

    TestBed.overrideComponent(WorkoutBorrowedLeasedComponent, {
      remove: {
        imports: [MultilineChartComponent, ElementHeightDirective],
      },
      add: {
        imports: [MultilineChartComponent, MockElementHeightDirective],
      },
    });

    await TestBed.configureTestingModule({
      imports: [WorkoutBorrowedLeasedComponent, MultilineChartComponent, MockElementHeightDirective],
      providers: [
        { provide: EmployeeService, useValue: mockEmployeeService },
        { provide: FiltersService, useValue: mockFiltersService },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(WorkoutBorrowedLeasedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    jest.clearAllMocks();
    mockParamsFilter.set([]);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getBorrowedLeased on initialization', () => {
    expect(mockEmployeeService.getBorrowedLeased).toHaveBeenCalledWith([]);
  });

  it('should react to changes in paramsFilter', () => {
    mockParamsFilter.set(['param1', 'param2']);

    fixture.detectChanges();

    expect(mockEmployeeService.getBorrowedLeased).toHaveBeenCalledWith(['param1', 'param2']);
  });
});
