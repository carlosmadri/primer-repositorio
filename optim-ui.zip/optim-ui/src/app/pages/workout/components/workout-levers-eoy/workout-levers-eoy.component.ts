import { ChangeDetectionStrategy, Component, computed, effect, inject, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { FiltersService } from '@app/services/filters/filters.service';
import { LeversService } from '@app/services/levers/levers.service';
import { ElementHeightDirective } from '@src/app/shared/directives/element-height.directive';
import { StackedBarsComponent } from '@src/app/shared/graphs/stacked-bars/stacked-bars.component';

@Component({
  selector: 'optim-workout-levers-eoy',
  standalone: true,
  imports: [MatButtonModule, StackedBarsComponent, ElementHeightDirective],
  templateUrl: './workout-levers-eoy.component.html',
  styleUrl: './workout-levers-eoy.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkoutLeversEoyComponent {
  private leversService: LeversService = inject(LeversService);
  private filtersService: FiltersService = inject(FiltersService);

  chartElementHeight = signal(0);

  protected readonly totalByEoY = this.leversService.totalByEoY;

  constructor() {
    effect(() => {
      const params = this.filtersService.paramsFilter();
      this.leversService.getTotalByEoY(params);
    });
  }

  onResize(newHeight: number): void {
    this.chartElementHeight.set(newHeight);
  }

  sortedTotalByEoY = computed(() => {
    return this.totalByEoY().sort((a, b) => a.leverType.localeCompare(b.leverType));
  });
}
