import { ChangeDetectionStrategy, Component, computed, inject, OnInit, Signal, signal, TemplateRef, ViewChild, WritableSignal } from '@angular/core';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatButton } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatOptionModule } from '@angular/material/core';
import { MatDatepickerInputEvent, MatDatepickerModule } from '@angular/material/datepicker';
import { MAT_DIALOG_DATA, MatDialog, MatDialogActions, MatDialogClose, MatDialogConfig, MatDialogContent, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIcon } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { LocationService } from '@src/app/services/location/location.service';
import { Location } from '@models/location.model';
import { SiglumService } from '@src/app/services/siglum/siglum.service';
import {
  JobRequest,
  JobRequestApprovalState,
  JobRequestCollarType,
  JobRequestForm,
  JobRequestStatus,
  JobRequestType,
  JobRequestWorkerType,
} from '@src/app/shared/models/job-request.model';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { JobRequestService } from '@src/app/services/job-request/job-request.service';
import { DialogService } from '@src/app/services/dialog-service/dialog.service';
import { ManageJobRequestService } from '@src/app/services/job-request/manage-job-request.service';
import { GenericDialogComponent } from '@src/app/shared/components/generic-dialog/generic-dialog.component';
import { SelectEmployeeTableComponent } from '@src/app/tables/select-employee-table/select-employee-table.component';
import { DIRECT_INDIRECT_VALUES, Employee } from '@src/app/shared/models/employee.model';
import { CostCenterService } from '@src/app/services/cost-center/cost-center.service';
import { CostCenter } from '@src/app/shared/models/cost-center.model';

const WORKDAY_LINK = 'https://wd3.myworkday.com/ag/d/home.html';

const DIALOG_CONFIG: MatDialogConfig = {
  panelClass: 'no-border-radius-dialog',
  width: '600px',
  height: '90%',
  maxWidth: '100vw',
  maxHeight: '100vh',
};

@Component({
  selector: 'optim-job-request-dialog',
  standalone: true,
  imports: [
    MatDialogClose,
    MatDialogContent,
    MatButton,
    MatIcon,
    MatDialogActions,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatOptionModule,
    MatSelectModule,
    ReactiveFormsModule,
    MatChipsModule,
    MatDatepickerModule,
    MatSlideToggleModule,
    SelectEmployeeTableComponent,
  ],
  templateUrl: './job-request-dialog.component.html',
  styleUrl: './job-request-dialog.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class JobRequestDialogComponent implements OnInit {
  private siglumService = inject(SiglumService);
  private locationService = inject(LocationService);
  private jobRequestService = inject(JobRequestService);
  private dialogService = inject(DialogService);
  private dialogRef = inject(MatDialogRef<JobRequestDialogComponent>);
  private manageJobRequestService = inject(ManageJobRequestService);
  private costCenterService = inject(CostCenterService);

  @ViewChild('employeeTemplate') employeeTemplate!: TemplateRef<unknown>;

  copyCurrentDialog: MatDialogRef<GenericDialogComponent, unknown> | undefined;

  dialogParams = inject<{ jobRequest?: JobRequest; employee?: Employee }>(MAT_DIALOG_DATA);
  editJobRequestData: JobRequest | undefined = this.dialogParams?.jobRequest;
  employeeToCopy: Employee | undefined = this.dialogParams?.employee;

  readonly dialog = inject(MatDialog);

  locations: Signal<Location[]> = this.locationService.allLocations;
  costCenters = this.costCenterService.allCostCenters;

  countryOptions = signal<string[]>([]);
  siteOptions = signal<string[]>([]);
  kapisCodeOptions = signal<string[]>([]);
  costCenterOptions = signal<string[]>([]);

  allSiglums = this.siglumService.allSiglums;
  readonly today = new Date();

  isEdit = signal<boolean>(false);
  jobRequest = signal<JobRequest | null>(this.editJobRequestData || null);
  jrStatus = computed(() => this.jobRequest()?.status || '');

  jrTypesOptions: string[] = Object.values(JobRequestType).sort();
  jrDirectOptions: string[] = Object.values(DIRECT_INDIRECT_VALUES).sort();
  jrWorkerTypeOptions: string[] = Object.values(JobRequestWorkerType).sort();
  jrCollarTypeOptions: string[] = Object.values(JobRequestCollarType).sort();

  requiredFieldError = 'This field is required';
  workdayNumberFormat = 'Format: ######## (8 digits)';

  form = signal<FormGroup<JobRequestForm> | null>(null);

  JobRequestStatus: typeof JobRequestStatus = JobRequestStatus;

  displayApprovalStepOnEdit: JobRequestApprovalState = {
    approvedQMC: false,
    approvedSHRBPHOT1Q: false,
    approvedHOCOOHOHRCOO: false,
    approvedEmploymentCommitee: false,
  };

  async ngOnInit() {
    if (this.costCenters().length === 0) {
      await this.costCenterService.getAllCostCenters();
    }
    if (this.editJobRequestData) {
      const editForm = this.getEditForm();
      this.initForm(editForm);
    } else {
      const newForm = this.manageJobRequestService.getFormGroup();
      this.initForm(newForm);
      if (this.employeeToCopy) {
        this.copyEmployee(this.employeeToCopy);
      }
    }
  }

  initForm(form: FormGroup<JobRequestForm>) {
    if (form) {
      this.form.set(form);
      this.initLocationValues();
    }
  }

  getEditForm(): FormGroup<JobRequestForm> {
    this.isEdit.set(true);
    this.displayApprovalStepOnEdit = this.manageJobRequestService.setApprovalStep(this.displayApprovalStepOnEdit, this.editJobRequestData!);

    return this.manageJobRequestService.getFormGroup(this.editJobRequestData);
  }

  initLocationValues() {
    const countryOptions = this.getCountryOptions();
    this.countryOptions.set(countryOptions);
    const siteOptions = this.getSiteOptions();
    this.siteOptions.set(siteOptions);
    const kapisCodeOptions = this.getKapisCodeOptions();
    this.kapisCodeOptions.set(kapisCodeOptions);
    const costCenterOptions = this.getCostCenterOptions();
    this.costCenterOptions.set(costCenterOptions);
  }

  onWorkerTypeChange() {
    const workType = this.form()!.controls['activeWorkforce'].getRawValue();
    this.manageJobRequestService.setWorkTypeDependentFields(this.form as WritableSignal<FormGroup<JobRequestForm>>, workType!, this.jobRequest());
  }

  onCountryChange() {
    this.form()!.controls['site'].setValue(null);
    this.form()!.controls['kapisCode'].setValue(null);
    this.form()!.controls['costCenter'].setValue(null);
    this.siteOptions.set(this.getSiteOptions());
    this.kapisCodeOptions.set(this.getKapisCodeOptions());
    this.costCenterOptions.set(this.getCostCenterOptions());
  }

  onSiteChange() {
    this.form()!.controls['kapisCode'].setValue(null);
    this.form()!.controls['costCenter'].setValue(null);
    this.kapisCodeOptions.set(this.getKapisCodeOptions());
    this.costCenterOptions.set(this.getCostCenterOptions());
  }

  onKapisCodeChange() {
    const selectedCountry = this.form()!.controls['country'].getRawValue();
    const selectedSite = this.form()!.controls['site'].getRawValue();
    const selectedKapis = this.form()!.controls['kapisCode'].getRawValue();
    if (selectedKapis && (!selectedCountry || !selectedSite)) {
      this.setValuesForKapisCode();
      this.countryOptions.set(this.getCountryOptions());
      this.siteOptions.set(this.getSiteOptions());
      this.kapisCodeOptions.set(this.getKapisCodeOptions());
      this.costCenterOptions.set(this.getCostCenterOptions());
    } else {
      this.form()!.controls['costCenter'].setValue(null);
      this.costCenterOptions.set(this.getCostCenterOptions());
    }
  }

  getCountryOptions(): string[] {
    return this.manageJobRequestService.getUniqueSortedCountries(this.locations());
  }

  getSiteOptions(): string[] {
    const locations: Location[] = this.locations();
    const selectedCountry = this.form()!.controls['country'].getRawValue();
    let sitesList: string[] = [];
    if (selectedCountry) {
      sitesList = this.manageJobRequestService.getUniqueSortedSitesForCountry(locations, selectedCountry);
    }
    if (sitesList.length === 1 && this.form()!.controls['site']?.value === null) {
      this.form()!.controls['site']?.setValue(sitesList[0]);
    }
    return sitesList;
  }

  getKapisCodeOptions(): string[] {
    const locations: Location[] = this.locations();
    const selectedCountry = this.form()!.controls['country'].getRawValue();
    const selectedSite = this.form()!.controls['site'].getRawValue();
    const filteredLocations = this.manageJobRequestService.getFilteredLocations(locations, selectedCountry!, selectedSite!);
    const kapisCodes = this.manageJobRequestService.getUniqueSortedKapisCodes(filteredLocations);

    if (kapisCodes.length === 1 && this.form()!.controls['kapisCode']?.value === null) {
      this.form()!.controls['kapisCode']?.setValue(kapisCodes[0]);
    }
    return kapisCodes;
  }

  getCostCenterOptions() {
    const costCenters: CostCenter[] = this.costCenters();
    const locations: Location[] = this.locations();
    const selectedSite = this.form()!.controls['site'].getRawValue();
    const selectedKapis = this.form()!.controls['kapisCode'].getRawValue();
    let costCentersList: string[] = [];
    if (selectedKapis && selectedSite) {
      const locationsWithSelectedSiteAndKapisCode = locations?.filter((location) => location.site === selectedSite && location.kapisCode === selectedKapis);
      costCentersList = this.manageJobRequestService.getUniqueSortedCostCenterForLocationId(costCenters, locationsWithSelectedSiteAndKapisCode) || [];
    } else if (selectedKapis) {
      const locationsWithSelectedKapisCode = locations?.filter((location) => location.kapisCode === selectedKapis);
      costCentersList = this.manageJobRequestService.getUniqueSortedCostCenterForLocationId(costCenters, locationsWithSelectedKapisCode) || [];
    } else if (selectedSite) {
      const locationsWithSelectedSite = locations?.filter((location) => location.site === selectedSite);
      costCentersList = this.manageJobRequestService.getUniqueSortedCostCenterForLocationId(costCenters, locationsWithSelectedSite) || [];
    }
    if (costCentersList.length === 1 && this.form()!.controls['costCenter']?.value === null) {
      this.form()!.controls['costCenter']?.setValue(costCentersList[0]);
    }
    return costCentersList;
  }

  setValuesForKapisCode() {
    this.manageJobRequestService.setValuesForKapisCode(this.form as Signal<FormGroup<JobRequestForm>>, this.locations(), this.costCenters());
  }

  save() {
    if (this.form() && this.checkFormValidity()) {
      const jobRequest: JobRequest = this.manageJobRequestService.getFormData(
        this.form as Signal<FormGroup<JobRequestForm>>,
        this.isEdit(),
        this.locations(),
        this.costCenters(),
      );
      this.saveJobRequest(jobRequest);
    }
  }

  submit() {
    if (this.form() && this.checkFormValidity()) {
      const jobRequest: JobRequest = this.manageJobRequestService.getFormData(
        this.form as Signal<FormGroup<JobRequestForm>>,
        this.isEdit(),
        this.locations(),
        this.costCenters(),
      );
      jobRequest.status = JobRequestStatus.VALIDATION;
      this.saveJobRequest(jobRequest);
    }
  }

  private checkFormValidity(): boolean {
    if (this.form()!.invalid) {
      this.form()!.markAllAsTouched();
      return false;
    }
    return true;
  }

  async saveJobRequest(jr: JobRequest) {
    try {
      let result: JobRequest;
      if (this.isEdit()) {
        result = await this.jobRequestService.updateJobRequest(jr, jr.id.toString());
      } else {
        result = await this.jobRequestService.createJobRequest(jr);
      }
      this.dialogRef.close({ jobRequest: result, delete: false });
    } catch (error) {
      console.error('Error creating job request:', error);
      this.dialogService.openMessageDialog(`Couldn't ${this.isEdit() ? 'edit' : 'add'} new Job Request`, `Please check the form and try again.`, 'warning');
    }
  }

  delete() {
    this.dialogRef.close({ jobRequest: this.jobRequest(), delete: true });
  }

  formatDateValue(formControl: string, event: MatDatepickerInputEvent<Date>) {
    this.form()!.get(formControl)!.setValue(event.value!.toISOString());
  }

  openWorkday() {
    window.open(WORKDAY_LINK, '_blank');
  }

  openCopyCurrent() {
    this.copyCurrentDialog = this.dialog.open(GenericDialogComponent, {
      ...DIALOG_CONFIG,
      data: {
        title: 'Select an employee to copy from',
        content: this.employeeTemplate,
      },
    });
  }

  copyEmployee(employee: Employee) {
    this.copyCurrentDialog?.close();
    if (this.form()) {
      const form = this.manageJobRequestService.setFormValuesForEmployee(employee, this.form as WritableSignal<FormGroup<JobRequestForm>>);
      this.initForm(form);
    }
  }
}
